# GridCons Figure 1 web-upload export provenance · architecture-matched v2

## Repair summary

- Repair: Panel D now uses the architecture-matched `dynamic_delta_consistency` arm.
- Baseline arm: `dynamic_delta`; parameterization: `content_delta`.
- GridCons arm: `dynamic_delta_consistency`; parameterization: `content_delta`.
- Architecture matched: `true`; parameterization matched: `true`.
- Panel title retained: `Dynamic Mamba + GridCons · seed 17`.
- No training, backward pass, optimizer step, tuning, post-processing, or DualGrid-Sup access occurred during repair.

## Case and frozen selection

- Anonymous case ID: `hippocampus_104`.
- Split: frozen Task04 40-case `confirm_test`.
- Display seed: `17`.
- Selection rule: mean baseline `dynamic_delta` R2 prediction consistency over two foreground classes × five frozen seeds; ascending order; numeric-median tie resolved to the lower mean, then case ID.
- Central pair: `hippocampus_104` (0.43660489255471202) and `hippocampus_394` (0.43957627937102906); median `0.43809058596287054`; selected mean `0.43660489255471202`.
- GridCons improvement was not used for case or slice selection.

## Slice, geometry, crop, window, and display

- Axial slice index: `15` (zero-based R1 D); physical RAS z: `16.000000 mm`.
- Slice rule: unique maximum R1 foreground-label area, `326` voxels.
- R1 spacing D×H×W: `[1.0, 1.0, 1.0]` mm; R2 spacing: `[2.0, 1.0, 1.0]` mm.
- Crop `[Y0:Y1, X0:X1)`: `[13:48, 0:35)`; physical voxel-center XYZ bounds `[1.0, 14.0, 16.0]` to `[35.0, 48.0, 16.0]` mm.
- Intensity window for all medical panels: `[-1.9459309577941895, 1.557874321937561]` cached R1 z-score units.
- Panel D uses the same R1 background, physical crop, window, contour renderer, and disagreement definition as Panel C.
- Disagreement: exact voxelwise multiclass inequality `R1 argmax != aligned R2 argmax`; no smoothing, filtering, dilation, or enlargement.
- A/B/C and `method_strip.svg` are byte-identical to v1.

## Frozen metric cross-validation

| Arm | Parameterization | Class | Frozen | Recomputed | Absolute error |
|---|---|---|---:|---:|---:|
| dynamic_delta_consistency | content_delta | anterior | 0.85851998865891688 | 0.85851998865891688 | 0 |
| dynamic_delta_consistency | content_delta | posterior | 0.85706680862390205 | 0.85706680862390205 | 0 |

- Exact decimal mean before frozen 16-place serialization: `0.85779339864140945`.
- Stored class mean (16 decimal places, half-even): `0.8577933986414094`.
- Recomputed class mean using the same serialization: `0.8577933986414094`.
- Maximum absolute metric error: `0`; acceptance tolerance: `1e-12`; result: **PASS**.
- Baseline seed-17 frozen class values remain `[0.5039123630672926, 0.5622305260132222]`; class mean `0.53307144454025734`.

## Checkpoint and original evaluation implementation

- Checkpoint: `/home/yanjingjia/gridcons_followup_20260720/01_task04_control_matrix/checkpoints/dynamic_delta_consistency_seed17.pt`.
- SHA-256: `ed6d99b911c21db81c882ab471281db42069a44b991208cad3a2a2ec8b814684`; matches confirm release, control evaluation, training log, and task `SHA256SUMS`.
- Checkpoint metadata: arm `dynamic_delta_consistency`, seed `17`, selected update `1750`, protocol hash `cb9bb07adce731318a102f9688be66e4c9772bb138770b901b92fe716f8b7c14`.
- Parameterization verification: frozen `build_model(dynamic_delta_consistency)` binds to `TinyMetricMamba(content_delta)`; strict state-dict load passed, while a strict non-content parameterization load was rejected.
- Forward/mapping implementation: frozen `control_matrix.predict` with BF16 autocast; native R2 probabilities mapped channel-wise by frozen `run_gate.map_probability` using affine order-1 interpolation, clipping, channel renormalization, then argmax.
- Device: `NVIDIA PG506-230`; PyTorch `2.2.2+cu121`; CUDA build `12.1`; two forward passes took `3.650477` seconds wall time.
- Training log is cited only as frozen provenance (`completed=True`); no training entrypoint was invoked.

## Prediction bundle

- Keys: `['baseline_r1_probability', 'baseline_r2_aligned_probability', 'baseline_r2_native_probability', 'dynamic_gridcons_r1_probability', 'dynamic_gridcons_r2_aligned_probability', 'dynamic_gridcons_r2_native_probability']`.
- The three v1 `baseline_*` arrays are byte-for-byte numerically unchanged.
- Erroneous `gridcons_*` arrays were removed and replaced by `dynamic_gridcons_*` arrays from the architecture-matched arm.
- Predictions are raw frozen softmax probability arrays (native or physically aligned as named); no post-processing was applied.

## Source and prediction SHA-256

| Artifact | Path | SHA-256 |
|---|---|---|
| raw image NIfTI | `/home/yanjingjia/data/Task04_Hippocampus/imagesTr/hippocampus_104.nii.gz` | `903e8d996687dc8b96685a00e7d2604df669c982c15b34b950fac490ee28133e` |
| raw label NIfTI | `/home/yanjingjia/data/Task04_Hippocampus/labelsTr/hippocampus_104.nii.gz` | `34b761d10da73c1493a7bec67c23158d16a6e54e54b3d6da4da61227f56139c6` |
| R1 image cache | `/home/yanjingjia/metric_mamba_gate/cache/hippocampus_104/R1_image.npy` | `8e15c970d13cfcfcc54ce8f9c09d5597c72625abe35ce98afdc33d76a9b0097c` |
| R2 image cache | `/home/yanjingjia/metric_mamba_gate/cache/hippocampus_104/R2_image.npy` | `f0ec171fea63fa9053328a5ca45f9ac46199a45d7ef0cecc94704a8b2b731c6a` |
| R1 label cache | `/home/yanjingjia/metric_mamba_gate/cache/hippocampus_104/R1_label.npy` | `dbd430a31ee7c4e8a3acf58324dbce54816799bac3de202cc5fa660ba9e1675d` |
| R2 label cache | `/home/yanjingjia/metric_mamba_gate/cache/hippocampus_104/R2_label.npy` | `f3576639d3f4b0c06074172489c4d9f440ebd91500ba54145daf46d32ab3ae4e` |
| frozen baseline metrics | `/home/yanjingjia/grid_stable_mamba_probe/outputs/paired_full/metrics.csv` | `067d3e94b87ebfd7febe21d208a22eb15d1444acc7ecc4b1e7cba464f5533368` |
| frozen control metrics | `/home/yanjingjia/gridcons_followup_20260720/01_task04_control_matrix/metrics.csv` | `9989d289c34e5f6214ace7d2145d3521b6a805f7d6e1d173a445ac778b75844d` |
| control protocol manifest | `/home/yanjingjia/gridcons_followup_20260720/01_task04_control_matrix/CONTROL_PROTOCOL_PRETRAINING.json` | `31e50c04b386f90b36c03095ff7c16e5035ecc509ecdf0f4ab3c059728768436` |
| control evaluation manifest | `/home/yanjingjia/gridcons_followup_20260720/01_task04_control_matrix/evaluation.json` | `792038df9de46720ceefdac19ac599c2b31af41a57d1e0d8bd2394cfde6df1b1` |
| confirm manifest | `/home/yanjingjia/grid_stable_mamba_probe/outputs/paired_full/confirm_manifest.json` | `ae909321483b277a216011d73c1cdc730d809d795cc656af4d3a2a0a4a891d96` |
| baseline checkpoint | `/home/yanjingjia/metric_mamba_gate/outputs/checkpoints/t1_seed17.pt` | `b0b8d30d666b7aa3d6443355d75b0176461eb10b092bacf1a738e28bcf086826` |
| architecture-matched GridCons checkpoint | `/home/yanjingjia/gridcons_followup_20260720/01_task04_control_matrix/checkpoints/dynamic_delta_consistency_seed17.pt` | `ed6d99b911c21db81c882ab471281db42069a44b991208cad3a2a2ec8b814684` |
| saved predictions | `/home/yanjingjia/GridCons_Figure1_WebUpload_v2/predictions_seed17.npz` | `572ee68637682aab6de8222ce22c547b74ea9d08d5450a5da29d77d2be9c79c1` |

## Rendered artifact SHA-256

| Artifact | SHA-256 |
|---|---|
| panel_A_R1.png | `14cfcf7d7310947d0b8505e1c14b0ce4ef60b00338705dd21a777b8196f2effa` |
| panel_B_R2.png | `2a9cccf4c7cca17fbea637886b01d3b3e2d40f3930d49d24e647f6d03c59126d` |
| panel_C_baseline_drift.png | `b43755ef801529dbdf341c6f5a0f8c1c7e35616e7876a9387ba207be72d2583b` |
| panel_D_gridcons.png | `ea52d3db39d43e8ea9ca818991b6d8ba117ea3d42515605c7802791ab3bbc9f6` |
| figure1_contact_sheet.png | `b1e21c68b291892e7b3515df2bed9f65d27efb938076448df84b7e1e6c2191a4` |
| method_strip.svg | `28731d1b221b7745334f798599493f4e7d1c44c0f5bc5b37a1b10ddc899f9ad8` |

## Integrity declarations

- Generative medical pixels: `false`.
- Labels or predictions edited: `false`.
- Training run during repair: `false`.
- DualGrid-Sup results read or used: `false`.
- Patient identity displayed: `false`.
