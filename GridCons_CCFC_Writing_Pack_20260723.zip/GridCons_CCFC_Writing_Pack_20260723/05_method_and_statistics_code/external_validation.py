#!/usr/bin/env python
"""Frozen five-fold external validation on official MSD Task09_Spleen."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import random
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

sys.dont_write_bytecode = True

import nibabel as nib
import numpy as np
import torch
from nibabel.processing import resample_from_to
from scipy import ndimage
from torch import nn
from torch.nn import functional as F


ROOT = Path(__file__).resolve().parent
DATA = Path("/home/yanjingjia/data/Task09_Spleen")
ORIGINAL = Path("/home/yanjingjia/grid_stable_mamba_probe")
OLD_ROOT = Path("/home/yanjingjia/metric_mamba_gate")
PROMPT2 = Path("/home/yanjingjia/gridcons_followup_20260720/01_task04_control_matrix")
sys.path.insert(0, str(ORIGINAL))
from model import TinyMetricMamba, parameter_count  # noqa: E402


TASK = "T2_EXTERNAL_REAL_SPACING_VALIDATION"
ARMS = ("dynamic_delta", "static_delta", "gridcons_mamba")
SEEDS = (17, 29, 41)
FOLDS = tuple(range(5))
CONSISTENCY_ARM = "gridcons_mamba"
UPDATES = 2500
VALIDATE_EVERY = 250
CONSISTENCY_WEIGHT = 0.1
WARMUP_UPDATES = 500
SPLIT_SEED = 20260720
BOOTSTRAP_SEED = 7301
BOOTSTRAP_SAMPLES = 10_000
PATCH_DHW = (24, 96, 96)
ROI_HW = 256
BODY_THRESHOLD_HU = -500.0
INTENSITY_CLIP_HU = (-1000.0, 1000.0)
DATA_GATE = ROOT / "DATA_GATE.json"
FOLDS_PATH = ROOT / "FOLDS.json"
PREPROCESSING_PATH = ROOT / "PREPROCESSING.json"
DRY_RUN_PATH = ROOT / "GPU_DRY_RUN.json"
PROTOCOL_PATH = ROOT / "EXTERNAL_PROTOCOL_PRETRAINING.json"
TEST_RESULTS_PATH = ROOT / "TEST_RESULTS.json"
RELEASE_PATH = ROOT / "OUTER_TEST_RELEASE.json"
METRICS_PATH = ROOT / "metrics.csv"
CODE_FILES = (
    "data_gate.py",
    "external_validation.py",
    "external_statistics.py",
    "test_external_validation.py",
    "reproduce_external.sh",
)
EXPECTED_TESTS = {
    "data_gate_and_real_spacing",
    "five_fold_partition_and_label_isolation",
    "model_shape_and_finite",
    "physical_affine_mapping",
    "zero_consistency_equals_supervised",
}


def now() -> str:
    return datetime.now().astimezone().isoformat()


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def load_json(path: Path) -> dict:
    return json.loads(path.read_text())


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def object_hash(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def internal_hash(value: dict, field: str) -> str:
    return object_hash({key: item for key, item in value.items() if key != field})


def append_jsonl(path: Path, value: dict) -> None:
    with path.open("a") as handle:
        handle.write(json.dumps(value, sort_keys=True, allow_nan=False) + "\n")


def code_hashes() -> dict[str, str]:
    missing = [name for name in CODE_FILES if not (ROOT / name).is_file()]
    if missing:
        raise RuntimeError(f"missing frozen source files: {missing}")
    return {name: sha256(ROOT / name) for name in CODE_FILES}


def source_hashes() -> dict[str, str]:
    paths = {
        "original_model.py": ORIGINAL / "model.py",
        "original_run_probe.py": ORIGINAL / "run_probe.py",
        "original_run_paired_full.py": ORIGINAL / "run_paired_full.py",
        "original_metric_gate.py": OLD_ROOT / "run_gate.py",
        "prompt2_control_matrix.py": PROMPT2 / "control_matrix.py",
        "prompt2_control_statistics.py": PROMPT2 / "control_statistics.py",
        "prompt2_results": PROMPT2 / "CONTROL_RESULTS.json",
        "prompt2_sha256sums": PROMPT2 / "SHA256SUMS",
    }
    return {name: sha256(path) for name, path in paths.items()}


def dataset_pairs() -> dict[str, tuple[Path, Path]]:
    dataset = load_json(DATA / "dataset.json")
    pairs = {}
    for item in dataset["training"]:
        image = DATA / item["image"].removeprefix("./")
        label = DATA / item["label"].removeprefix("./")
        identifier = image.name.removesuffix(".nii.gz")
        if identifier in pairs or not image.is_file() or not label.is_file():
            raise RuntimeError(f"invalid dataset pair: {identifier}")
        pairs[identifier] = image, label
    return pairs


def audit_rows() -> dict[str, dict]:
    with (ROOT / "SPACING_AUDIT.csv").open() as handle:
        return {row["case_id"]: row for row in csv.DictReader(handle)}


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def build_model(arm: str) -> TinyMetricMamba:
    if arm not in ARMS:
        raise ValueError(f"unknown arm: {arm}")
    parameterization = "content_delta" if arm == "dynamic_delta" else "separated_physical_delta"
    model = TinyMetricMamba(parameterization)
    model.out = nn.Conv3d(12, 2, 1)
    return model


def loss_fn(logits: torch.Tensor, label: torch.Tensor) -> torch.Tensor:
    probabilities = logits.softmax(1)
    one_hot = F.one_hot(label, 2).movedim(-1, 1).float()
    dims = (0, 2, 3, 4)
    intersection = (probabilities[:, 1:] * one_hot[:, 1:]).sum(dims)
    denominator = probabilities[:, 1:].sum(dims) + one_hot[:, 1:].sum(dims)
    dice_loss = 1.0 - ((2.0 * intersection + 1e-5) / (denominator + 1e-5)).mean()
    return 0.5 * dice_loss + 0.5 * F.cross_entropy(logits, label)


def forward_logits(model: TinyMetricMamba, image: torch.Tensor, spacing_dhw: list[float]) -> torch.Tensor:
    spacing = torch.tensor([spacing_dhw], device=image.device, dtype=torch.float32)
    return model(image, spacing)


def shifted_affine(affine_xyz: np.ndarray, start_dhw: tuple[int, int, int] | list[int]) -> np.ndarray:
    transform = np.eye(4, dtype=np.float64)
    transform[:3, 3] = [start_dhw[2], start_dhw[1], start_dhw[0]]
    return np.asarray(affine_xyz, dtype=np.float64) @ transform


def physical_grid(
    source_shape_dhw: tuple[int, int, int] | list[int],
    source_affine_xyz: np.ndarray,
    target_shape_dhw: tuple[int, int, int] | list[int],
    target_affine_xyz: np.ndarray,
    device: torch.device,
) -> torch.Tensor:
    d, h, w = (int(value) for value in target_shape_dhw)
    z, y, x = torch.meshgrid(
        torch.arange(d, device=device, dtype=torch.float32),
        torch.arange(h, device=device, dtype=torch.float32),
        torch.arange(w, device=device, dtype=torch.float32),
        indexing="ij",
    )
    target_xyz = torch.stack((x, y, z, torch.ones_like(x)), -1)
    matrix = torch.as_tensor(
        np.linalg.inv(np.asarray(source_affine_xyz)) @ np.asarray(target_affine_xyz),
        device=device,
        dtype=torch.float32,
    )
    source = target_xyz @ matrix.T
    sd, sh, sw = (int(value) for value in source_shape_dhw)

    def normalize(value: torch.Tensor, size: int) -> torch.Tensor:
        return torch.zeros_like(value) if size == 1 else 2.0 * value / (size - 1) - 1.0

    return torch.stack((normalize(source[..., 0], sw), normalize(source[..., 1], sh), normalize(source[..., 2], sd)), -1)[None]


def map_probability_torch(
    source_probability: torch.Tensor,
    source_affine_xyz: np.ndarray,
    target_shape_dhw: tuple[int, int, int] | list[int],
    target_affine_xyz: np.ndarray,
) -> torch.Tensor:
    grid = physical_grid(source_probability.shape[2:], source_affine_xyz, target_shape_dhw, target_affine_xyz, source_probability.device)
    mapped = F.grid_sample(source_probability.float(), grid, mode="bilinear", padding_mode="zeros", align_corners=True)
    total = mapped.sum(1, keepdim=True)
    mapped[:, :1] += (1.0 - total).clamp_min(0.0)
    return mapped / mapped.sum(1, keepdim=True).clamp_min(1e-7)


def physical_consistency_loss(
    native_logits: torch.Tensor,
    paired_logits: torch.Tensor,
    native_affine_xyz: np.ndarray,
    paired_affine_xyz: np.ndarray,
) -> torch.Tensor:
    teacher = native_logits.float().softmax(1)[:, 1:].detach()
    student = map_probability_torch(
        paired_logits.float().softmax(1), paired_affine_xyz, native_logits.shape[2:], native_affine_xyz
    )[:, 1:]
    dims = (0, 2, 3, 4)
    intersection = (teacher * student).sum(dims)
    denominator = teacher.square().sum(dims) + student.square().sum(dims)
    return 1.0 - ((2.0 * intersection + 1e-5) / (denominator + 1e-5)).mean()


def batch_loss(
    model: TinyMetricMamba,
    native_image: torch.Tensor,
    native_label: torch.Tensor,
    native_spacing_dhw: list[float],
    native_affine_xyz: np.ndarray,
    paired_image: torch.Tensor | None,
    paired_spacing_dhw: list[float] | None,
    paired_affine_xyz: np.ndarray | None,
    consistency_weight: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor | None]:
    native_logits = forward_logits(model, native_image, native_spacing_dhw)
    segmentation = loss_fn(native_logits, native_label)
    if consistency_weight == 0.0:
        return segmentation, segmentation, None
    if paired_image is None or paired_spacing_dhw is None or paired_affine_xyz is None:
        raise ValueError("paired image geometry is required for non-zero consistency")
    paired_logits = forward_logits(model, paired_image, paired_spacing_dhw)
    consistency = physical_consistency_loss(native_logits, paired_logits, native_affine_xyz, paired_affine_xyz)
    return segmentation + consistency_weight * consistency, segmentation, consistency


def binary_dice(prediction: np.ndarray, label: np.ndarray) -> float:
    denominator = int(prediction.sum()) + int(label.sum())
    return 1.0 if denominator == 0 else 2.0 * float(np.logical_and(prediction, label).sum()) / denominator


def surface_dice_2mm(prediction: np.ndarray, label: np.ndarray, spacing_dhw: list[float]) -> float:
    if not prediction.any() and not label.any():
        return 1.0
    if not prediction.any() or not label.any():
        return 0.0
    structure = ndimage.generate_binary_structure(3, 1)
    pred_surface = prediction ^ ndimage.binary_erosion(prediction, structure=structure, border_value=0)
    label_surface = label ^ ndimage.binary_erosion(label, structure=structure, border_value=0)
    to_prediction = ndimage.distance_transform_edt(~pred_surface, sampling=spacing_dhw)
    to_label = ndimage.distance_transform_edt(~label_surface, sampling=spacing_dhw)
    numerator = int((to_label[pred_surface] <= 2.0).sum()) + int((to_prediction[label_surface] <= 2.0).sum())
    return numerator / (int(pred_surface.sum()) + int(label_surface.sum()))


def make_folds(case_ids: list[str], spacings_xyz: dict[str, list[float]]) -> dict:
    shuffled = np.asarray(sorted(case_ids))[np.random.default_rng(SPLIT_SEED).permutation(len(case_ids))]
    test_folds = [list(map(str, values)) for values in np.array_split(shuffled, 5)]
    records = []
    for fold, outer_test in enumerate(test_folds):
        outer_pool = sorted(set(case_ids) - set(outer_test))
        order = np.random.default_rng(SPLIT_SEED + fold + 1).permutation(len(outer_pool))
        validation_count = int(math.ceil(0.2 * len(outer_pool)))
        validation = sorted(outer_pool[index] for index in order[:validation_count])
        train = sorted(set(outer_pool) - set(validation))
        target = np.median(np.asarray([spacings_xyz[item] for item in outer_pool]), axis=0)

        def severity(identifier: str) -> float:
            return float(np.linalg.norm(np.log(np.asarray(spacings_xyz[identifier]) / target)))

        threshold = float(np.quantile([severity(item) for item in outer_pool], 0.75))
        records.append(
            {
                "fold": fold,
                "train": train,
                "validation": validation,
                "outer_test": sorted(outer_test),
                "outer_train_all": outer_pool,
                "target_spacing_xyz": target.tolist(),
                "target_spacing_source": "componentwise median of this fold's outer-train headers",
                "severe_spacing_definition": "log-spacing distance from fold target >= outer-train 75th percentile",
                "severe_spacing_threshold": threshold,
                "outer_test_metadata": {
                    item: {"severity_score": severity(item), "severe_spacing": severity(item) >= threshold}
                    for item in sorted(outer_test)
                },
            }
        )
    value = {
        "version": 1,
        "split_seed": SPLIT_SEED,
        "selection": "sorted 41 IDs; one numpy.default_rng(20260720) permutation; numpy.array_split into five outer tests; fold-specific deterministic 20% inner validation",
        "case_ids": sorted(case_ids),
        "folds": records,
    }
    value["fold_hash"] = internal_hash(value, "fold_hash")
    return value


def validate_folds(value: dict) -> None:
    if value.get("fold_hash") != internal_hash(value, "fold_hash") or len(value.get("folds", [])) != 5:
        raise RuntimeError("fold manifest hash/count mismatch")
    case_ids = set(value["case_ids"])
    seen = []
    for record in value["folds"]:
        train, validation, test = map(set, (record["train"], record["validation"], record["outer_test"]))
        if train & validation or train & test or validation & test or train | validation | test != case_ids:
            raise RuntimeError(f"fold {record['fold']} is not case-disjoint/exhaustive")
        seen.extend(test)
    if sorted(seen) != sorted(case_ids) or len(seen) != len(case_ids):
        raise RuntimeError("each case must appear in exactly one outer-test")


def body_box(image_xyz: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    components, count = ndimage.label(image_xyz > BODY_THRESHOLD_HU)
    if count == 0:
        raise RuntimeError("body mask is empty")
    sizes = np.bincount(components.ravel())
    sizes[0] = 0
    points = np.where(components == sizes.argmax())
    return np.asarray([axis.min() for axis in points]), np.asarray([axis.max() + 1 for axis in points])


def prepare_native(identifier: str, image_path: Path) -> dict:
    image = nib.as_closest_canonical(nib.load(image_path))
    if nib.aff2axcodes(image.affine) != ("R", "A", "S") or image.ndim != 3:
        raise RuntimeError(f"{identifier}: canonical image is not 3D RAS")
    raw = np.asarray(image.dataobj, dtype=np.float32)
    lower, upper = body_box(raw)
    x_start = int(np.clip(lower[0], 0, raw.shape[0] - ROI_HW))
    y_start = int(np.clip(round((lower[1] + upper[1] - ROI_HW) / 2), 0, raw.shape[1] - ROI_HW))
    normalized = np.clip(raw, *INTENSITY_CLIP_HU) / max(abs(value) for value in INTENSITY_CLIP_HU)
    roi = normalized[x_start : x_start + ROI_HW, y_start : y_start + ROI_HW, :].transpose(2, 1, 0).astype(np.float32)
    if roi.shape[1:] != (ROI_HW, ROI_HW) or not np.isfinite(roi).all():
        raise RuntimeError(f"{identifier}: invalid image-only ROI")
    cache = ROOT / "cache" / "images" / "native" / f"{identifier}.npy"
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.save(cache, roi)
    affine = shifted_affine(np.asarray(image.affine), (0, y_start, x_start))
    spacing_xyz = np.linalg.norm(affine[:3, :3], axis=0)
    return {
        "image_path": str(image_path),
        "image_path_sha256": sha256(image_path),
        "cache": str(cache),
        "cache_sha256": sha256(cache),
        "shape_dhw": list(roi.shape),
        "affine_xyz": affine.tolist(),
        "spacing_dhw": spacing_xyz[::-1].tolist(),
        "source_shape_xyz": list(image.shape),
        "source_affine_xyz": np.asarray(image.affine).tolist(),
        "source_spacing_dhw": np.asarray(image.header.get_zooms()[:3])[::-1].astype(float).tolist(),
        "roi_start_xyz": [x_start, y_start, 0],
        "body_bbox_xyz": [lower.tolist(), upper.tolist()],
        "roi_rule": "RAS: first 256 voxels from image-derived body left bound; 256 voxels centered on body AP; complete native z",
    }


def prepare_paired(identifier: str, fold: int, native: dict, target_spacing_xyz: list[float]) -> dict:
    native_array = np.load(native["cache"], mmap_mode="r")
    source_shape_xyz = np.asarray(native_array.shape[::-1], dtype=int)
    source_affine = np.asarray(native["affine_xyz"], dtype=np.float64)
    source_spacing = np.linalg.norm(source_affine[:3, :3], axis=0)
    direction = source_affine[:3, :3] / source_spacing
    target_spacing = np.asarray(target_spacing_xyz, dtype=np.float64)
    extent = (source_shape_xyz - 1) * source_spacing
    target_shape_xyz = np.ceil(extent / target_spacing).astype(int) + 1
    target_affine = source_affine.copy()
    target_affine[:3, :3] = direction * target_spacing
    source_image = nib.Nifti1Image(np.asarray(native_array).transpose(2, 1, 0), source_affine)
    result = resample_from_to(source_image, (tuple(target_shape_xyz), target_affine), order=1, mode="constant", cval=-1.0)
    paired = np.asarray(result.dataobj, dtype=np.float32).transpose(2, 1, 0)
    if not np.isfinite(paired).all():
        raise RuntimeError(f"{identifier}/fold{fold}: invalid paired image")
    cache = ROOT / "cache" / "images" / f"fold{fold}" / "paired" / f"{identifier}.npy"
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.save(cache, paired)
    return {
        "cache": str(cache),
        "cache_sha256": sha256(cache),
        "shape_dhw": list(paired.shape),
        "affine_xyz": target_affine.tolist(),
        "spacing_dhw": target_spacing[::-1].tolist(),
        "label_cache": None,
        "source": "same-case normalized native image resampled in physical coordinates; no paired label created",
    }


def prepare_images(folds: dict) -> dict:
    pairs = dataset_pairs()
    native = {}
    for number, identifier in enumerate(sorted(pairs), 1):
        native[identifier] = prepare_native(identifier, pairs[identifier][0])
        print(f"prepared native image {number}/{len(pairs)} {identifier}", flush=True)
    paired = {}
    for record in folds["folds"]:
        fold = int(record["fold"])
        paired[str(fold)] = {}
        for number, identifier in enumerate(sorted(pairs), 1):
            paired[str(fold)][identifier] = prepare_paired(identifier, fold, native[identifier], record["target_spacing_xyz"])
            print(f"prepared paired image fold{fold} {number}/{len(pairs)} {identifier}", flush=True)
    value = {
        "version": 1,
        "image_only": True,
        "labels_read_or_cached": False,
        "native": native,
        "paired": paired,
        "patch_dhw": list(PATCH_DHW),
        "roi_hw": ROI_HW,
        "intensity_normalization": f"clip HU to {INTENSITY_CLIP_HU}; divide by 1000",
        "fold_hash": folds["fold_hash"],
    }
    value["preprocessing_hash"] = internal_hash(value, "preprocessing_hash")
    return value


def validate_preprocessing(value: dict, folds: dict) -> None:
    if value.get("preprocessing_hash") != internal_hash(value, "preprocessing_hash"):
        raise RuntimeError("preprocessing manifest hash mismatch")
    if value.get("fold_hash") != folds["fold_hash"] or value.get("labels_read_or_cached") is not False:
        raise RuntimeError("preprocessing provenance mismatch")
    if set(value["native"]) != set(folds["case_ids"]):
        raise RuntimeError("native preprocessing case mismatch")
    for fold in FOLDS:
        if set(value["paired"][str(fold)]) != set(folds["case_ids"]):
            raise RuntimeError(f"paired preprocessing case mismatch fold {fold}")
        if any(item.get("label_cache") is not None for item in value["paired"][str(fold)].values()):
            raise RuntimeError("paired label cache is forbidden")


def extract_padded(array: np.ndarray, start_dhw: list[int] | tuple[int, int, int], shape_dhw: list[int] | tuple[int, int, int], cval: float) -> np.ndarray:
    output = np.full(tuple(shape_dhw), cval, dtype=np.asarray(array).dtype)
    source_slices, target_slices = [], []
    for start, size, available in zip(start_dhw, shape_dhw, array.shape):
        source_start, source_end = max(0, start), min(available, start + size)
        target_start = source_start - start
        source_slices.append(slice(source_start, source_end))
        target_slices.append(slice(target_start, target_start + max(0, source_end - source_start)))
    output[tuple(target_slices)] = array[tuple(source_slices)]
    return output


def paired_patch(
    paired_image: np.ndarray,
    native_start_dhw: list[int],
    native_meta: dict,
    paired_meta: dict,
) -> tuple[np.ndarray, list[float], np.ndarray]:
    native_affine = np.asarray(native_meta["affine_xyz"])
    paired_affine = np.asarray(paired_meta["affine_xyz"])
    native_patch_affine = shifted_affine(native_affine, native_start_dhw)
    native_spacing = np.asarray(native_meta["spacing_dhw"])
    paired_spacing = np.asarray(paired_meta["spacing_dhw"])
    shape = np.ceil((np.asarray(PATCH_DHW) - 1) * native_spacing / paired_spacing).astype(int) + 1
    native_center_xyz = np.asarray([(PATCH_DHW[2] - 1) / 2, (PATCH_DHW[1] - 1) / 2, (PATCH_DHW[0] - 1) / 2, 1.0])
    world_center = native_patch_affine @ native_center_xyz
    paired_center_xyz = np.linalg.inv(paired_affine) @ world_center
    shape_xyz = shape[::-1]
    start_xyz = np.floor(paired_center_xyz[:3] - (shape_xyz - 1) / 2).astype(int)
    start_dhw = start_xyz[::-1].tolist()
    patch = extract_padded(paired_image, start_dhw, shape.tolist(), -1.0).astype(np.float32)
    return patch, paired_spacing.tolist(), shifted_affine(paired_affine, start_dhw)


def dry_run(preprocessing: dict, folds: dict) -> dict:
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for the mandatory dry-run")
    combinations = []
    for record in folds["folds"]:
        target_dhw = np.asarray(record["target_spacing_xyz"])[::-1]
        for identifier in folds["case_ids"]:
            native_dhw = np.asarray(preprocessing["native"][identifier]["spacing_dhw"])
            shape = np.ceil((np.asarray(PATCH_DHW) - 1) * native_dhw / target_dhw).astype(int) + 1
            combinations.append((int(np.prod(shape)), identifier, int(record["fold"]), shape.tolist(), native_dhw.tolist(), target_dhw.tolist()))
    _, identifier, fold, paired_shape, native_spacing, paired_spacing = max(combinations)
    device = torch.device("cuda:0")
    seed_all(17)
    model = build_model(CONSISTENCY_ARM).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-5)
    x1 = torch.zeros((1, 1, *PATCH_DHW), device=device)
    x2 = torch.zeros((1, 1, *paired_shape), device=device)
    y = torch.zeros((1, *PATCH_DHW), dtype=torch.long, device=device)
    y[:, :, PATCH_DHW[1] // 3 : 2 * PATCH_DHW[1] // 3, PATCH_DHW[2] // 3 : 2 * PATCH_DHW[2] // 3] = 1
    a1 = np.diag([native_spacing[2], native_spacing[1], native_spacing[0], 1.0])
    a2 = np.diag([paired_spacing[2], paired_spacing[1], paired_spacing[0], 1.0])
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    optimizer.zero_grad(set_to_none=True)
    with torch.autocast("cuda", dtype=torch.bfloat16):
        loss, _, _ = batch_loss(model, x1, y, native_spacing, a1, x2, paired_spacing, a2, CONSISTENCY_WEIGHT)
    loss.backward()
    optimizer.step()
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    peak_allocated = int(torch.cuda.max_memory_allocated())
    peak_reserved = int(torch.cuda.max_memory_reserved())
    total = int(torch.cuda.get_device_properties(device).total_memory)
    finite = bool(torch.isfinite(loss) and all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None))
    jobs = min(6, max(1, int(total * 0.72 // max(peak_reserved, 1))))
    value = {
        "completed_at": now(),
        "selected_batch_size": 1,
        "selected_patch_dhw": list(PATCH_DHW),
        "selection_basis": "full native 512x512 volumes exceed the source model regime; one pre-test worst-header gridcons forward/backward",
        "worst_case_id_by_paired_patch_voxels": identifier,
        "worst_fold": fold,
        "native_spacing_dhw": native_spacing,
        "paired_spacing_dhw": paired_spacing,
        "paired_patch_dhw": paired_shape,
        "loss": float(loss),
        "finite": finite,
        "seconds": elapsed,
        "peak_allocated_bytes": peak_allocated,
        "peak_reserved_bytes": peak_reserved,
        "gpu_total_bytes": total,
        "recommended_parallel_jobs": jobs,
        "gpu": torch.cuda.get_device_name(device),
    }
    if not finite or peak_reserved >= total * 0.8:
        raise RuntimeError(f"mandatory GPU dry-run failed: {value}")
    value["dry_run_hash"] = internal_hash(value, "dry_run_hash")
    return value


def protocol_hash(value: dict) -> str:
    return internal_hash(value, "protocol_hash")


def setup() -> None:
    gate = load_json(DATA_GATE)
    if gate.get("status") != "PASS_EXTERNAL_DATA_GATE" or not gate.get("training_allowed"):
        raise RuntimeError("external data gate is not PASS_EXTERNAL_DATA_GATE")
    if PROTOCOL_PATH.exists():
        verify_protocol()
        print(f"frozen protocol exists: {load_json(PROTOCOL_PATH)['protocol_hash']}")
        return
    rows = audit_rows()
    spacings = {identifier: [float(rows[identifier][f"spacing_{axis}"]) for axis in "xyz"] for identifier in rows}
    folds = make_folds(sorted(rows), spacings)
    validate_folds(folds)
    dump_json(FOLDS_PATH, folds)
    with (ROOT / "FOLDS.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=("case_id", "fold", "role"))
        writer.writeheader()
        for record in folds["folds"]:
            for role in ("train", "validation", "outer_test"):
                for identifier in record[role]:
                    writer.writerow({"case_id": identifier, "fold": record["fold"], "role": role})
    preprocessing = prepare_images(folds)
    validate_preprocessing(preprocessing, folds)
    dump_json(PREPROCESSING_PATH, preprocessing)
    gpu = dry_run(preprocessing, folds)
    dump_json(DRY_RUN_PATH, gpu)
    value = {
        "task": TASK,
        "frozen_at": now(),
        "prerequisites": {
            "data_gate_path": str(DATA_GATE),
            "data_gate_status": gate["status"],
            "data_gate_sha256": sha256(DATA_GATE),
            "prompt2_root": str(PROMPT2),
            "prompt2_status": gate["prompt2"]["status"],
            "prompt2_read_only": True,
        },
        "scientific_scope": {
            "INDEPENDENT_DATASET": True,
            "REAL_HETEROGENEOUS_SPACING": True,
            "SYNTHETIC_PAIRED_GRID_ON_EXTERNAL_DATA": False,
            "engineering_runnable": None,
            "scientific_effect_pass": None,
        },
        "dataset": {
            "name": "MSD Task09_Spleen",
            "labeled_cases": 41,
            "input_channels": 1,
            "output_classes": 2,
            "labels": {"0": "background", "1": "spleen"},
            "challenge_test_used": False,
        },
        "folds": {
            "path": str(FOLDS_PATH),
            "sha256": sha256(FOLDS_PATH),
            "fold_hash": folds["fold_hash"],
            "outer_folds": 5,
            "each_case_outer_test_once_per_seed": True,
            "inner_validation": "fixed ceil(20%) of each outer-train; never used for training updates",
            "target_spacing": "componentwise outer-train header median, frozen separately per fold",
        },
        "preprocessing": {
            "path": str(PREPROCESSING_PATH),
            "sha256": sha256(PREPROCESSING_PATH),
            "preprocessing_hash": preprocessing["preprocessing_hash"],
            "native_view": "image-only fixed RAS ROI on original affine and spacing; complete native z",
            "paired_view": "same physical ROI resampled to fold target spacing; image only",
            "alignment": "affine physical-coordinate grid_sample for training; nibabel affine resampling for evaluation",
            "intensity": preprocessing["intensity_normalization"],
            "crop": "image-derived body ROI followed by non-label-driven uniform patches",
            "patch_dhw": list(PATCH_DHW),
            "batch_size": 1,
            "labels": "native view only; paired labels are never created",
        },
        "gpu_dry_run": {"path": str(DRY_RUN_PATH), "sha256": sha256(DRY_RUN_PATH), **gpu},
        "arms": {
            "dynamic_delta": "source TinyMetricMamba content_delta; supervised native view only",
            "static_delta": "source TinyMetricMamba separated_physical_delta; supervised native view only",
            "gridcons_mamba": "same static-delta model plus physical paired-grid consistency",
        },
        "training": {
            "seeds": list(SEEDS),
            "runs": 45,
            "updates": UPDATES,
            "validation_every": VALIDATE_EVERY,
            "optimizer": "AdamW",
            "learning_rate": 3e-4,
            "weight_decay": 1e-5,
            "amp": "bfloat16",
            "loss": "0.5*foreground soft Dice + 0.5*cross entropy",
            "augmentation": "none",
            "checkpoint_selection": "strictly highest inner-validation native-grid foreground Dice; earliest tie",
        },
        "consistency": {
            "paired_view_label_free": True,
            "native_teacher_stop_gradient": True,
            "loss": "foreground squared-denominator soft Dice after affine physical mapping",
            "weight": CONSISTENCY_WEIGHT,
            "linear_warmup_updates": WARMUP_UPDATES,
        },
        "outer_test_release": "only after current code/protocol, tests, all 45 checkpoints, and training logs validate",
        "evaluation": {
            "primary": "gridcons_mamba - dynamic_delta paired prediction consistency",
            "primary_requirements": "mean > 0; native-grid Dice difference >= -0.01; hierarchical CI lower bound > 0",
            "secondary": "gridcons_mamba - static_delta",
            "metrics": ["prediction consistency", "native-grid Dice", "mapped Dice", "surface Dice@2mm"],
            "severe_spacing": "per-fold outer-train 75th percentile log-spacing distance threshold",
            "bootstrap": {"kind": "hierarchical paired case-and-seed", "samples": BOOTSTRAP_SAMPLES, "seed": BOOTSTRAP_SEED},
            "all_five_outer_folds_reported": True,
        },
        "final_status_rule": {
            "PASS_EXTERNAL_SCIENTIFIC": "all evidence valid and all three primary requirements pass",
            "FAIL_EXTERNAL_SCIENTIFIC": "complete valid evidence but at least one primary requirement fails",
            "BLOCKED_EXTERNAL_DATA_GATE": "data gate failure before training",
            "BLOCKED_EXTERNAL_ENGINEERING": "missing, leaked, drifted, or incomplete engineering evidence",
        },
        "model_parameters": {arm: parameter_count(build_model(arm)) for arm in ARMS},
        "code_sha256": code_hashes(),
        "source_sha256": source_hashes(),
        "environment": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "nibabel": nib.__version__,
            "pytorch": torch.__version__,
            "cuda": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(0),
            "gpu_total_bytes": torch.cuda.get_device_properties(0).total_memory,
            "command": str(ROOT / "reproduce_external.sh"),
        },
        "expected_tests": sorted(EXPECTED_TESTS),
    }
    value["protocol_hash"] = protocol_hash(value)
    dump_json(PROTOCOL_PATH, value)
    append_jsonl(ROOT / "PIPELINE_ATTEMPTS.jsonl", {"event": "protocol_frozen", "at": now(), "protocol_hash": value["protocol_hash"]})
    print(f"frozen protocol: {value['protocol_hash']}")


def verify_protocol() -> dict:
    value = load_json(PROTOCOL_PATH)
    if value.get("protocol_hash") != protocol_hash(value):
        raise RuntimeError("protocol internal hash mismatch")
    if value.get("code_sha256") != code_hashes() or value.get("source_sha256") != source_hashes():
        raise RuntimeError("frozen code/source hash drift")
    if value["prerequisites"]["data_gate_sha256"] != sha256(DATA_GATE):
        raise RuntimeError("data gate drift")
    folds, preprocessing, dry = load_json(FOLDS_PATH), load_json(PREPROCESSING_PATH), load_json(DRY_RUN_PATH)
    validate_folds(folds)
    validate_preprocessing(preprocessing, folds)
    if folds["fold_hash"] != value["folds"]["fold_hash"] or preprocessing["preprocessing_hash"] != value["preprocessing"]["preprocessing_hash"]:
        raise RuntimeError("fold/preprocessing drift")
    if dry.get("dry_run_hash") != internal_hash(dry, "dry_run_hash") or not dry.get("finite"):
        raise RuntimeError("GPU dry-run invalid")
    return value


def fold_record(fold: int) -> dict:
    folds = load_json(FOLDS_PATH)
    validate_folds(folds)
    return folds["folds"][fold]


def load_label_full(identifier: str, allowed: set[str]) -> np.ndarray:
    if identifier not in allowed:
        raise PermissionError(f"label access outside the authorized fold role: {identifier}")
    label_path = dataset_pairs()[identifier][1]
    label = nib.as_closest_canonical(nib.load(label_path))
    array = np.asarray(label.dataobj, dtype=np.uint8).transpose(2, 1, 0)
    if set(np.unique(array).tolist()) - {0, 1}:
        raise RuntimeError(f"invalid label values: {identifier}")
    return array


def label_roi(identifier: str, native_meta: dict, allowed: set[str]) -> np.ndarray:
    full = load_label_full(identifier, allowed)
    x, y, z = native_meta["roi_start_xyz"]
    d, h, w = native_meta["shape_dhw"]
    return full[z : z + d, y : y + h, x : x + w]


def random_start(rng: np.random.Generator, shape_dhw: tuple[int, ...] | list[int]) -> list[int]:
    return [int(rng.integers(0, size - patch + 1)) for size, patch in zip(shape_dhw, PATCH_DHW)]


@torch.inference_mode()
def predict_patch(model: TinyMetricMamba, patch: np.ndarray, spacing_dhw: list[float]) -> np.ndarray:
    device = next(model.parameters()).device
    tensor = torch.from_numpy(np.asarray(patch, dtype=np.float32))[None, None].to(device)
    with torch.autocast("cuda", dtype=torch.bfloat16):
        probability = forward_logits(model, tensor, spacing_dhw).softmax(1)[0, 1].float()
    if not torch.isfinite(probability).all():
        raise RuntimeError("non-finite prediction")
    return probability.cpu().numpy()


def sliding_starts(size: int, patch: int) -> list[int]:
    if size <= patch:
        return [0]
    values = list(range(0, size - patch + 1, patch))
    if values[-1] != size - patch:
        values.append(size - patch)
    return values


def sliding_predict(model: TinyMetricMamba, image: np.ndarray, spacing_dhw: list[float]) -> np.ndarray:
    total = np.zeros(image.shape, dtype=np.float32)
    count = np.zeros(image.shape, dtype=np.uint8)
    for d in sliding_starts(image.shape[0], PATCH_DHW[0]):
        for h in sliding_starts(image.shape[1], PATCH_DHW[1]):
            for w in sliding_starts(image.shape[2], PATCH_DHW[2]):
                patch = extract_padded(image, (d, h, w), PATCH_DHW, -1.0).astype(np.float32)
                probability = predict_patch(model, patch, spacing_dhw)
                valid = tuple(slice(0, min(patch_size, size - start)) for patch_size, size, start in zip(PATCH_DHW, image.shape, (d, h, w)))
                destination = tuple(slice(start, start + section.stop) for start, section in zip((d, h, w), valid))
                total[destination] += probability[valid]
                count[destination] += 1
    if (count == 0).any():
        raise RuntimeError("sliding prediction did not cover the image")
    return total / count


def embed_native_roi(probability: np.ndarray, native_meta: dict) -> np.ndarray:
    full_shape_dhw = tuple(reversed(native_meta["source_shape_xyz"]))
    full = np.zeros(full_shape_dhw, dtype=np.float32)
    x, y, z = native_meta["roi_start_xyz"]
    d, h, w = probability.shape
    full[z : z + d, y : y + h, x : x + w] = probability
    return full


def validation_dice(model: TinyMetricMamba, record: dict, preprocessing: dict) -> float:
    scores = []
    allowed = set(record["validation"])
    for identifier in record["validation"]:
        meta = preprocessing["native"][identifier]
        image = np.load(meta["cache"], mmap_mode="r")
        probability = sliding_predict(model, image, meta["spacing_dhw"])
        hard = embed_native_roi(probability, meta) >= 0.5
        truth = load_label_full(identifier, allowed) == 1
        scores.append(binary_dice(hard, truth))
    return float(np.mean(scores))


def training_paths(arm: str, fold: int, seed: int) -> tuple[Path, Path]:
    if arm not in ARMS or fold not in FOLDS or seed not in SEEDS:
        raise ValueError("unregistered training run")
    stem = f"{arm}_fold{fold}_seed{seed}"
    return ROOT / "checkpoints" / f"{stem}.pt", ROOT / "logs" / f"train_{stem}.json"


def validate_training(arm: str, fold: int, seed: int, protocol: dict | None = None) -> str:
    frozen = protocol or verify_protocol()
    checkpoint, log_path = training_paths(arm, fold, seed)
    if not checkpoint.is_file() or not log_path.is_file():
        raise RuntimeError(f"missing training evidence: {arm}/fold{fold}/seed{seed}")
    log = load_json(log_path)
    record = fold_record(fold)
    history = log.get("history", [])
    expected_weights = [CONSISTENCY_WEIGHT * min(1.0, update / WARMUP_UPDATES) for update in range(VALIDATE_EVERY, UPDATES + 1, VALIDATE_EVERY)]
    checks = [
        log.get("completed") is True,
        log.get("finite") is True,
        log.get("arm") == arm,
        log.get("fold") == fold,
        log.get("seed") == seed,
        log.get("protocol_hash") == frozen["protocol_hash"],
        log.get("updates") == UPDATES,
        log.get("validation_interval") == VALIDATE_EVERY,
        log.get("checkpoint_selection") == "inner_validation_native_grid_foreground_Dice_only",
        log.get("paired_label_loaded") is False,
        sorted(log.get("label_ids_loaded", [])) == sorted(record["train"] + record["validation"]),
        set(log.get("outer_test_ids_excluded", [])) == set(record["outer_test"]),
        len(history) == UPDATES // VALIDATE_EVERY,
        [item.get("update") for item in history] == list(range(VALIDATE_EVERY, UPDATES + 1, VALIDATE_EVERY)),
        checkpoint.is_file() and log.get("checkpoint_sha256") == sha256(checkpoint),
    ]
    for index, item in enumerate(history):
        expected = expected_weights[index] if arm == CONSISTENCY_ARM else 0.0
        checks.append(abs(float(item.get("effective_consistency_weight")) - expected) < 1e-12)
        checks.append(all(np.isfinite(float(item[field])) for field in ("training_loss", "r1_segmentation_loss", "validation_native_dice")))
        checks.append(np.isfinite(float(item["paired_consistency_loss"])) if arm == CONSISTENCY_ARM else item["paired_consistency_loss"] is None)
    best_index = int(np.argmax([float(item["validation_native_dice"]) for item in history]))
    saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
    checks += [
        saved.get("arm") == arm,
        saved.get("fold") == fold,
        saved.get("seed") == seed,
        saved.get("update") == history[best_index]["update"],
        saved.get("selection") == "inner_validation_native_grid_foreground_Dice_only",
        abs(float(saved.get("validation_native_dice")) - float(history[best_index]["validation_native_dice"])) < 1e-12,
    ]
    model = build_model(arm)
    model.load_state_dict(saved["model_state"], strict=True)
    if not all(checks):
        raise RuntimeError(f"invalid training evidence: {arm}/fold{fold}/seed{seed}")
    return sha256(checkpoint)


def train(arm: str, fold: int, seed: int) -> None:
    frozen = verify_protocol()
    checkpoint, log_path = training_paths(arm, fold, seed)
    if checkpoint.exists() and log_path.exists():
        try:
            validate_training(arm, fold, seed, frozen)
            print(f"validated completed training: {arm}/fold{fold}/seed{seed}")
            return
        except Exception:
            pass
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    append_jsonl(ROOT / "TRAINING_ATTEMPTS.jsonl", {"event": "started", "at": now(), "arm": arm, "fold": fold, "seed": seed})
    folds, preprocessing = load_json(FOLDS_PATH), load_json(PREPROCESSING_PATH)
    record = folds["folds"][fold]
    allowed_train = set(record["train"])
    native_images = {identifier: np.load(preprocessing["native"][identifier]["cache"], mmap_mode="r") for identifier in record["train"]}
    native_labels = {identifier: label_roi(identifier, preprocessing["native"][identifier], allowed_train) for identifier in record["train"]}
    paired_images = (
        {identifier: np.load(preprocessing["paired"][str(fold)][identifier]["cache"], mmap_mode="r") for identifier in record["train"]}
        if arm == CONSISTENCY_ARM
        else {}
    )
    device = torch.device("cuda:0")
    seed_all(seed)
    model = build_model(arm).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-5)
    rng = np.random.default_rng(seed)
    case_order: list[int] = []
    history, best = [], -1.0
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    for update in range(1, UPDATES + 1):
        if not case_order:
            case_order = rng.permutation(len(record["train"])).tolist()
        identifier = record["train"][case_order.pop()]
        native_meta = preprocessing["native"][identifier]
        start = random_start(rng, native_meta["shape_dhw"])
        native_patch = np.asarray(native_images[identifier][tuple(slice(value, value + size) for value, size in zip(start, PATCH_DHW))], dtype=np.float32)
        label_patch = np.asarray(native_labels[identifier][tuple(slice(value, value + size) for value, size in zip(start, PATCH_DHW))], dtype=np.int64)
        native_affine = shifted_affine(np.asarray(native_meta["affine_xyz"]), start)
        x1 = torch.from_numpy(native_patch)[None, None].to(device)
        y1 = torch.from_numpy(label_patch)[None].to(device)
        weight = CONSISTENCY_WEIGHT * min(1.0, update / WARMUP_UPDATES) if arm == CONSISTENCY_ARM else 0.0
        if arm == CONSISTENCY_ARM:
            pair_meta = preprocessing["paired"][str(fold)][identifier]
            pair_patch, pair_spacing, pair_affine = paired_patch(paired_images[identifier], start, native_meta, pair_meta)
            x2 = torch.from_numpy(pair_patch)[None, None].to(device)
        else:
            x2 = pair_spacing = pair_affine = None
        model.train()
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            loss, segmentation, consistency = batch_loss(
                model, x1, y1, native_meta["spacing_dhw"], native_affine, x2, pair_spacing, pair_affine, weight
            )
        if not torch.isfinite(loss):
            raise RuntimeError(f"non-finite loss at update {update}")
        loss.backward()
        if not all(torch.isfinite(parameter.grad).all() for parameter in model.parameters() if parameter.grad is not None):
            raise RuntimeError(f"non-finite gradient at update {update}")
        optimizer.step()
        if update % VALIDATE_EVERY == 0:
            model.eval()
            score = validation_dice(model, record, preprocessing)
            item = {
                "update": update,
                "training_loss": float(loss),
                "r1_segmentation_loss": float(segmentation),
                "paired_consistency_loss": None if consistency is None else float(consistency),
                "effective_consistency_weight": weight,
                "validation_native_dice": score,
            }
            history.append(item)
            print(arm, fold, seed, item, flush=True)
            if score > best:
                best = score
                torch.save(
                    {
                        "model_state": model.state_dict(),
                        "arm": arm,
                        "fold": fold,
                        "seed": seed,
                        "update": update,
                        "validation_native_dice": score,
                        "selection": "inner_validation_native_grid_foreground_Dice_only",
                        "protocol_hash": frozen["protocol_hash"],
                    },
                    checkpoint,
                )
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    log = {
        "completed": True,
        "finite": True,
        "arm": arm,
        "fold": fold,
        "seed": seed,
        "protocol_hash": frozen["protocol_hash"],
        "updates": UPDATES,
        "validation_interval": VALIDATE_EVERY,
        "history": history,
        "best_validation_native_dice": best,
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": sha256(checkpoint),
        "checkpoint_selection": "inner_validation_native_grid_foreground_Dice_only",
        "optimizer": "AdamW(lr=3e-4, weight_decay=1e-5)",
        "amp": "bfloat16",
        "consistency_weight": CONSISTENCY_WEIGHT if arm == CONSISTENCY_ARM else 0.0,
        "consistency_warmup_updates": WARMUP_UPDATES if arm == CONSISTENCY_ARM else 0,
        "paired_label_loaded": False,
        "label_ids_loaded": sorted(record["train"] + record["validation"]),
        "outer_test_ids_excluded": sorted(record["outer_test"]),
        "gpu_seconds": elapsed,
        "peak_allocated_bytes": int(torch.cuda.max_memory_allocated()),
        "peak_reserved_bytes": int(torch.cuda.max_memory_reserved()),
    }
    dump_json(log_path, log)
    validate_training(arm, fold, seed, frozen)
    append_jsonl(ROOT / "TRAINING_ATTEMPTS.jsonl", {"event": "completed", "at": now(), "arm": arm, "fold": fold, "seed": seed, "checkpoint_sha256": log["checkpoint_sha256"]})


def record_tests() -> None:
    frozen = verify_protocol()
    value = {
        "completed_at": now(),
        "command": f"{sys.executable} -m unittest -v test_external_validation.py",
        "protocol_hash": frozen["protocol_hash"],
        "code_sha256": code_hashes(),
        "gates": {name: True for name in sorted(EXPECTED_TESTS)},
    }
    dump_json(TEST_RESULTS_PATH, value)


def validate_tests(frozen: dict) -> None:
    value = load_json(TEST_RESULTS_PATH)
    if value.get("protocol_hash") != frozen["protocol_hash"] or value.get("code_sha256") != code_hashes():
        raise RuntimeError("test evidence is not bound to current frozen code")
    if set(value.get("gates", {})) != EXPECTED_TESTS or not all(value["gates"].values()):
        raise RuntimeError("required tests did not all pass")


def release_outer_test() -> None:
    frozen = verify_protocol()
    validate_tests(frozen)
    hashes = {arm: {} for arm in ARMS}
    logs = {arm: {} for arm in ARMS}
    for arm in ARMS:
        for fold in FOLDS:
            for seed in SEEDS:
                key = f"fold{fold}_seed{seed}"
                hashes[arm][key] = validate_training(arm, fold, seed, frozen)
                logs[arm][key] = sha256(training_paths(arm, fold, seed)[1])
    value = {
        "task": TASK,
        "released_once": True,
        "released_at": now(),
        "protocol_hash": frozen["protocol_hash"],
        "fold_hash": frozen["folds"]["fold_hash"],
        "preprocessing_hash": frozen["preprocessing"]["preprocessing_hash"],
        "test_results_sha256": sha256(TEST_RESULTS_PATH),
        "checkpoint_sha256": hashes,
        "training_log_sha256": logs,
        "outer_test_labels_opened_before_release": False,
    }
    value["release_hash"] = internal_hash(value, "release_hash")
    if RELEASE_PATH.exists():
        old = load_json(RELEASE_PATH)
        if old.get("protocol_hash") != value["protocol_hash"] or old.get("checkpoint_sha256") != hashes:
            raise RuntimeError("existing outer-test release conflicts with current evidence")
        print(f"validated existing release: {old['release_hash']}")
        return
    dump_json(RELEASE_PATH, value)
    append_jsonl(ROOT / "PIPELINE_ATTEMPTS.jsonl", {"event": "outer_test_released", "at": now(), "release_hash": value["release_hash"]})


def verify_release() -> tuple[dict, dict]:
    frozen = verify_protocol()
    release = load_json(RELEASE_PATH)
    if release.get("release_hash") != internal_hash(release, "release_hash") or release.get("protocol_hash") != frozen["protocol_hash"]:
        raise RuntimeError("invalid outer-test release")
    for arm in ARMS:
        for fold in FOLDS:
            for seed in SEEDS:
                key = f"fold{fold}_seed{seed}"
                if release["checkpoint_sha256"][arm][key] != validate_training(arm, fold, seed, frozen):
                    raise RuntimeError("checkpoint drift after outer-test release")
    return frozen, release


def load_model(arm: str, fold: int, seed: int, device: torch.device) -> TinyMetricMamba:
    saved = torch.load(training_paths(arm, fold, seed)[0], map_location=device, weights_only=False)
    if (saved.get("arm"), saved.get("fold"), saved.get("seed")) != (arm, fold, seed):
        raise RuntimeError("checkpoint metadata mismatch")
    model = build_model(arm).to(device)
    model.load_state_dict(saved["model_state"], strict=True)
    return model.eval()


def map_pair_to_source(pair_probability: np.ndarray, pair_meta: dict, native_meta: dict) -> np.ndarray:
    source = nib.Nifti1Image(pair_probability.transpose(2, 1, 0).astype(np.float32), np.asarray(pair_meta["affine_xyz"]))
    target = (tuple(native_meta["source_shape_xyz"]), np.asarray(native_meta["source_affine_xyz"]))
    mapped = np.asarray(resample_from_to(source, target, order=1, mode="constant", cval=0.0).dataobj, dtype=np.float32)
    if not np.isfinite(mapped).all():
        raise RuntimeError("non-finite physically mapped probability")
    return np.clip(mapped, 0.0, 1.0).transpose(2, 1, 0)


def evaluate() -> None:
    frozen, release = verify_release()
    if METRICS_PATH.exists() and (ROOT / "evaluation.json").exists():
        old = load_json(ROOT / "evaluation.json")
        if old.get("metrics_sha256") == sha256(METRICS_PATH) and old.get("release_hash") == release["release_hash"] and old.get("failures") == []:
            print("validated existing outer-test evaluation")
            return
    folds, preprocessing = load_json(FOLDS_PATH), load_json(PREPROCESSING_PATH)
    device = torch.device("cuda:0")
    rows, failures = [], []
    torch.cuda.synchronize()
    started = time.perf_counter()
    for record in folds["folds"]:
        fold = int(record["fold"])
        allowed_test = set(record["outer_test"])
        for seed in SEEDS:
            models = {arm: load_model(arm, fold, seed, device) for arm in ARMS}
            for identifier in record["outer_test"]:
                native_meta = preprocessing["native"][identifier]
                pair_meta = preprocessing["paired"][str(fold)][identifier]
                native_image = np.load(native_meta["cache"], mmap_mode="r")
                pair_image = np.load(pair_meta["cache"], mmap_mode="r")
                truth = load_label_full(identifier, allowed_test) == 1
                severity = record["outer_test_metadata"][identifier]
                for arm, model in models.items():
                    try:
                        native_roi_probability = sliding_predict(model, native_image, native_meta["spacing_dhw"])
                        native_probability = embed_native_roi(native_roi_probability, native_meta)
                        pair_probability = sliding_predict(model, pair_image, pair_meta["spacing_dhw"])
                        mapped_probability = map_pair_to_source(pair_probability, pair_meta, native_meta)
                        native_hard, mapped_hard = native_probability >= 0.5, mapped_probability >= 0.5
                        rows.append(
                            {
                                "case_id": identifier,
                                "fold": fold,
                                "seed": seed,
                                "arm": arm,
                                "native_grid_dice": binary_dice(native_hard, truth),
                                "prediction_consistency_dice": binary_dice(mapped_hard, native_hard),
                                "mapped_dice": binary_dice(mapped_hard, truth),
                                "surface_dice_2mm": surface_dice_2mm(mapped_hard, truth, native_meta["source_spacing_dhw"]),
                                "severity_score": severity["severity_score"],
                                "severe_spacing": severity["severe_spacing"],
                                "native_spacing_dhw": json.dumps(native_meta["source_spacing_dhw"], separators=(",", ":")),
                                "paired_spacing_dhw": json.dumps(pair_meta["spacing_dhw"], separators=(",", ":")),
                            }
                        )
                    except Exception as error:
                        failures.append({"case_id": identifier, "fold": fold, "seed": seed, "arm": arm, "error": repr(error)})
                print(f"evaluated fold{fold} seed{seed} {identifier}", flush=True)
            del models
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    expected = {(identifier, fold, seed, arm) for fold, record in enumerate(folds["folds"]) for identifier in record["outer_test"] for seed in SEEDS for arm in ARMS}
    observed = {(row["case_id"], int(row["fold"]), int(row["seed"]), row["arm"]) for row in rows}
    if failures or observed != expected or len(rows) != 41 * len(SEEDS) * len(ARMS):
        dump_json(ROOT / "evaluation_failed.json", {"failures": failures, "rows": len(rows), "missing": sorted(expected - observed)})
        raise RuntimeError("outer-test evaluation incomplete")
    fields = list(rows[0])
    with METRICS_PATH.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    value = {
        "completed_at": now(),
        "protocol_hash": frozen["protocol_hash"],
        "release_hash": release["release_hash"],
        "rows": len(rows),
        "expected_rows": 41 * len(SEEDS) * len(ARMS),
        "identities_exact": observed == expected,
        "failures": failures,
        "metrics_sha256": sha256(METRICS_PATH),
        "outer_test_label_access_after_release_only": True,
        "gpu_seconds": elapsed,
    }
    dump_json(ROOT / "evaluation.json", value)
    print(json.dumps(value, indent=2))


def blocked(reason: str) -> None:
    gate = load_json(DATA_GATE) if DATA_GATE.exists() else {}
    status = "BLOCKED_EXTERNAL_DATA_GATE" if gate.get("status") != "PASS_EXTERNAL_DATA_GATE" else "BLOCKED_EXTERNAL_ENGINEERING"
    result = {
        "task": TASK,
        "status": status,
        "reason": reason,
        "reported_at": now(),
        "axes": {
            "engineering_runnable": False,
            "independent_dataset": gate.get("INDEPENDENT_DATASET", False),
            "real_heterogeneous_spacing": gate.get("REAL_HETEROGENEOUS_SPACING", False),
            "scientific_effect_pass": None,
        },
    }
    dump_json(ROOT / "EXTERNAL_RESULTS.json", result)
    (ROOT / "EXTERNAL_STATUS.txt").write_text(status + "\n")
    (ROOT / "EXTERNAL_REPORT.md").write_text(f"# External validation\n\nFinal status: **{status}**\n\nReason: {reason}\n")
    append_jsonl(ROOT / "PIPELINE_ATTEMPTS.jsonl", {"event": "blocked", "at": now(), "status": status, "reason": reason})
    write_sha256sums()


def write_sha256sums() -> None:
    paths = sorted(
        path
        for path in ROOT.rglob("*")
        if path.is_file() and path.name != "SHA256SUMS" and "__pycache__" not in path.parts and not path.name.endswith(".tmp")
    )
    lines = [f"{sha256(path)}  {path.relative_to(ROOT)}" for path in paths]
    (ROOT / "SHA256SUMS").write_text("\n".join(lines) + "\n")
    print(f"hashed {len(paths)} files")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("setup")
    train_parser = sub.add_parser("train")
    train_parser.add_argument("--arm", choices=ARMS, required=True)
    train_parser.add_argument("--fold", type=int, choices=FOLDS, required=True)
    train_parser.add_argument("--seed", type=int, choices=SEEDS, required=True)
    sub.add_parser("record-tests")
    sub.add_parser("release")
    sub.add_parser("evaluate")
    blocked_parser = sub.add_parser("blocked")
    blocked_parser.add_argument("--reason", required=True)
    sub.add_parser("sha")
    args = parser.parse_args()
    if args.command == "setup":
        setup()
    elif args.command == "train":
        train(args.arm, args.fold, args.seed)
    elif args.command == "record-tests":
        record_tests()
    elif args.command == "release":
        release_outer_test()
    elif args.command == "evaluate":
        evaluate()
    elif args.command == "blocked":
        blocked(args.reason)
    elif args.command == "sha":
        write_sha256sums()


if __name__ == "__main__":
    main()
