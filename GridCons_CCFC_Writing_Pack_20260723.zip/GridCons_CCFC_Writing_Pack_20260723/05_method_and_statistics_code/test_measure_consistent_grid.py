import unittest
import inspect

import torch

from conservative_transport import axial_overlap_weights, conservative_axial_transport, soft_segmentation_loss
from model import TinyMetricMamba, parameter_count
from run_grid_causal_audit import frozen_schedule
from run_measure_consistent_grid import train


def affine(spacing: float = 1.0) -> torch.Tensor:
    value = torch.eye(4, dtype=torch.float64)
    value[2, 2] = spacing
    return value


class ConservativeTransportTests(unittest.TestCase):
    def test_identity(self):
        source = torch.rand(2, 3, 7, 4, 5)
        source /= source.sum(1, keepdim=True)
        result = conservative_axial_transport(source, affine(), source.shape[2:], affine())
        self.assertLess((result - source).abs().max().item(), 1e-7)

    def test_nonnegative_and_normalized_with_edge_background(self):
        source = torch.zeros(1, 3, 5, 1, 1)
        source[:, 1] = 1
        result = conservative_axial_transport(source, affine(), (3, 1, 1), affine(2))
        self.assertGreaterEqual(result.min().item(), 0)
        self.assertLess((result.sum(1) - 1).abs().max().item(), 1e-7)
        self.assertAlmostEqual(result[0, 0, 0, 0, 0].item(), 0.25)

    def test_foreground_physical_volume_conservation(self):
        source = torch.nn.functional.one_hot(torch.tensor([[[[0]], [[1]], [[2]], [[1]], [[0]]]]), 3)
        source = source.movedim(-1, 1).float()
        result = conservative_axial_transport(source, affine(), (3, 1, 1), affine(2))
        for cls in (1, 2):
            self.assertAlmostEqual(source[:, cls].sum().item(), 2 * result[:, cls].sum().item(), places=6)

    def test_expected_overlap_matrix(self):
        expected = torch.tensor([[0.5, 0.25, 0, 0, 0], [0, 0.25, 0.5, 0.25, 0], [0, 0, 0, 0.25, 0.5]], dtype=torch.float64)
        self.assertTrue(torch.equal(axial_overlap_weights(5, 1, 3, 2), expected))

    def test_soft_loss_gradient_finite(self):
        logits = torch.randn(1, 3, 3, 2, 2, requires_grad=True)
        source = torch.softmax(torch.randn(1, 3, 5, 2, 2), 1)
        target = conservative_axial_transport(source, affine(), (3, 2, 2), affine(2))
        loss = soft_segmentation_loss(logits, target)
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        self.assertTrue(torch.isfinite(logits.grad).all())

    def test_permutation_invariant_classes(self):
        source = torch.softmax(torch.randn(1, 3, 5, 2, 2), 1)
        baseline = conservative_axial_transport(source, affine(), (3, 2, 2), affine(2))
        result = conservative_axial_transport(source[:, [0, 2, 1]], affine(), (3, 2, 2), affine(2))
        self.assertLess((result[:, [0, 2, 1]] - baseline).abs().max().item(), 1e-7)

    def test_rejects_nonmatched_grid(self):
        target_affine = affine(2)
        target_affine[0, 0] = 2
        with self.assertRaises(ValueError):
            conservative_axial_transport(torch.ones(1, 3, 5, 1, 1), affine(), (3, 1, 1), target_affine)

    def test_no_parameter_increase(self):
        counts = [parameter_count(TinyMetricMamba("separated_physical_delta")) for _ in ("R", "P", "H", "O")]
        self.assertEqual(counts, [99411] * 4)

    def test_frozen_random_k1_schedule_parity(self):
        schedule = frozen_schedule(["a", "b", "c"], 17, 2500)
        sequences = [[row["spacing_1"] for row in schedule] for _ in ("R", "P", "H", "O")]
        self.assertTrue(all(sequence == sequences[0] for sequence in sequences[1:]))

    def test_no_candidate_label_io_and_r1_checkpoint_rule(self):
        source = inspect.getsource(train)
        self.assertEqual(source.count('load_grid(ctx.causal, case_id, "R1")'), 1)
        self.assertNotIn('load_grid(ctx.causal, case_id, "candidate', source)
        self.assertIn('score = validation_dice(ctx, model, device)', source)
        self.assertNotIn('source_mean_Dmap', source)
        self.assertNotIn('extrapolation_Dmap', source)


if __name__ == "__main__":
    unittest.main()
