import inspect
import json
import time
import unittest
from unittest import mock

import numpy as np
import torch

import control_matrix as task
from unet3d import PlainUNet3D


class ControlMatrixTests(unittest.TestCase):
    gates: dict[str, bool] = {}

    @classmethod
    def setUpClass(cls) -> None:
        cls.started = time.perf_counter()

    @classmethod
    def tearDownClass(cls) -> None:
        task.dump_json(
            task.ROOT / "TEST_RESULTS.json",
            {
                "command": f"{task.sys.executable} -m unittest -v test_control_matrix.py",
                "gates": cls.gates,
                "code_sha256": task.code_hashes(),
                "protocol_hash": json.loads(task.PROTOCOL_PATH.read_text())["protocol_hash"]
                if task.PROTOCOL_PATH.exists()
                else None,
                "seconds": time.perf_counter() - cls.started,
            },
        )

    def test_1_unet_output_shape_and_finite(self) -> None:
        torch.manual_seed(1)
        model = PlainUNet3D(out_channels=3).eval()
        image = torch.randn(1, 1, 9, 11, 13)
        with torch.inference_mode():
            output = model(image)
        self.assertEqual(output.shape, (1, 3, 9, 11, 13))
        self.assertTrue(torch.isfinite(output).all())
        self.gates["unet_output_shape_and_finite"] = True

    def test_2_zero_consistency_matches_supervised_update(self) -> None:
        torch.manual_seed(2)
        direct = torch.nn.Conv3d(1, 3, 1, bias=False)
        combined = torch.nn.Conv3d(1, 3, 1, bias=False)
        combined.load_state_dict(direct.state_dict())
        image = torch.randn(1, 1, 4, 4, 4)
        label = torch.randint(0, 3, (1, 4, 4, 4))
        r2 = torch.randn(1, 1, 2, 4, 4, requires_grad=True)
        direct_loss = task.source.OLD.loss_fn(direct(image), label)
        combined_loss, segmentation, consistency = task.batch_loss(
            combined, "unet3d", image, label, r2, [4, 4, 4], [2, 4, 4], 0.0
        )
        direct_loss.backward()
        combined_loss.backward()
        self.assertEqual(float(direct_loss), float(combined_loss))
        self.assertEqual(float(segmentation), float(combined_loss))
        self.assertIsNone(consistency)
        self.assertIsNone(r2.grad)
        for left, right in zip(direct.parameters(), combined.parameters()):
            self.assertTrue(torch.equal(left.grad, right.grad))
        self.gates["zero_consistency_matches_supervised_update"] = True

    def test_3_r2_label_not_in_train_graph_or_loader(self) -> None:
        manifest = task.source.manifest()
        case_id = manifest["split"]["train"][0]
        one_case = {"split": {"train": [case_id]}, "cases": manifest["cases"]}
        opened = []
        original_load = np.load

        def record(path, *args, **kwargs):
            opened.append(str(path))
            return original_load(path, *args, **kwargs)

        with mock.patch.object(task.np, "load", side_effect=record):
            cases = task.load_training_cases(one_case, use_consistency=True)
        grids = manifest["cases"][case_id]["grids"]
        self.assertEqual(len(cases), 1)
        self.assertEqual(
            opened,
            [grids["R1"]["image_cache"], grids["R1"]["label_cache"], grids["R2"]["image_cache"]],
        )
        self.assertNotIn(grids["R2"]["label_cache"], opened)
        self.assertNotIn("r2_label", inspect.signature(task.batch_loss).parameters)
        self.gates["r2_label_not_in_train_graph_or_loader"] = True

    def test_4_same_case_physical_alignment(self) -> None:
        manifest = task.source.manifest()
        case_id = manifest["split"]["train"][0]
        grids = manifest["cases"][case_id]["grids"]
        r1, r2 = grids["R1"], grids["R2"]
        self.assertTrue(
            np.allclose(r1["physical_bounds_center_mm"], r2["physical_bounds_center_mm"], atol=1e-6)
        )
        affine1, affine2 = np.asarray(r1["affine_xyz"]), np.asarray(r2["affine_xyz"])
        self.assertTrue(np.allclose(affine1[:3, 3], affine2[:3, 3], atol=1e-6))
        direction1 = affine1[:3, :3] / np.linalg.norm(affine1[:3, :3], axis=0)
        direction2 = affine2[:3, :3] / np.linalg.norm(affine2[:3, :3], axis=0)
        self.assertTrue(np.allclose(direction1, direction2, atol=1e-6))
        self.assertEqual(r1["unpadded_shape_dhw"][0], 2 * (r2["unpadded_shape_dhw"][0] - 1) + 1)
        self.gates["same_case_physical_alignment"] = True


if __name__ == "__main__":
    unittest.main(verbosity=2)
