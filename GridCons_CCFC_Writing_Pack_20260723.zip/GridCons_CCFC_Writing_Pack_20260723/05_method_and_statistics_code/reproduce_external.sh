#!/usr/bin/env bash
set -Eeuo pipefail

ROOT=/home/yanjingjia/gridcons_followup_20260720/02_external_spacing
PYTHON_BIN=/home/yanjingjia/miniforge3/envs/metric-mamba/bin/python
export PYTHON_BIN
export CUDA_VISIBLE_DEVICES=0
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
cd "$ROOT"
mkdir -p logs checkpoints

fail() {
  code=$?
  trap - ERR
  "$PYTHON_BIN" external_validation.py blocked --reason "pipeline error exit=${code} line=$1"
  exit "$code"
}
trap 'fail $LINENO' ERR

test "$(jq -r .status DATA_GATE.json)" = PASS_EXTERNAL_DATA_GATE
"$PYTHON_BIN" external_validation.py setup 2>&1 | tee -a logs/setup.log
"$PYTHON_BIN" -m unittest -v test_external_validation.py 2>&1 | tee -a logs/tests.log
"$PYTHON_BIN" external_validation.py record-tests

parallel_jobs=$(jq -r .recommended_parallel_jobs GPU_DRY_RUN.json)
for arm in dynamic_delta static_delta gridcons_mamba; do
  for fold in 0 1 2 3 4; do
    for seed in 17 29 41; do
      printf '%s\t%s\t%s\n' "$arm" "$fold" "$seed"
    done
  done
done | xargs -P "$parallel_jobs" -n 3 bash -c '
  arm=$1; fold=$2; seed=$3
  "$PYTHON_BIN" external_validation.py train --arm "$arm" --fold "$fold" --seed "$seed" >> "logs/console_${arm}_fold${fold}_seed${seed}.log" 2>&1
' _

"$PYTHON_BIN" external_validation.py release 2>&1 | tee -a logs/release.log
"$PYTHON_BIN" external_validation.py evaluate 2>&1 | tee -a logs/evaluation.log
"$PYTHON_BIN" external_statistics.py 2>&1 | tee -a logs/statistics.log
"$PYTHON_BIN" external_validation.py sha
sha256sum -c SHA256SUMS >/dev/null
