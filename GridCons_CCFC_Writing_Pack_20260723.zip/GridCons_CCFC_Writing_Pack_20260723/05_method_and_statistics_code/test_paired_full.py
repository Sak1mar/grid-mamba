import unittest

import torch
from torch.nn import functional as F

import run_probe as base
from run_paired_full import confirm_manifest, paired_grid_consistency_loss


class PairedGridTests(unittest.TestCase):
    def test_confirm_split_is_frozen_and_disjoint(self) -> None:
        confirm = confirm_manifest()
        ids = confirm["confirm_test"]
        development = set().union(*base.manifest()["split"].values())
        self.assertEqual(len(ids), 40)
        self.assertEqual(len(set(ids)), 40)
        self.assertFalse(set(ids) & development)

    def test_alignment_and_gradients(self) -> None:
        torch.manual_seed(7)
        line = torch.arange(3.0).reshape(1, 1, 3, 1, 1)
        aligned = F.interpolate(line, size=(5, 1, 1), mode="trilinear", align_corners=True)
        self.assertTrue(torch.equal(aligned.flatten(), torch.tensor([0.0, 0.5, 1.0, 1.5, 2.0])))
        same = torch.randn(1, 3, 5, 6, 7)
        self.assertLess(float(paired_grid_consistency_loss(same, same, [5, 6, 7], [5, 6, 7])), 1e-6)
        r1 = torch.randn(1, 3, 9, 6, 7, requires_grad=True)
        r2 = torch.randn(1, 3, 5, 6, 7, requires_grad=True)
        loss = paired_grid_consistency_loss(r1, r2, [9, 6, 7], [5, 6, 7])
        loss.backward()
        self.assertIsNone(r1.grad)
        self.assertIsNotNone(r2.grad)
        self.assertTrue(torch.isfinite(r2.grad).all())
        self.assertGreater(float(r2.grad.abs().max()), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
