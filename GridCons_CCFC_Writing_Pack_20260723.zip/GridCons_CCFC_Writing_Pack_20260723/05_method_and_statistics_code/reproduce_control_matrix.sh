#!/usr/bin/env bash
set -euo pipefail

ROOT=/home/yanjingjia/gridcons_followup_20260720/01_task04_control_matrix
PY=/home/yanjingjia/miniforge3/envs/metric-mamba/bin/python
export CUDA_VISIBLE_DEVICES=0
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1

cd "$ROOT"
mkdir -p logs checkpoints
exec 9>logs/pipeline.lock
flock -n 9 || { printf '%s\n' 'another control-matrix pipeline is already running' >&2; exit 1; }

on_error() {
    exit_code=$?
    failed_command=$BASH_COMMAND
    trap - ERR
    "$PY" control_statistics.py --blocked-reason "pipeline command failed with exit ${exit_code}: ${failed_command}; see append-only logs" >>logs/blocked.log 2>&1 || true
    "$PY" control_matrix.py hashes >/dev/null 2>&1 || true
    exit "$exit_code"
}
trap on_error ERR

"$PY" control_matrix.py setup 2>&1 | tee -a logs/setup.log
"$PY" -m unittest -v test_control_matrix.py 2>&1 | tee -a logs/tests.log

for arm in dynamic_delta_consistency unet3d unet3d_consistency; do
    for seed in 17 29 41 53 67; do
        printf '%s %s\n' "$arm" "$seed"
    done
done | xargs -P8 -n2 bash -c 'flock -n "logs/train_${1}_seed${2}.lock" "$0" control_matrix.py train --arm "$1" --seed "$2" >>"logs/console_${1}_seed${2}.log" 2>&1' "$PY"

"$PY" control_matrix.py screen-dev 2>&1 | tee -a logs/development.log
if "$PY" -c 'import json; raise SystemExit(not json.load(open("DEVELOPMENT_GATE.json"))["release_confirm"])'; then
    "$PY" control_matrix.py evaluate-confirm 2>&1 | tee -a logs/confirm.log
    "$PY" control_matrix.py benchmark 2>&1 | tee -a logs/benchmark.log
fi
"$PY" control_statistics.py 2>&1 | tee -a logs/statistics.log
"$PY" control_matrix.py hashes
