"""Exact conservative class-measure transport for matched axial voxel grids."""

from __future__ import annotations

import torch
from torch.nn import functional as F


def axial_overlap_weights(
    source_depth: int,
    source_spacing: float,
    target_depth: int,
    target_spacing: float,
    *,
    device: torch.device | str = "cpu",
) -> torch.Tensor:
    """Return target-cell fractions covered by each aligned source cell."""
    if min(source_depth, target_depth) < 1 or min(source_spacing, target_spacing) <= 0:
        raise ValueError("depths and spacings must be positive")
    source = torch.arange(source_depth, dtype=torch.float64, device=device) * source_spacing
    target = torch.arange(target_depth, dtype=torch.float64, device=device) * target_spacing
    source_lo, source_hi = source - source_spacing / 2, source + source_spacing / 2
    target_lo, target_hi = target - target_spacing / 2, target + target_spacing / 2
    overlap = (
        torch.minimum(target_hi[:, None], source_hi[None])
        - torch.maximum(target_lo[:, None], source_lo[None])
    ).clamp_min(0)
    weights = overlap / target_spacing
    if (weights < 0).any() or (weights.sum(1) > 1 + 1e-10).any():
        raise RuntimeError("invalid cell-overlap weights")
    return weights


def conservative_axial_transport(
    measures: torch.Tensor,
    source_affine_xyz: torch.Tensor,
    target_shape_dhw: tuple[int, int, int] | list[int],
    target_affine_xyz: torch.Tensor,
) -> torch.Tensor:
    """Push cell class fractions to an aligned axial grid, padding outside as background."""
    if measures.ndim != 5 or measures.shape[1] < 2:
        raise ValueError("measures must be [B,C,D,H,W] with background channel 0")
    target_shape = tuple(int(x) for x in target_shape_dhw)
    if target_shape[1:] != tuple(measures.shape[3:]):
        raise ValueError("conservative axial transport requires the same in-plane lattice")
    source_affine = torch.as_tensor(source_affine_xyz, dtype=torch.float64, device=measures.device)
    target_affine = torch.as_tensor(target_affine_xyz, dtype=torch.float64, device=measures.device)
    if source_affine.shape != (4, 4) or target_affine.shape != (4, 4):
        raise ValueError("affines must be [4,4]")
    source_axis, target_axis = source_affine[:3, 2], target_affine[:3, 2]
    source_spacing, target_spacing = torch.linalg.vector_norm(source_axis), torch.linalg.vector_norm(target_axis)
    if not torch.allclose(source_axis / source_spacing, target_axis / target_spacing, atol=1e-7, rtol=0):
        raise ValueError("axial directions differ")
    if not torch.allclose(source_affine[:, :2], target_affine[:, :2], atol=1e-7, rtol=0):
        raise ValueError("in-plane lattices differ")
    direction = source_axis / source_spacing
    axial_origin_shift = torch.dot(target_affine[:3, 3] - source_affine[:3, 3], direction)
    if abs(float(axial_origin_shift)) > 1e-7:
        raise ValueError("axial origins differ")
    weights = axial_overlap_weights(
        measures.shape[2], float(source_spacing), target_shape[0], float(target_spacing), device=measures.device
    ).to(measures.dtype)
    transported = torch.einsum("vd,bcdhw->bcvhw", weights, measures)
    uncovered = (1 - weights.sum(1)).clamp_min(0).to(measures.dtype)
    transported[:, 0] += uncovered[None, :, None, None]
    if not torch.isfinite(transported).all():
        raise FloatingPointError("transport produced NaN or Inf")
    return transported


def soft_segmentation_loss(logits: torch.Tensor, target_fractions: torch.Tensor) -> torch.Tensor:
    """Equal-weight foreground soft Dice and all-class soft cross entropy."""
    if logits.shape != target_fractions.shape:
        raise ValueError("logits and target fractions must have identical shapes")
    probabilities = logits.softmax(1)
    dims = (0, 2, 3, 4)
    intersection = (probabilities[:, 1:] * target_fractions[:, 1:]).sum(dims)
    denominator = probabilities[:, 1:].sum(dims) + target_fractions[:, 1:].sum(dims)
    dice = 1 - ((2 * intersection + 1e-5) / (denominator + 1e-5)).mean()
    cross_entropy = -(target_fractions * F.log_softmax(logits, 1)).sum(1).mean()
    return 0.5 * dice + 0.5 * cross_entropy
