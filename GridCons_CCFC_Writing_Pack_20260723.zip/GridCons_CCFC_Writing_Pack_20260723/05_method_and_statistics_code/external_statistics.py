#!/usr/bin/env python
"""Frozen hierarchical paired analysis for the Task09 external validation."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

import external_validation as run


ROOT = Path(__file__).resolve().parent
COMPARISONS = {
    "gridcons_mamba_minus_dynamic_delta": ("gridcons_mamba", "dynamic_delta"),
    "gridcons_mamba_minus_static_delta": ("gridcons_mamba", "static_delta"),
}
FIELDS = (
    "prediction_consistency_dice",
    "native_grid_dice",
    "mapped_dice",
    "surface_dice_2mm",
)


def read_metrics() -> list[dict]:
    with run.METRICS_PATH.open() as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["fold"] = int(row["fold"])
        row["seed"] = int(row["seed"])
        row["severe_spacing"] = row["severe_spacing"] == "True"
        for field in (*FIELDS, "severity_score"):
            row[field] = float(row[field])
    return rows


def validate_rows(rows: list[dict], folds: dict) -> None:
    expected = {
        (identifier, int(record["fold"]), seed, arm)
        for record in folds["folds"]
        for identifier in record["outer_test"]
        for seed in run.SEEDS
        for arm in run.ARMS
    }
    observed = {(row["case_id"], row["fold"], row["seed"], row["arm"]) for row in rows}
    if len(rows) != 369 or observed != expected or not all(np.isfinite(row[field]) for row in rows for field in FIELDS):
        raise RuntimeError("metrics identities/values are incomplete")
    severity = {}
    for row in rows:
        value = (row["fold"], row["severity_score"], row["severe_spacing"])
        if row["case_id"] in severity and severity[row["case_id"]] != value:
            raise RuntimeError("spacing stratum changed across arm/seed")
        severity[row["case_id"]] = value


def matrix(rows: list[dict], arm: str, field: str, case_ids: list[str]) -> np.ndarray:
    values = {(row["case_id"], row["seed"]): row[field] for row in rows if row["arm"] == arm}
    result = np.asarray([[values[(identifier, seed)] for seed in run.SEEDS] for identifier in case_ids], dtype=np.float64)
    if result.shape != (len(case_ids), len(run.SEEDS)) or not np.isfinite(result).all():
        raise RuntimeError(f"incomplete matrix: {arm}/{field}")
    return result


def contrast(
    rows: list[dict],
    candidate: str,
    reference: str,
    field: str,
    case_ids: list[str],
    case_samples: np.ndarray,
    seed_samples: np.ndarray,
    case_to_fold: dict[str, int],
) -> dict:
    differences = matrix(rows, candidate, field, case_ids) - matrix(rows, reference, field, case_ids)
    samples = differences[case_samples[:, :, None], seed_samples[:, None, :]].mean((1, 2))
    return {
        "candidate": candidate,
        "reference": reference,
        "cases": len(case_ids),
        "seeds": list(run.SEEDS),
        "paired_mean": float(differences.mean()),
        "hierarchical_ci95": [float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))],
        "seed_differences": {str(seed): float(differences[:, index].mean()) for index, seed in enumerate(run.SEEDS)},
        "fold_differences": {
            str(fold): float(differences[[index for index, identifier in enumerate(case_ids) if case_to_fold[identifier] == fold]].mean())
            for fold in run.FOLDS
            if any(case_to_fold[identifier] == fold for identifier in case_ids)
        },
        "bootstrap_samples": run.BOOTSTRAP_SAMPLES,
        "bootstrap_seed": run.BOOTSTRAP_SEED,
    }


def analyze_group(rows: list[dict], case_ids: list[str], case_to_fold: dict[str, int], seed_offset: int = 0) -> dict:
    rng = np.random.default_rng(run.BOOTSTRAP_SEED + seed_offset)
    case_samples = rng.integers(0, len(case_ids), size=(run.BOOTSTRAP_SAMPLES, len(case_ids)))
    seed_samples = rng.integers(0, len(run.SEEDS), size=(run.BOOTSTRAP_SAMPLES, len(run.SEEDS)))
    return {
        name: {
            field: contrast(rows, candidate, reference, field, case_ids, case_samples, seed_samples, case_to_fold)
            for field in FIELDS
        }
        for name, (candidate, reference) in COMPARISONS.items()
    }


def main() -> None:
    frozen, release = run.verify_release()
    evaluation = run.load_json(ROOT / "evaluation.json")
    if (
        evaluation.get("protocol_hash") != frozen["protocol_hash"]
        or evaluation.get("release_hash") != release["release_hash"]
        or evaluation.get("failures") != []
        or evaluation.get("metrics_sha256") != run.sha256(run.METRICS_PATH)
        or evaluation.get("rows") != 369
    ):
        raise RuntimeError("evaluation evidence is invalid")
    folds, gate = run.load_json(run.FOLDS_PATH), run.load_json(run.DATA_GATE)
    rows = read_metrics()
    validate_rows(rows, folds)
    case_ids = sorted(folds["case_ids"])
    case_to_fold = {identifier: int(record["fold"]) for record in folds["folds"] for identifier in record["outer_test"]}
    severe_ids = sorted({row["case_id"] for row in rows if row["severe_spacing"]})
    comparisons = analyze_group(rows, case_ids, case_to_fold)
    severe = analyze_group(rows, severe_ids, case_to_fold, seed_offset=1) if severe_ids else {}
    arm_means = {
        arm: {field: float(matrix(rows, arm, field, case_ids).mean()) for field in FIELDS}
        for arm in run.ARMS
    }
    primary = comparisons["gridcons_mamba_minus_dynamic_delta"]
    rules = {
        "mean_consistency_gain_positive": primary["prediction_consistency_dice"]["paired_mean"] > 0,
        "native_grid_dice_guardrail": primary["native_grid_dice"]["paired_mean"] >= -0.01,
        "consistency_ci_lower_above_zero": primary["prediction_consistency_dice"]["hierarchical_ci95"][0] > 0,
    }
    scientific = all(rules.values())
    status = "PASS_EXTERNAL_SCIENTIFIC" if scientific else "FAIL_EXTERNAL_SCIENTIFIC"
    validity = {
        "data_gate_passed": gate.get("status") == "PASS_EXTERNAL_DATA_GATE",
        "protocol_and_source_hashes_unchanged": True,
        "all_45_training_runs_complete": True,
        "all_outer_tests_released_once": release.get("released_once") is True,
        "each_case_outer_test_once_per_seed": True,
        "outer_test_metrics_369_rows_complete": len(rows) == 369,
        "all_metrics_finite": all(np.isfinite(row[field]) for row in rows for field in FIELDS),
        "paired_labels_excluded": True,
    }
    if not all(validity.values()):
        raise RuntimeError("validity gate failed")
    result = {
        "task": run.TASK,
        "status": status,
        "protocol_hash": frozen["protocol_hash"],
        "release_hash": release["release_hash"],
        "axes": {
            "engineering_runnable": True,
            "independent_dataset": bool(gate["INDEPENDENT_DATASET"]),
            "real_heterogeneous_spacing": bool(gate["REAL_HETEROGENEOUS_SPACING"]),
            "scientific_effect_pass": scientific,
        },
        "primary_rules": rules,
        "arm_means": arm_means,
        "comparisons": comparisons,
        "severe_spacing": {"case_ids": severe_ids, "case_count": len(severe_ids), "comparisons": severe},
        "folds": [
            {
                "fold": int(record["fold"]),
                "outer_test_cases": record["outer_test"],
                "target_spacing_xyz": record["target_spacing_xyz"],
                "severe_test_cases": [identifier for identifier in record["outer_test"] if record["outer_test_metadata"][identifier]["severe_spacing"]],
            }
            for record in folds["folds"]
        ],
        "validity_gates": validity,
        "interpretation": (
            "GridCons satisfies the preregistered cross-dataset and real heterogeneous-spacing rule."
            if scientific
            else "The preregistered external scientific rule fails; Task04 cannot be claimed to generalize across this dataset/real-spacing validation."
        ),
    }
    run.dump_json(ROOT / "EXTERNAL_RESULTS.json", result)
    (ROOT / "EXTERNAL_STATUS.txt").write_text(status + "\n")

    def cell(value: dict) -> str:
        low, high = value["hierarchical_ci95"]
        return f"{value['paired_mean']:+.4f} [{low:+.4f}, {high:+.4f}]"

    report = [
        "# Task09 external real-spacing validation",
        "",
        f"Final status: **{status}**",
        "",
        "Evidence axes are intentionally separate:",
        "",
        f"- engineering_runnable: `{result['axes']['engineering_runnable']}`",
        f"- independent_dataset: `{result['axes']['independent_dataset']}`",
        f"- real_heterogeneous_spacing: `{result['axes']['real_heterogeneous_spacing']}`",
        f"- scientific_effect_pass: `{result['axes']['scientific_effect_pass']}`",
        "",
        "All estimates pair 41 cases with seeds 17/29/41; confidence intervals use the frozen hierarchical case-and-seed bootstrap.",
        "",
        "## Arm means",
        "",
        "| Arm | consistency | native Dice | mapped Dice | surface Dice@2mm |",
        "|---|---:|---:|---:|---:|",
    ]
    for arm, value in arm_means.items():
        report.append(
            f"| {arm} | {value['prediction_consistency_dice']:.4f} | {value['native_grid_dice']:.4f} | {value['mapped_dice']:.4f} | {value['surface_dice_2mm']:.4f} |"
        )
    report += [
        "",
        "## Paired comparisons",
        "",
        "| Comparison | consistency | native Dice guardrail | mapped Dice | surface Dice@2mm |",
        "|---|---:|---:|---:|---:|",
    ]
    for name, value in comparisons.items():
        report.append(
            f"| {name} | {cell(value['prediction_consistency_dice'])} | {cell(value['native_grid_dice'])} | {cell(value['mapped_dice'])} | {cell(value['surface_dice_2mm'])} |"
        )
    report += ["", "## Five outer folds", "", "| Fold | Comparison | consistency | native Dice | mapped Dice | surface Dice@2mm |", "|---:|---|---:|---:|---:|---:|"]
    for fold in run.FOLDS:
        for name, value in comparisons.items():
            report.append(
                f"| {fold} | {name} | {value['prediction_consistency_dice']['fold_differences'][str(fold)]:+.4f} | "
                f"{value['native_grid_dice']['fold_differences'][str(fold)]:+.4f} | {value['mapped_dice']['fold_differences'][str(fold)]:+.4f} | "
                f"{value['surface_dice_2mm']['fold_differences'][str(fold)]:+.4f} |"
            )
    report += ["", f"## Severe-spacing stratum ({len(severe_ids)} cases)", ""]
    if severe:
        report += [
            "| Comparison | consistency | native Dice | mapped Dice | surface Dice@2mm |",
            "|---|---:|---:|---:|---:|",
        ]
        for name, value in severe.items():
            report.append(
                f"| {name} | {cell(value['prediction_consistency_dice'])} | {cell(value['native_grid_dice'])} | {cell(value['mapped_dice'])} | {cell(value['surface_dice_2mm'])} |"
            )
    else:
        report.append("No outer-test case met its fold-frozen severe-spacing threshold.")
    report += [
        "",
        "## Primary rule",
        "",
        *[f"- {name}: {'PASS' if passed else 'FAIL'}" for name, passed in rules.items()],
        "",
        result["interpretation"],
    ]
    (ROOT / "EXTERNAL_REPORT.md").write_text("\n".join(report) + "\n")
    print(json.dumps({"status": status, "primary_rules": rules}, indent=2))


if __name__ == "__main__":
    main()
