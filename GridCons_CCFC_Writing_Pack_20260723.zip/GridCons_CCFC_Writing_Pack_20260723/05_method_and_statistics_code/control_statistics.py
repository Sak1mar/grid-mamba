#!/usr/bin/env python
"""Frozen paired statistics and report for the Task04 control matrix."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

import control_matrix as task


BOOTSTRAP_SAMPLES = 10_000
BOOTSTRAP_SEED = 7301
METRICS = {
    "r2_consistency": ("R2", "prediction_consistency_dice"),
    "r2_mapped_dice": ("R2", "mapped_label_dice"),
    "r2_surface_dice_2mm": ("R2", "surface_dice_2mm"),
    "r1_guardrail": ("R1", "native_r1_label_dice"),
    "r4_consistency": ("R4", "prediction_consistency_dice"),
}
CONTRASTS = {
    "dynamic_delta_consistency_minus_dynamic_delta": {
        "dynamic_delta_consistency": 1.0,
        "dynamic_delta": -1.0,
    },
    "gridcons_mamba_minus_static_delta": {"gridcons_mamba": 1.0, "static_delta": -1.0},
    "unet3d_consistency_minus_unet3d": {"unet3d_consistency": 1.0, "unet3d": -1.0},
    "mamba_difference_in_differences": {
        "gridcons_mamba": 1.0,
        "static_delta": -1.0,
        "dynamic_delta_consistency": -1.0,
        "dynamic_delta": 1.0,
    },
}


def read_metrics(path: Path) -> list[dict]:
    with path.open() as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["seed"] = int(row["seed"])
        for field in (
            "prediction_consistency_dice",
            "mapped_label_dice",
            "native_r1_label_dice",
            "surface_dice_2mm",
            "oracle_grid_dice",
        ):
            row[field] = float(row[field])
    return rows


def matrix(rows: list[dict], method: str, spacing: str, field: str) -> np.ndarray:
    case_ids = sorted(task.paired_source.confirm_manifest()["confirm_test"])
    values: dict[tuple[str, int], list[float]] = {}
    for row in rows:
        if row["method"] == method and row["spacing"] == spacing:
            values.setdefault((row["case_id"], row["seed"]), []).append(row[field])
    result = np.asarray(
        [[np.mean(values[(case_id, seed)]) for seed in task.SEEDS] for case_id in case_ids], dtype=np.float64
    )
    if result.shape != (40, 5) or not np.isfinite(result).all():
        raise RuntimeError(f"incomplete matrix: {method}/{spacing}/{field}")
    return result


def contrast(
    rows: list[dict],
    coefficients: dict[str, float],
    spacing: str,
    field: str,
    case_samples: np.ndarray,
    seed_samples: np.ndarray,
) -> dict:
    differences = sum(coefficient * matrix(rows, method, spacing, field) for method, coefficient in coefficients.items())
    samples = differences[case_samples[:, :, None], seed_samples[:, None, :]].mean((1, 2))
    return {
        "coefficients": coefficients,
        "paired_mean": float(differences.mean()),
        "hierarchical_ci95": [float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))],
        "seed_differences": {str(seed): float(differences[:, index].mean()) for index, seed in enumerate(task.SEEDS)},
        "positive_seed_count": int((differences.mean(0) > 0).sum()),
        "cases": 40,
        "seeds": list(task.SEEDS),
        "bootstrap_samples": BOOTSTRAP_SAMPLES,
        "bootstrap_seed": BOOTSTRAP_SEED,
    }


def write_outputs(result: dict, lines: list[str]) -> None:
    task.dump_json(task.ROOT / "CONTROL_RESULTS.json", result)
    (task.ROOT / "CONTROL_REPORT.md").write_text("\n".join(lines) + "\n")
    (task.ROOT / "CONTROL_STATUS.txt").write_text(result["status"] + "\n")


def development_failure(frozen: dict, gate: dict) -> None:
    result = {
        "task": "T1_TASK04_CONTROL_MATRIX",
        "status": "FAIL_CONTROL_SCIENTIFIC",
        "protocol_hash": frozen["protocol_hash"],
        "development_gate": gate,
        "confirm_released": False,
        "confirm_evaluated": False,
        "reason": "at least one preregistered development consistency pair failed; confirm remained sealed",
    }
    lines = [
        "# Task04 independent control matrix",
        "",
        "Final status: **FAIL_CONTROL_SCIENTIFIC**",
        "",
        "The preregistered development gate failed, so the 40-case confirm set remained sealed exactly as required.",
        "",
        "| Development comparison | mean ΔR2 consistency | mean ΔR1 Dice | Gate |",
        "|---|---:|---:|---|",
    ]
    for name, value in gate["comparisons"].items():
        lines.append(
            f"| {name} | {value['mean_r2_consistency_difference']:+.4f} | "
            f"{value['mean_r1_dice_difference']:+.4f} | {'PASS' if value['passed'] else 'FAIL'} |"
        )
    lines.extend(("", "No confirm metric was read, tuned against, or reported."))
    write_outputs(result, lines)


def blocked(reason: str) -> None:
    task.append_jsonl(task.ROOT / "ENGINEERING_FAILURES.jsonl", {"at": task.now(), "reason": reason})
    result = {
        "task": "T1_TASK04_CONTROL_MATRIX",
        "status": "BLOCKED_CONTROL_ENGINEERING",
        "reason": reason,
        "finished_at": task.now(),
    }
    write_outputs(
        result,
        ["# Task04 independent control matrix", "", "Final status: **BLOCKED_CONTROL_ENGINEERING**", "", reason],
    )


def complete_report() -> None:
    frozen, release = task.verify_release()
    evaluation_path, metrics_path, performance_path = (
        task.ROOT / "evaluation.json",
        task.ROOT / "metrics.csv",
        task.ROOT / "PERFORMANCE.json",
    )
    if not all(path.is_file() for path in (evaluation_path, metrics_path, performance_path)):
        raise RuntimeError("confirm evaluation or performance evidence is missing")
    evaluation = json.loads(evaluation_path.read_text())
    performance = json.loads(performance_path.read_text())
    task.validate_evaluation(evaluation, frozen, release)
    task.validate_performance(performance, frozen, release)
    rows = read_metrics(metrics_path)
    expected = 40 * 2 * len(task.SEEDS) * len(task.ALL_ARMS) * 3
    identities = {(row["case_id"], row["class"], row["seed"], row["method"], row["spacing"]) for row in rows}
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    case_samples = rng.integers(0, 40, size=(BOOTSTRAP_SAMPLES, 40))
    seed_samples = rng.integers(0, len(task.SEEDS), size=(BOOTSTRAP_SAMPLES, len(task.SEEDS)))
    comparisons = {
        name: {
            metric: contrast(rows, coefficients, spacing, field, case_samples, seed_samples)
            for metric, (spacing, field) in METRICS.items()
        }
        for name, coefficients in CONTRASTS.items()
    }
    method_means = {
        method: {
            metric: float(matrix(rows, method, spacing, field).mean())
            for metric, (spacing, field) in METRICS.items()
        }
        for method in task.ALL_ARMS
    }
    seed_means = {
        method: {
            str(seed): {
                metric: float(matrix(rows, method, spacing, field)[:, index].mean())
                for metric, (spacing, field) in METRICS.items()
            }
            for index, seed in enumerate(task.SEEDS)
        }
        for method in task.ALL_ARMS
    }
    outcomes = {}
    for name in (
        "dynamic_delta_consistency_minus_dynamic_delta",
        "gridcons_mamba_minus_static_delta",
        "unet3d_consistency_minus_unet3d",
    ):
        outcomes[name] = {
            "mean_gain_with_r1_guardrail": comparisons[name]["r2_consistency"]["paired_mean"] > 0
            and comparisons[name]["r1_guardrail"]["paired_mean"] >= -0.01,
            "r2_ci_lower_above_zero": comparisons[name]["r2_consistency"]["hierarchical_ci95"][0] > 0,
            "r1_guardrail_passed": comparisons[name]["r1_guardrail"]["paired_mean"] >= -0.01,
        }
    did_lower = comparisons["mamba_difference_in_differences"]["r2_consistency"]["hierarchical_ci95"][0]
    interpretations = []
    if did_lower <= 0:
        interpretations.append(
            "The Mamba difference-in-differences 95% CI lower bound is not above zero; static delta cannot be claimed as a necessary source of the consistency gain."
        )
    else:
        interpretations.append(
            "The Mamba difference-in-differences supports a larger observed consistency gain for static delta than dynamic delta under this frozen protocol."
        )
    unet_pass = outcomes["unet3d_consistency_minus_unet3d"]["mean_gain_with_r1_guardrail"]
    gridcons_pass = outcomes["gridcons_mamba_minus_static_delta"]["mean_gain_with_r1_guardrail"]
    if unet_pass:
        interpretations.append(
            "The U-Net control passes: consistency has a cross-backbone effect, so the full gain cannot be attributed to Mamba."
        )
    elif gridcons_pass:
        interpretations.append("Observed architecture-related interaction.")
    else:
        interpretations.append("Neither the U-Net control nor GridCons passes its frozen mean-gain and R1-guardrail rule.")
    logs = [
        json.loads(task.checkpoint_paths(arm, seed)[1].read_text()) for arm in task.NEW_ARMS for seed in task.SEEDS
    ]
    training_resources = {
        arm: {
            "gpu_seconds_sum": float(sum(item["gpu_seconds"] for item in logs if item["arm"] == arm)),
            "peak_allocated_bytes_max": max(item["peak_allocated_bytes"] for item in logs if item["arm"] == arm),
            "peak_reserved_bytes_max": max(item["peak_reserved_bytes"] for item in logs if item["arm"] == arm),
        }
        for arm in task.NEW_ARMS
    }
    validity_gates = {
        "protocol_and_source_hashes_unchanged": True,
        "development_gate_released_exact_checkpoints": True,
        "all_15_new_training_runs_complete": len(logs) == 15 and all(item.get("completed") for item in logs),
        "r2_labels_excluded_from_training_and_selection": all(
            item.get("r2_label_loaded_for_training_or_selection") is False for item in logs
        ),
        "confirm_7200_rows_complete": len(rows) == expected == evaluation.get("rows"),
        "confirm_metric_identities_exact": identities == task.expected_confirm_identities(list(task.ALL_ARMS)),
        "confirm_evaluation_has_no_failures": not evaluation.get("failures"),
        "confirm_metrics_hash_matches": evaluation.get("metrics_sha256") == task.sha256(metrics_path),
        "all_metrics_finite": all(
            np.isfinite(value)
            for row in rows
            for key, value in row.items()
            if key.endswith("dice") or key == "surface_dice_2mm"
        ),
        "all_six_performance_records_complete": set(performance.get("records", {})) == set(task.ALL_ARMS),
        "benchmark_protocol_matches_frozen": performance.get("protocol") == frozen["benchmark"],
        "evaluation_bound_to_current_release": evaluation.get("confirm_release") == release,
        "performance_bound_to_current_release_and_checkpoints": performance.get("confirm_release") == release
        and performance.get("new_checkpoint_sha256") == release["checkpoint_sha256"],
    }
    if not all(validity_gates.values()):
        raise RuntimeError(f"validity gate failed: {[key for key, value in validity_gates.items() if not value]}")
    result = {
        "task": "T1_TASK04_CONTROL_MATRIX",
        "status": "PASS_CONTROL_EVIDENCE_COMPLETE",
        "protocol_hash": frozen["protocol_hash"],
        "method_means": method_means,
        "seed_means": seed_means,
        "comparisons": comparisons,
        "outcome_flags": outcomes,
        "interpretations": interpretations,
        "performance": performance,
        "training_resources": training_resources,
        "evaluation": evaluation,
        "validity_gates": validity_gates,
        "source_file_sha256": frozen["source_file_sha256"],
        "source_checkpoint_sha256": frozen["source_checkpoint_sha256"],
        "finished_at": task.now(),
    }

    def cell(value: dict) -> str:
        ci = value["hierarchical_ci95"]
        return f"{value['paired_mean']:+.4f} [{ci[0]:+.4f}, {ci[1]:+.4f}]"

    lines = [
        "# Task04 independent control matrix",
        "",
        "Final status: **PASS_CONTROL_EVIDENCE_COMPLETE**",
        "",
        "All confirm values are paired over 40 cases × 5 seeds. Confidence intervals use the frozen hierarchical paired bootstrap over cases and seeds.",
        "",
        "## Arm means",
        "",
        "| Arm | R1 Dice | R2 consistency | R2 mapped Dice | R2 surface Dice@2mm | R4 consistency |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for method in task.ALL_ARMS:
        value = method_means[method]
        lines.append(
            f"| {method} | {value['r1_guardrail']:.4f} | {value['r2_consistency']:.4f} | "
            f"{value['r2_mapped_dice']:.4f} | {value['r2_surface_dice_2mm']:.4f} | {value['r4_consistency']:.4f} |"
        )
    lines.extend(
        (
            "",
            "## Required paired comparisons",
            "",
            "| Comparison | R2 consistency | R2 mapped Dice | R2 surface@2mm | R1 guardrail | R4 consistency |",
            "|---|---:|---:|---:|---:|---:|",
        )
    )
    for name, value in comparisons.items():
        lines.append(
            f"| {name} | {cell(value['r2_consistency'])} | {cell(value['r2_mapped_dice'])} | "
            f"{cell(value['r2_surface_dice_2mm'])} | {cell(value['r1_guardrail'])} | {cell(value['r4_consistency'])} |"
        )
    lines.extend(("", "## Five-seed paired differences", ""))
    for name, value in comparisons.items():
        lines.append(f"- `{name}` R2 consistency: {value['r2_consistency']['seed_differences']}")
        lines.append(f"- `{name}` R1 guardrail: {value['r1_guardrail']['seed_differences']}")
    lines.extend(
        (
            "",
            "## Parameters, batch-1 latency, and peak allocated memory",
            "",
            "Same R1 development case, GPU, bfloat16, batch=1, 20 warmups, 100 synchronized iterations for every arm.",
            f"Hardware: {frozen['environment']['gpu']}; {frozen['environment']['nvidia_smi'][0]}.",
            "",
            "| Arm | Parameters | Mean latency (ms) | Median (ms) | p95 (ms) | Peak allocated (bytes) |",
            "|---|---:|---:|---:|---:|---:|",
        )
    )
    for method in task.ALL_ARMS:
        value = performance["records"][method]
        lines.append(
            f"| {method} | {value['parameters']} | {value['latency_ms_mean']:.3f} | "
            f"{value['latency_ms_median']:.3f} | {value['latency_ms_p95']:.3f} | {value['peak_allocated_bytes']} |"
        )
    lines.extend(("", "## Frozen interpretation", ""))
    lines.extend(f"- {item}" for item in interpretations)
    lines.extend(("", "## Validity gates", ""))
    lines.extend(f"- {name}: PASS" for name in validity_gates)
    write_outputs(result, lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--blocked-reason")
    args = parser.parse_args()
    if args.blocked_reason:
        blocked(args.blocked_reason)
        return
    frozen = task.verify_protocol()
    gate_path = task.ROOT / "DEVELOPMENT_GATE.json"
    if not gate_path.is_file():
        raise RuntimeError("development gate is missing")
    gate = json.loads(gate_path.read_text())
    task.validate_development_gate(gate)
    if gate.get("release_confirm") is not True:
        stale_confirm = [
            path.name
            for path in (
                task.ROOT / "CONFIRM_RELEASE.json",
                task.ROOT / "evaluation.json",
                task.ROOT / "metrics.csv",
                task.ROOT / "PERFORMANCE.json",
            )
            if path.exists()
        ]
        if stale_confirm:
            raise RuntimeError(f"failed development gate has stale confirm artifacts: {stale_confirm}")
        development_failure(frozen, gate)
    else:
        complete_report()


if __name__ == "__main__":
    main()
