#!/usr/bin/env python
"""Audit the official MSD Task09_Spleen archive before any model work."""

from __future__ import annotations

import csv
import hashlib
import json
import subprocess
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import nibabel as nib
import numpy as np


ROOT = Path(__file__).resolve().parent
DATA = Path("/home/yanjingjia/data/Task09_Spleen")
ARCHIVE = DATA / "Task09_Spleen.tar"
DATASET_JSON = DATA / "dataset.json"
PROMPT2 = Path("/home/yanjingjia/gridcons_followup_20260720/01_task04_control_matrix")
EXPECTED_BYTES = 1_610_352_640
EXPECTED_MD5 = "410d4a301da4e5b2f6f86ec3ddba524e"
ARCHIVE_URL = "https://msd-for-monai.s3-us-west-2.amazonaws.com/Task09_Spleen.tar"


def digest(path: Path, algorithm: str = "sha256") -> str:
    value = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            value.update(chunk)
    return value.hexdigest()


def object_hash(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def dump_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def verify_prompt2() -> tuple[str, bool]:
    status = json.loads((PROMPT2 / "CONTROL_RESULTS.json").read_text())["status"]
    check = subprocess.run(
        ["sha256sum", "-c", "SHA256SUMS"], cwd=PROMPT2, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    return status, check.returncode == 0


def case_id(path: Path) -> str:
    name = path.name
    if not name.endswith(".nii.gz"):
        raise ValueError(path)
    return name[:-7]


def duplicates(values: list[str]) -> list[str]:
    return sorted({value for value in values if values.count(value) > 1})


def audit_nifti(image_path: Path, label_path: Path) -> tuple[dict, list[str]]:
    image = nib.load(image_path)
    label = nib.load(label_path)
    image_data = np.asanyarray(image.dataobj)
    label_data = np.asanyarray(label.dataobj)
    labels = np.unique(label_data).tolist()
    row = {
        "case_id": case_id(image_path),
        "image_path": str(image_path),
        "label_path": str(label_path),
        "image_sha256": digest(image_path),
        "label_sha256": digest(label_path),
        "image_shape_xyz": json.dumps(list(image.shape)),
        "label_shape_xyz": json.dumps(list(label.shape)),
        "image_affine_xyz": json.dumps(np.asarray(image.affine).tolist(), separators=(",", ":")),
        "label_affine_xyz": json.dumps(np.asarray(label.affine).tolist(), separators=(",", ":")),
        "image_orientation": "".join(nib.aff2axcodes(image.affine)),
        "label_orientation": "".join(nib.aff2axcodes(label.affine)),
        "spacing_x": float(image.header.get_zooms()[0]),
        "spacing_y": float(image.header.get_zooms()[1]),
        "spacing_z": float(image.header.get_zooms()[2]),
        "label_spacing_x": float(label.header.get_zooms()[0]),
        "label_spacing_y": float(label.header.get_zooms()[1]),
        "label_spacing_z": float(label.header.get_zooms()[2]),
        "image_qform_code": int(image.header["qform_code"]),
        "image_sform_code": int(image.header["sform_code"]),
        "label_qform_code": int(label.header["qform_code"]),
        "label_sform_code": int(label.header["sform_code"]),
        "geometry_match": bool(image.shape == label.shape and np.allclose(image.affine, label.affine, atol=1e-5)),
        "affine_finite_nonsingular": bool(
            np.isfinite(image.affine).all() and abs(np.linalg.det(np.asarray(image.affine)[:3, :3])) > 1e-8
        ),
        "image_finite": bool(np.isfinite(image_data).all()),
        "label_values": json.dumps(labels),
        "foreground_voxels": int((label_data == 1).sum()),
    }
    errors = []
    if image.ndim != 3 or label.ndim != 3:
        errors.append("not_3d")
    if not row["geometry_match"]:
        errors.append("image_label_geometry_mismatch")
    if not row["affine_finite_nonsingular"]:
        errors.append("invalid_affine")
    if not row["image_finite"]:
        errors.append("nonfinite_image")
    if labels not in ([0, 1], [1]):
        errors.append(f"invalid_label_values:{labels}")
    if row["foreground_voxels"] <= 0:
        errors.append("empty_spleen_label")
    return row, errors


def axis_summary(values: np.ndarray) -> dict[str, float]:
    q1, q3 = np.quantile(values, (0.25, 0.75))
    return {
        "min": float(values.min()),
        "median": float(np.median(values)),
        "max": float(values.max()),
        "q1": float(q1),
        "q3": float(q3),
        "iqr": float(q3 - q1),
    }


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    prompt2_status, prompt2_hashes_ok = verify_prompt2()
    dataset = json.loads(DATASET_JSON.read_text()) if DATASET_JSON.is_file() else {}
    listed = dataset.get("training", [])
    listed_image_ids = [case_id(DATA / item["image"].removeprefix("./")) for item in listed]
    listed_label_ids = [case_id(DATA / item["label"].removeprefix("./")) for item in listed]
    image_paths = sorted((DATA / "imagesTr").glob("*.nii.gz"))
    label_paths = sorted((DATA / "labelsTr").glob("*.nii.gz"))
    images = {case_id(path): path for path in image_paths}
    labels = {case_id(path): path for path in label_paths}
    paired_ids = sorted(set(images) & set(labels))

    rows, nifti_errors = [], {}
    for number, identifier in enumerate(paired_ids, 1):
        row, errors = audit_nifti(images[identifier], labels[identifier])
        rows.append(row)
        if errors:
            nifti_errors[identifier] = errors
        print(f"audited {number}/{len(paired_ids)} {identifier}", flush=True)

    fields = list(rows[0]) if rows else []
    with (ROOT / "SPACING_AUDIT.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    spacing = np.asarray([[row[f"spacing_{axis}"] for axis in "xyz"] for row in rows], dtype=np.float64)
    triplets = sorted({tuple(round(float(value), 6) for value in item) for item in spacing})
    spacing_summary = {
        "units": "millimetres",
        "axis_order": "NIfTI voxel XYZ",
        "unique_triplet_count": len(triplets),
        "unique_triplets_xyz": [list(item) for item in triplets],
        "x": axis_summary(spacing[:, 0]),
        "y": axis_summary(spacing[:, 1]),
        "z": axis_summary(spacing[:, 2]),
    }
    image_hashes, label_hashes = defaultdict(list), defaultdict(list)
    for row in rows:
        image_hashes[row["image_sha256"]].append(row["case_id"])
        label_hashes[row["label_sha256"]].append(row["case_id"])
    duplicate_content = {
        "images": [ids for ids in image_hashes.values() if len(ids) > 1],
        "labels": [ids for ids in label_hashes.values() if len(ids) > 1],
    }
    checks = {
        "prompt2_terminal_complete": prompt2_status == "PASS_CONTROL_EVIDENCE_COMPLETE",
        "prompt2_sha256sums_valid": prompt2_hashes_ok,
        "archive_exists": ARCHIVE.is_file(),
        "archive_bytes_match_official": ARCHIVE.is_file() and ARCHIVE.stat().st_size == EXPECTED_BYTES,
        "archive_md5_matches_official": ARCHIVE.is_file() and digest(ARCHIVE, "md5") == EXPECTED_MD5,
        "dataset_json_present": DATASET_JSON.is_file(),
        "license_clear": dataset.get("licence") == "CC-BY-SA 4.0",
        "label_definition_exact": dataset.get("labels") == {"0": "background", "1": "spleen"},
        "at_least_40_labeled_cases": len(paired_ids) >= 40,
        "declared_41_training_cases": dataset.get("numTraining") == 41,
        "listed_pairs_unique": not duplicates(listed_image_ids) and not duplicates(listed_label_ids),
        "listed_image_label_ids_match": listed_image_ids == listed_label_ids,
        "listed_and_extracted_images_match": set(listed_image_ids) == set(images),
        "listed_and_extracted_labels_match": set(listed_label_ids) == set(labels),
        "all_image_label_pairs_present": set(images) == set(labels),
        "no_duplicate_file_content": not duplicate_content["images"] and not duplicate_content["labels"],
        "all_nifti_checks_pass": not nifti_errors,
        "challenge_test_labels_absent": not (DATA / "labelsTs").exists(),
        "five_fold_case_disjoint_split_feasible": len(paired_ids) >= 40,
        "independent_from_task04": dataset.get("name") == "Spleen" and "Task09_Spleen" in str(DATA),
    }
    real_spacing = len(triplets) >= 2
    status = "PASS_EXTERNAL_DATA_GATE" if all(checks.values()) else "BLOCKED_EXTERNAL_DATA_GATE"
    audit = {
        "task": "T2_EXTERNAL_REAL_SPACING_VALIDATION",
        "status": status,
        "generated_at": datetime.now().astimezone().isoformat(),
        "INDEPENDENT_DATASET": checks["independent_from_task04"],
        "REAL_HETEROGENEOUS_SPACING": real_spacing,
        "SYNTHETIC_PAIRED_GRID_ON_EXTERNAL_DATA": not real_spacing,
        "training_allowed": status == "PASS_EXTERNAL_DATA_GATE",
        "source": {
            "official_dataset_page": "https://medicaldecathlon.com/",
            "official_aws_registry": "https://registry.opendata.aws/msd/",
            "archive_url": ARCHIVE_URL,
            "archive_path": str(ARCHIVE),
            "archive_bytes": ARCHIVE.stat().st_size if ARCHIVE.is_file() else None,
            "archive_md5": digest(ARCHIVE, "md5") if ARCHIVE.is_file() else None,
            "archive_sha256": digest(ARCHIVE) if ARCHIVE.is_file() else None,
            "license": dataset.get("licence"),
            "citation": "Antonelli et al., The Medical Segmentation Decathlon, Nature Communications 13, 4128 (2022)",
            "citation_doi": "https://doi.org/10.1038/s41467-022-30695-9",
            "dataset_json_sha256": digest(DATASET_JSON) if DATASET_JSON.is_file() else None,
        },
        "dataset": {
            "name": dataset.get("name"),
            "description": dataset.get("description"),
            "reference": dataset.get("reference"),
            "modality": dataset.get("modality"),
            "labels": dataset.get("labels"),
            "labeled_case_count": len(paired_ids),
            "challenge_test_image_count": len(list((DATA / "imagesTs").glob("*.nii.gz"))),
            "challenge_test_used": False,
            "case_ids": paired_ids,
        },
        "spacing": spacing_summary,
        "duplicates_or_conflicts": {
            "listed_image_ids": duplicates(listed_image_ids),
            "listed_label_ids": duplicates(listed_label_ids),
            "duplicate_content": duplicate_content,
            "nifti_errors": nifti_errors,
        },
        "checks": checks,
        "prompt2": {
            "root": str(PROMPT2),
            "status": prompt2_status,
            "control_results_sha256": digest(PROMPT2 / "CONTROL_RESULTS.json"),
            "sha256sums_sha256": digest(PROMPT2 / "SHA256SUMS"),
            "read_only": True,
        },
    }
    audit["audit_hash"] = object_hash(audit)
    dump_json(ROOT / "SPACING_AUDIT.json", {"rows": rows, "summary": spacing_summary, "audit_hash": audit["audit_hash"]})
    dump_json(ROOT / "DATA_GATE.json", audit)
    markdown = [
        "# External data gate",
        "",
        f"Status: **{status}**",
        "",
        f"- Official archive: `{ARCHIVE_URL}`",
        f"- License: `{dataset.get('licence')}`",
        f"- Archive bytes: `{audit['source']['archive_bytes']}`",
        f"- Archive SHA-256: `{audit['source']['archive_sha256']}`",
        f"- Labeled image/label pairs: `{len(paired_ids)}`",
        f"- Labels: `{dataset.get('labels')}`",
        f"- INDEPENDENT_DATASET: `{audit['INDEPENDENT_DATASET']}`",
        f"- REAL_HETEROGENEOUS_SPACING: `{real_spacing}`",
        f"- Unique spacing triplets: `{len(triplets)}`",
        "",
        "## Spacing summary (mm, NIfTI XYZ)",
        "",
        "| Axis | min | median | max | IQR |",
        "|---|---:|---:|---:|---:|",
    ]
    for axis in "xyz":
        value = spacing_summary[axis]
        markdown.append(
            f"| {axis.upper()} | {value['min']:.6g} | {value['median']:.6g} | {value['max']:.6g} | {value['iqr']:.6g} |"
        )
    markdown += [
        "",
        "## Checks",
        "",
        *[f"- {name}: {'PASS' if passed else 'FAIL'}" for name, passed in checks.items()],
        "",
        "Citation: Antonelli et al. (2022), *The Medical Segmentation Decathlon*, Nature Communications 13, 4128, doi:10.1038/s41467-022-30695-9.",
    ]
    (ROOT / "DATA_GATE.md").write_text("\n".join(markdown) + "\n")
    if status != "PASS_EXTERNAL_DATA_GATE":
        (ROOT / "EXTERNAL_STATUS.txt").write_text("BLOCKED_EXTERNAL_DATA_GATE\n")
        raise SystemExit(2)
    print(json.dumps({"status": status, "spacing": spacing_summary}, indent=2))


if __name__ == "__main__":
    main()
