"""Frozen plain four-level 3D U-Net control."""

from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class DoubleConv(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int):
        super().__init__(
            nn.Conv3d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.InstanceNorm3d(out_channels, affine=True, track_running_stats=False),
            nn.ReLU(inplace=True),
            nn.Conv3d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.InstanceNorm3d(out_channels, affine=True, track_running_stats=False),
            nn.ReLU(inplace=True),
        )


class PlainUNet3D(nn.Module):
    """No attention, Mamba, Transformer, dropout, or task-specific modules."""

    def __init__(self, out_channels: int):
        super().__init__()
        self.encoder1 = DoubleConv(1, 16)
        self.encoder2 = DoubleConv(16, 32)
        self.encoder3 = DoubleConv(32, 64)
        self.encoder4 = DoubleConv(64, 128)
        self.pool = nn.MaxPool3d(2)
        self.up3 = nn.ConvTranspose3d(128, 64, 2, stride=2)
        self.decoder3 = DoubleConv(128, 64)
        self.up2 = nn.ConvTranspose3d(64, 32, 2, stride=2)
        self.decoder2 = DoubleConv(64, 32)
        self.up1 = nn.ConvTranspose3d(32, 16, 2, stride=2)
        self.decoder1 = DoubleConv(32, 16)
        self.head = nn.Conv3d(16, out_channels, 1)

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        original = image.shape[2:]
        padding = tuple(value for size in reversed(original) for value in (0, (-size) % 8))
        image = F.pad(image, padding)
        e1 = self.encoder1(image)
        e2 = self.encoder2(self.pool(e1))
        e3 = self.encoder3(self.pool(e2))
        e4 = self.encoder4(self.pool(e3))
        d3 = self.decoder3(torch.cat((self.up3(e4), e3), 1))
        d2 = self.decoder2(torch.cat((self.up2(d3), e2), 1))
        d1 = self.decoder1(torch.cat((self.up1(d2), e1), 1))
        return self.head(d1)[:, :, : original[0], : original[1], : original[2]]


def parameter_count(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
