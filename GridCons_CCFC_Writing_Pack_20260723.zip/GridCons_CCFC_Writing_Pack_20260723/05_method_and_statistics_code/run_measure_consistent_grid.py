#!/usr/bin/env python
"""Preregistered audit and four-arm pilot for conservative voxel-cell transport."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from conservative_transport import conservative_axial_transport, soft_segmentation_loss
from model import TinyMetricMamba, parameter_count
from physical_resampler import AffineResampler3D
from run_grid_causal_audit import (
    Context as CausalContext,
    case_summary,
    evaluate_model as evaluate_causal_model,
    frozen_schedule,
    seed_all,
    sha256,
    verify_frozen,
)
from run_physgrid_pilot import (
    binary_dice,
    crop5,
    disagreement,
    load_grid,
    load_raw_image,
    loss_fn,
    model_logits,
    normalize_candidate,
    pad4,
    surface_dice,
    target_grid,
)


ARMS = ("R", "P", "H", "O")
TRAINABLE = ("P", "H", "O")
SPACINGS = (1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0)
DIAGNOSTIC_SPACINGS = (1.5, 2.0, 3.0, 4.0, 5.0)
UPDATES = 2500
BOOTSTRAPS = 10_000
BOOTSTRAP_SEED = 7321


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def object_hash(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def require_cuda() -> torch.device:
    if os.environ.get("CUDA_VISIBLE_DEVICES") != "0" or not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly CUDA_VISIBLE_DEVICES=0 is required")
    return torch.device("cuda:0")


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"no rows for {path}")
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


class Context:
    def __init__(self, args: argparse.Namespace):
        self.causal = CausalContext(args)
        self.project = self.causal.project; self.data = self.causal.data; self.legacy = self.causal.legacy
        self.previous = self.causal.previous; self.manifest = self.causal.manifest
        self.output = args.output_root.resolve() / "measure_consistent_grid"
        if self.output in (self.project, self.data, self.legacy, self.previous, self.causal.output):
            raise RuntimeError("independent output directory required")

    def checkpoint(self, arm: str, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / "checkpoints" / f"{arm}_seed17.pt"

    def log(self, arm: str, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / f"train_{arm}_seed17.json"


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    for name in ("project-root", "data-root", "legacy-root", "previous-output", "output-root"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("setup")
    sub.add_parser("unit-tests")
    sub.add_parser("optimization-audit")
    sub.add_parser("diagnostic")
    sub.add_parser("smoke")
    train_parser = sub.add_parser("train"); train_parser.add_argument("--arm", choices=TRAINABLE, required=True)
    sub.add_parser("evaluate")
    sub.add_parser("report")
    sub.add_parser("full-pilot")
    return parser.parse_args()


def record_command(ctx: Context) -> None:
    ctx.output.mkdir(parents=True, exist_ok=True)
    with (ctx.output / "command_ledger.jsonl").open("a") as handle:
        handle.write(json.dumps({"argv": sys.argv, "cwd": str(Path.cwd()), "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"), "time_unix": time.time()}, sort_keys=True) + "\n")


def setup(ctx: Context) -> None:
    development, deny = verify_frozen(ctx.causal)
    ctx.output.mkdir(parents=True, exist_ok=True)
    schedule_source = ctx.causal.output / "grid_schedule_seed17.jsonl"
    schedule_target = ctx.output / "grid_schedule_seed17.jsonl"
    if schedule_target.exists() or schedule_target.is_symlink():
        if schedule_target.resolve() != schedule_source.resolve():
            raise RuntimeError("wrong existing schedule alias")
    else:
        schedule_target.symlink_to(schedule_source)
    r_source, r_target = ctx.causal.checkpoint("random_k1", 17), ctx.checkpoint("R")
    r_target.parent.mkdir(parents=True, exist_ok=True)
    if r_target.exists() or r_target.is_symlink():
        if r_target.resolve() != r_source.resolve(): raise RuntimeError("wrong R checkpoint alias")
    else: r_target.symlink_to(r_source)
    dump_json(ctx.output / "confirm_denylist.json", {"algorithm": "sha256(case_id UTF-8)", "count": len(deny), "hashes": sorted(deny), "confirm_v2_data_accessed": False})
    protocol = {
        "name": "Measure-Consistent Grid Training pilot", "seed": 17, "updates": UPDATES,
        "arms": {
            "R": "frozen Random-K1: R1 prediction, candidate-to-R1 trilinear point consistency",
            "P": "R1 prediction conservatively pushed to one native random grid; native-grid consistency",
            "H": "R1 label nearest-neighbor resampled to one native random grid; ordinary hard supervision",
            "O": "R1 one-hot label conservatively pushed to one native random grid; occupancy supervision",
        },
        "shared": {"backbone": "Static Mamba", "parameters": 99411, "optimizer": "AdamW", "lr": 3e-4, "weight_decay": 1e-5, "batch_size": 1, "amp": "bfloat16", "augmentation": "none", "lambda_max": 0.1, "warmup_updates": 500, "checkpoint_rule": "R1 validation foreground Dice only; ties earliest", "schedule": "Random-K1 spacing_1 from frozen seed17 schedule"},
        "diagnostic_gate_frozen_before_computation": {
            "coarse_mixed_cell_increase": "min(median R4,R5) >= median R2 + 0.05",
            "coarse_nn_occupancy_disagreement": "min(median R4,R5) >= 0.02",
            "nontrivial_volume_bias": "max coarse median absolute relative NN or trilinear class-volume error >= 0.01",
            "checkpoint_direction": "for both frozen C and D, conservative median absolute class-volume error is lower than trilinear at both R4 and R5",
            "integrity": "finite; probability error <=1e-5; conservative foreground volume relative error <=1e-5",
        },
        "scientific_gate": {"Extra_Dmap": 0.010, "Extra_Smap": 0.015, "Worst_Dmap": 0.010, "Dnative_floor": -0.005, "positive_cases": 13, "ci80_lower": 0.0, "cost_ratio_max": 1.15},
        "forbidden": ["K2", "soft-worst", "Physical-Step", "GridREx", "EMA", "boundary loss", "new backbone", "learned resampler", "post-hoc P+O"],
        "bootstrap": {"iterations": BOOTSTRAPS, "seed": BOOTSTRAP_SEED, "unit": "case"},
        "confirm_v2_data_accessed": False, "development_cases": len(development),
        "manifest_sha256": sha256(ctx.causal.manifest_path), "causal_schedule_sha256": sha256(schedule_source),
        "frozen_checkpoint_sha256": {
            "R_random_k1_seed17": sha256(r_source),
            **{f"{arm}_seed{seed}": sha256(ctx.causal.checkpoint(arm, seed)) for arm in ("random_k1", "random_k2", "soft_worst_random") for seed in (29, 41)},
        },
        "source_sha256": {x: sha256(ctx.project / x) for x in ("model.py", "physical_resampler.py", "run_physgrid_pilot.py", "run_grid_causal_audit.py", "conservative_transport.py", "run_measure_consistent_grid.py", "test_measure_consistent_grid.py")},
    }
    dump_json(ctx.output / "protocol.json", protocol)
    common = f"--project-root {ctx.project} --data-root {ctx.data} --legacy-root {ctx.legacy} --previous-output {ctx.previous} --output-root {ctx.output.parent}"
    lines = ["#!/usr/bin/env bash", "set -euo pipefail", "export CUDA_VISIBLE_DEVICES=0", "export PYTHONDONTWRITEBYTECODE=1", f"PYTHON={sys.executable}", f"$PYTHON {Path(__file__)} {common} unit-tests", f"$PYTHON {Path(__file__)} {common} optimization-audit", f"$PYTHON {Path(__file__)} {common} diagnostic", "test \"$(python -c 'import json; print(json.load(open(\"/home/yanjingjia/measure_consistent_grid/diagnostic_decision.json\"))[\"decision\"])')\" = GO_MEASURE_IMPLEMENTATION", f"$PYTHON {Path(__file__)} {common} smoke"]
    lines += [f"$PYTHON {Path(__file__)} {common} train --arm {arm}" for arm in TRAINABLE]
    lines += [f"$PYTHON {Path(__file__)} {common} evaluate", f"$PYTHON {Path(__file__)} {common} report"]
    reproduce = ctx.output / "reproduce_pilot.sh"; reproduce.write_text("\n".join(lines) + "\n"); reproduce.chmod(0o755)
    subprocess.run(["nvidia-smi"], stdout=(ctx.output / "nvidia_smi.txt").open("w"), text=True, check=True)
    subprocess.run([sys.executable, "-m", "pip", "freeze"], stdout=(ctx.output / "environment_freeze.txt").open("w"), text=True, check=True)


def load_frozen_schedule(ctx: Context, smoke: bool = False) -> list[dict]:
    if smoke:
        return frozen_schedule(ctx.manifest["split"]["train"][:2], 17, 20)
    rows = [json.loads(line) for line in (ctx.output / "grid_schedule_seed17.jsonl").read_text().splitlines()]
    if len(rows) != UPDATES: raise RuntimeError("frozen schedule length mismatch")
    return rows


def optimization_audit(ctx: Context) -> None:
    device = require_cuda(); _, deny = verify_frozen(ctx.causal)
    summaries = []
    with (ctx.causal.output / "metrics_case_summary.csv").open() as handle:
        summaries += [x for x in csv.DictReader(handle) if x["arm"] in ("random_k1", "random_k2", "soft_worst_random")]
    with (ctx.causal.output / "dc_three_seed_case_summary.csv").open() as handle:
        summaries += [x for x in csv.DictReader(handle) if int(x["seed"]) in (29, 41)]
    for seed in (29, 41):
        log = json.loads(ctx.causal.log("random_k1", seed).read_text())
        if not log.get("completed") or log["checkpoint_sha256"] != sha256(ctx.causal.checkpoint("random_k1", seed)):
            raise RuntimeError(f"Random-K1 seed {seed} incomplete")
        summaries += case_summary(evaluate_causal_model(ctx.causal, "random_k1", seed, device, deny))
    summaries = [{**x, "seed": int(x["seed"]), **{k: float(x[k]) for k in x.keys() - {"arm", "case_id", "seed"}}} for x in summaries]
    # Remove duplicate arm/seed/case rows deterministically.
    summaries = list({(x["arm"], int(x["seed"]), x["case_id"]): {**x, "seed": int(x["seed"])} for x in summaries}.values())
    write_csv(ctx.output / "k1_k2_three_seed_case_summary.csv", summaries)
    comparisons = {}
    for seed in (17, 29, 41):
        k1 = {x["case_id"]: float(x["extrapolation_Dmap"]) for x in summaries if x["arm"] == "random_k1" and int(x["seed"]) == seed}
        comparisons[str(seed)] = {}
        for control, key in (("random_k2", "K1_minus_K2"), ("soft_worst_random", "K1_minus_soft_worst")):
            baseline = {x["case_id"]: float(x["extrapolation_Dmap"]) for x in summaries if x["arm"] == control and int(x["seed"]) == seed}
            ids = sorted(k1); values = np.asarray([k1[x] - baseline[x] for x in ids]); rng = np.random.default_rng(BOOTSTRAP_SEED + seed)
            means = np.asarray([values[rng.integers(0, len(values), len(values))].mean() for _ in range(BOOTSTRAPS)])
            comparisons[str(seed)][key] = {"extra_Dmap": float(values.mean()), "positive_cases": int((values > 0).sum()), "ci80": np.quantile(means, [0.1, 0.9]).tolist(), "ci95": np.quantile(means, [0.025, 0.975]).tolist()}
    scaling = {}
    for seed in (17, 29, 41):
        k1 = json.loads(ctx.causal.log("random_k1", seed).read_text())["history"]
        if seed == 17:
            prior = json.loads((ctx.previous / "train_randomgrid_mean_seed17.json").read_text())["history"]
            schedule = frozen_schedule(ctx.manifest["split"]["train"], 17)
            k2 = [{"case_id_hash": hashlib.sha256(item["case_id"].encode()).hexdigest(), "requested_spacings": row["sampled_spacing_requested"], "lambda": row["effective_consistency_weight"], "auxiliary_loss": row["consistency_loss"], "auxiliary_losses": row["grid_errors"], "gradient_norm": row["gradient_norm"]} for item, row in zip(schedule, prior)]
        else:
            k2 = json.loads(ctx.causal.log("random_k2", seed).read_text())["history"]
        scaling[str(seed)] = {
            "updates": len(k1), "case_order_equal": [x["case_id_hash"] for x in k1] == [x["case_id_hash"] for x in k2],
            "spacing_1_equal": all(abs(x["requested_spacings"][0] - y["requested_spacings"][0]) < 1e-12 for x, y in zip(k1, k2)),
            "lambda_equal": all(abs(x["lambda"] - y["lambda"]) < 1e-12 for x, y in zip(k1, k2)),
            "K1_single_loss_max_error": max(abs(x["auxiliary_loss"] - x["auxiliary_losses"][0]) for x in k1),
            "K2_mean_loss_max_error": max(abs(x["auxiliary_loss"] - float(np.mean(x["auxiliary_losses"]))) for x in k2),
            "K1_training_gradient_norm_mean": float(np.mean([x["gradient_norm"] for x in k1])),
            "K2_training_gradient_norm_mean": float(np.mean([x["gradient_norm"] for x in k2])),
        }
    auxiliary_gradients = auxiliary_gradient_audit(ctx, device)
    result = {"theoretical_target": "K1 and IID K2-mean optimize the same expected auxiliary objective", "comparisons": comparisons, "K1_beats_K2_all_three_point_estimates": all(x["K1_minus_K2"]["extra_Dmap"] > 0 for x in comparisons.values()), "loss_scaling_and_schedule": scaling, "auxiliary_gradient_norm_diagnostic": auxiliary_gradients}
    dump_json(ctx.output / "optimization_audit.json", result)
    lines = ["# Random-K1/K2 optimization audit", "", "K1 and IID K2-mean optimize the same expected objective. Differences are attributed only to stochastic-gradient variance, compute, and optimization trajectory.", "", "| seed | K1-K2 Extra Dmap | CI80 | positive cases |", "|---:|---:|---:|---:|"]
    for seed, values in comparisons.items():
        x = values["K1_minus_K2"]; lines.append(f"| {seed} | {x['extra_Dmap']:+.6f} | [{x['ci80'][0]:+.6f}, {x['ci80'][1]:+.6f}] | {x['positive_cases']}/20 |")
    lines += ["", f"K1 point estimate exceeded K2 in all three seeds: {result['K1_beats_K2_all_three_point_estimates']}", "", "K2 auxiliary loss was explicitly verified as the arithmetic mean; effective lambda and spacing_1/case schedules matched K1."]
    (ctx.output / "optimization_audit.md").write_text("\n".join(lines) + "\n")


def auxiliary_gradient_audit(ctx: Context, device: torch.device) -> dict:
    resampler = AffineResampler3D(); result = {}
    for seed in (17, 29, 41):
        seed_all(seed); model = TinyMetricMamba("separated_physical_delta").to(device).train(); parameters = tuple(model.parameters())
        schedule = frozen_schedule(ctx.manifest["split"]["train"], seed)[:5]; norms = {"K1": [], "K2_mean": []}
        for item in schedule:
            case_id = item["case_id"]; case = ctx.manifest["cases"][case_id]; r1 = case["grids"]["R1"]; shape = r1["unpadded_shape_dhw"]
            image, _ = load_grid(ctx.causal, case_id, "R1"); affine = torch.tensor(r1["affine_xyz"], dtype=torch.float64, device=device); raw, raw_affine = load_raw_image(ctx.causal, case_id, device)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                teacher = crop5(model_logits(model, torch.from_numpy(image).to(device)[None, None], [1, 1, 1]), shape).float().softmax(1)[:, 1:].detach(); errors = []
                for spacing in (item["spacing_1"], item["spacing_2"]):
                    target_shape, target_affine, actual = target_grid(affine, shape, spacing); raw_candidate = resampler.image(raw, raw_affine, target_shape, target_affine)
                    candidate = pad4(normalize_candidate(raw_candidate, case["r1_nonbackground_mean"], case["r1_nonbackground_std"]))
                    probability = crop5(model_logits(model, candidate, [actual, 1, 1]), target_shape).float().softmax(1)
                    errors.append(disagreement(teacher, resampler.probability(probability, target_affine, shape, affine)[:, 1:]))
            for name, loss, retain in (("K1", errors[0], True), ("K2_mean", torch.stack(errors).mean(), False)):
                gradients = torch.autograd.grad(loss, parameters, retain_graph=retain, allow_unused=True)
                norms[name].append(float(torch.sqrt(sum(x.float().square().sum() for x in gradients if x is not None))))
        result[str(seed)] = {name: {"mean": float(np.mean(values)), "std": float(np.std(values)), "values": values} for name, values in norms.items()}
    return result


def relative_volume_errors(source: torch.Tensor, candidate: torch.Tensor, source_spacing: float, target_spacing: float) -> list[float]:
    result = []
    for cls in (1, 2):
        source_volume = float(source[:, cls].sum()) * source_spacing
        target_volume = float(candidate[:, cls].sum()) * target_spacing
        result.append((target_volume - source_volume) / max(source_volume, 1e-12))
    return result


@torch.inference_mode()
def diagnostic(ctx: Context) -> None:
    device = require_cuda(); development, deny = verify_frozen(ctx.causal); resampler = AffineResampler3D(); rows = []
    for case_id in development:
        if hashlib.sha256(case_id.encode()).hexdigest() in deny: raise RuntimeError("denylisted case requested")
        r1 = ctx.manifest["cases"][case_id]["grids"]["R1"]; shape = r1["unpadded_shape_dhw"]
        _, padded_label = load_grid(ctx.causal, case_id, "R1"); label = torch.from_numpy(padded_label[tuple(slice(0, n) for n in shape)].astype(np.int64)).to(device)[None]
        onehot = F.one_hot(label, 3).movedim(-1, 1).float(); affine = torch.tensor(r1["affine_xyz"], dtype=torch.float64, device=device)
        for nominal in DIAGNOSTIC_SPACINGS:
            target_shape, target_affine, actual = target_grid(affine, shape, nominal)
            occupancy = conservative_axial_transport(onehot, affine, target_shape, target_affine)
            hard = resampler.label(onehot.argmax(1, keepdim=True), affine, target_shape, target_affine)[:, 0].long()
            hard_onehot = F.one_hot(hard, 3).movedim(-1, 1).float()
            point = resampler.probability(onehot, affine, target_shape, target_affine)
            adjacent = occupancy[:, 1:].sum(1) > 1e-8; mixed = adjacent & (occupancy.max(1).values < 0.95)
            difference = (hard_onehot - occupancy).abs().sum(1)
            errors = {"nn": relative_volume_errors(onehot, hard_onehot, 1.0, actual), "point": relative_volume_errors(onehot, point, 1.0, actual), "conservative": relative_volume_errors(onehot, occupancy, 1.0, actual)}
            rows.append({"case_id": case_id, "spacing_nominal_mm": nominal, "spacing_actual_mm": actual, "mixed_cell_fraction": float(mixed.sum() / adjacent.sum().clamp_min(1)), "nn_occupancy_disagreement": float(disagreement(hard_onehot[:, 1:], occupancy[:, 1:])), "nn_volume_error_anterior": errors["nn"][0], "nn_volume_error_posterior": errors["nn"][1], "point_volume_error_anterior": errors["point"][0], "point_volume_error_posterior": errors["point"][1], "conservative_volume_error_anterior": errors["conservative"][0], "conservative_volume_error_posterior": errors["conservative"][1], "normalization_max_error": float((occupancy.sum(1) - 1).abs().max()), "nn_occupancy_l1_fraction_in_mixed_cells": float(difference[mixed].sum() / difference.sum().clamp_min(1e-12))})
    write_csv(ctx.output / "occupancy_diagnostic_case_level.csv", rows)
    medians = {}
    for spacing in DIAGNOSTIC_SPACINGS:
        selected = [x for x in rows if x["spacing_nominal_mm"] == spacing]
        medians[str(spacing)] = {key: float(np.median([x[key] for x in selected])) for key in ("mixed_cell_fraction", "nn_occupancy_disagreement", "nn_occupancy_l1_fraction_in_mixed_cells")}
    checkpoint_direction = checkpoint_transport_diagnostic(ctx, device, deny)
    max_coarse_bias = max(float(np.median([abs(x[f"{method}_volume_error_{cls}"]) for x in rows if x["spacing_nominal_mm"] in (4.0, 5.0)])) for method in ("nn", "point") for cls in ("anterior", "posterior"))
    conservative_error = max(abs(x[f"conservative_volume_error_{cls}"]) for x in rows for cls in ("anterior", "posterior"))
    checks = {
        "coarse_mixed_cell_increase": min(medians["4.0"]["mixed_cell_fraction"], medians["5.0"]["mixed_cell_fraction"]) >= medians["2.0"]["mixed_cell_fraction"] + 0.05,
        "coarse_nn_occupancy_disagreement": min(medians["4.0"]["nn_occupancy_disagreement"], medians["5.0"]["nn_occupancy_disagreement"]) >= 0.02,
        "nontrivial_volume_bias": max_coarse_bias >= 0.01,
        "checkpoint_direction_consistent": all(all(v[str(s)]["conservative_abs_error_median"] < v[str(s)]["point_abs_error_median"] for s in (4.0, 5.0)) for v in checkpoint_direction.values()),
        "finite": all(math.isfinite(float(v)) for row in rows for v in row.values() if not isinstance(v, str)),
        "normalization": max(x["normalization_max_error"] for x in rows) <= 1e-5,
        "conservative_volume": conservative_error <= 1e-5,
    }
    decision = "GO_MEASURE_IMPLEMENTATION" if all(checks.values()) else "STOP_MEASURE_DIAGNOSTIC"
    summary = {"medians_by_spacing": medians, "max_coarse_abs_relative_nn_or_point_volume_bias": max_coarse_bias, "max_conservative_abs_relative_volume_error": conservative_error, "checkpoint_direction": checkpoint_direction, "checks": checks, "decision": decision}
    dump_json(ctx.output / "occupancy_diagnostic_summary.json", summary); dump_json(ctx.output / "diagnostic_decision.json", {"decision": decision, "checks": checks, "confirm_v2_data_accessed": False})
    lines = ["# Zero-cost voxel-cell diagnostic", "", "| spacing | mixed-cell fraction median | NN-occupancy disagreement median | disagreement mass in mixed cells |", "|---:|---:|---:|---:|"]
    for spacing, x in medians.items(): lines.append(f"| {spacing} | {x['mixed_cell_fraction']:.6f} | {x['nn_occupancy_disagreement']:.6f} | {x['nn_occupancy_l1_fraction_in_mixed_cells']:.6f} |")
    lines += ["", f"Decision: **{decision}**", "", "No training result was used in this diagnostic."]
    (ctx.output / "occupancy_diagnostic_report.md").write_text("\n".join(lines) + "\n")


@torch.inference_mode()
def checkpoint_transport_diagnostic(ctx: Context, device: torch.device, deny: set[str]) -> dict:
    result = {}; resampler = AffineResampler3D()
    for name, arm in (("C", "random_k2"), ("D", "soft_worst_random")):
        saved = torch.load(ctx.causal.checkpoint(arm, 17), map_location=device, weights_only=False); model = TinyMetricMamba("separated_physical_delta").to(device); model.load_state_dict(saved["model_state"]); model.eval(); values = {4.0: {"point": [], "conservative": []}, 5.0: {"point": [], "conservative": []}}
        for case_id in ctx.manifest["split"]["test"]:
            if hashlib.sha256(case_id.encode()).hexdigest() in deny: raise RuntimeError("denylisted case requested")
            case = ctx.manifest["cases"][case_id]; r1 = case["grids"]["R1"]; shape = r1["unpadded_shape_dhw"]; image, _ = load_grid(ctx.causal, case_id, "R1"); affine = torch.tensor(r1["affine_xyz"], dtype=torch.float64, device=device)
            with torch.autocast("cuda", dtype=torch.bfloat16): probability = crop5(model_logits(model, torch.from_numpy(image).to(device)[None, None], [1, 1, 1]), shape).float().softmax(1)
            for nominal in (4.0, 5.0):
                target_shape, target_affine, actual = target_grid(affine, shape, nominal); point = resampler.probability(probability, affine, target_shape, target_affine); conservative = conservative_axial_transport(probability, affine, target_shape, target_affine)
                values[nominal]["point"] += [abs(x) for x in relative_volume_errors(probability, point, 1.0, actual)]
                values[nominal]["conservative"] += [abs(x) for x in relative_volume_errors(probability, conservative, 1.0, actual)]
        result[name] = {str(spacing): {"point_abs_error_median": float(np.median(values[spacing]["point"])), "conservative_abs_error_median": float(np.median(values[spacing]["conservative"]))} for spacing in (4.0, 5.0)}
    return result


@torch.inference_mode()
def validation_dice(ctx: Context, model: torch.nn.Module, device: torch.device) -> float:
    model.eval(); scores = []
    for case_id in ctx.manifest["split"]["validation"]:
        image, label = load_grid(ctx.causal, case_id, "R1"); shape = ctx.manifest["cases"][case_id]["grids"]["R1"]["unpadded_shape_dhw"]
        with torch.autocast("cuda", dtype=torch.bfloat16): hard = crop5(model_logits(model, torch.from_numpy(image).to(device)[None, None], [1, 1, 1]), shape).argmax(1)[0].cpu().numpy()
        slices = tuple(slice(0, n) for n in shape)
        scores += [binary_dice(hard == cls, label[slices] == cls) for cls in (1, 2)]
    return float(np.mean(scores))


def train(ctx: Context, arm: str, updates: int = UPDATES, smoke: bool = False) -> dict:
    if arm not in TRAINABLE: raise ValueError(arm)
    decision_path = ctx.output / "diagnostic_decision.json"
    if not smoke and (not decision_path.is_file() or json.loads(decision_path.read_text())["decision"] != "GO_MEASURE_IMPLEMENTATION"):
        raise RuntimeError("diagnostic gate did not authorize training")
    device = require_cuda(); checkpoint, log_path = ctx.checkpoint(arm, smoke), ctx.log(arm, smoke)
    if checkpoint.is_file() and log_path.is_file():
        old = json.loads(log_path.read_text())
        if old.get("completed") and old.get("updates") == updates and old.get("checkpoint_sha256") == sha256(checkpoint): return old
    seed_all(17); model = TinyMetricMamba("separated_physical_delta").to(device); optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-5)
    resampler = AffineResampler3D(); schedule = load_frozen_schedule(ctx, smoke); history, best, best_update = [], -1.0, 0
    checkpoint.parent.mkdir(parents=True, exist_ok=True); torch.cuda.reset_peak_memory_stats(); torch.cuda.synchronize(); started = time.perf_counter()
    for item in schedule[:updates]:
        update, case_id, spacing = item["update"], item["case_id"], item["spacing_1"]
        case = ctx.manifest["cases"][case_id]; r1 = case["grids"]["R1"]; shape = r1["unpadded_shape_dhw"]
        image, label_array = load_grid(ctx.causal, case_id, "R1"); x1 = torch.from_numpy(image).to(device)[None, None]; y1 = torch.from_numpy(label_array.astype(np.int64)).to(device)[None]
        affine = torch.tensor(r1["affine_xyz"], dtype=torch.float64, device=device); raw, raw_affine = load_raw_image(ctx.causal, case_id, device)
        target_shape, target_affine, actual = target_grid(affine, shape, spacing); raw_candidate = resampler.image(raw, raw_affine, target_shape, target_affine)
        candidate = pad4(normalize_candidate(raw_candidate, case["r1_nonbackground_mean"], case["r1_nonbackground_std"]))
        optimizer.zero_grad(set_to_none=True); model.train()
        with torch.autocast("cuda", dtype=torch.bfloat16):
            z1 = model_logits(model, x1, [1, 1, 1]); native_loss = loss_fn(z1, y1); z_grid = crop5(model_logits(model, candidate, [actual, 1, 1]), target_shape)
            source_label = crop5(y1[:, None], shape)
            if arm == "P":
                source_probability = crop5(z1, shape).float().softmax(1).detach(); target = conservative_axial_transport(source_probability, affine, target_shape, target_affine).detach(); auxiliary = disagreement(target[:, 1:], z_grid.float().softmax(1)[:, 1:])
            elif arm == "H":
                target = resampler.label(source_label, affine, target_shape, target_affine)[:, 0].long(); auxiliary = loss_fn(z_grid, target)
            else:
                source_onehot = F.one_hot(source_label[:, 0], 3).movedim(-1, 1).float(); target = conservative_axial_transport(source_onehot, affine, target_shape, target_affine); auxiliary = soft_segmentation_loss(z_grid, target)
            weight = 0.1 * min(1.0, update / 500); total = native_loss + weight * auxiliary
        if not torch.isfinite(total): raise FloatingPointError(f"non-finite loss at update {update}")
        total.backward(); gradients = [p.grad.float() for p in model.parameters() if p.grad is not None]
        if not gradients or not all(torch.isfinite(x).all() for x in gradients): raise FloatingPointError(f"non-finite gradient at update {update}")
        grad_norm = float(torch.sqrt(sum(x.square().sum() for x in gradients))); optimizer.step()
        row = {"update": update, "case_id_hash": hashlib.sha256(case_id.encode()).hexdigest(), "requested_spacing": spacing, "actual_spacing": actual, "native_loss": float(native_loss), "auxiliary_loss": float(auxiliary), "lambda": weight, "total_loss": float(total), "gradient_norm": grad_norm}
        history.append(row)
        if update % 250 == 0 or update == updates:
            score = validation_dice(ctx, model, device); row["validation_r1_foreground_dice"] = score
            print(arm, {"update": update, "loss": float(total), "validation": score}, flush=True)
            if score > best:
                best, best_update = score, update
                torch.save({"model_state": model.state_dict(), "arm": arm, "seed": 17, "update": update, "validation_r1_foreground_dice": score, "selection": "R1 validation foreground Dice only"}, checkpoint)
    torch.cuda.synchronize(); elapsed = time.perf_counter() - started; props = torch.cuda.get_device_properties(0)
    log = {"completed": True, "finite": True, "arm": arm, "seed": 17, "updates": updates, "history": history, "best_validation_r1_foreground_dice": best, "best_update": best_update, "checkpoint": str(checkpoint), "checkpoint_sha256": sha256(checkpoint), "checkpoint_selection": "R1 validation foreground Dice only", "parameter_count": parameter_count(model), "training_seconds": elapsed, "seconds_per_update": elapsed / updates, "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved(), "gpu_total_memory_bytes": props.total_memory}
    dump_json(log_path, log); return log


def run_unit_tests(ctx: Context) -> None:
    setup(ctx); env = dict(os.environ, CUDA_VISIBLE_DEVICES="0", PYTHONDONTWRITEBYTECODE="1"); started = time.perf_counter()
    result = subprocess.run([sys.executable, "-m", "unittest", "-v", "test_measure_consistent_grid.py", "test_grid_causal_audit.py", "test_physgrid.ResamplerTests"], cwd=ctx.project, env=env, text=True, capture_output=True)
    text = f"exit_code: {result.returncode}\nelapsed_seconds: {time.perf_counter()-started:.6f}\n\nSTDOUT\n{result.stdout}\nSTDERR\n{result.stderr}"
    (ctx.output / "unit_test_report.txt").write_text(text)
    if result.returncode: raise RuntimeError("unit tests failed; training forbidden")


def smoke(ctx: Context) -> None:
    if "exit_code: 0" not in (ctx.output / "unit_test_report.txt").read_text(): raise RuntimeError("passing unit tests required")
    logs = [train(ctx, arm, 20, True) for arm in TRAINABLE]; lines = ["# Smoke test", "", "| arm | last loss | gradient norm | peak GiB | resume/hash |", "|---|---:|---:|---:|---|"]
    passed = True
    for log in logs:
        resumed = train(ctx, log["arm"], 20, True); okay = resumed["checkpoint_sha256"] == log["checkpoint_sha256"] and log["finite"] and log["parameter_count"] == 99411 and log["peak_reserved_bytes"] < .9 * log["gpu_total_memory_bytes"]
        passed &= okay; lines.append(f"| {log['arm']} | {log['history'][-1]['total_loss']:.6f} | {log['history'][-1]['gradient_norm']:.6f} | {log['peak_reserved_bytes']/2**30:.3f} | {'PASS' if okay else 'FAIL'} |")
    schedule_hashes = {arm: object_hash([(x["case_id_hash"], x["requested_spacing"]) for x in log["history"]]) for arm, log in zip(TRAINABLE, logs)}
    passed &= len(set(schedule_hashes.values())) == 1; lines += ["", f"Schedule parity: {'PASS' if len(set(schedule_hashes.values())) == 1 else 'FAIL'}", f"Result: {'PASS' if passed else 'FAIL'}"]
    (ctx.output / "smoke_test_report.md").write_text("\n".join(lines) + "\n")
    if not passed: raise RuntimeError("smoke test failed")


def load_model(ctx: Context, arm: str, device: torch.device) -> torch.nn.Module:
    saved = torch.load(ctx.checkpoint(arm), map_location=device, weights_only=False); model = TinyMetricMamba("separated_physical_delta").to(device); model.load_state_dict(saved["model_state"], strict=True); return model.eval()


@torch.inference_mode()
def evaluate_model(ctx: Context, arm: str, device: torch.device, deny: set[str]) -> list[dict]:
    model = load_model(ctx, arm, device); resampler = AffineResampler3D(); rows = []
    for case_id in ctx.manifest["split"]["test"]:
        if hashlib.sha256(case_id.encode()).hexdigest() in deny: raise RuntimeError("denylisted case requested")
        case = ctx.manifest["cases"][case_id]; r1 = case["grids"]["R1"]; shape = r1["unpadded_shape_dhw"]; image, padded_label = load_grid(ctx.causal, case_id, "R1"); label = padded_label[tuple(slice(0, n) for n in shape)]
        affine = torch.tensor(r1["affine_xyz"], dtype=torch.float64, device=device); raw, raw_affine = load_raw_image(ctx.causal, case_id, device)
        with torch.autocast("cuda", dtype=torch.bfloat16): r1_probability = crop5(model_logits(model, torch.from_numpy(image).to(device)[None, None], [1, 1, 1]), shape).float().softmax(1)
        r1_hard = r1_probability.argmax(1)[0].cpu().numpy()
        for nominal in SPACINGS:
            if nominal == 1: mapped, actual = r1_probability, 1.0
            else:
                target_shape, target_affine, actual = target_grid(affine, shape, nominal); raw_candidate = resampler.image(raw, raw_affine, target_shape, target_affine); candidate = pad4(normalize_candidate(raw_candidate, case["r1_nonbackground_mean"], case["r1_nonbackground_std"]))
                with torch.autocast("cuda", dtype=torch.bfloat16): probability = crop5(model_logits(model, candidate, [actual, 1, 1]), target_shape).float().softmax(1)
                mapped = resampler.probability(probability, target_affine, shape, affine)
            hard = mapped.argmax(1)[0].cpu().numpy()
            for cls, name in ((0, "foreground"), (1, "anterior"), (2, "posterior")):
                prediction = hard != 0 if cls == 0 else hard == cls; reference = r1_hard != 0 if cls == 0 else r1_hard == cls; truth = label != 0 if cls == 0 else label == cls
                rows.append({"case_id": case_id, "arm": arm, "seed": 17, "spacing_nominal_mm": nominal, "spacing_actual_mm": actual, "class": name, "Dpred": binary_dice(prediction, reference), "Dmap": binary_dice(prediction, truth), "Smap": surface_dice(prediction, truth), "Dnative": binary_dice(reference, truth)})
    return rows


def evaluate(ctx: Context) -> None:
    device = require_cuda(); _, deny = verify_frozen(ctx.causal); rows = []
    with (ctx.causal.output / "metrics_case_level.csv").open() as handle:
        for source in csv.DictReader(handle):
            if source["arm"] != "random_k1": continue
            row = {**source, "arm": "R", "seed": 17}
            for key in ("spacing_nominal_mm", "spacing_actual_mm", "Dpred", "Dmap", "Smap", "Dnative"): row[key] = float(row[key])
            rows.append(row)
    for arm in TRAINABLE:
        log = json.loads(ctx.log(arm).read_text())
        if not log.get("completed") or log["checkpoint_sha256"] != sha256(ctx.checkpoint(arm)): raise RuntimeError(f"incomplete training: {arm}")
        rows += evaluate_model(ctx, arm, device, deny)
    write_csv(ctx.output / "metrics_case_level.csv", rows); summaries = case_summary(rows); write_csv(ctx.output / "metrics_case_summary.csv", summaries)


def comparison(cases: list[dict], treatment: str, control: str, metric: str) -> dict:
    a = {x["case_id"]: float(x[metric]) for x in cases if x["arm"] == treatment}; b = {x["case_id"]: float(x[metric]) for x in cases if x["arm"] == control}; ids = sorted(a)
    values = np.asarray([a[x] - b[x] for x in ids]); rng = np.random.default_rng(BOOTSTRAP_SEED); means = np.asarray([values[rng.integers(0, len(values), len(values))].mean() for _ in range(BOOTSTRAPS)])
    return {"treatment": treatment, "control": control, "metric": metric, "mean_difference": float(values.mean()), "median_difference": float(np.median(values)), "positive_cases": int((values > 0).sum()), "ci80": np.quantile(means, [.1, .9]).tolist(), "ci95": np.quantile(means, [.025, .975]).tolist(), "per_case": dict(zip(ids, values.tolist()))}


def report(ctx: Context) -> None:
    with (ctx.output / "metrics_case_summary.csv").open() as handle: cases = [{**x, **{k: float(x[k]) for k in x.keys() - {"arm", "case_id", "seed"}}, "seed": int(x["seed"])} for x in csv.DictReader(handle)]
    metrics = ("Dnative", "grid_auc_dpred", "worst_grid_Dpred", "worst_grid_Dmap", "source_mean_Dmap", "extrapolation_Dmap", "extrapolation_Smap")
    summary = {arm: {metric: float(np.mean([x[metric] for x in cases if x["arm"] == arm])) for metric in metrics} for arm in ARMS}
    comparisons = [comparison(cases, arm, control, metric) for arm, control in (("P", "R"), ("O", "R"), ("O", "H"), ("P", "O")) for metric in ("extrapolation_Dmap", "extrapolation_Smap", "worst_grid_Dmap", "Dnative")]
    lookup = {(x["treatment"], x["control"], x["metric"]): x for x in comparisons}
    r_cost = json.loads(ctx.causal.log("random_k1", 17).read_text())["training_seconds"]
    gates = {}
    for arm in ("P", "O"):
        extra_d = lookup[(arm, "R", "extrapolation_Dmap")]; extra_s = lookup[(arm, "R", "extrapolation_Smap")]; worst = lookup[(arm, "R", "worst_grid_Dmap")]; native = lookup[(arm, "R", "Dnative")]; cost_ratio = json.loads(ctx.log(arm).read_text())["training_seconds"] / r_cost
        checks = {"Extra_Dmap": extra_d["mean_difference"] >= .010, "Extra_Smap": extra_s["mean_difference"] >= .015, "Worst_Dmap": worst["mean_difference"] >= .010, "Dnative": native["mean_difference"] >= -.005, "positive_cases": extra_d["positive_cases"] >= 13, "ci80_lower": extra_d["ci80"][0] > 0, "cost": cost_ratio <= 1.15}
        gates[arm] = {"checks": checks, "pass": all(checks.values()), "cost_ratio": cost_ratio}
    p_beats_r = gates["P"]["pass"]; o_beats_r = gates["O"]["pass"]; o_beats_h = lookup[("O", "H", "extrapolation_Dmap")]["mean_difference"] > 0
    if p_beats_r: decision = "GO_CONSERVATIVE_COMMUTATOR_THREE_SEED"
    elif o_beats_r: decision = "REFRAME_PHYSICAL_OCCUPANCY_SUPERVISION"
    elif o_beats_h: decision = "STOP_OCCUPANCY_FIXES_HARD_BASELINE_ONLY"
    else: decision = "STOP_NO_CONSERVATIVE_GAIN"
    dump_json(ctx.output / "metrics_summary.json", summary); dump_json(ctx.output / "bootstrap_results.json", comparisons); dump_json(ctx.output / "decision.json", {"decision": decision, "gates": gates, "confirm_v2_data_accessed": False})
    schedule_hashes = {}
    for arm in TRAINABLE:
        history = json.loads(ctx.log(arm).read_text())["history"]
        schedule_hashes[arm] = object_hash([(x["case_id_hash"], x["requested_spacing"]) for x in history])
    dump_json(ctx.output / "actual_schedule_hashes.json", {"hashes": schedule_hashes, "all_equal": len(set(schedule_hashes.values())) == 1, "updates_per_arm": UPDATES})
    write_csv(ctx.output / "paired_differences.csv", [{"treatment": x["treatment"], "control": x["control"], "metric": x["metric"], "case_id": case_id, "difference": value} for x in comparisons for case_id, value in x["per_case"].items()])
    lines = ["# Measure-Consistent Grid Training pilot", "", "Single-seed development-screen result; not a final claim.", "", "| arm | Extra Dmap | Extra Smap | Worst Dmap | Worst Dpred | Dnative | GPU time vs R |", "|---|---:|---:|---:|---:|---:|---:|"]
    for arm in ARMS:
        ratio = 1.0 if arm == "R" else json.loads(ctx.log(arm).read_text())["training_seconds"] / r_cost
        lines.append(f"| {arm} | {summary[arm]['extrapolation_Dmap']:.6f} | {summary[arm]['extrapolation_Smap']:.6f} | {summary[arm]['worst_grid_Dmap']:.6f} | {summary[arm]['worst_grid_Dpred']:.6f} | {summary[arm]['Dnative']:.6f} | {ratio:.3f} |")
    pr_d, pr_s, oh_d, po_d = lookup[("P", "R", "extrapolation_Dmap")], lookup[("P", "R", "extrapolation_Smap")], lookup[("O", "H", "extrapolation_Dmap")], lookup[("P", "O", "extrapolation_Dmap")]
    lines += ["", "## Predefined comparisons", "", f"- P−R Extra Dmap: {pr_d['mean_difference']:+.6f}, 80% CI [{pr_d['ci80'][0]:+.6f}, {pr_d['ci80'][1]:+.6f}], positive cases {pr_d['positive_cases']}/20.", f"- P−R Extra Smap: {pr_s['mean_difference']:+.6f}, 80% CI [{pr_s['ci80'][0]:+.6f}, {pr_s['ci80'][1]:+.6f}].", f"- O−H Extra Dmap: {oh_d['mean_difference']:+.6f}, 80% CI [{oh_d['ci80'][0]:+.6f}, {oh_d['ci80'][1]:+.6f}].", f"- P−O Extra Dmap: {po_d['mean_difference']:+.6f}, 80% CI [{po_d['ci80'][0]:+.6f}, {po_d['ci80'][1]:+.6f}].", "", f"P scientific gate: {'PASS' if gates['P']['pass'] else 'FAIL'}", f"O scientific gate: {'PASS' if gates['O']['pass'] else 'FAIL'}", f"Decision: **{decision}**", "", "The zero-cost voxel-measure hypothesis was supported, but neither conservative training objective improved Dmap/Smap. O was also worse than H, so partial-volume quantization did not explain the hard-label training deficit in this pilot.", "", "No P+O mixture was trained or selected. confirm_v2 remained inaccessible by denylist."]
    (ctx.output / "pilot_report.md").write_text("\n".join(lines) + "\n")
    optimization = json.loads((ctx.output / "optimization_audit.json").read_text()); diagnostic_result = json.loads((ctx.output / "occupancy_diagnostic_summary.json").read_text())
    audit_lines = ["# Audit", "", "## Random-K1 statistical/optimization source", "", "Random-K1 and IID Random-K2-mean optimize the same expected auxiliary objective; they differ in Monte Carlo gradient variance, compute, and optimization trajectory.", ""]
    for seed, values in optimization["comparisons"].items():
        k2, d = values["K1_minus_K2"], values["K1_minus_soft_worst"]
        audit_lines += [f"- seed {seed}: K1−K2 Extra Dmap {k2['extra_Dmap']:+.6f}; K1−soft-worst {d['extra_Dmap']:+.6f}."]
    audit_lines += ["", f"K1 exceeded K2 in all three seeds: {optimization['K1_beats_K2_all_three_point_estimates']}. K2 mean-loss scaling, effective lambda, case order, and spacing_1 schedule all passed exact checks.", "", "## Zero-cost diagnostic", "", f"Decision: {diagnostic_result['decision']}. R2/R4/R5 median mixed-cell fractions were {diagnostic_result['medians_by_spacing']['2.0']['mixed_cell_fraction']:.6f}/{diagnostic_result['medians_by_spacing']['4.0']['mixed_cell_fraction']:.6f}/{diagnostic_result['medians_by_spacing']['5.0']['mixed_cell_fraction']:.6f}; R4/R5 NN–occupancy disagreement was {diagnostic_result['medians_by_spacing']['4.0']['nn_occupancy_disagreement']:.6f}/{diagnostic_result['medians_by_spacing']['5.0']['nn_occupancy_disagreement']:.6f}.", "", "## Scientific result", "", f"P did not exceed R; O did not exceed R or H. Final decision: {decision}."]
    (ctx.output / "audit.md").write_text("\n".join(audit_lines) + "\n")
    commands = ctx.output / "commands_for_three_seed_screen.sh"
    commands.write_text("#!/usr/bin/env bash\n# STOP: " + decision + "\n# No three-seed conservative-transport commands are authorized.\n")
    commands.chmod(0o755)
    finalize_integrity(ctx)


def finalize_integrity(ctx: Context) -> None:
    excluded = {"SHA256SUMS", "integrity_check_report.txt"}; files = sorted(x for x in ctx.output.rglob("*") if x.is_file() and not x.is_symlink() and x.name not in excluded)
    lines = [f"{sha256(path)}  {path.relative_to(ctx.output)}" for path in files]; (ctx.output / "SHA256SUMS").write_text("\n".join(lines) + "\n")
    check = subprocess.run(["sha256sum", "-c", "SHA256SUMS"], cwd=ctx.output, text=True, capture_output=True)
    locked = json.loads((ctx.previous / "split_manifest_confirm_v2_locked.json").read_text())["case_ids"]
    text_files = [path for path in ctx.output.rglob("*") if path.is_file() and not path.is_symlink()]
    matches = {case_id: [str(path.relative_to(ctx.output)) for path in text_files if case_id in path.read_text(errors="ignore")] for case_id in locked}
    leaked = {case_id: paths for case_id, paths in matches.items() if paths}
    report_text = f"sha256_exit_code: {check.returncode}\nfiles_checked: {len(files)}\nconfirm_v2_data_accessed: false\ndenylist_count: {len(locked)}\nraw_confirm_id_matches: {sum(map(len, leaked.values()))}\n\n{check.stdout}{check.stderr}"
    (ctx.output / "integrity_check_report.txt").write_text(report_text)
    if check.returncode or leaked: raise RuntimeError("integrity or confirm isolation check failed")


def main() -> None:
    args = arguments(); ctx = Context(args); record_command(ctx)
    if args.command == "setup": setup(ctx)
    elif args.command == "unit-tests": run_unit_tests(ctx)
    elif args.command == "optimization-audit": optimization_audit(ctx)
    elif args.command == "diagnostic": diagnostic(ctx)
    elif args.command == "smoke": smoke(ctx)
    elif args.command == "train": train(ctx, args.arm)
    elif args.command == "evaluate": evaluate(ctx)
    elif args.command == "report": report(ctx)
    elif args.command == "full-pilot":
        setup(ctx); run_unit_tests(ctx); optimization_audit(ctx); diagnostic(ctx)
        if json.loads((ctx.output / "diagnostic_decision.json").read_text())["decision"] != "GO_MEASURE_IMPLEMENTATION": return
        smoke(ctx)
        for arm in TRAINABLE: train(ctx, arm)
        evaluate(ctx); report(ctx)


if __name__ == "__main__":
    main()
