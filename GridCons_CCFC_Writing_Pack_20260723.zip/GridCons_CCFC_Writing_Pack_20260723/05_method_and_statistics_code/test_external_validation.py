#!/usr/bin/env python
"""Minimal frozen checks for the external validation."""

from __future__ import annotations

import unittest

import numpy as np
import torch

import external_validation as run


class ExternalValidationTests(unittest.TestCase):
    def test_data_gate_and_real_spacing(self) -> None:
        gate = run.load_json(run.DATA_GATE)
        self.assertEqual(gate["status"], "PASS_EXTERNAL_DATA_GATE")
        self.assertTrue(gate["INDEPENDENT_DATASET"])
        self.assertTrue(gate["REAL_HETEROGENEOUS_SPACING"])
        self.assertGreaterEqual(gate["spacing"]["unique_triplet_count"], 2)

    def test_five_fold_partition_and_label_isolation(self) -> None:
        folds = run.load_json(run.FOLDS_PATH)
        run.validate_folds(folds)
        preprocessing = run.load_json(run.PREPROCESSING_PATH)
        run.validate_preprocessing(preprocessing, folds)
        seen = []
        for record in folds["folds"]:
            seen.extend(record["outer_test"])
            self.assertTrue(all(item["label_cache"] is None for item in preprocessing["paired"][str(record["fold"])].values()))
            with self.assertRaises(PermissionError):
                run.load_label_full(record["outer_test"][0], set(record["train"] + record["validation"]))
        self.assertEqual(sorted(seen), sorted(folds["case_ids"]))

    def test_model_shape_and_finite(self) -> None:
        for arm in run.ARMS:
            model = run.build_model(arm).eval()
            with torch.inference_mode():
                output = run.forward_logits(model, torch.zeros(1, 1, 4, 8, 8), [2.0, 1.0, 1.0])
            self.assertEqual(tuple(output.shape), (1, 2, 4, 8, 8))
            self.assertTrue(torch.isfinite(output).all())

    def test_physical_affine_mapping(self) -> None:
        probability = torch.rand(1, 2, 4, 5, 6)
        probability /= probability.sum(1, keepdim=True)
        affine = np.asarray([[0.8, 0, 0, -100], [0, 0.9, 0, -80], [0, 0, 5.0, -50], [0, 0, 0, 1]], dtype=float)
        mapped = run.map_probability_torch(probability, affine, probability.shape[2:], affine)
        self.assertTrue(torch.allclose(mapped, probability, atol=2e-6, rtol=2e-6))
        folds, preprocessing = run.load_json(run.FOLDS_PATH), run.load_json(run.PREPROCESSING_PATH)
        record = folds["folds"][0]
        identifier = record["train"][0]
        native, paired = preprocessing["native"][identifier], preprocessing["paired"]["0"][identifier]
        native_origin = np.asarray(native["affine_xyz"]) @ np.asarray([0, 0, 0, 1])
        paired_origin = np.asarray(paired["affine_xyz"]) @ np.asarray([0, 0, 0, 1])
        self.assertTrue(np.allclose(native_origin, paired_origin, atol=1e-5))

    def test_zero_consistency_equals_supervised(self) -> None:
        torch.manual_seed(17)
        first, second = run.build_model("static_delta"), run.build_model("static_delta")
        second.load_state_dict(first.state_dict())
        image = torch.randn(1, 1, 4, 8, 8)
        label = torch.randint(0, 2, (1, 4, 8, 8))
        expected = run.loss_fn(run.forward_logits(first, image, [2.0, 1.0, 1.0]), label)
        expected.backward()
        actual, segmentation, consistency = run.batch_loss(
            second, image, label, [2.0, 1.0, 1.0], np.eye(4), None, None, None, 0.0
        )
        actual.backward()
        self.assertTrue(torch.equal(actual, segmentation))
        self.assertIsNone(consistency)
        self.assertTrue(torch.allclose(actual, expected, atol=0, rtol=0))
        for left, right in zip(first.parameters(), second.parameters()):
            self.assertTrue(torch.allclose(left.grad, right.grad, atol=0, rtol=0))


if __name__ == "__main__":
    unittest.main()
