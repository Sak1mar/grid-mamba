#!/usr/bin/env python
"""Add the missing dynamic-delta + full-consistency factorial arm."""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import time
from pathlib import Path

import numpy as np
import torch

import run_paired_full as paired
import run_probe as base
from model import TinyMetricMamba, parameter_count


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs" / "dynamic_full"
SEEDS = base.SEEDS
METHOD = "dynamic_full_consistency"
BOOTSTRAPS = 10_000
BOOTSTRAP_SEED = 7341


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def paths(seed: int) -> tuple[Path, Path]:
    return OUT / "checkpoints" / f"dynamic_full_seed{seed}.pt", OUT / f"train_dynamic_full_seed{seed}.json"


def check() -> None:
    subprocess.run(["sha256sum", "-c", "outputs/paired_full/SHA256SUMS"], cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
    if parameter_count(TinyMetricMamba("content_delta")) != 99_555:
        raise RuntimeError("unexpected model size")
    z1 = torch.randn(1, 3, 5, 4, 4, requires_grad=True)
    z2 = torch.randn(1, 3, 3, 4, 4, requires_grad=True)
    loss = paired.paired_grid_consistency_loss(z1, z2, [5, 4, 4], [3, 4, 4])
    loss.backward()
    if not torch.isfinite(loss) or z1.grad is not None or z2.grad is None or not torch.isfinite(z2.grad).all():
        raise RuntimeError("consistency loss/stop-gradient check failed")
    dump_json(OUT / "check.json", {"passed": True, "parameterization": "content_delta", "method": METHOD})


def train(seed: int) -> None:
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly one visible CUDA GPU is required")
    checkpoint, log_path = paths(seed)
    if checkpoint.exists() and log_path.exists():
        old = json.loads(log_path.read_text())
        if old.get("completed") and old.get("checkpoint_sha256") == paired.sha256(checkpoint):
            print(f"completed training exists: {log_path}")
            return

    manifest = base.manifest()
    base.OLD.seed_all(seed)
    device = torch.device("cuda:0")
    model = TinyMetricMamba("content_delta").to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-5)
    cases = []
    for case_id in manifest["split"]["train"]:
        r1_image, r1_label = base.load_array(manifest, case_id, "R1")
        r2_image, _ = base.load_array(manifest, case_id, "R2")
        cases.append((case_id, r1_image, r1_label, r2_image))
    rng, order = np.random.default_rng(seed), []
    history, best = [], -1.0
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    for update in range(1, base.UPDATES + 1):
        if not order:
            order = rng.permutation(len(cases)).tolist()
        case_id, r1_image, r1_label, r2_image = cases[order.pop()]
        r1_shape = manifest["cases"][case_id]["grids"]["R1"]["unpadded_shape_dhw"]
        r2_shape = manifest["cases"][case_id]["grids"]["R2"]["unpadded_shape_dhw"]
        x1, y1 = base.OLD.tensors(r1_image, r1_label, device)
        x2 = torch.from_numpy(np.asarray(r2_image, dtype=np.float32)).to(device)[None, None]
        model.train()
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            z1 = model(x1, torch.ones(1, 3, device=device))
            z2 = model(x2, torch.tensor([[2.0, 1.0, 1.0]], device=device))
            segmentation = base.OLD.loss_fn(z1, y1)
            consistency = paired.paired_grid_consistency_loss(z1, z2, r1_shape, r2_shape)
            weight = paired.CONSISTENCY_WEIGHT * min(1.0, update / 500)
            loss = segmentation + weight * consistency
        if not torch.isfinite(loss):
            raise RuntimeError(f"non-finite loss at update {update}")
        loss.backward()
        if not all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None):
            raise RuntimeError(f"non-finite gradient at update {update}")
        optimizer.step()
        if update % base.VALIDATE_EVERY == 0:
            score = base.validation_dice(model, manifest)
            item = {"update": update, "training_loss": float(loss), "r1_segmentation_loss": float(segmentation), "paired_consistency_loss": float(consistency), "effective_consistency_weight": weight, "validation_r1_mean_dice": score}
            history.append(item)
            print(seed, item, flush=True)
            if score > best:
                best = score
                torch.save({"model_state": model.state_dict(), "parameterization": "content_delta", "method": METHOD, "seed": seed, "update": update, "validation_r1_mean_dice": score, "selection": "validation_R1_mean_anterior_posterior_Dice_only", "consistency_weight": paired.CONSISTENCY_WEIGHT}, checkpoint)
    torch.cuda.synchronize()
    log = {"completed": True, "finite": True, "method": METHOD, "parameterization": "content_delta", "seed": seed, "updates": base.UPDATES, "validation_interval": base.VALIDATE_EVERY, "history": history, "best_validation_r1_mean_dice": best, "checkpoint": str(checkpoint), "checkpoint_sha256": paired.sha256(checkpoint), "checkpoint_selection": "validation_R1_mean_anterior_posterior_Dice_only", "consistency_weight": paired.CONSISTENCY_WEIGHT, "r2_labels_used_for_training": False, "gpu_seconds": time.perf_counter() - started, "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved()}
    dump_json(log_path, log)


def load(seed: int, device: torch.device) -> TinyMetricMamba:
    saved = torch.load(paths(seed)[0], map_location=device, weights_only=False)
    if saved.get("method") != METHOD or saved.get("parameterization") != "content_delta" or saved.get("seed") != seed:
        raise RuntimeError("checkpoint metadata mismatch")
    model = TinyMetricMamba("content_delta").to(device)
    model.load_state_dict(saved["model_state"], strict=True)
    return model.eval()


def evaluate() -> None:
    manifest = paired.confirm_manifest()
    missing = [seed for seed in SEEDS if not paths(seed)[0].exists()]
    if missing:
        raise RuntimeError(f"missing checkpoints: {missing}")
    rows, failures = [], []
    device = torch.device("cuda:0")
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    for seed in SEEDS:
        model = load(seed, device)
        for case_id in manifest["confirm_test"]:
            case = manifest["cases"][case_id]
            r1_image, r1_label_padded = base.load_array(manifest, case_id, "R1")
            r1_grid = case["grids"]["R1"]
            r1_shape = r1_grid["unpadded_shape_dhw"]
            r1_slices = tuple(slice(0, n) for n in r1_shape)
            r1_label = r1_label_padded[r1_slices]
            r1_affine = np.asarray(r1_grid["affine_xyz"])
            try:
                r1_probability = base.predict(model, r1_image, r1_grid["spacing_dhw"])[(slice(None),) + r1_slices]
                r1_hard = r1_probability.argmax(0)
                for spacing_name in ("R1", "R2", "R4"):
                    grid = case["grids"][spacing_name]
                    image, label_padded = base.load_array(manifest, case_id, spacing_name)
                    shape = grid["unpadded_shape_dhw"]
                    slices = tuple(slice(0, n) for n in shape)
                    label = label_padded[slices]
                    if spacing_name == "R1":
                        mapped_probability, mapped_label = r1_probability, r1_label
                    else:
                        probability = base.predict(model, image, grid["spacing_dhw"])[(slice(None),) + slices]
                        mapped_probability = base.OLD.map_probability(probability, np.asarray(grid["affine_xyz"]), r1_shape, r1_affine)
                        mapped_label = base.OLD.map_label(label, np.asarray(grid["affine_xyz"]), r1_shape, r1_affine)
                    mapped_hard = mapped_probability.argmax(0)
                    for cls, name in ((1, "anterior"), (2, "posterior")):
                        rows.append({"case_id": case_id, "class": name, "seed": seed, "method": METHOD, "spacing": spacing_name, "prediction_consistency_dice": base.OLD.binary_dice(mapped_hard == cls, r1_hard == cls), "mapped_label_dice": base.OLD.binary_dice(mapped_hard == cls, r1_label == cls), "native_r1_label_dice": base.OLD.binary_dice(r1_hard == cls, r1_label == cls), "surface_dice_2mm": base.OLD.surface_dice(mapped_hard == cls, r1_label == cls), "oracle_grid_dice": base.OLD.binary_dice(mapped_label == cls, r1_label == cls)})
            except Exception as error:
                failures.append({"seed": seed, "case_id": case_id, "error": str(error)})
        del model
    torch.cuda.synchronize()
    if failures or len(rows) != 40 * 2 * len(SEEDS) * 3:
        raise RuntimeError(f"incomplete evaluation: rows={len(rows)}, failures={failures[:3]}")
    with (OUT / "metrics.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    dump_json(OUT / "evaluation.json", {"rows": len(rows), "failures": failures, "gpu_seconds": time.perf_counter() - started, "metrics_sha256": paired.sha256(OUT / "metrics.csv")})


def read_candidate() -> list[dict]:
    with (OUT / "metrics.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["seed"] = int(row["seed"])
        for key in ("prediction_consistency_dice", "mapped_label_dice", "native_r1_label_dice", "surface_dice_2mm", "oracle_grid_dice"):
            row[key] = float(row[key])
    return rows


def summarize(values: np.ndarray, case_samples: np.ndarray, seed_samples: np.ndarray) -> dict:
    samples = values[case_samples[:, :, None], seed_samples[:, None, :]].mean((1, 2))
    return {"mean_difference": float(values.mean()), "ci95": [float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))], "seed_differences": {str(seed): float(values[:, i].mean()) for i, seed in enumerate(SEEDS)}}


def report() -> None:
    rows = paired.read_metrics() + read_candidate()
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    case_samples = rng.integers(0, 40, size=(BOOTSTRAPS, 40))
    seed_samples = rng.integers(0, len(SEEDS), size=(BOOTSTRAPS, len(SEEDS)))
    specs = {"r2_consistency": ("R2", "prediction_consistency_dice"), "r2_mapped_dice": ("R2", "mapped_label_dice"), "r2_surface_dice_2mm": ("R2", "surface_dice_2mm"), "r1_dice": ("R1", "native_r1_label_dice"), "r4_consistency": ("R4", "prediction_consistency_dice")}
    means, direct, interaction = {}, {}, {}
    for method in ("dynamic_delta", "static_delta", "gridcons_mamba", METHOD):
        means[method] = {name: float(paired.matrix(rows, method, spacing, field).mean()) for name, (spacing, field) in specs.items()}
    for name, (spacing, field) in specs.items():
        dynamic_full = paired.matrix(rows, METHOD, spacing, field)
        static_full = paired.matrix(rows, "gridcons_mamba", spacing, field)
        dynamic_none = paired.matrix(rows, "dynamic_delta", spacing, field)
        static_none = paired.matrix(rows, "static_delta", spacing, field)
        direct[name] = summarize(dynamic_full - static_full, case_samples, seed_samples)
        interaction[name] = summarize((static_full - static_none) - (dynamic_full - dynamic_none), case_samples, seed_samples)
    dynamic_gain = {name: summarize(paired.matrix(rows, METHOD, spacing, field) - paired.matrix(rows, "dynamic_delta", spacing, field), case_samples, seed_samples) for name, (spacing, field) in specs.items()}
    flags = {"dynamic_consistency_main_effect": dynamic_gain["r2_consistency"]["ci95"][0] > 0 and dynamic_gain["r1_dice"]["ci95"][0] >= -0.01, "static_carrier_interaction_supported": interaction["r2_consistency"]["ci95"][0] > 0 and interaction["r2_mapped_dice"]["ci95"][0] > 0, "full_arms_r2_consistency_equivalent_0p01": direct["r2_consistency"]["ci95"][0] >= -0.01 and direct["r2_consistency"]["ci95"][1] <= 0.01}
    result = {"role": "post-hoc completion of the missing 2x2 factorial arm", "method_means": means, "dynamic_full_minus_static_full": direct, "difference_in_differences_static_minus_dynamic": interaction, "dynamic_full_minus_dynamic_none": dynamic_gain, "flags": flags}
    dump_json(OUT / "results.json", result)
    lines = ["# Dynamic-delta + full-consistency causal audit", "", "This is a post-hoc completion of the missing delta × consistency factorial arm.", "", "| Method | R1 Dice | R2 consistency | R2 mapped Dice | R2 surface@2mm | R4 consistency |", "|---|---:|---:|---:|---:|---:|"]
    for method, values in means.items():
        lines.append(f"| {method} | {values['r1_dice']:.4f} | {values['r2_consistency']:.4f} | {values['r2_mapped_dice']:.4f} | {values['r2_surface_dice_2mm']:.4f} | {values['r4_consistency']:.4f} |")
    lines += ["", "## Dynamic-full minus static-full", "", "| Metric | Difference [95% CI] |", "|---|---:|"]
    for name, value in direct.items(): lines.append(f"| {name} | {value['mean_difference']:+.4f} [{value['ci95'][0]:+.4f}, {value['ci95'][1]:+.4f}] |")
    lines += ["", "## Factorial interaction: (static-full − static-none) − (dynamic-full − dynamic-none)", "", "| Metric | Interaction [95% CI] |", "|---|---:|"]
    for name, value in interaction.items(): lines.append(f"| {name} | {value['mean_difference']:+.4f} [{value['ci95'][0]:+.4f}, {value['ci95'][1]:+.4f}] |")
    lines += ["", f"Flags: `{json.dumps(flags, sort_keys=True)}`", ""]
    (OUT / "report.md").write_text("\n".join(lines))
    print(OUT / "report.md")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("check")
    train_parser = sub.add_parser("train"); train_parser.add_argument("--seed", type=int, choices=SEEDS, required=True)
    sub.add_parser("evaluate"); sub.add_parser("report")
    args = parser.parse_args()
    if args.command == "check": check()
    elif args.command == "train": train(args.seed)
    elif args.command == "evaluate": evaluate()
    else: report()


if __name__ == "__main__":
    main()
