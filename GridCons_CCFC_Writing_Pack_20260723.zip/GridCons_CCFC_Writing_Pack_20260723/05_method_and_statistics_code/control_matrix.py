#!/usr/bin/env python
"""Frozen Task04 independent control-matrix runner."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True

import numpy as np
import torch


ROOT = Path(__file__).resolve().parent
ORIGINAL = Path("/home/yanjingjia/grid_stable_mamba_probe")
OLD_ROOT = Path("/home/yanjingjia/metric_mamba_gate")
AUDIT_PATH = Path("/home/yanjingjia/gridcons_followup_20260720/00_original_audit/ORIGINAL_MACHINE_AUDIT.json")
CONFIRM_METRICS_PATH = ORIGINAL / "outputs" / "paired_full" / "metrics.csv"
sys.path.insert(0, str(ORIGINAL))
import run_paired_full as paired_source  # noqa: E402
import run_probe as source  # noqa: E402
from model import TinyMetricMamba, parameter_count as mamba_parameter_count  # noqa: E402
from unet3d import PlainUNet3D, parameter_count as unet_parameter_count  # noqa: E402


PROTOCOL_PATH = ROOT / "CONTROL_PROTOCOL_PRETRAINING.json"
SEEDS = (17, 29, 41, 53, 67)
NEW_ARMS = ("dynamic_delta_consistency", "unet3d", "unet3d_consistency")
ALL_ARMS = ("dynamic_delta", "static_delta", "gridcons_mamba", *NEW_ARMS)
CONSISTENCY_ARMS = {"dynamic_delta_consistency", "unet3d_consistency"}
UPDATES = 2500
VALIDATE_EVERY = 250
CONSISTENCY_WEIGHT = 0.1
WARMUP_UPDATES = 500
CODE_FILES = (
    "unet3d.py",
    "control_matrix.py",
    "control_statistics.py",
    "test_control_matrix.py",
    "reproduce_control_matrix.sh",
)
SOURCE_FILES = {
    "original_machine_audit": AUDIT_PATH,
    "source_model": ORIGINAL / "model.py",
    "source_probe": ORIGINAL / "run_probe.py",
    "source_paired_runner": ORIGINAL / "run_paired_full.py",
    "source_data_runner": OLD_ROOT / "run_gate.py",
    "source_manifest": OLD_ROOT / "outputs" / "manifest.json",
    "source_configs": OLD_ROOT / "outputs" / "configs.json",
    "confirm_manifest": ORIGINAL / "outputs" / "paired_full" / "confirm_manifest.json",
    "source_development_metrics": ORIGINAL / "outputs" / "metrics.csv",
    "source_gridcons_development": ORIGINAL / "outputs" / "paired_full" / "dev_screen.json",
    "source_protocol_pretraining": ORIGINAL / "outputs" / "paired_full" / "protocol_pretraining.json",
    "source_protocol": ORIGINAL / "outputs" / "paired_full" / "protocol.json",
    "dataset_json": Path("/home/yanjingjia/data/Task04_Hippocampus/dataset.json"),
    "dataset_archive": Path("/home/yanjingjia/data/Task04_Hippocampus.tar"),
}
AUDITED_FIXED_SOURCE_SHA256 = {
    "source_model": "e783f223161da9fd9add5867956d0f3dba2cbeff0c2929f23523b09e48a5c1eb",
    "source_probe": "37a7f407063880d4cc5e07b0a6bf29ad05b1a09993e8a9782519ef98f5697894",
    "source_paired_runner": "8aac96d628ac0fc8881936f49629219c5accb3fdc2c97f52636072672b44fbc4",
    "source_data_runner": "9a098af8165db70a83c3c91c48c621956fdd0214d03f9fa038a0949a5db4d3f7",
    "source_manifest": "73c1a32f8aaab91e67a2da596cd3489245829aa8ac90c1e289fc67dc978b8c21",
    "source_configs": "c7be6fda7fc7ec5447687957632afdea9c6739e21cf0921fbcb233e67a7261b1",
    "confirm_manifest": "ae909321483b277a216011d73c1cdc730d809d795cc656af4d3a2a0a4a891d96",
    "source_protocol_pretraining": "f0ed35807c33ce64d5d2c747f2b94ee600ca72bf9cbcfdf14bbd16c4a614ace5",
    "source_protocol": "c2aa3089e674f32f973bbcecba0942c337d93bc6880fc9587cbd8abc3102195d",
    "dataset_json": "5ad98d4c7146d434badcdf4051d9ca98291056fc66083bee7904fdbceb0c356e",
    "dataset_archive": "282d808a3e84e5a52f090d9dd4c0b0057b94a6bd51ad41569aef5ff303287771",
}
_VERIFIED_PROTOCOL: dict | None = None


def now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat()


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def object_hash(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def protocol_hash(value: dict) -> str:
    return object_hash({key: item for key, item in value.items() if key != "protocol_hash"})


def append_jsonl(path: Path, value: dict) -> None:
    payload = (json.dumps(value, sort_keys=True, allow_nan=False) + "\n").encode()
    descriptor = os.open(path, os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o664)
    try:
        os.write(descriptor, payload)
    finally:
        os.close(descriptor)


def append_attempt(value: dict) -> None:
    append_jsonl(ROOT / "TRAINING_ATTEMPTS.jsonl", value)


def archive_failed_output(path: Path) -> None:
    if path.exists():
        destination = ROOT / "logs" / f"failed_{time.time_ns()}_{path.name}"
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)


def code_hashes() -> dict[str, str]:
    return {name: sha256(ROOT / name) for name in CODE_FILES}


def source_hashes() -> dict[str, str]:
    return {name: sha256(path) for name, path in SOURCE_FILES.items()}


def nvidia_inventory() -> list[str]:
    return subprocess.run(
        [
            "nvidia-smi",
            "--query-gpu=index,uuid,name,driver_version,memory.total,compute_cap",
            "--format=csv,noheader",
        ],
        text=True,
        capture_output=True,
        check=True,
    ).stdout.splitlines()


def hardware_fingerprint() -> dict:
    return {
        "gpu": torch.cuda.get_device_name(0),
        "gpu_memory_bytes": torch.cuda.get_device_properties(0).total_memory,
        "pytorch": torch.__version__,
        "cuda_build": torch.version.cuda,
        "cudnn": torch.backends.cudnn.version(),
        "nvidia_smi": nvidia_inventory(),
    }


def audit_binding_checks(
    audit: dict, current_sources: dict[str, str], checkpoints: dict[str, dict[str, str]]
) -> dict[str, bool]:
    checks = {
        f"audited_file_{name}": current_sources.get(name) == expected
        for name, expected in AUDITED_FIXED_SOURCE_SHA256.items()
    }
    checks.update(
        audit_status=audit.get("status") == "PASS_ORIGINAL_MACHINE_AUDIT",
        audited_source_manifest_internal_hash=source.manifest()["manifest_hash"]
        == audit["hashes"]["source_manifest_content_sha256"],
        audited_confirm_manifest_internal_hash=paired_source.confirm_manifest()["manifest_hash"]
        == audit["hashes"]["confirm_manifest_content_sha256"],
        audited_dynamic_checkpoints=checkpoints["dynamic_delta"] == audit["hashes"]["source_checkpoints"]["dynamic_delta"],
        audited_static_checkpoints=checkpoints["static_delta"] == audit["hashes"]["source_checkpoints"]["static_delta"],
        audited_gridcons_checkpoints=checkpoints["gridcons_mamba"] == audit["hashes"]["proposed_checkpoints"],
        audited_gpu0=torch.cuda.is_available()
        and torch.cuda.get_device_name(0) == audit["environment"]["gpu"][0]["name"],
        audited_sealed_confirm_metrics_expected=audit["hashes"]["metrics_csv_sha256"]
        == "067d3e94b87ebfd7febe21d208a22eb15d1444acc7ecc4b1e7cba464f5533368",
    )
    return checks


def split_payload() -> dict[str, list[str]]:
    manifest = source.manifest()
    confirm = paired_source.confirm_manifest()
    return {
        "train": manifest["split"]["train"],
        "validation": manifest["split"]["validation"],
        "development": manifest["split"]["test"],
        "confirm": confirm["confirm_test"],
    }


def source_checkpoint_hashes() -> dict[str, dict[str, str]]:
    result = {
        "dynamic_delta": {str(seed): sha256(source.checkpoint_path("content_delta", seed)) for seed in SEEDS},
        "static_delta": {
            str(seed): sha256(source.checkpoint_path("separated_physical_delta", seed)) for seed in SEEDS
        },
        "gridcons_mamba": {
            str(seed): sha256(ORIGINAL / "outputs" / "paired_full" / "checkpoints" / f"gridcons_seed{seed}.pt")
            for seed in SEEDS
        },
    }
    return result


def cache_tree_snapshot(role: str) -> dict[str, int | str]:
    if role not in {"development", "confirm"}:
        raise ValueError("cache role must be development or confirm")
    paths = []
    manifest = source.manifest() if role == "development" else paired_source.confirm_manifest()
    for case in manifest["cases"].values():
        for grid in case["grids"].values():
            paths.extend((Path(grid["image_cache"]), Path(grid["label_cache"])))
    unique = sorted(set(paths), key=lambda path: str(path.relative_to(source.OLD.CACHE)))
    digest, total_bytes = hashlib.sha256(), 0
    for path in unique:
        relative = str(path.relative_to(source.OLD.CACHE))
        file_hash = sha256(path)
        digest.update(relative.encode() + b"\0" + file_hash.encode() + b"\n")
        total_bytes += path.stat().st_size
    return {"files": len(unique), "bytes": total_bytes, "sha256": digest.hexdigest()}


def verify_split(splits: dict[str, list[str]]) -> dict[str, bool]:
    dataset = json.loads(SOURCE_FILES["dataset_json"].read_text())
    case_ids = sorted(Path(item["image"]).name.removesuffix(".nii.gz") for item in dataset["training"])
    indices = np.arange(len(case_ids))
    np.random.default_rng(source.OLD.SPLIT_SEED).shuffle(indices)
    expected = {
        "train": [case_ids[index] for index in indices[:80]],
        "validation": [case_ids[index] for index in indices[80:100]],
        "development": [case_ids[index] for index in indices[100:120]],
        "confirm": [case_ids[index] for index in indices[120:160]],
    }
    flat = [case_id for values in splits.values() for case_id in values]
    return {
        "counts_80_20_20_40": [len(splits[key]) for key in ("train", "validation", "development", "confirm")]
        == [80, 20, 20, 40],
        "all_160_case_ids_unique": len(flat) == len(set(flat)) == 160,
        "exact_seeded_selection_reproduced": splits == expected,
    }


def verify_physical_alignment(splits: dict[str, list[str]]) -> bool:
    source_manifest = source.manifest()
    confirm_manifest = paired_source.confirm_manifest()
    for role, case_ids in splits.items():
        manifest = confirm_manifest if role == "confirm" else source_manifest
        for case_id in case_ids:
            grids = manifest["cases"][case_id]["grids"]
            bounds = [np.asarray(grids[name]["physical_bounds_center_mm"]) for name in ("R1", "R2", "R4")]
            depths = [grids[name]["unpadded_shape_dhw"][0] for name in ("R1", "R2", "R4")]
            if not all(np.allclose(bounds[0], item, atol=1e-6) for item in bounds[1:]):
                return False
            if depths[0] != 2 * (depths[1] - 1) + 1 or depths[0] != 4 * (depths[2] - 1) + 1:
                return False
    return True


def setup() -> None:
    audit = json.loads(AUDIT_PATH.read_text())
    if audit.get("status") != "PASS_ORIGINAL_MACHINE_AUDIT":
        raise RuntimeError("prerequisite is not PASS_ORIGINAL_MACHINE_AUDIT")
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly one visible CUDA GPU is required")
    if (
        not sys.dont_write_bytecode
        or os.environ.get("PYTHONDONTWRITEBYTECODE") != "1"
        or os.environ.get("CUDA_VISIBLE_DEVICES") != "0"
        or os.environ.get("OMP_NUM_THREADS") != "1"
        or os.environ.get("MKL_NUM_THREADS") != "1"
    ):
        raise RuntimeError("setup requires frozen bytecode, CUDA, OMP, and MKL environment variables")
    if PROTOCOL_PATH.exists():
        verify_protocol()
        print(f"frozen protocol already valid: {PROTOCOL_PATH}")
        return
    splits = split_payload()
    split_checks = verify_split(splits)
    if not all(split_checks.values()) or not verify_physical_alignment(splits):
        raise RuntimeError("source split or physical alignment is invalid")
    records = source.training_records()
    if len(records) != 10 or not all(source.training_record_valid(item) for item in records):
        raise RuntimeError("source dynamic/static training evidence is invalid")
    source_checkpoints = source_checkpoint_hashes()
    current_sources = source_hashes()
    binding_checks = audit_binding_checks(audit, current_sources, source_checkpoints)
    if not all(binding_checks.values()):
        raise RuntimeError(f"current originals do not match the original-machine audit: {[k for k, v in binding_checks.items() if not v]}")
    for seed in SEEDS:
        source.load_model("content_delta", seed, torch.device("cpu"))
        source.load_model("separated_physical_delta", seed, torch.device("cpu"))
        path = ORIGINAL / "outputs" / "paired_full" / "checkpoints" / f"gridcons_seed{seed}.pt"
        saved = torch.load(path, map_location="cpu", weights_only=False)
        if saved.get("method") != "gridcons_mamba" or saved.get("seed") != seed:
            raise RuntimeError(f"invalid source GridCons checkpoint: {path}")
        model = TinyMetricMamba("separated_physical_delta")
        model.load_state_dict(saved["model_state"], strict=True)
    unet = PlainUNet3D(out_channels=3)
    structure = (
        "PlainUNet3D frozen before training\n"
        "four resolution levels; three 2x MaxPool3d downsamples and three 2x ConvTranspose3d upsamples\n"
        "each encoder/decoder level: two 3x3x3 bias-free Conv3d + InstanceNorm3d(affine=True, "
        "track_running_stats=False) + ReLU\n"
        "channels: 16, 32, 64, 128; skip connections by concatenation; final 1x1x1 3-class head\n"
        "input is zero-padded at the high D/H/W ends to multiples of 8 and output is cropped to the exact input shape\n"
        "no attention, Mamba, Transformer, dropout, deep supervision, residual block, or task-specific module\n\n"
        + str(unet)
        + "\n"
    )
    structure_path = ROOT / "UNET3D_STRUCTURE.txt"
    structure_path.write_text(structure)
    pip_freeze = subprocess.run(
        [sys.executable, "-m", "pip", "freeze"], text=True, capture_output=True, check=True
    ).stdout
    nvidia_smi = nvidia_inventory()
    split_hashes = {key: object_hash(value) for key, value in splits.items()}
    value = {
        "task": "T1_TASK04_CONTROL_MATRIX",
        "frozen_at": now(),
        "prerequisite": {"path": str(AUDIT_PATH), "required_status": "PASS_ORIGINAL_MACHINE_AUDIT"},
        "isolation": {
            "read_only_roots": [str(ORIGINAL), str(OLD_ROOT), "/home/yanjingjia/data/Task04_Hippocampus"],
            "only_write_root": str(ROOT),
            "python_dont_write_bytecode": True,
        },
        "arms": list(NEW_ARMS),
        "references": ["dynamic_delta", "static_delta", "gridcons_mamba"],
        "seeds": list(SEEDS),
        "split": splits,
        "split_hashes": split_hashes,
        "combined_split_sha256": object_hash(splits),
        "split_checks": split_checks,
        "source_manifest_hash": source.manifest()["manifest_hash"],
        "confirm_manifest_hash": paired_source.confirm_manifest()["manifest_hash"],
        "training": {
            "updates": UPDATES,
            "validation_every_updates": VALIDATE_EVERY,
            "optimizer": "AdamW",
            "learning_rate": 3e-4,
            "weight_decay": 1e-5,
            "amp": "bfloat16",
            "augmentation": "none",
            "case_order": "numpy.default_rng(seed).permutation(80).tolist(), consumed by pop()",
            "supervised_loss": "source loss: 0.5 foreground multiclass soft-Dice + 0.5 cross-entropy",
            "checkpoint_selection": "strictly highest R1 validation foreground mean Dice; ties retain earliest",
        },
        "consistency": {
            "source_function": "run_paired_full.paired_grid_consistency_loss",
            "view": "same-case R2 image only; training/selection loaders never open or deserialize R2 labels",
            "teacher": "stop-gradient R1 foreground probability",
            "alignment": "crop padding; trilinear R2 probabilities to R1 shape with align_corners=True; renormalize",
            "loss": "foreground squared-denominator soft-Dice",
            "maximum_weight": CONSISTENCY_WEIGHT,
            "linear_warmup_updates": WARMUP_UPDATES,
            "formula": "0.1 * min(1, update / 500)",
        },
        "unet3d": {
            "base_channels": 16,
            "output_classes": 3,
            "parameters": unet_parameter_count(unet),
            "structure_path": str(structure_path),
            "structure_sha256": sha256(structure_path),
        },
        "model_parameters": {
            "dynamic_delta": mamba_parameter_count(TinyMetricMamba("content_delta")),
            "static_delta": mamba_parameter_count(TinyMetricMamba("separated_physical_delta")),
            "unet3d": unet_parameter_count(unet),
        },
        "development_release_rule": {
            "pairs": [
                "dynamic_delta_consistency - dynamic_delta",
                "gridcons_mamba - static_delta",
                "unet3d_consistency - unet3d",
            ],
            "each_pair_requires": "mean R2 consistency difference > 0 and mean R1 Dice difference >= -0.01",
            "release_confirm": "all three pair rules plus code/data/test/checkpoint integrity",
            "confirm_results_used": False,
        },
        "confirm": {
            "single_release": True,
            "no_tuning_or_seed_selection_after_release": True,
            "metrics": ["R1 Dice", "R2 consistency", "R2 mapped Dice", "surface Dice@2mm", "R4 consistency"],
            "bootstrap": {
                "kind": "hierarchical paired case-and-seed bootstrap",
                "samples": 10000,
                "seed": 7301,
            },
        },
        "interpretation_rules": {
            "mamba_did": "if 95% CI lower bound <= 0, do not claim static delta is necessary for consistency gain",
            "unet_pass": "if U-Net consistency mean gain > 0 with R1 difference >= -0.01, conclude cross-backbone consistency effect and do not attribute all gain to Mamba",
            "unet_fail_gridcons_pass": "state only: observed architecture-related interaction; never claim Mamba generally outperforms U-Net",
            "negative_results": "retain as-is; do not change metric, model, hyperparameter, seed, or rerun to select results",
        },
        "status_rule": {
            "development_scientific_gate_false": "FAIL_CONTROL_SCIENTIFIC; confirm remains sealed",
            "released_confirm_complete_and_valid": "PASS_CONTROL_EVIDENCE_COMPLETE regardless of effect direction",
            "missing_leakage_protocol_drift_or_incomplete": "BLOCKED_CONTROL_ENGINEERING",
        },
        "benchmark": {
            "case_id": splits["development"][0],
            "grid": "R1",
            "batch_size": 1,
            "amp": "bfloat16",
            "inference_mode": True,
            "warmup_iterations": 20,
            "timed_iterations": 100,
            "synchronize_each_iteration": True,
            "seed_checkpoint": 17,
            "all_six_arms_same_process_serially": True,
        },
        "commands": {
            "full": str(ROOT / "reproduce_control_matrix.sh"),
            "setup": f"{sys.executable} {ROOT / 'control_matrix.py'} setup",
            "test": f"{sys.executable} -m unittest -v test_control_matrix.py",
            "train": f"{sys.executable} {ROOT / 'control_matrix.py'} train --arm ARM --seed SEED",
            "development": f"{sys.executable} {ROOT / 'control_matrix.py'} screen-dev",
            "confirm": f"{sys.executable} {ROOT / 'control_matrix.py'} evaluate-confirm",
            "benchmark": f"{sys.executable} {ROOT / 'control_matrix.py'} benchmark",
            "statistics": f"{sys.executable} {ROOT / 'control_statistics.py'}",
            "parallelism": 8,
        },
        "environment": {
            "python": platform.python_version(),
            "python_executable": sys.executable,
            "pytorch": torch.__version__,
            "cuda_build": torch.version.cuda,
            "cudnn": torch.backends.cudnn.version(),
            "numpy": np.__version__,
            "gpu": torch.cuda.get_device_name(0),
            "gpu_memory_bytes": torch.cuda.get_device_properties(0).total_memory,
            "visible_cuda_devices": 1,
            "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
            "omp_num_threads": os.environ.get("OMP_NUM_THREADS"),
            "mkl_num_threads": os.environ.get("MKL_NUM_THREADS"),
            "pip_freeze_sha256": hashlib.sha256(pip_freeze.encode()).hexdigest(),
            "pip_freeze": pip_freeze.splitlines(),
            "nvidia_smi": nvidia_smi,
        },
        "code_sha256": code_hashes(),
        "arm_code_sha256": {
            "dynamic_delta_consistency": {
                "runner": sha256(ROOT / "control_matrix.py"),
                "mamba_model_source": sha256(ORIGINAL / "model.py"),
                "consistency_source": sha256(ORIGINAL / "run_paired_full.py"),
            },
            "unet3d": {"runner": sha256(ROOT / "control_matrix.py"), "model": sha256(ROOT / "unet3d.py")},
            "unet3d_consistency": {
                "runner": sha256(ROOT / "control_matrix.py"),
                "model": sha256(ROOT / "unet3d.py"),
                "consistency_source": sha256(ORIGINAL / "run_paired_full.py"),
            },
        },
        "source_file_sha256": current_sources,
        "source_checkpoint_sha256": source_checkpoints,
        "original_audit_binding_checks": binding_checks,
        "development_cache_snapshot": cache_tree_snapshot("development"),
        "sealed_confirm_evidence": {
            "metrics_path": str(CONFIRM_METRICS_PATH),
            "expected_metrics_sha256_from_original_audit": audit["hashes"]["metrics_csv_sha256"],
            "metrics_and_confirm_cache_must_not_be_opened_before_development_release": True,
        },
    }
    value["protocol_hash"] = protocol_hash(value)
    dump_json(PROTOCOL_PATH, value)
    print(f"frozen protocol: {PROTOCOL_PATH}\nprotocol_hash={value['protocol_hash']}")


def verify_protocol() -> dict:
    global _VERIFIED_PROTOCOL
    if _VERIFIED_PROTOCOL is not None:
        return _VERIFIED_PROTOCOL
    value = json.loads(PROTOCOL_PATH.read_text())
    if value.get("protocol_hash") != protocol_hash(value):
        raise RuntimeError("pretraining protocol internal hash mismatch")
    if value.get("code_sha256") != code_hashes():
        raise RuntimeError("frozen code hash drift")
    if value.get("source_file_sha256") != source_hashes():
        raise RuntimeError("read-only source hash drift")
    if value.get("source_checkpoint_sha256") != source_checkpoint_hashes():
        raise RuntimeError("read-only source checkpoint drift")
    audit = json.loads(AUDIT_PATH.read_text())
    if audit.get("status") != "PASS_ORIGINAL_MACHINE_AUDIT":
        raise RuntimeError("prerequisite audit no longer passes")
    current_bindings = audit_binding_checks(audit, value["source_file_sha256"], value["source_checkpoint_sha256"])
    if value.get("original_audit_binding_checks") != current_bindings or not all(current_bindings.values()):
        raise RuntimeError("frozen originals are not bound to the original-machine audit")
    if split_payload() != value["split"] or not all(verify_split(value["split"]).values()):
        raise RuntimeError("frozen split drift")
    if sha256(ROOT / "UNET3D_STRUCTURE.txt") != value["unet3d"]["structure_sha256"]:
        raise RuntimeError("frozen U-Net structure drift")
    if cache_tree_snapshot("development") != value.get("development_cache_snapshot"):
        raise RuntimeError("read-only development cached data drift")
    _VERIFIED_PROTOCOL = value
    return value


def build_model(arm: str) -> torch.nn.Module:
    if arm == "dynamic_delta_consistency":
        return TinyMetricMamba("content_delta")
    if arm in {"unet3d", "unet3d_consistency"}:
        return PlainUNet3D(out_channels=3)
    raise ValueError(f"not a new arm: {arm}")


def forward_logits(model: torch.nn.Module, arm: str, image: torch.Tensor, spacing: list[float]) -> torch.Tensor:
    if arm in {"dynamic_delta", "static_delta", "gridcons_mamba", "dynamic_delta_consistency"}:
        value = torch.tensor([spacing], device=image.device, dtype=torch.float32)
        return model(image, value)
    return model(image)


def batch_loss(
    model: torch.nn.Module,
    arm: str,
    r1_image: torch.Tensor,
    r1_label: torch.Tensor,
    r2_image: torch.Tensor | None,
    r1_shape: list[int],
    r2_shape: list[int],
    consistency_weight: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor | None]:
    r1_logits = forward_logits(model, arm, r1_image, [1.0, 1.0, 1.0])
    segmentation = source.OLD.loss_fn(r1_logits, r1_label)
    if consistency_weight == 0:
        return segmentation, segmentation, None
    if r2_image is None:
        raise ValueError("R2 image is required when consistency weight is non-zero")
    r2_logits = forward_logits(model, arm, r2_image, [2.0, 1.0, 1.0])
    consistency = paired_source.paired_grid_consistency_loss(r1_logits, r2_logits, r1_shape, r2_shape)
    return segmentation + consistency_weight * consistency, segmentation, consistency


def load_training_cases(
    manifest: dict, use_consistency: bool
) -> list[tuple[str, np.ndarray, np.ndarray, np.ndarray | None]]:
    cases = []
    for case_id in manifest["split"]["train"]:
        grids = manifest["cases"][case_id]["grids"]
        cases.append(
            (
                case_id,
                np.load(grids["R1"]["image_cache"]),
                np.load(grids["R1"]["label_cache"]),
                np.load(grids["R2"]["image_cache"]) if use_consistency else None,
            )
        )
    return cases


@torch.inference_mode()
def predict(model: torch.nn.Module, arm: str, image: np.ndarray, spacing: list[float]) -> np.ndarray:
    device = next(model.parameters()).device
    tensor = torch.from_numpy(np.asarray(image, dtype=np.float32)).to(device)[None, None]
    with torch.autocast("cuda", dtype=torch.bfloat16):
        probability = forward_logits(model, arm, tensor, spacing).softmax(1)[0].float()
    if not torch.isfinite(probability).all():
        raise RuntimeError("non-finite probability")
    return probability.cpu().numpy()


@torch.inference_mode()
def validation_dice(model: torch.nn.Module, arm: str, manifest: dict) -> float:
    scores = []
    for case_id in manifest["split"]["validation"]:
        grids = manifest["cases"][case_id]["grids"]
        image = np.load(grids["R1"]["image_cache"])
        label = np.load(grids["R1"]["label_cache"])
        shape = grids["R1"]["unpadded_shape_dhw"]
        slices = tuple(slice(0, size) for size in shape)
        hard = predict(model, arm, image, [1.0, 1.0, 1.0])[(slice(None),) + slices].argmax(0)
        truth = label[slices]
        scores.extend(source.OLD.binary_dice(hard == cls, truth == cls) for cls in (1, 2))
    return float(np.mean(scores))


def checkpoint_paths(arm: str, seed: int) -> tuple[Path, Path]:
    if arm not in NEW_ARMS or seed not in SEEDS:
        raise ValueError("unregistered arm or seed")
    return ROOT / "checkpoints" / f"{arm}_seed{seed}.pt", ROOT / "logs" / f"train_{arm}_seed{seed}.json"


def validate_training_output(arm: str, seed: int, frozen: dict | None = None) -> str:
    frozen = frozen or verify_protocol()
    checkpoint, log_path = checkpoint_paths(arm, seed)
    if not checkpoint.is_file() or not log_path.is_file():
        raise RuntimeError(f"missing training output: {arm}/{seed}")
    log = json.loads(log_path.read_text())
    history = log.get("history", [])
    expected_updates = list(range(VALIDATE_EVERY, UPDATES + 1, VALIDATE_EVERY))
    current_hash = sha256(checkpoint)
    if not (
        log.get("completed")
        and log.get("finite")
        and log.get("arm") == arm
        and log.get("seed") == seed
        and log.get("updates") == UPDATES
        and log.get("validation_interval") == VALIDATE_EVERY
        and [item.get("update") for item in history] == expected_updates
        and log.get("checkpoint") == str(checkpoint)
        and log.get("checkpoint_sha256") == current_hash
        and log.get("checkpoint_selection") == "validation_R1_mean_anterior_posterior_Dice_only"
        and log.get("optimizer") == "AdamW(lr=3e-4, weight_decay=1e-5)"
        and log.get("amp") == "bfloat16"
        and log.get("consistency_weight") == (CONSISTENCY_WEIGHT if arm in CONSISTENCY_ARMS else 0.0)
        and log.get("consistency_warmup_updates") == (WARMUP_UPDATES if arm in CONSISTENCY_ARMS else 0)
        and log.get("r2_label_loaded_for_training_or_selection") is False
        and log.get("protocol_hash") == frozen["protocol_hash"]
        and log.get("gpu_seconds", 0) > 0
        and log.get("peak_allocated_bytes", 0) > 0
    ):
        raise RuntimeError(f"invalid training log: {arm}/{seed}")
    for item in history:
        values = [item.get("training_loss"), item.get("r1_segmentation_loss"), item.get("validation_r1_mean_dice")]
        expected_weight = (
            CONSISTENCY_WEIGHT * min(1.0, item["update"] / WARMUP_UPDATES) if arm in CONSISTENCY_ARMS else 0.0
        )
        if not (
            np.isfinite(values).all()
            and item.get("effective_consistency_weight") == expected_weight
            and (
                np.isfinite(item.get("paired_consistency_loss"))
                if arm in CONSISTENCY_ARMS
                else item.get("paired_consistency_loss") is None
            )
        ):
            raise RuntimeError(f"invalid training history: {arm}/{seed}")
    scores = [item["validation_r1_mean_dice"] for item in history]
    best_score = max(scores)
    best_update = history[scores.index(best_score)]["update"]
    if log.get("best_validation_r1_mean_dice") != best_score:
        raise RuntimeError(f"training best-score mismatch: {arm}/{seed}")
    saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if not (
        saved.get("arm") == arm
        and saved.get("seed") == seed
        and saved.get("protocol_hash") == frozen["protocol_hash"]
        and saved.get("selection") == "validation_R1_mean_anterior_posterior_Dice_only"
        and saved.get("validation_r1_mean_dice") == best_score
        and saved.get("update") == best_update
    ):
        raise RuntimeError(f"invalid checkpoint metadata: {arm}/{seed}")
    model = build_model(arm)
    model.load_state_dict(saved["model_state"], strict=True)
    return current_hash


def train(arm: str, seed: int) -> None:
    frozen = verify_protocol()
    checkpoint, log_path = checkpoint_paths(arm, seed)
    if checkpoint.exists() and log_path.exists():
        try:
            validate_training_output(arm, seed, frozen)
            print(f"completed training exists: {log_path}")
            return
        except Exception as error:
            append_attempt(
                {"arm": arm, "seed": seed, "event": "invalid_existing_rerun", "at": now(), "error": repr(error)}
            )
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    attempt = {"arm": arm, "seed": seed, "started_at": now(), "protocol_hash": frozen["protocol_hash"]}
    append_attempt({**attempt, "event": "started"})
    started = time.perf_counter()
    try:
        manifest = source.manifest()
        device = torch.device("cuda:0")
        source.OLD.seed_all(seed)
        model = build_model(arm).to(device)
        optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-5)
        cases = load_training_cases(manifest, arm in CONSISTENCY_ARMS)
        rng = np.random.default_rng(seed)
        order: list[int] = []
        history, best = [], -1.0
        checkpoint.parent.mkdir(parents=True, exist_ok=True)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
        for update in range(1, UPDATES + 1):
            if not order:
                order = rng.permutation(len(cases)).tolist()
            case_id, r1_image, r1_label, r2_image = cases[order.pop()]
            r1_shape = manifest["cases"][case_id]["grids"]["R1"]["unpadded_shape_dhw"]
            r2_shape = manifest["cases"][case_id]["grids"]["R2"]["unpadded_shape_dhw"]
            x1, y1 = source.OLD.tensors(r1_image, r1_label, device)
            x2 = (
                torch.from_numpy(np.asarray(r2_image, dtype=np.float32)).to(device)[None, None]
                if arm in CONSISTENCY_ARMS
                else None
            )
            weight = CONSISTENCY_WEIGHT * min(1.0, update / WARMUP_UPDATES) if arm in CONSISTENCY_ARMS else 0.0
            model.train()
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                loss, segmentation, consistency = batch_loss(model, arm, x1, y1, x2, r1_shape, r2_shape, weight)
            if not torch.isfinite(loss):
                raise RuntimeError(f"non-finite loss at update {update}")
            loss.backward()
            if not all(torch.isfinite(parameter.grad).all() for parameter in model.parameters() if parameter.grad is not None):
                raise RuntimeError(f"non-finite gradient at update {update}")
            optimizer.step()
            if update % VALIDATE_EVERY == 0:
                score = validation_dice(model, arm, manifest)
                item = {
                    "update": update,
                    "training_loss": float(loss),
                    "r1_segmentation_loss": float(segmentation),
                    "paired_consistency_loss": None if consistency is None else float(consistency),
                    "effective_consistency_weight": weight,
                    "validation_r1_mean_dice": score,
                }
                history.append(item)
                print(arm, seed, item, flush=True)
                if score > best:
                    best = score
                    torch.save(
                        {
                            "model_state": model.state_dict(),
                            "arm": arm,
                            "seed": seed,
                            "update": update,
                            "validation_r1_mean_dice": score,
                            "selection": "validation_R1_mean_anterior_posterior_Dice_only",
                            "protocol_hash": frozen["protocol_hash"],
                        },
                        checkpoint,
                    )
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - started
        log = {
            "completed": True,
            "finite": True,
            "arm": arm,
            "seed": seed,
            "updates": UPDATES,
            "validation_interval": VALIDATE_EVERY,
            "history": history,
            "best_validation_r1_mean_dice": best,
            "checkpoint": str(checkpoint),
            "checkpoint_sha256": sha256(checkpoint),
            "checkpoint_selection": "validation_R1_mean_anterior_posterior_Dice_only",
            "optimizer": "AdamW(lr=3e-4, weight_decay=1e-5)",
            "amp": "bfloat16",
            "consistency_weight": CONSISTENCY_WEIGHT if arm in CONSISTENCY_ARMS else 0.0,
            "consistency_warmup_updates": WARMUP_UPDATES if arm in CONSISTENCY_ARMS else 0,
            "r2_label_loaded_for_training_or_selection": False,
            "protocol_hash": frozen["protocol_hash"],
            "gpu_seconds": elapsed,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "finished_at": now(),
        }
        dump_json(log_path, log)
        append_attempt({**attempt, "event": "completed", "finished_at": log["finished_at"], "gpu_seconds": elapsed})
        print(json.dumps(log, indent=2))
    except Exception as error:
        append_attempt({**attempt, "event": "failed", "finished_at": now(), "error": repr(error)})
        raise


def load_new_model(arm: str, seed: int, device: torch.device) -> torch.nn.Module:
    checkpoint, _ = checkpoint_paths(arm, seed)
    saved = torch.load(checkpoint, map_location=device, weights_only=False)
    frozen = verify_protocol()
    if saved.get("arm") != arm or saved.get("seed") != seed or saved.get("protocol_hash") != frozen["protocol_hash"]:
        raise RuntimeError(f"checkpoint metadata mismatch: {checkpoint}")
    model = build_model(arm).to(device)
    model.load_state_dict(saved["model_state"], strict=True)
    return model.eval()


def validate_new_checkpoints() -> dict[str, dict[str, str]]:
    frozen = verify_protocol()
    return {
        arm: {str(seed): validate_training_output(arm, seed, frozen) for seed in SEEDS} for arm in NEW_ARMS
    }


def source_development_records() -> list[dict]:
    records: dict[tuple[str, str, int, str], dict] = {}
    with SOURCE_FILES["source_development_metrics"].open() as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        if row["method"] not in {"dynamic_delta_baseline", "trained_static_delta"}:
            continue
        arm = "dynamic_delta" if row["method"] == "dynamic_delta_baseline" else "static_delta"
        key = (row["case_id"], row["class"], int(row["seed"]), arm)
        item = records.setdefault(
            key,
            {"case_id": row["case_id"], "class": row["class"], "seed": int(row["seed"]), "arm": arm},
        )
        if row["spacing"] == "R1":
            item["r1_dice"] = float(row["native_r1_label_dice"])
        elif row["spacing"] == "R2":
            item["r2_consistency"] = float(row["prediction_consistency_dice"])
    gridcons = json.loads(SOURCE_FILES["source_gridcons_development"].read_text())
    if not (
        gridcons.get("source_manifest_hash") == source.manifest()["manifest_hash"]
        and gridcons.get("source_metrics_sha256") == sha256(SOURCE_FILES["source_development_metrics"])
        and gridcons.get("gridcons_checkpoint_sha256") == source_checkpoint_hashes()["gridcons_mamba"]
    ):
        raise RuntimeError("source GridCons development evidence does not match its frozen sources")
    for row in gridcons["records"]:
        key = (row["case_id"], row["class"], int(row["seed"]), "gridcons_mamba")
        records[key] = {
            "case_id": row["case_id"],
            "class": row["class"],
            "seed": int(row["seed"]),
            "arm": "gridcons_mamba",
            "r1_dice": float(row["r1_dice"]),
            "r2_consistency": float(row["r2_consistency"]),
        }
    result = list(records.values())
    expected = 20 * 2 * len(SEEDS) * 3
    if len(result) != expected or not all(
        set(item) == {"case_id", "class", "seed", "arm", "r1_dice", "r2_consistency"} for item in result
    ):
        raise RuntimeError("source development evidence is incomplete")
    return result


def expected_development_identities(case_ids: list[str]) -> set[tuple[str, str, int, str]]:
    return {
        (case_id, cls, seed, arm)
        for case_id in case_ids
        for cls in ("anterior", "posterior")
        for seed in SEEDS
        for arm in ALL_ARMS
    }


def expected_confirm_identities(methods: tuple[str, ...] | list[str]) -> set[tuple[str, str, int, str, str]]:
    return {
        (case_id, cls, seed, method, spacing)
        for case_id in paired_source.confirm_manifest()["confirm_test"]
        for cls in ("anterior", "posterior")
        for seed in SEEDS
        for method in methods
        for spacing in ("R1", "R2", "R4")
    }


def validate_development_gate(gate: dict, checkpoint_hashes: dict[str, dict[str, str]] | None = None) -> None:
    frozen = verify_protocol()
    metrics_path = ROOT / "development_metrics.csv"
    current_checkpoints = checkpoint_hashes or validate_new_checkpoints()
    expected_hash = object_hash({key: item for key, item in gate.items() if key != "development_gate_hash"})
    expected_comparisons = {
        "dynamic_delta_consistency_minus_dynamic_delta",
        "gridcons_mamba_minus_static_delta",
        "unet3d_consistency_minus_unet3d",
    }
    if not (
        metrics_path.is_file()
        and gate.get("protocol_hash") == frozen["protocol_hash"]
        and gate.get("case_ids") == frozen["split"]["development"]
        and gate.get("metrics_path") == str(metrics_path)
        and gate.get("metrics_sha256") == sha256(metrics_path)
        and gate.get("checkpoint_sha256") == current_checkpoints
        and gate.get("development_gate_hash") == expected_hash
        and set(gate.get("comparisons", {})) == expected_comparisons
        and gate.get("confirm_results_used") is False
        and gate.get("integrity_gates")
        and all(gate["integrity_gates"].values())
    ):
        raise RuntimeError("development gate provenance mismatch")
    with metrics_path.open() as handle:
        rows = list(csv.DictReader(handle))
    identities = {(row["case_id"], row["class"], int(row["seed"]), row["arm"]) for row in rows}
    if len(rows) != 20 * 2 * len(SEEDS) * len(ALL_ARMS) or identities != expected_development_identities(
        frozen["split"]["development"]
    ) or not all(np.isfinite(float(row[field])) for row in rows for field in ("r1_dice", "r2_consistency")):
        raise RuntimeError("development metric domain or values mismatch")
    pairs = {
        "dynamic_delta_consistency_minus_dynamic_delta": ("dynamic_delta_consistency", "dynamic_delta"),
        "gridcons_mamba_minus_static_delta": ("gridcons_mamba", "static_delta"),
        "unet3d_consistency_minus_unet3d": ("unet3d_consistency", "unet3d"),
    }
    for name, value in gate["comparisons"].items():
        candidate, reference = pairs[name]
        expected_r2 = np.mean([float(row["r2_consistency"]) for row in rows if row["arm"] == candidate]) - np.mean(
            [float(row["r2_consistency"]) for row in rows if row["arm"] == reference]
        )
        expected_r1 = np.mean([float(row["r1_dice"]) for row in rows if row["arm"] == candidate]) - np.mean(
            [float(row["r1_dice"]) for row in rows if row["arm"] == reference]
        )
        r2, r1 = value.get("mean_r2_consistency_difference"), value.get("mean_r1_dice_difference")
        if not (
            np.isfinite((r2, r1)).all()
            and value.get("candidate") == candidate
            and value.get("reference") == reference
            and np.isclose(r2, expected_r2, rtol=0, atol=1e-15)
            and np.isclose(r1, expected_r1, rtol=0, atol=1e-15)
            and value.get("r2_gain_positive") is (r2 > 0)
            and value.get("r1_guardrail_passed") is (r1 >= -0.01)
            and value.get("passed") is (r2 > 0 and r1 >= -0.01)
        ):
            raise RuntimeError("development comparison gate mismatch")
    if gate.get("release_confirm") is not all(value["passed"] for value in gate["comparisons"].values()):
        raise RuntimeError("development release decision mismatch")


def write_confirm_release(frozen: dict, gate: dict, checkpoint_hashes: dict[str, dict[str, str]]) -> None:
    if gate.get("release_confirm") is not True:
        raise RuntimeError("cannot release confirm after a failed scientific gate")
    validate_development_gate(gate, checkpoint_hashes)
    confirm_metrics_sha = sha256(CONFIRM_METRICS_PATH)
    if confirm_metrics_sha != frozen["sealed_confirm_evidence"]["expected_metrics_sha256_from_original_audit"]:
        raise RuntimeError("sealed source confirm metrics do not match the original-machine audit")
    gate_path = ROOT / "DEVELOPMENT_GATE.json"
    dump_json(
        ROOT / "CONFIRM_RELEASE.json",
        {
            "released_once": True,
            "released_at": now(),
            "protocol_hash": frozen["protocol_hash"],
            "development_gate_sha256": sha256(gate_path),
            "development_gate_hash": gate["development_gate_hash"],
            "checkpoint_sha256": checkpoint_hashes,
            "source_confirm_metrics_sha256": confirm_metrics_sha,
            "confirm_cache_snapshot": cache_tree_snapshot("confirm"),
        },
    )


def evaluate_development_arm(arm: str, seed: int, manifest: dict, device: torch.device) -> list[dict]:
    model = load_new_model(arm, seed, device)
    records = []
    for case_id in manifest["split"]["test"]:
        grids = manifest["cases"][case_id]["grids"]
        r1_grid, r2_grid = grids["R1"], grids["R2"]
        r1_image = np.load(r1_grid["image_cache"])
        r1_label_padded = np.load(r1_grid["label_cache"])
        r2_image = np.load(r2_grid["image_cache"])
        r1_shape, r2_shape = r1_grid["unpadded_shape_dhw"], r2_grid["unpadded_shape_dhw"]
        r1_slices, r2_slices = tuple(slice(0, n) for n in r1_shape), tuple(slice(0, n) for n in r2_shape)
        r1_label = r1_label_padded[r1_slices]
        r1_probability = predict(model, arm, r1_image, r1_grid["spacing_dhw"])[(slice(None),) + r1_slices]
        r1_hard = r1_probability.argmax(0)
        r2_probability = predict(model, arm, r2_image, r2_grid["spacing_dhw"])[(slice(None),) + r2_slices]
        mapped = source.OLD.map_probability(
            r2_probability, np.asarray(r2_grid["affine_xyz"]), r1_shape, np.asarray(r1_grid["affine_xyz"])
        ).argmax(0)
        for cls, name in ((1, "anterior"), (2, "posterior")):
            records.append(
                {
                    "case_id": case_id,
                    "class": name,
                    "seed": seed,
                    "arm": arm,
                    "r1_dice": source.OLD.binary_dice(r1_hard == cls, r1_label == cls),
                    "r2_consistency": source.OLD.binary_dice(mapped == cls, r1_hard == cls),
                }
            )
    del model
    return records


def screen_dev() -> None:
    frozen = verify_protocol()
    test_results_path = ROOT / "TEST_RESULTS.json"
    if not test_results_path.is_file():
        raise RuntimeError("official tests have not run")
    test_results = json.loads(test_results_path.read_text())
    required_tests = {
        "unet_output_shape_and_finite",
        "zero_consistency_matches_supervised_update",
        "r2_label_not_in_train_graph_or_loader",
        "same_case_physical_alignment",
    }
    if (
        set(test_results.get("gates", {})) != required_tests
        or not all(test_results["gates"].values())
        or test_results.get("code_sha256") != frozen["code_sha256"]
        or test_results.get("protocol_hash") != frozen["protocol_hash"]
    ):
        raise RuntimeError("official tests are incomplete or stale")
    checkpoint_hashes = validate_new_checkpoints()
    gate_path = ROOT / "DEVELOPMENT_GATE.json"
    if gate_path.exists():
        existing = json.loads(gate_path.read_text())
        validate_development_gate(existing, checkpoint_hashes)
        if existing.get("release_confirm"):
            if (ROOT / "CONFIRM_RELEASE.json").exists():
                verify_release()
            else:
                write_confirm_release(frozen, existing, checkpoint_hashes)
        elif (ROOT / "CONFIRM_RELEASE.json").exists():
            raise RuntimeError("failed development gate has a confirm release file")
        print(f"completed development gate exists: {gate_path}")
        return
    manifest = source.manifest()
    device = torch.device("cuda:0")
    records = source_development_records()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    for arm in NEW_ARMS:
        for seed in SEEDS:
            records.extend(evaluate_development_arm(arm, seed, manifest, device))
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    expected = 20 * 2 * len(SEEDS) * len(ALL_ARMS)
    identities = {(item["case_id"], item["class"], item["seed"], item["arm"]) for item in records}
    if identities != expected_development_identities(manifest["split"]["test"]) or len(records) != expected or not all(
        np.isfinite(item[field]) for item in records for field in ("r1_dice", "r2_consistency")
    ):
        raise RuntimeError("development evaluation is incomplete")
    metrics_path = ROOT / "development_metrics.csv"
    with metrics_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)

    def mean(arm: str, field: str) -> float:
        return float(np.mean([item[field] for item in records if item["arm"] == arm]))

    comparisons = {}
    for candidate, reference in (
        ("dynamic_delta_consistency", "dynamic_delta"),
        ("gridcons_mamba", "static_delta"),
        ("unet3d_consistency", "unet3d"),
    ):
        r2 = mean(candidate, "r2_consistency") - mean(reference, "r2_consistency")
        r1 = mean(candidate, "r1_dice") - mean(reference, "r1_dice")
        comparisons[f"{candidate}_minus_{reference}"] = {
            "candidate": candidate,
            "reference": reference,
            "mean_r2_consistency_difference": r2,
            "mean_r1_dice_difference": r1,
            "r2_gain_positive": r2 > 0,
            "r1_guardrail_passed": r1 >= -0.01,
            "passed": r2 > 0 and r1 >= -0.01,
        }
    scientific_release = all(item["passed"] for item in comparisons.values())
    result = {
        "role": "development screening only",
        "protocol_hash": frozen["protocol_hash"],
        "case_ids": manifest["split"]["test"],
        "metrics_path": str(metrics_path),
        "metrics_sha256": sha256(metrics_path),
        "checkpoint_sha256": checkpoint_hashes,
        "comparisons": comparisons,
        "integrity_gates": {
            "prerequisite_passed": True,
            "frozen_code_and_sources_unchanged": True,
            "official_tests_passed": True,
            "all_15_trainings_valid": True,
            "development_metrics_complete": True,
            "r2_labels_not_used_for_selection": True,
        },
        "release_confirm": scientific_release,
        "confirm_results_used": False,
        "gpu_seconds": elapsed,
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
        "finished_at": now(),
    }
    result["development_gate_hash"] = object_hash(
        {key: item for key, item in result.items() if key != "development_gate_hash"}
    )
    dump_json(gate_path, result)
    if scientific_release:
        write_confirm_release(frozen, result, checkpoint_hashes)
    print(json.dumps({"comparisons": comparisons, "release_confirm": scientific_release}, indent=2))


def verify_release() -> tuple[dict, dict]:
    frozen = verify_protocol()
    gate_path, release_path = ROOT / "DEVELOPMENT_GATE.json", ROOT / "CONFIRM_RELEASE.json"
    if not gate_path.is_file() or not release_path.is_file():
        raise RuntimeError("confirm has not been released")
    gate, release = json.loads(gate_path.read_text()), json.loads(release_path.read_text())
    checkpoint_hashes = validate_new_checkpoints()
    validate_development_gate(gate, checkpoint_hashes)
    if not (
        gate.get("release_confirm") is True
        and release.get("released_once") is True
        and release.get("protocol_hash") == frozen["protocol_hash"]
        and release.get("development_gate_sha256") == sha256(gate_path)
        and release.get("development_gate_hash") == gate.get("development_gate_hash")
        and release.get("checkpoint_sha256") == checkpoint_hashes
        and release.get("source_confirm_metrics_sha256")
        == frozen["sealed_confirm_evidence"]["expected_metrics_sha256_from_original_audit"]
        == sha256(CONFIRM_METRICS_PATH)
        and release.get("confirm_cache_snapshot") == cache_tree_snapshot("confirm")
    ):
        raise RuntimeError("confirm release evidence mismatch")
    return frozen, release


def validate_evaluation(value: dict, frozen: dict, release: dict) -> None:
    metrics_path = ROOT / "metrics.csv"
    if not metrics_path.is_file():
        raise RuntimeError("confirm metrics are missing")
    with metrics_path.open() as handle:
        rows = list(csv.DictReader(handle))
    with CONFIRM_METRICS_PATH.open() as handle:
        sealed_rows = list(csv.DictReader(handle))
    reference_methods = {"dynamic_delta", "static_delta", "gridcons_mamba"}

    def identity(row: dict) -> tuple[str, str, int, str, str]:
        return row["case_id"], row["class"], int(row["seed"]), row["method"], row["spacing"]

    combined_references = {identity(row): row for row in rows if row["method"] in reference_methods}
    sealed_references = {identity(row): row for row in sealed_rows}
    expected = 40 * 2 * len(SEEDS) * len(ALL_ARMS) * 3
    identities = {(row["case_id"], row["class"], int(row["seed"]), row["method"], row["spacing"]) for row in rows}
    numeric_fields = (
        "prediction_consistency_dice",
        "mapped_label_dice",
        "native_r1_label_dice",
        "surface_dice_2mm",
        "oracle_grid_dice",
    )
    if not (
        len(rows) == expected
        and combined_references == sealed_references
        and identities == expected_confirm_identities(list(ALL_ARMS))
        and all(np.isfinite(float(row[field])) for row in rows for field in numeric_fields)
        and value.get("protocol_hash") == frozen["protocol_hash"]
        and value.get("confirm_release") == release
        and value.get("rows") == value.get("expected_rows") == expected
        and value.get("unique_identities") == expected
        and not value.get("failures")
        and value.get("metrics_sha256") == sha256(metrics_path)
        and value.get("source_confirm_metrics_sha256") == release["source_confirm_metrics_sha256"]
        and value.get("new_checkpoint_sha256") == release["checkpoint_sha256"]
        and value.get("gpu_seconds", 0) > 0
        and value.get("peak_allocated_bytes", 0) > 0
    ):
        raise RuntimeError("confirm evaluation provenance or completeness mismatch")


def evaluate_confirm() -> None:
    frozen, release = verify_release()
    evaluation_path, metrics_path = ROOT / "evaluation.json", ROOT / "metrics.csv"
    if evaluation_path.exists() or metrics_path.exists():
        try:
            existing = json.loads(evaluation_path.read_text())
            validate_evaluation(existing, frozen, release)
            print(f"completed confirm evaluation exists: {evaluation_path}")
            return
        except Exception as error:
            append_jsonl(ROOT / "CONFIRM_ATTEMPTS.jsonl", {"event": "invalid_existing_rerun", "at": now(), "error": repr(error)})
            archive_failed_output(evaluation_path)
            archive_failed_output(metrics_path)
    append_jsonl(ROOT / "CONFIRM_ATTEMPTS.jsonl", {"event": "started", "at": now(), "protocol_hash": frozen["protocol_hash"]})
    with CONFIRM_METRICS_PATH.open() as handle:
        rows = list(csv.DictReader(handle))
    expected_source = 40 * 2 * len(SEEDS) * 3 * 3
    identities = {(row["case_id"], row["class"], int(row["seed"]), row["method"], row["spacing"]) for row in rows}
    if len(rows) != expected_source or identities != expected_confirm_identities(
        ("dynamic_delta", "static_delta", "gridcons_mamba")
    ):
        raise RuntimeError("source confirm metrics are incomplete")
    confirm = paired_source.confirm_manifest()
    device = torch.device("cuda:0")
    failures = []
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    for seed in SEEDS:
        models = {arm: load_new_model(arm, seed, device) for arm in NEW_ARMS}
        for case_id in confirm["confirm_test"]:
            case = confirm["cases"][case_id]
            r1_grid = case["grids"]["R1"]
            r1_image = np.load(r1_grid["image_cache"])
            r1_label_padded = np.load(r1_grid["label_cache"])
            r1_shape = r1_grid["unpadded_shape_dhw"]
            r1_slices = tuple(slice(0, n) for n in r1_shape)
            r1_label = r1_label_padded[r1_slices]
            r1_affine = np.asarray(r1_grid["affine_xyz"])
            r1_probability, r1_hard = {}, {}
            for arm, model in models.items():
                try:
                    probability = predict(model, arm, r1_image, r1_grid["spacing_dhw"])[(slice(None),) + r1_slices]
                    r1_probability[arm], r1_hard[arm] = probability, probability.argmax(0)
                except Exception as error:
                    failures.append({"seed": seed, "case_id": case_id, "method": arm, "spacing": "R1", "error": repr(error)})
            for spacing_name in ("R1", "R2", "R4"):
                grid = case["grids"][spacing_name]
                image = np.load(grid["image_cache"])
                label_padded = np.load(grid["label_cache"])
                shape = grid["unpadded_shape_dhw"]
                slices = tuple(slice(0, n) for n in shape)
                label = label_padded[slices]
                affine = np.asarray(grid["affine_xyz"])
                for arm, model in models.items():
                    if arm not in r1_probability:
                        continue
                    try:
                        if spacing_name == "R1":
                            mapped_probability, mapped_label = r1_probability[arm], r1_label
                        else:
                            probability = predict(model, arm, image, grid["spacing_dhw"])[(slice(None),) + slices]
                            mapped_probability = source.OLD.map_probability(probability, affine, r1_shape, r1_affine)
                            mapped_label = source.OLD.map_label(label, affine, r1_shape, r1_affine)
                        mapped_hard = mapped_probability.argmax(0)
                        for cls in (1, 2):
                            rows.append(
                                {
                                    "case_id": case_id,
                                    "class": "anterior" if cls == 1 else "posterior",
                                    "seed": seed,
                                    "method": arm,
                                    "spacing": spacing_name,
                                    "prediction_consistency_dice": source.OLD.binary_dice(
                                        mapped_hard == cls, r1_hard[arm] == cls
                                    ),
                                    "mapped_label_dice": source.OLD.binary_dice(mapped_hard == cls, r1_label == cls),
                                    "native_r1_label_dice": source.OLD.binary_dice(r1_hard[arm] == cls, r1_label == cls),
                                    "surface_dice_2mm": source.OLD.surface_dice(mapped_hard == cls, r1_label == cls),
                                    "oracle_grid_dice": source.OLD.binary_dice(mapped_label == cls, r1_label == cls),
                                }
                            )
                    except Exception as error:
                        failures.append(
                            {"seed": seed, "case_id": case_id, "method": arm, "spacing": spacing_name, "error": repr(error)}
                        )
        del models
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    with metrics_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    expected = 40 * 2 * len(SEEDS) * len(ALL_ARMS) * 3
    identities = {(row["case_id"], row["class"], int(row["seed"]), row["method"], row["spacing"]) for row in rows}
    evaluation = {
        "protocol_hash": frozen["protocol_hash"],
        "confirm_release": release,
        "rows": len(rows),
        "expected_rows": expected,
        "unique_identities": len(identities),
        "failures": failures,
        "metrics_sha256": sha256(metrics_path),
        "source_confirm_metrics_sha256": sha256(CONFIRM_METRICS_PATH),
        "new_checkpoint_sha256": validate_new_checkpoints(),
        "gpu_seconds": elapsed,
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
        "finished_at": now(),
    }
    dump_json(evaluation_path, evaluation)
    if failures or len(rows) != expected or identities != expected_confirm_identities(list(ALL_ARMS)):
        raise RuntimeError("confirm evaluation is incomplete")
    validate_evaluation(evaluation, frozen, release)
    append_jsonl(ROOT / "CONFIRM_ATTEMPTS.jsonl", {"event": "completed", "at": now(), "metrics_sha256": evaluation["metrics_sha256"]})
    print(f"wrote {len(rows)} rows; gpu_seconds={elapsed:.1f}")


def load_any_model(arm: str, seed: int, device: torch.device) -> torch.nn.Module:
    if arm == "dynamic_delta":
        return source.load_model("content_delta", seed, device)
    if arm == "static_delta":
        return source.load_model("separated_physical_delta", seed, device)
    if arm == "gridcons_mamba":
        return paired_source.load_proposed(seed, device)
    return load_new_model(arm, seed, device)


def validate_performance(value: dict, frozen: dict, release: dict) -> None:
    evaluation_path, metrics_path = ROOT / "evaluation.json", ROOT / "metrics.csv"
    current_hardware = hardware_fingerprint()
    frozen_hardware = {key: frozen["environment"][key] for key in current_hardware}
    expected_parameters = {
        "dynamic_delta": frozen["model_parameters"]["dynamic_delta"],
        "static_delta": frozen["model_parameters"]["static_delta"],
        "gridcons_mamba": frozen["model_parameters"]["static_delta"],
        "dynamic_delta_consistency": frozen["model_parameters"]["dynamic_delta"],
        "unet3d": frozen["model_parameters"]["unet3d"],
        "unet3d_consistency": frozen["model_parameters"]["unet3d"],
    }
    if not (
        evaluation_path.is_file()
        and metrics_path.is_file()
        and value.get("protocol_hash") == frozen["protocol_hash"]
        and value.get("protocol") == frozen["benchmark"]
        and value.get("confirm_release") == release
        and value.get("new_checkpoint_sha256") == release["checkpoint_sha256"]
        and value.get("source_checkpoint_sha256") == frozen["source_checkpoint_sha256"]
        and value.get("evaluation_sha256") == sha256(evaluation_path)
        and value.get("metrics_sha256") == sha256(metrics_path)
        and value.get("hardware") == current_hardware == frozen_hardware
        and set(value.get("records", {})) == set(ALL_ARMS)
    ):
        raise RuntimeError("performance provenance mismatch")
    for arm, item in value["records"].items():
        samples = np.asarray(item.get("samples_ms", []), dtype=np.float64)
        if not (
            item.get("parameters") == expected_parameters[arm]
            and samples.shape == (frozen["benchmark"]["timed_iterations"],)
            and np.isfinite(samples).all()
            and (samples > 0).all()
            and np.isclose(item.get("latency_ms_mean"), samples.mean(), rtol=0, atol=1e-12)
            and np.isclose(item.get("latency_ms_median"), np.median(samples), rtol=0, atol=1e-12)
            and np.isclose(item.get("latency_ms_p95"), np.quantile(samples, 0.95), rtol=0, atol=1e-12)
            and item.get("peak_allocated_bytes", 0) > 0
            and item.get("peak_reserved_bytes", 0) >= item["peak_allocated_bytes"]
        ):
            raise RuntimeError(f"invalid performance record: {arm}")


def benchmark() -> None:
    frozen, release = verify_release()
    if not (ROOT / "evaluation.json").is_file():
        raise RuntimeError("confirm evaluation must finish before benchmark")
    performance_path = ROOT / "PERFORMANCE.json"
    if performance_path.exists():
        existing = json.loads(performance_path.read_text())
        try:
            validate_performance(existing, frozen, release)
            print(f"completed benchmark exists: {performance_path}")
            return
        except Exception as error:
            append_jsonl(ROOT / "BENCHMARK_ATTEMPTS.jsonl", {"event": "invalid_existing_rerun", "at": now(), "error": repr(error)})
            archive_failed_output(performance_path)
    case_id = frozen["benchmark"]["case_id"]
    manifest = source.manifest()
    grid = manifest["cases"][case_id]["grids"]["R1"]
    image = np.load(grid["image_cache"])
    device = torch.device("cuda:0")
    records = {}
    for arm in ALL_ARMS:
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        model = load_any_model(arm, 17, device)
        tensor = torch.from_numpy(np.asarray(image, dtype=np.float32)).to(device)[None, None]
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            for _ in range(frozen["benchmark"]["warmup_iterations"]):
                forward_logits(model, arm, tensor, grid["spacing_dhw"])
            torch.cuda.synchronize()
            samples = []
            for _ in range(frozen["benchmark"]["timed_iterations"]):
                started = time.perf_counter()
                output = forward_logits(model, arm, tensor, grid["spacing_dhw"])
                torch.cuda.synchronize()
                samples.append((time.perf_counter() - started) * 1000)
        if output.shape != (1, 3, *image.shape) or not torch.isfinite(output).all():
            raise RuntimeError(f"invalid benchmark output: {arm}")
        records[arm] = {
            "parameters": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad),
            "latency_ms_mean": float(np.mean(samples)),
            "latency_ms_median": float(np.median(samples)),
            "latency_ms_p95": float(np.quantile(samples, 0.95)),
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "samples_ms": samples,
        }
        del model, tensor, output
    dump_json(
        performance_path,
        {
            "protocol_hash": frozen["protocol_hash"],
            "protocol": frozen["benchmark"],
            "confirm_release": release,
            "new_checkpoint_sha256": release["checkpoint_sha256"],
            "source_checkpoint_sha256": frozen["source_checkpoint_sha256"],
            "evaluation_sha256": sha256(ROOT / "evaluation.json"),
            "metrics_sha256": sha256(ROOT / "metrics.csv"),
            "hardware": hardware_fingerprint(),
            "records": records,
            "finished_at": now(),
        },
    )
    validate_performance(json.loads(performance_path.read_text()), frozen, release)
    print(json.dumps({arm: {k: v for k, v in item.items() if k != "samples_ms"} for arm, item in records.items()}, indent=2))


def write_sha256sums() -> None:
    files = sorted(
        path for path in ROOT.rglob("*") if path.is_file() and path.name != "SHA256SUMS" and "__pycache__" not in path.parts
    )
    (ROOT / "SHA256SUMS").write_text(
        "".join(f"{sha256(path)}  {path.relative_to(ROOT)}\n" for path in files)
    )
    print(f"hashed {len(files)} files")


def main() -> None:
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("setup")
    train_parser = commands.add_parser("train")
    train_parser.add_argument("--arm", choices=NEW_ARMS, required=True)
    train_parser.add_argument("--seed", choices=SEEDS, type=int, required=True)
    commands.add_parser("screen-dev")
    commands.add_parser("evaluate-confirm")
    commands.add_parser("benchmark")
    commands.add_parser("hashes")
    args = parser.parse_args()
    try:
        if args.command == "setup":
            setup()
        elif args.command == "train":
            train(args.arm, args.seed)
        elif args.command == "screen-dev":
            screen_dev()
        elif args.command == "evaluate-confirm":
            evaluate_confirm()
        elif args.command == "benchmark":
            benchmark()
        else:
            write_sha256sums()
    except Exception as error:
        event = {"command": args.command, "event": "failed", "at": now(), "error": repr(error)}
        append_jsonl(ROOT / "PIPELINE_ATTEMPTS.jsonl", event)
        if args.command == "evaluate-confirm":
            append_jsonl(ROOT / "CONFIRM_ATTEMPTS.jsonl", event)
        raise


if __name__ == "__main__":
    main()
