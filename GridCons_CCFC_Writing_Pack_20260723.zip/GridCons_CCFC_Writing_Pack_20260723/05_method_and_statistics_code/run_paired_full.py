#!/usr/bin/env python
"""Train and evaluate GridCons-Mamba on the frozen five-seed Task04 split."""

from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

import run_probe as base
from model import TinyMetricMamba, parameter_count


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs" / "paired_full"
CONFIRM_MANIFEST = OUT / "confirm_manifest.json"
SEEDS = base.SEEDS
METHODS = ("dynamic_delta", "static_delta", "gridcons_mamba")
CONSISTENCY_WEIGHT = 0.1
UPDATES = base.UPDATES
VALIDATE_EVERY = base.VALIDATE_EVERY
BOOTSTRAP_SAMPLES = 10_000
BOOTSTRAP_SEED = 7301


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def sha256(path: Path) -> str:
    return base.sha256(path)


def proposed_paths(seed: int) -> tuple[Path, Path]:
    if seed not in SEEDS:
        raise ValueError(f"unregistered seed: {seed}")
    return OUT / "checkpoints" / f"gridcons_seed{seed}.pt", OUT / f"train_gridcons_seed{seed}.json"


def source_checkpoints() -> dict[str, dict[str, str]]:
    return {
        method: {
            str(seed): sha256(base.checkpoint_path(parameterization, seed))
            for seed in SEEDS
        }
        for method, parameterization in (
            ("dynamic_delta", "content_delta"),
            ("static_delta", "separated_physical_delta"),
        )
    }


def confirm_manifest() -> dict:
    value = json.loads(CONFIRM_MANIFEST.read_text())
    if value.get("manifest_hash") != base.OLD.manifest_hash(value):
        raise RuntimeError("confirm manifest hash mismatch")
    return value


def prepare_confirm_manifest() -> dict:
    if CONFIRM_MANIFEST.exists():
        return confirm_manifest()
    dataset = base.OLD.load_json(base.OLD.DATA / "dataset.json")
    pairs = []
    for item in dataset["training"]:
        image = base.OLD.DATA / item["image"].removeprefix("./")
        label = base.OLD.DATA / item["label"].removeprefix("./")
        pairs.append((image.name.removesuffix(".nii.gz"), image, label))
    pairs.sort(key=lambda item: item[0])
    if len(pairs) != 260:
        raise RuntimeError(f"expected 260 labeled cases, found {len(pairs)}")
    indices = np.arange(len(pairs))
    np.random.default_rng(base.OLD.SPLIT_SEED).shuffle(indices)
    selected = [pairs[index] for index in indices[120:160]]
    old_ids = set().union(*base.manifest()["split"].values())
    confirm_ids = [item[0] for item in selected]
    if old_ids & set(confirm_ids) or len(confirm_ids) != 40:
        raise RuntimeError("confirm split overlaps the 120-case development split")
    cases = {}
    for number, (case_id, image, label) in enumerate(selected, 1):
        cases[case_id] = base.OLD.prepare_case(case_id, image, label)
        print(f"prepared confirm {number}/40 {case_id}", flush=True)
    value = {
        "version": 1,
        "selection": "same sorted IDs and numpy.default_rng(20260718) shuffle as source; indices[120:160]",
        "confirm_test": confirm_ids,
        "development_overlap": [],
        "cases": cases,
    }
    value["manifest_hash"] = base.OLD.manifest_hash(value)
    dump_json(CONFIRM_MANIFEST, value)
    return value


def setup() -> None:
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly one visible CUDA GPU is required")
    source_manifest = base.manifest()
    records = base.training_records()
    if len(records) != 10 or not all(base.training_record_valid(item) for item in records):
        raise RuntimeError("the ten frozen five-seed source trainings are incomplete")
    checks = base.config_assertions()
    if not all(checks.values()):
        raise RuntimeError(f"source config mismatch: {[key for key, value in checks.items() if not value]}")
    OUT.mkdir(parents=True, exist_ok=True)
    frozen_confirm = prepare_confirm_manifest()
    archive = Path("/home/yanjingjia/data/Task04_Hippocampus.tar")
    extracted = Path("/home/yanjingjia/data/Task04_Hippocampus")
    extracted_bytes = sum(path.stat().st_size for path in extracted.rglob("*") if path.is_file())
    dump_json(
        OUT / "protocol.json",
        {
            "name": "GridCons-Mamba full experiment",
            "methods": list(METHODS),
            "seeds": list(SEEDS),
            "updates": UPDATES,
            "validation_interval": VALIDATE_EVERY,
            "checkpoint_selection": "validation_R1_mean_anterior_posterior_Dice_only",
            "consistency_weight": CONSISTENCY_WEIGHT,
            "consistency_view": "R2 image only; R2 labels excluded from training loss",
            "consistency_alignment": "crop padding then trilinear probability interpolation to R1 with align_corners=True",
            "training_loss": "R1 Dice/CE + linear-warmup-to-0.1 foreground paired-grid soft-Dice loss; stop-gradient R1 teacher",
            "source_manifest_hash": source_manifest["manifest_hash"],
            "confirm_manifest_hash": frozen_confirm["manifest_hash"],
            "confirm_cases": 40,
            "confirm_selection": frozen_confirm["selection"],
            "development_screen": {
                "cases": "source 20-case test, reclassified as development evidence",
                "release_rule": "GridCons R2 consistency > dynamic delta and GridCons R1 Dice >= dynamic delta - 0.01",
                "addon_rule": "GridCons R2 consistency > static delta and GridCons R1 Dice >= static delta - 0.01",
                "confirm_results_used": False,
            },
            "confirmatory_outcome_rules_frozen_before_evaluation": {
                "primary_incremental_success": "GridCons minus dynamic mean R2 consistency > 0 and mean R1 Dice difference >= -0.01",
                "static_addon_success": "GridCons minus static mean R2 consistency > 0 and mean R1 Dice difference >= -0.01",
                "strong_primary_evidence": "hierarchical 95% CI lower bound for GridCons minus dynamic R2 consistency > 0",
                "secondary_guardrails": "report R2 mapped Dice, R2 surface Dice@2mm, and R4 consistency without using them to redefine primary success",
            },
            "source_checkpoints": source_checkpoints(),
            "code_sha256": {
                name: sha256(ROOT / name)
                for name in ("model.py", "run_probe.py", "run_paired_full.py", "test_probe.py", "test_paired_full.py", "reproduce_paired_full.sh")
            },
            "official_archive_bytes": archive.stat().st_size,
            "official_archive_sha256": sha256(archive),
            "extracted_dataset_bytes": extracted_bytes,
            "dataset_limit_bytes": 6_000_000_000,
            "dataset_limit_passed": max(archive.stat().st_size, extracted_bytes) < 6_000_000_000,
            "model_parameters": parameter_count(TinyMetricMamba("separated_physical_delta")),
            "optimizer": "AdamW(lr=3e-4, weight_decay=1e-5)",
            "amp": "bfloat16",
            "gpu": torch.cuda.get_device_name(0),
            "gpu_memory_bytes": torch.cuda.get_device_properties(0).total_memory,
        },
    )
    print(f"protocol ready: {OUT / 'protocol.json'}")


def crop(logits: torch.Tensor, shape: list[int]) -> torch.Tensor:
    return logits[:, :, : shape[0], : shape[1], : shape[2]]


def paired_grid_consistency_loss(
    r1_logits: torch.Tensor,
    r2_logits: torch.Tensor,
    r1_shape: list[int],
    r2_shape: list[int],
) -> torch.Tensor:
    p1 = crop(r1_logits, r1_shape).float().softmax(1)[:, 1:].detach()
    p2 = crop(r2_logits, r2_shape).float().softmax(1)
    p2 = F.interpolate(p2, size=r1_shape, mode="trilinear", align_corners=True)
    p2 = (p2 / p2.sum(1, keepdim=True).clamp_min(1e-7))[:, 1:]
    dims = (0, 2, 3, 4)
    intersection = (p1 * p2).sum(dims)
    denominator = p1.square().sum(dims) + p2.square().sum(dims)
    return 1.0 - ((2.0 * intersection + 1e-5) / (denominator + 1e-5)).mean()


def train(seed: int) -> None:
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    source_manifest = base.manifest()
    checkpoint, log_path = proposed_paths(seed)
    if checkpoint.exists() and log_path.exists():
        old = json.loads(log_path.read_text())
        if old.get("completed") and old.get("checkpoint_sha256") == sha256(checkpoint):
            print(f"completed training exists: {log_path}")
            return

    device = torch.device("cuda:0")
    base.OLD.seed_all(seed)
    model = TinyMetricMamba("separated_physical_delta").to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-5)
    cases = []
    for case_id in source_manifest["split"]["train"]:
        r1_image, r1_label = base.load_array(source_manifest, case_id, "R1")
        r2_image, _ = base.load_array(source_manifest, case_id, "R2")
        cases.append((case_id, r1_image, r1_label, r2_image))
    rng = np.random.default_rng(seed)
    order: list[int] = []
    history, best = [], -1.0
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    for update in range(1, UPDATES + 1):
        if not order:
            order = rng.permutation(len(cases)).tolist()
        case_id, r1_image, r1_label, r2_image = cases[order.pop()]
        r1_shape = source_manifest["cases"][case_id]["grids"]["R1"]["unpadded_shape_dhw"]
        r2_shape = source_manifest["cases"][case_id]["grids"]["R2"]["unpadded_shape_dhw"]
        x1, y1 = base.OLD.tensors(r1_image, r1_label, device)
        x2 = torch.from_numpy(np.asarray(r2_image, dtype=np.float32)).to(device)[None, None]
        model.train()
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            z1 = model(x1, torch.ones(1, 3, device=device))
            z2 = model(x2, torch.tensor([[2.0, 1.0, 1.0]], device=device))
            segmentation = base.OLD.loss_fn(z1, y1)
            consistency = paired_grid_consistency_loss(z1, z2, r1_shape, r2_shape)
            weight = CONSISTENCY_WEIGHT * min(1.0, update / 500)
            loss = segmentation + weight * consistency
        if not torch.isfinite(loss):
            raise RuntimeError(f"non-finite loss at update {update}")
        loss.backward()
        if not all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None):
            raise RuntimeError(f"non-finite gradient at update {update}")
        optimizer.step()
        if update % VALIDATE_EVERY == 0:
            score = base.validation_dice(model, source_manifest)
            item = {
                "update": update,
                "training_loss": float(loss),
                "r1_segmentation_loss": float(segmentation),
                "paired_consistency_loss": float(consistency),
                "effective_consistency_weight": weight,
                "validation_r1_mean_dice": score,
            }
            history.append(item)
            print(seed, item, flush=True)
            if score > best:
                best = score
                torch.save(
                    {
                        "model_state": model.state_dict(),
                        "parameterization": "separated_physical_delta",
                        "method": "gridcons_mamba",
                        "seed": seed,
                        "update": update,
                        "validation_r1_mean_dice": score,
                        "selection": "validation_R1_mean_anterior_posterior_Dice_only",
                        "consistency_weight": CONSISTENCY_WEIGHT,
                    },
                    checkpoint,
                )
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    log = {
        "completed": True,
        "finite": True,
        "method": "gridcons_mamba",
        "parameterization": "separated_physical_delta",
        "seed": seed,
        "updates": UPDATES,
        "validation_interval": VALIDATE_EVERY,
        "history": history,
        "best_validation_r1_mean_dice": best,
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": sha256(checkpoint),
        "checkpoint_selection": "validation_R1_mean_anterior_posterior_Dice_only",
        "consistency_weight": CONSISTENCY_WEIGHT,
        "r2_labels_used_for_training": False,
        "gpu_seconds": elapsed,
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
    }
    dump_json(log_path, log)
    print(json.dumps(log, indent=2))


def load_proposed(seed: int, device: torch.device) -> TinyMetricMamba:
    checkpoint, _ = proposed_paths(seed)
    saved = torch.load(checkpoint, map_location=device, weights_only=False)
    if saved.get("method") != "gridcons_mamba" or saved.get("seed") != seed:
        raise RuntimeError(f"checkpoint metadata mismatch: {checkpoint}")
    model = TinyMetricMamba("separated_physical_delta").to(device)
    model.load_state_dict(saved["model_state"], strict=True)
    return model.eval()


def screen_dev() -> None:
    source_manifest = base.manifest()
    source_evaluation = json.loads((base.OUTPUTS / "evaluation.json").read_text())
    if (
        source_evaluation.get("failures")
        or source_evaluation.get("rows") != 1800
        or source_evaluation.get("metrics_sha256") != sha256(base.OUTPUTS / "metrics.csv")
        or source_evaluation.get("source_hashes") != base.evaluation_source_hashes()
    ):
        raise RuntimeError("frozen development baseline evaluation is invalid")
    training = []
    for seed in SEEDS:
        checkpoint, log_path = proposed_paths(seed)
        if not checkpoint.exists() or not log_path.exists():
            raise RuntimeError(f"seed {seed} training is not complete")
        item = json.loads(log_path.read_text())
        if not item.get("completed") or item.get("checkpoint_sha256") != sha256(checkpoint):
            raise RuntimeError(f"seed {seed} training/checkpoint hash mismatch")
        training.append(item)

    device = torch.device("cuda:0")
    records = []
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    for seed in SEEDS:
        model = load_proposed(seed, device)
        for case_id in source_manifest["split"]["test"]:
            case = source_manifest["cases"][case_id]
            r1_image, r1_label_padded = base.load_array(source_manifest, case_id, "R1")
            r1_grid = case["grids"]["R1"]
            r1_shape = r1_grid["unpadded_shape_dhw"]
            r1_slices = tuple(slice(0, n) for n in r1_shape)
            r1_label = r1_label_padded[r1_slices]
            r1_probability = base.predict(model, r1_image, r1_grid["spacing_dhw"])[(slice(None),) + r1_slices]
            r1_hard = r1_probability.argmax(0)
            r2_grid = case["grids"]["R2"]
            r2_image, _ = base.load_array(source_manifest, case_id, "R2")
            r2_shape = r2_grid["unpadded_shape_dhw"]
            r2_slices = tuple(slice(0, n) for n in r2_shape)
            r2_probability = base.predict(model, r2_image, r2_grid["spacing_dhw"])[(slice(None),) + r2_slices]
            mapped = base.OLD.map_probability(
                r2_probability,
                np.asarray(r2_grid["affine_xyz"]),
                r1_shape,
                np.asarray(r1_grid["affine_xyz"]),
            ).argmax(0)
            for cls, name in ((1, "anterior"), (2, "posterior")):
                records.append(
                    {
                        "case_id": case_id,
                        "class": name,
                        "seed": seed,
                        "r1_dice": base.OLD.binary_dice(r1_hard == cls, r1_label == cls),
                        "r2_consistency": base.OLD.binary_dice(mapped == cls, r1_hard == cls),
                    }
                )
        del model
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    if len(records) != 20 * len(SEEDS) * 2 or not all(
        np.isfinite(item[field]) for item in records for field in ("r1_dice", "r2_consistency")
    ):
        raise RuntimeError("development screen is incomplete")

    source_rows = base.read_metrics()
    controls = {
        "dynamic_delta": {
            "r1_dice": float(base.metric_matrix(source_rows, "dynamic_delta_baseline", "R1", "native_r1_label_dice").mean()),
            "r2_consistency": float(base.metric_matrix(source_rows, "dynamic_delta_baseline", "R2", "prediction_consistency_dice").mean()),
        },
        "static_delta": {
            "r1_dice": float(base.metric_matrix(source_rows, "trained_static_delta", "R1", "native_r1_label_dice").mean()),
            "r2_consistency": float(base.metric_matrix(source_rows, "trained_static_delta", "R2", "prediction_consistency_dice").mean()),
        },
    }
    gridcons = {
        "r1_dice": float(np.mean([item["r1_dice"] for item in records])),
        "r2_consistency": float(np.mean([item["r2_consistency"] for item in records])),
        "by_seed": {
            str(seed): {
                field: float(np.mean([item[field] for item in records if item["seed"] == seed]))
                for field in ("r1_dice", "r2_consistency")
            }
            for seed in SEEDS
        },
    }
    vs_dynamic = (
        gridcons["r2_consistency"] > controls["dynamic_delta"]["r2_consistency"]
        and gridcons["r1_dice"] >= controls["dynamic_delta"]["r1_dice"] - 0.01
    )
    addon = (
        gridcons["r2_consistency"] > controls["static_delta"]["r2_consistency"]
        and gridcons["r1_dice"] >= controls["static_delta"]["r1_dice"] - 0.01
    )
    result = {
        "role": "development screening only; not confirmatory evidence",
        "case_ids": source_manifest["split"]["test"],
        "source_manifest_hash": source_manifest["manifest_hash"],
        "source_metrics_sha256": source_evaluation["metrics_sha256"],
        "gridcons_checkpoint_sha256": {str(item["seed"]): item["checkpoint_sha256"] for item in training},
        "controls": controls,
        "gridcons_mamba": gridcons,
        "screening_gates": {
            "above_dynamic_with_r1_guardrail": vs_dynamic,
            "adds_to_static_with_r1_guardrail": addon,
            "release_frozen_confirm_evaluation": vs_dynamic,
        },
        "records": records,
        "gpu_seconds": elapsed,
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
    }
    dump_json(OUT / "dev_screen.json", result)
    print(json.dumps({"controls": controls, "gridcons_mamba": gridcons, "screening_gates": result["screening_gates"]}, indent=2))
    if not vs_dynamic:
        raise RuntimeError("development screen did not release the frozen confirm evaluation")


def evaluate() -> None:
    frozen_confirm = confirm_manifest()
    missing = [seed for seed in SEEDS if not proposed_paths(seed)[0].exists()]
    if missing:
        raise RuntimeError(f"missing proposed checkpoints: {missing}")
    screen_path = OUT / "dev_screen.json"
    if not screen_path.exists():
        raise RuntimeError("development screen must release confirm evaluation first")
    screen = json.loads(screen_path.read_text())
    current_hashes = {str(seed): sha256(proposed_paths(seed)[0]) for seed in SEEDS}
    if not screen.get("screening_gates", {}).get("release_frozen_confirm_evaluation") or screen.get(
        "gridcons_checkpoint_sha256"
    ) != current_hashes:
        raise RuntimeError("development screen did not release these exact checkpoints")
    rows, failures = [], []
    device = torch.device("cuda:0")
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    for seed in SEEDS:
        models = {
            "dynamic_delta": base.load_model("content_delta", seed, device),
            "static_delta": base.load_model("separated_physical_delta", seed, device),
            "gridcons_mamba": load_proposed(seed, device),
        }
        for case_id in frozen_confirm["confirm_test"]:
            case = frozen_confirm["cases"][case_id]
            r1_image, r1_label_padded = base.load_array(frozen_confirm, case_id, "R1")
            r1_shape = case["grids"]["R1"]["unpadded_shape_dhw"]
            r1_slices = tuple(slice(0, n) for n in r1_shape)
            r1_label = r1_label_padded[r1_slices]
            r1_affine = np.asarray(case["grids"]["R1"]["affine_xyz"])
            r1_probability, r1_hard = {}, {}
            for method, model in models.items():
                try:
                    probability = base.predict(model, r1_image, [1.0, 1.0, 1.0])[(slice(None),) + r1_slices]
                    r1_probability[method] = probability
                    r1_hard[method] = probability.argmax(0)
                except Exception as error:
                    failures.append({"seed": seed, "case_id": case_id, "method": method, "spacing": "R1", "error": str(error)})
            for spacing_name in ("R1", "R2", "R4"):
                grid = case["grids"][spacing_name]
                image, label_padded = base.load_array(frozen_confirm, case_id, spacing_name)
                shape = grid["unpadded_shape_dhw"]
                slices = tuple(slice(0, n) for n in shape)
                label = label_padded[slices]
                affine = np.asarray(grid["affine_xyz"])
                for method, model in models.items():
                    if method not in r1_probability:
                        continue
                    try:
                        if spacing_name == "R1":
                            mapped_probability, mapped_label = r1_probability[method], r1_label
                        else:
                            probability = base.predict(model, image, grid["spacing_dhw"])[(slice(None),) + slices]
                            mapped_probability = base.OLD.map_probability(probability, affine, r1_shape, r1_affine)
                            mapped_label = base.OLD.map_label(label, affine, r1_shape, r1_affine)
                        mapped_hard = mapped_probability.argmax(0)
                        for cls in (1, 2):
                            rows.append(
                                {
                                    "case_id": case_id,
                                    "class": "anterior" if cls == 1 else "posterior",
                                    "seed": seed,
                                    "method": method,
                                    "spacing": spacing_name,
                                    "prediction_consistency_dice": base.OLD.binary_dice(mapped_hard == cls, r1_hard[method] == cls),
                                    "mapped_label_dice": base.OLD.binary_dice(mapped_hard == cls, r1_label == cls),
                                    "native_r1_label_dice": base.OLD.binary_dice(r1_hard[method] == cls, r1_label == cls),
                                    "surface_dice_2mm": base.OLD.surface_dice(mapped_hard == cls, r1_label == cls),
                                    "oracle_grid_dice": base.OLD.binary_dice(mapped_label == cls, r1_label == cls),
                                }
                            )
                    except Exception as error:
                        failures.append({"seed": seed, "case_id": case_id, "method": method, "spacing": spacing_name, "error": str(error)})
        del models
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    fields = list(rows[0])
    with (OUT / "metrics.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    dump_json(
        OUT / "evaluation.json",
        {
            "gpu_seconds": elapsed,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "rows": len(rows),
            "failures": failures,
            "metrics_sha256": sha256(OUT / "metrics.csv"),
        },
    )
    print(f"wrote {len(rows)} rows; failures={len(failures)}; gpu_seconds={elapsed:.1f}")


def read_metrics() -> list[dict]:
    with (OUT / "metrics.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["seed"] = int(row["seed"])
        for field in (
            "prediction_consistency_dice",
            "mapped_label_dice",
            "native_r1_label_dice",
            "surface_dice_2mm",
            "oracle_grid_dice",
        ):
            row[field] = float(row[field])
    return rows


def matrix(rows: list[dict], method: str, spacing: str, field: str, cls: str | None = None) -> np.ndarray:
    case_ids = sorted(confirm_manifest()["confirm_test"])
    values: dict[tuple[str, int], list[float]] = {}
    for row in rows:
        if row["method"] == method and row["spacing"] == spacing and (cls is None or row["class"] == cls):
            values.setdefault((row["case_id"], row["seed"]), []).append(row[field])
    result = np.array([[np.mean(values[(case_id, seed)]) for seed in SEEDS] for case_id in case_ids])
    if result.shape != (40, len(SEEDS)) or not np.isfinite(result).all():
        raise RuntimeError(f"incomplete metric matrix: {method}/{spacing}/{field}")
    return result


def paired(
    rows: list[dict],
    candidate: str,
    reference: str,
    spacing: str,
    field: str,
    case_samples: np.ndarray,
    seed_samples: np.ndarray,
) -> dict:
    differences = matrix(rows, candidate, spacing, field) - matrix(rows, reference, spacing, field)
    samples = differences[case_samples[:, :, None], seed_samples[:, None, :]].mean((1, 2))
    return {
        "candidate": candidate,
        "reference": reference,
        "mean_difference": float(differences.mean()),
        "ci95": [float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))],
        "seed_differences": {str(seed): float(differences[:, i].mean()) for i, seed in enumerate(SEEDS)},
        "positive_seed_count": int((differences.mean(0) > 0).sum()),
    }


def report() -> None:
    rows = read_metrics()
    evaluation = json.loads((OUT / "evaluation.json").read_text())
    expected = 40 * 2 * len(SEEDS) * len(METHODS) * 3
    if evaluation["failures"] or len(rows) != expected or len(rows) != len({(r["case_id"], r["class"], r["seed"], r["method"], r["spacing"]) for r in rows}):
        raise RuntimeError("evaluation is incomplete")
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    case_samples = rng.integers(0, 40, size=(BOOTSTRAP_SAMPLES, 40))
    seed_samples = rng.integers(0, len(SEEDS), size=(BOOTSTRAP_SAMPLES, len(SEEDS)))
    comparisons = {}
    for candidate, reference in (
        ("static_delta", "dynamic_delta"),
        ("gridcons_mamba", "dynamic_delta"),
        ("gridcons_mamba", "static_delta"),
    ):
        key = f"{candidate}_vs_{reference}"
        comparisons[key] = {
            "r2_consistency": paired(rows, candidate, reference, "R2", "prediction_consistency_dice", case_samples, seed_samples),
            "r2_mapped_label": paired(rows, candidate, reference, "R2", "mapped_label_dice", case_samples, seed_samples),
            "r2_surface_2mm": paired(rows, candidate, reference, "R2", "surface_dice_2mm", case_samples, seed_samples),
            "r1_native_label": paired(rows, candidate, reference, "R1", "native_r1_label_dice", case_samples, seed_samples),
            "r4_consistency": paired(rows, candidate, reference, "R4", "prediction_consistency_dice", case_samples, seed_samples),
        }
    means = {
        method: {
            "r1_dice": float(matrix(rows, method, "R1", "native_r1_label_dice").mean()),
            "r2_consistency": float(matrix(rows, method, "R2", "prediction_consistency_dice").mean()),
            "r2_mapped_dice": float(matrix(rows, method, "R2", "mapped_label_dice").mean()),
            "r2_surface_dice_2mm": float(matrix(rows, method, "R2", "surface_dice_2mm").mean()),
            "r4_consistency": float(matrix(rows, method, "R4", "prediction_consistency_dice").mean()),
        }
        for method in METHODS
    }
    class_means = {
        method: {
            cls: {
                "r1_dice": float(matrix(rows, method, "R1", "native_r1_label_dice", cls).mean()),
                "r2_consistency": float(matrix(rows, method, "R2", "prediction_consistency_dice", cls).mean()),
                "r2_mapped_dice": float(matrix(rows, method, "R2", "mapped_label_dice", cls).mean()),
                "r2_surface_dice_2mm": float(matrix(rows, method, "R2", "surface_dice_2mm", cls).mean()),
                "r4_consistency": float(matrix(rows, method, "R4", "prediction_consistency_dice", cls).mean()),
            }
            for cls in ("anterior", "posterior")
        }
        for method in METHODS
    }
    seed_means = {
        method: {
            str(seed): {
                "r1_dice": float(matrix(rows, method, "R1", "native_r1_label_dice")[:, i].mean()),
                "r2_consistency": float(matrix(rows, method, "R2", "prediction_consistency_dice")[:, i].mean()),
                "r2_mapped_dice": float(matrix(rows, method, "R2", "mapped_label_dice")[:, i].mean()),
                "r4_consistency": float(matrix(rows, method, "R4", "prediction_consistency_dice")[:, i].mean()),
            }
            for i, seed in enumerate(SEEDS)
        }
        for method in METHODS
    }
    grid_oracle = {
        spacing: {
            cls: float(matrix(rows, "dynamic_delta", spacing, "oracle_grid_dice", cls).mean())
            for cls in ("anterior", "posterior")
        }
        for spacing in ("R2", "R4")
    }
    training = [json.loads(proposed_paths(seed)[1].read_text()) for seed in SEEDS]
    development_screen = json.loads((OUT / "dev_screen.json").read_text())
    aggregate_process_seconds = sum(item["gpu_seconds"] for item in training) + evaluation["gpu_seconds"]
    single_gpu_wall_seconds = max(item["gpu_seconds"] for item in training) + evaluation["gpu_seconds"]
    protocol = json.loads((OUT / "protocol.json").read_text())
    confirm_ids = confirm_manifest()["confirm_test"]
    development_ids = set().union(*base.manifest()["split"].values())
    all_finite = all(
        np.isfinite(value)
        for row in rows
        for key, value in row.items()
        if key.endswith("dice") or key == "surface_dice_2mm"
    )
    validity_gates = {
        "confirm_has_40_unique_cases": len(confirm_ids) == len(set(confirm_ids)) == 40,
        "confirm_disjoint_from_120_case_development_split": not (set(confirm_ids) & development_ids),
        "all_five_trainings_complete": len(training) == len(SEEDS) and all(item.get("completed") for item in training),
        "ten_validation_records_per_training": all(len(item.get("history", [])) == UPDATES // VALIDATE_EVERY for item in training),
        "checkpoint_hashes_match_training_logs": all(
            item.get("checkpoint_sha256") == sha256(proposed_paths(item["seed"])[0]) for item in training
        ),
        "checkpoint_selection_uses_r1_validation_only": all(
            item.get("checkpoint_selection") == "validation_R1_mean_anterior_posterior_Dice_only" for item in training
        ),
        "r2_labels_excluded_from_training": all(item.get("r2_labels_used_for_training") is False for item in training),
        "development_screen_released_confirm": development_screen["screening_gates"]["release_frozen_confirm_evaluation"] is True,
        "development_screen_checkpoint_hashes_match": development_screen["gridcons_checkpoint_sha256"]
        == {str(item["seed"]): item["checkpoint_sha256"] for item in training},
        "source_checkpoint_hashes_unchanged": protocol["source_checkpoints"] == source_checkpoints(),
        "code_hashes_match_frozen_protocol": protocol["code_sha256"]
        == {
            name: sha256(ROOT / name)
            for name in ("model.py", "run_probe.py", "run_paired_full.py", "test_probe.py", "test_paired_full.py", "reproduce_paired_full.sh")
        },
        "evaluation_complete_without_failures": not evaluation["failures"] and len(rows) == expected,
        "all_metrics_finite": all_finite,
        "official_archive_under_6gb": protocol["dataset_limit_passed"],
    }
    if not all(validity_gates.values()):
        raise RuntimeError(f"validity gate failed: {[key for key, value in validity_gates.items() if not value]}")
    result = {
        "method_means": means,
        "class_means": class_means,
        "seed_means": seed_means,
        "grid_oracle_label_dice": grid_oracle,
        "hierarchical_paired_bootstrap": comparisons,
        "training_runs": training,
        "development_screen": development_screen,
        "evaluation": evaluation,
        "protocol": protocol,
        "validity_gates": validity_gates,
        "aggregate_process_seconds": aggregate_process_seconds,
        "aggregate_process_hours": aggregate_process_seconds / 3600,
        "single_gpu_wall_seconds_approx": single_gpu_wall_seconds,
        "single_gpu_wall_hours_approx": single_gpu_wall_seconds / 3600,
        "all_finite": all_finite,
    }
    primary = comparisons["gridcons_mamba_vs_dynamic_delta"]
    addon_comparison = comparisons["gridcons_mamba_vs_static_delta"]
    result["outcome_flags"] = {
        "primary_incremental_success": primary["r2_consistency"]["mean_difference"] > 0
        and primary["r1_native_label"]["mean_difference"] >= -0.01,
        "static_addon_success": addon_comparison["r2_consistency"]["mean_difference"] > 0
        and addon_comparison["r1_native_label"]["mean_difference"] >= -0.01,
        "strong_primary_evidence": primary["r2_consistency"]["ci95"][0] > 0,
        "at_least_four_of_five_primary_seed_gains_positive": primary["r2_consistency"]["positive_seed_count"] >= 4,
    }
    dump_json(OUT / "results.json", result)
    p = comparisons["gridcons_mamba_vs_dynamic_delta"]
    s = comparisons["gridcons_mamba_vs_static_delta"]
    def cell(value: dict) -> str:
        return f"{value['mean_difference']:+.4f} [{value['ci95'][0]:+.4f}, {value['ci95'][1]:+.4f}]"

    lines = [
        "# GridCons-Mamba full results",
        "",
        "All values are held-out means over a newly frozen 40-case confirmatory split × 5 seeds; CIs use hierarchical paired bootstrap over cases and seeds.",
        "",
        "| Method | R1 Dice | R2 consistency | R2 mapped Dice | R2 surface Dice@2mm | R4 consistency |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for method in METHODS:
        value = means[method]
        lines.append(
            f"| {method} | {value['r1_dice']:.4f} | {value['r2_consistency']:.4f} | {value['r2_mapped_dice']:.4f} | {value['r2_surface_dice_2mm']:.4f} | {value['r4_consistency']:.4f} |"
        )
    lines.extend(("", "## Per-class means", "", "| Method | Class | R1 Dice | R2 consistency | R2 mapped Dice | R2 surface@2mm | R4 consistency |", "|---|---|---:|---:|---:|---:|---:|"))
    for method in METHODS:
        for cls in ("anterior", "posterior"):
            value = class_means[method][cls]
            lines.append(
                f"| {method} | {cls} | {value['r1_dice']:.4f} | {value['r2_consistency']:.4f} | {value['r2_mapped_dice']:.4f} | {value['r2_surface_dice_2mm']:.4f} | {value['r4_consistency']:.4f} |"
            )
    lines.extend(("", "## Paired differences (candidate − reference; hierarchical 95% CI)", "", "| Comparison | R2 consistency | R2 mapped Dice | R2 surface@2mm | R1 Dice | R4 consistency |", "|---|---:|---:|---:|---:|---:|"))
    for key, value in comparisons.items():
        label = key.replace("_vs_", " vs ")
        lines.append(
            f"| {label} | {cell(value['r2_consistency'])} | {cell(value['r2_mapped_label'])} | {cell(value['r2_surface_2mm'])} | {cell(value['r1_native_label'])} | {cell(value['r4_consistency'])} |"
        )
    lines.extend(
        (
            "",
            f"- Proposed vs dynamic R2 consistency: {p['r2_consistency']['mean_difference']:+.4f}, 95% CI {p['r2_consistency']['ci95']}, seeds {p['r2_consistency']['seed_differences']}.",
            f"- Proposed vs static R2 consistency: {s['r2_consistency']['mean_difference']:+.4f}, 95% CI {s['r2_consistency']['ci95']}, seeds {s['r2_consistency']['seed_differences']}.",
            f"- Proposed vs dynamic R1 Dice: {p['r1_native_label']['mean_difference']:+.4f}, 95% CI {p['r1_native_label']['ci95']}.",
            f"- Approximate single-GPU wall time: {result['single_gpu_wall_hours_approx']:.3f} h; summed process time: {result['aggregate_process_hours']:.3f} h on {result['protocol']['gpu']}.",
            f"- Official dataset archive/extracted size: {result['protocol']['official_archive_bytes']} / {result['protocol']['extracted_dataset_bytes']} bytes (<6GB: {result['protocol']['dataset_limit_passed']}).",
            f"- Label-resampling oracle Dice: {grid_oracle}.",
            f"- Frozen outcome flags: {result['outcome_flags']}.",
            "",
            "## Validity gates",
        )
    )
    lines.extend(f"- {key}: PASS" for key in validity_gates)
    (OUT / "report.md").write_text("\n".join(lines) + "\n")
    print(OUT / "report.md")


def main() -> None:
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("setup")
    train_parser = commands.add_parser("train")
    train_parser.add_argument("--seed", type=int, choices=SEEDS, required=True)
    commands.add_parser("screen-dev")
    commands.add_parser("evaluate")
    commands.add_parser("report")
    args = parser.parse_args()
    if args.command == "setup":
        setup()
    elif args.command == "train":
        train(args.seed)
    elif args.command == "screen-dev":
        screen_dev()
    elif args.command == "evaluate":
        evaluate()
    else:
        report()


if __name__ == "__main__":
    main()
