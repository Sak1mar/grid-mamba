# External data gate

Status: **PASS_EXTERNAL_DATA_GATE**

- Official archive: `https://msd-for-monai.s3-us-west-2.amazonaws.com/Task09_Spleen.tar`
- License: `CC-BY-SA 4.0`
- Archive bytes: `1610352640`
- Archive SHA-256: `dfeba347daae4fb08c38f4d243ab606b28b91b206ffc445ec55c35489fa65e60`
- Labeled image/label pairs: `41`
- Labels: `{'0': 'background', '1': 'spleen'}`
- INDEPENDENT_DATASET: `True`
- REAL_HETEROGENEOUS_SPACING: `True`
- Unique spacing triplets: `41`

## Spacing summary (mm, NIfTI XYZ)

| Axis | min | median | max | IQR |
|---|---:|---:|---:|---:|
| X | 0.613281 | 0.792969 | 0.976562 | 0.160156 |
| Y | 0.613281 | 0.792969 | 0.976562 | 0.160156 |
| Z | 1.5 | 5 | 8 | 1 |

## Checks

- prompt2_terminal_complete: PASS
- prompt2_sha256sums_valid: PASS
- archive_exists: PASS
- archive_bytes_match_official: PASS
- archive_md5_matches_official: PASS
- dataset_json_present: PASS
- license_clear: PASS
- label_definition_exact: PASS
- at_least_40_labeled_cases: PASS
- declared_41_training_cases: PASS
- listed_pairs_unique: PASS
- listed_image_label_ids_match: PASS
- listed_and_extracted_images_match: PASS
- listed_and_extracted_labels_match: PASS
- all_image_label_pairs_present: PASS
- no_duplicate_file_content: PASS
- all_nifti_checks_pass: PASS
- challenge_test_labels_absent: PASS
- five_fold_case_disjoint_split_feasible: PASS
- independent_from_task04: PASS

Citation: Antonelli et al. (2022), *The Medical Segmentation Decathlon*, Nature Communications 13, 4128, doi:10.1038/s41467-022-30695-9.
