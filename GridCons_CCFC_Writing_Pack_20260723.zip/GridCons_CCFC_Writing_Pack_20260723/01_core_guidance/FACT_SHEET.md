# Canonical fact sheet

## Paper identity

- Recommended title: **Paired-Grid Consistency for Resampling-Stable 3D Medical Image Segmentation**
- Target: a modest CCF-C-level conference paper, not a top-tier method paper.
- Paper type: controlled empirical study plus a minimal training-only regularizer.
- General method name: **paired-grid consistency**.
- `GridCons-Mamba` may name the Mamba implementation, but not a supposedly novel Mamba primitive.

## Task04 design

- Dataset: Medical Segmentation Decathlon Task04 Hippocampus, MRI, 260 labeled cases, two foreground classes.
- Frozen split from `numpy.default_rng(20260718)`: 80 train, 20 validation, 20 development, 40 untouched confirmation; 100 unused.
- Controlled same-case grids: R1, R2, and R4 use 1, 2, and 4 mm through-plane spacing, 1 mm in-plane spacing, and matched physical bounds.
- Seeds: 17, 29, 41, 53, 67.
- Training: 2,500 updates; validation every 250 updates; AdamW, learning rate `3e-4`, weight decay `1e-5`, bfloat16.
- Checkpoint selection: R1 validation foreground Dice only.
- R2 labels: excluded from training and model selection.
- Statistics: class average within each case/seed cell; 10,000-replicate paired hierarchical bootstrap over cases and seeds.
- Confirmation evidence: 40 cases × 5 seeds.

## Method

For native view `x1`, label `y1`, and label-free coarser rendering `x2` of the same physical volume:

`L = Lseg(f(x1), y1) + lambda(t) [1 - SoftDice(stopgrad(p1), Align(p2))]`

`p1` and `p2` are foreground softmax probabilities. Remove padding, trilinearly resize R2 probabilities to the R1 shape with `align_corners=True`, then renormalize. The consistency weight warms linearly to 0.1 over the first 500 updates. The regularizer is absent at inference, so paired and unpaired arms of the same backbone have identical inference architecture and parameter count.

## Canonical Task04 means

Use these values in the main paper; source: `02_task04_primary/CONTROL_REPORT.md`.

| Backbone / arm | R1 Dice | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Mamba, dynamic delta | 0.8469 | 0.4384 | 0.4309 | 0.5942 | 0.0024 |
| Mamba, dynamic delta + consistency | 0.8467 | 0.8525 | 0.8189 | 0.9580 | 0.1048 |
| Mamba, static delta | 0.8455 | 0.4966 | 0.4837 | 0.6563 | 0.0068 |
| Mamba, static delta + consistency | 0.8467 | 0.8531 | 0.8150 | 0.9555 | 0.1186 |
| 3D U-Net | 0.8739 | 0.5883 | 0.5652 | 0.7438 | 0.0149 |
| 3D U-Net + consistency | 0.8755 | 0.9141 | 0.8536 | 0.9807 | 0.1970 |

## Canonical paired effects with 95% CIs

| Comparison | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R1 Dice | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Dynamic Mamba + consistency − Dynamic Mamba | +0.4141 [0.3380, 0.4896] | +0.3881 [0.3104, 0.4655] | +0.3638 [0.2851, 0.4462] | -0.0003 [-0.0057, 0.0044] | +0.1023 [0.0741, 0.1338] |
| Static Mamba + consistency − Static Mamba | +0.3566 [0.2997, 0.4130] | +0.3313 [0.2766, 0.3857] | +0.2991 [0.2451, 0.3542] | +0.0012 [-0.0028, 0.0049] | +0.1118 [0.0725, 0.1538] |
| 3D U-Net + consistency − 3D U-Net | +0.3258 [0.2539, 0.3983] | +0.2884 [0.2207, 0.3594] | +0.2369 [0.1757, 0.3042] | +0.0016 [-0.0019, 0.0051] | +0.1821 [0.1270, 0.2404] |
| Mamba delta × consistency interaction | -0.0576 [-0.1213, -0.0010] | -0.0567 [-0.1258, 0.0038] | -0.0646 [-0.1427, 0.0029] | +0.0015 [-0.0037, 0.0067] | +0.0095 [-0.0312, 0.0523] |

The negative interaction means static delta is not a privileged carrier of the effect. Do not reinterpret it as evidence for static delta.

## Efficiency facts

- Mamba dynamic arms: 99,555 parameters; static arms: 99,411 parameters.
- Consistency adds no inference-time branch and no parameters within a fixed backbone arm.
- Measured batch-1 inference latency and memory are in `02_task04_primary/PERFORMANCE.json` and the report. Do not claim meaningful speed differences between paired and unpaired variants; the observed sub-millisecond differences are measurement noise.

## Task09 external boundary

- Independent MSD Task09 Spleen CT, heterogeneous real spacing.
- Five outer folds, three seeds, 41 outer-test cases.
- The preregistered external scientific rule failed.
- Static-consistency versus dynamic baseline: consistency -0.0083 [-0.0327, 0.0098], native Dice +0.0043 [-0.0290, 0.0437], mapped Dice +0.0070 [-0.0296, 0.0467], Surface Dice@2mm -0.0052 [-0.0283, 0.0238].
- Correct conclusion: Task04 gains do not establish robustness to heterogeneous cross-dataset acquisition.

## Negative mechanism work

- A simple conservative/observable-grid transport pilot failed its preregistered development gate: P−R Extra mapped Dice -0.023217, 80% CI [-0.033781, -0.012464].
- A physical-spacing-scaled Mamba delta idea was invalidated by local controls and is also too close to TIDES.
- Neither idea belongs in the proposed method. Mention them only if useful as future-work cautions, not as contributions.

## Non-negotiable forbidden claims

Do not write any of the following, even in softened form:

- static channel-wise state timescales are the key/useful/necessary carrier of paired-grid consistency;
- token-wise delta adaptation is proven to cause grid sensitivity;
- first spacing-aware Mamba, metric-calibrated Mamba, millimetre-scaled transition, or physical-step Mamba;
- general clinical robustness, cross-dataset generalization, scanner robustness, or real-spacing robustness;
- state of the art, unless a complete and directly comparable benchmark table is added later;
- paired-grid consistency, consistency regularization, common-frame alignment, or Mamba-plus-consistency is individually novel.

## Defensible contribution language

1. Formulate and measure controlled same-anatomy resampling instability with physically aligned grids and label-referenced mapped metrics.
2. Evaluate a minimal, training-only paired-grid consistency objective with no auxiliary inference branch.
3. Provide five-seed factorial Mamba evidence and an independent 3D U-Net control showing that the effect comes from consistency rather than static timescales or a Mamba-specific interaction.
4. Report a disjoint confirmation study and a negative external validation to define the supported scope.

## Known number discrepancy

`04_negative_and_boundary/dynamic_full_corroboration/` contains a separate exact-protocol rerun with R2 consistency 0.8541. The independent full control matrix reports 0.8525. Use **0.8525** and its paired effects in the paper because the control matrix is the canonical integrated analysis. The separate rerun is corroboration only.

