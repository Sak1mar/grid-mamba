# GridCons-Mamba 科研审计与高成功率实验路线

日期：2026-07-23  
审计对象：`/home/yanjingjia/桌面/GridCons-Mamba_MMM_20260719.zip`

## 一、结论先行

这项工作不是“完全没有结果”，但目前**没有足以支撑主标题和机制叙事的因果证据**。真正可靠的发现只有一个：在静态 `delta` 模型上加入 R1/R2 输出一致性损失，可以大幅改善同一病例的受控重采样稳定性，并基本保持原生 R1 Dice。这个结果是实的；把它解释成“静态状态时间尺度是 consistency 的关键载体”，证据则不成立。

当前稿件按创新性应判为 **Level 2：高度重合、无精确复现式 scoop**。它更像一篇严谨的小型组合研究，不像一个新方法论文。若不补核心对照、外部数据和真实采样扰动，建议不要按现有题目投稿。主观审稿先验：原样投稿到中等竞争度医学图像/多媒体会议，进入接收区间约 **15%–30%**；这不是统计概率，只是基于当前证据完整度的专家判断。

我建议彻底放弃“static delta 是创新”的中心叙事，改做：

> **Observable-Grid Consistency（OGC，共同可观测网格一致性）**：面对不可逆的跨网格采样，只约束两个网格共同能表示的预测分量，不强迫粗网格复现其根本没有观测到的细粒度边界。

这条路线比“给 Mamba 的 delta 乘 spacing”更有科学依据，也更容易形成一条可证伪的因果链。独立机制审计把它评为 **Level 3：中度重合、需要数学修正后才能推进**。它不是 Mamba 专属技巧；Mamba 是主要载体，再用 CNN/nnU-Net 证明方法的普适性。

## 二、现有工作到底证明了什么

### 2.1 已经站得住的结果

在 MSD Task04 Hippocampus 的 40 例确认集、5 个种子上：

| 方法 | R1 Dice | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| dynamic delta | 0.8469 | 0.4384 | 0.4309 | 0.5942 | 0.0024 |
| static delta | 0.8455 | 0.4966 | 0.4837 | 0.6563 | 0.0068 |
| static delta + full consistency | 0.8467 | 0.8531 | 0.8150 | 0.9555 | 0.1186 |

其中，现方法相对 dynamic delta 的 R2 consistency 增益为 `+0.4148`，分层配对 bootstrap 95% CI `[+0.3371,+0.4934]`；R1 Dice 差为 `-0.0002`，CI `[-0.0087,+0.0093]`。这说明训练目标确实能够把 R2 输出拉向 R1，且没有明显破坏 R1。

### 2.2 没有被证明的部分

1. **没有 `dynamic delta + 同一个 consistency loss`。** 现有三臂实验不是完整的 `delta × loss` 因子设计。因此无法区分巨大增益来自 consistency 本身，还是 static delta 与 consistency 的特殊交互。
2. **static delta 单独效果不显著。** static 相对 dynamic 的 R2 consistency 为 `+0.0582`，95% CI `[-0.0002,+0.1260]`；R2 mapped Dice 和 Surface Dice 的区间也跨 0。
3. **R4 并没有被解决。** 即使加入 consistency，R4 consistency 也只有 `0.1186`。R2 成功不能外推成“任意 spacing 稳健”。
4. **一致性指标与训练目标距离太近。** 训练直接优化 R1/R2 预测一致性，再用相同类型的 R2 consistency 作为主要成功标准，会天然偏向正结果。真正的主指标应是未见网格扰动下、对标签的物理空间边界误差。
5. **只有一个小型 MRI 数据集与一个 99,411 参数研究载体。** R1/R2/R4 是同一图像的合成重采样，不是独立扫描仪、重建协议或外部中心。
6. **当前 alignment 是把粗网格概率三线性上采样回 R1。** 这隐含了一个未经验证的假设：粗网格预测经过插值后，可以作为细网格完整概率场的识别目标。对非单射采样，这个目标通常并不唯一，因而可能过约束细网格独有的边界分量。

### 2.3 “物理 spacing 进入 delta”已经被本地实验否定

包内 `metric_mamba_gate` 的 `separated_physical_delta` 虽然给出 R2 consistency `+0.0499`，但：

- 两个种子的方向冲突；
- R1 守门条件失败；
- `m=1` 对照获得几乎相同的增益（`+0.0490`）；
- R4 增益仅 `+0.00127`，CI 跨 0。

因此，增益来自新的参数化方式，而不是物理 spacing 乘子。继续沿这一方向包装，会被一个正确的 reviewer 直接问死。

## 三、现有文献边界与被否掉的候选

最近邻工作已经覆盖了大量外围组件：

- Bortsova 等的 transformation-consistent segmentation 已经建立“变换前后预测应一致”的医学分割范式；它主要处理可对齐变换，不回答不可逆降采样中哪些分量不该一致。[论文](https://arxiv.org/abs/1911.01218)
- CR-GLoCo 用低分辨率全局分支和高分辨率局部分支，在重叠 FOV 上进行跨分辨率互伪监督；它的目标是半监督全局/局部上下文交换，不是采样算子的可观测子空间。[论文](https://pubmed.ncbi.nlm.nih.gov/41780211/)
- Mamba-Sea 已经证明“Mamba + 针对分布偏移的序列增强/一致性式训练”不是新概念。[论文](https://arxiv.org/abs/2504.17515)
- Consispace 用 ODE/隐式网络做语义保持的任意 spacing 重采样，再把它作为分割预处理；它解决的是 resampler，不是 consistency loss 的识别对象。[论文](https://arxiv.org/abs/2606.31839)
- CROWn 从采样理论出发，在 3D 分割网络内部做抗混叠降采样和相位校准的 skip fusion；它是 OGC 的强基线，但不等同于输出空间的“共同可观测约束”。[CVPR 2026 论文](https://openaccess.thecvf.com/content/CVPR2026/papers/Huang_CROWn_A_Unified_Framework_for_Anti-Aliased_Downsampling_and_Phase-Calibrated_Fusion_CVPR_2026_paper.pdf)
- Tunable Soft Equivariance 把网络权重投影到设计子空间并给出 equivariance error 界；它处理群变换下的权重软等变，不是不可逆医学重采样下的预测商空间。[CVPR 2026 论文](https://openaccess.thecvf.com/content/CVPR2026/papers/Rahman_Tunable_Soft_Equivariance_with_Guarantees_CVPR_2026_paper.pdf)

一个初看很强的候选——用世界坐标步长对 Mamba 做连续状态转移——必须放弃。TIDES 已经明确保留观测到的物理 `Delta` 作为 selective SSM 的离散化间隔，并把输入依赖移到状态矩阵；把时间秒迁移成空间毫米，再加一个医学分割应用，不足以构成新的承重机制。[TIDES](https://arxiv.org/abs/2605.09742)

文献检索并非完美无缺：OpenReview 连接因缺少本地包失败，DBLP/OpenAlex/Semantic Scholar/arXiv 在部分查询中出现 500、504、SSL EOF 或超时。因此下面的 novelty 判断是“截至 2026-07-23、在已检索来源中未发现精确重合”，不是绝对世界首创证明。

## 四、建议保留的唯一主 idea：Observable-Grid Consistency

### 4.1 问题定义

先固定一个足够细的 canonical 物理网格，将网格 `g` 的概率测量写为 `A_g`。`A_g` 由 affine 与体素 footprint 的物理重叠权重构成，作用在 class probability 上，而不是 logits 上。图像的 linear/B-spline/其他重建核作为独立 nuisance factor 随机化和外测，不与标签/概率测量算子混为一谈。

在体素体积加权内积下，单个网格的可观测投影应写成加权形式

`P_g = A_g* (A_g A_g*)^† A_g`，

其中 `*` 是体积加权伴随，`†` 是伪逆。两视图真正共同可比较的对象是 `range(P_a) ∩ range(P_b)` 上的投影 `Q_ab`。先把每个网格概率用加权伪逆放回 canonical 空间，再比较 `Q_ab` 保留的分量。只有在整数倍、同相位、嵌套网格的特殊情形，这才可简化成直观的 fine-to-coarse 体积平均：

粗采样是非单射：存在大量不同的细网格边界，经 `D` 后得到相同的粗观测。也就是说，`ker(D)` 中的信息对粗网格不可见。现稿实际优化近似：

`d(p_f, U_{c→f} p_c)`

其中 `U` 是三线性上采样。这个目标把 `U p_c` 当成 `p_f` 的完整监督；当粗采样不能唯一识别细边界时，它可能惩罚 `p_f` 中粗网格不能表示的分量。

正确的最低要求是：

`L_OGC = d(stopgrad(D_{f→c} p_f), p_c)`

若两边都不是天然的嵌套细/粗关系，则不能随便指定一个 common grid。必须显式构造 `Q_ab`，或证明所选 common cells 能从两个采样中精确观测：

`L_OGC = d(stopgrad(Q_ab A_a^† p_a), Q_ab A_b^† p_b)`

这等价于只在两种采样共同可观测的商空间上施加一致性。细网格独有的残差不接受粗网格伪监督，继续由原生标签和边界损失学习。需要特别报告 `rank(Q_ab)`：若相位错开后精确交集退化得过小，不能掩盖这一事实。可以把 principal-angle 阈值化的“近似交集”作为扩展，但阈值必须在开发集前固定，并单独标为近似方法。

主实现建议让 `d` 使用 Brier/MSE（必要时加小权重 symmetric KL），而不是只用 soft Dice：在平方损失下，coarse-voxel 条件期望具有清楚的正交投影解释；Dice 可以作为辅助项和评价指标，但不能拿来证明“正交投影最优”。论文应给出一个短命题：在给定 coarse voxel 分区下，体积平均是所有 coarse-measurable 概率场中最小化 L2 误差的唯一表示，而细网格单元内的零均值残差不可由 coarse consistency 识别。

### 4.2 为什么它比现稿更像科研贡献

- 它指出了现有 full consistency 在非单射采样下的**不可识别/潜在过约束部分**，不是简单换一个 backbone 或 loss 名称。
- 它给出明确数学对象：已知、非单射采样算子的核与共同可观测空间。
- 它自然产生可证伪对照：用错误 spacing/phase/voxel footprint 构造 `A_wrong/Q_wrong`。如果错误算子也同样有效，机制解释失败。
- 它能解释为何 R2 大幅改善、R4 仍崩溃：随着 spacing 增大，共同可观测带宽缩小，全场上采样一致性中的虚假约束越来越多。
- 它是训练期插件，不增加推理分支；在现有代码里只需替换概率对齐方向并加入正确的预滤波/物理坐标映射。

### 4.3 安全的贡献句

> We formulate cross-grid segmentation consistency under non-invertible resampling as agreement in the grids’ common observable space, and show that sampling-operator-aware projection improves unseen-grid physical-boundary robustness over full-field upsampled consistency without degrading native-grid accuracy.

不要声称“首个 spacing-aware Mamba”“首个跨分辨率一致性”“连续空间 Mamba”或“严格等变”。

## 五、按失败成本排序的实验漏斗

### 阶段 0：先修复现稿因果缺口

只新增一组：`dynamic delta + 当前 full consistency`，使用原来的 5 个种子、相同 split、相同训练预算。

| delta | 无 consistency | full consistency |
|---|---|---|
| dynamic | 已有 | **必须新增** |
| static | 已有 | 已有 GridCons |

分析用两因素模型或每病例/每种子的配对效应，直接估计 `delta × consistency` 交互。预注册等效界：若 dynamic+full 与 static+full 的 R2 mapped Dice 差异 95% CI 完全落在 `[-0.01,+0.01]`，则 static-carrier 叙事终止。

**我对结果的先验：70%–85% 概率会显示 consistency 是主体、static 交互很小。** 这对旧论文不利，但会清掉错误机制，为新论文提供诚实基线。

### 阶段 1：零/低成本机制诊断

在现有 checkpoint 上重新推理，不训练新模型：

1. 保存 R1、R2、R4 soft probability，而不是只保存 hard mask。
2. 对每个 grid pair 同时计算：
   - 当前全场误差 `d(p_f,U p_c)`；
   - 共同可观测误差 `d(D p_f,p_c)`；
   - fine-only 残差能量，按边界距离和频带分层。
3. 用标签经过同一 `D` 得到 oracle，确认误差不是标签重采样伪影。
4. 检查 R2→R4 时，full error 中落在 coarse Nyquist 以上的比例是否显著上升。

**继续门槛：** 至少 60% 的 `full − observable` 误差集中在标签边界 3 mm 内，且该比例从 R2 到 R4 单调上升；否则 OGC 的主要机制缺乏数据支持，停止开发。

再加一个不依赖真实数据的受控 phantom：用解析 signed-distance field 生成球、细管、薄片和分叉结构，随机 sub-voxel phase，并以精确体积积分生成不同网格的 class occupancy。预先固定结构半径、spacing 和 phase 网格。对明显高于 Nyquist 的厚结构，OGC 与 full consistency 应接近；对接近/低于 coarse Nyquist 的薄结构，full consistency 应产生更大的细网格边界偏差，而 OGC 只要求 coarse occupancy 正确。这个实验不能替代真实数据，但能把“效果来自不可识别高频分量”与“只是一个更弱的 loss”区分开。若在这套有解析真值的诊断上也看不到预期交互，直接停止。

### 阶段 2：最小可行训练筛选

先在对齐、整数倍的 R1/R2/R4 上做 MVP，再扩展到 phase-shifted 的一般 `Q_ab`。只用 Hippocampus development split，3 个种子，固定 dynamic-delta backbone，比较：

| 组别 | 用途 |
|---|---|
| B0：无 consistency | 纯监督下限 |
| B1：当前 `U(coarse) ↔ fine` full consistency | 直接基线 |
| B2：OGC，`D(fine) ↔ coarse` | 主方法 |
| C1：OGC + `A_wrong/Q_wrong` | 承重机制 falsifier |
| C2：只做 matched anti-alias augmentation，无 consistency | 排除“只是模糊增强” |
| C3：naive trilinear `U·D` | 证明精确 row-space 构造不是换名 resize |
| C4：强制匹配 null residual | 预期恶化 fine-grid HD95，检验“不可识别残差不该被粗监督” |

训练 grid 不再只有固定 R2：每个 batch 随机采样 through-plane spacing `1.5–3.0 mm`、origin phase `[-0.5,+0.5] voxel`，并从 linear/B-spline 两种图像重建核中采样。`A/Q` 始终由体素几何/footprint 决定。测试使用训练未见的 spacing、phase、image-kernel 的**联合组合**，并保留 R4 压力测试。

开发门槛：

- 相比 B1，预注册 worst-case HD95 至少降低 10%；
- 原生 R1 Dice 非劣界为 `-0.005`；
- 5 个最困难的联合网格条件中至少 4 个方向一致；
- `A_wrong/Q_wrong` 至少丢失 OGC 增益的 50%，否则不得写“sampling-operator-aware mechanism”。

我对 B2 相比 B0 得到正向结果的先验为 **75%–90%**；相比已经很强的 B1 在 worst-case boundary 上仍胜出的先验为 **55%–70%**；错误算子对照同时支持机制的概率约 **45%–60%**。后两个才决定论文是否真的新，而不是第一个。

### 阶段 3：主实验，不再用 consistency Dice 当主终点

数据：

- MSD Hippocampus：保留已有确认集，但只能用于最终一次性验证；
- ACDC：作为主要外部 MRI 数据，天然具有明显的层厚/spacing 变化；
- 若算力允许，再加一个 CT 数据集作为跨模态外部验证。

backbone：

- 当前 dynamic-delta Mamba；
- 一个标准 3D CNN（DynUNet 或严格配置的 nnU-Net）作为架构外验证。

主终点只能有一个：每个病例在预注册网格压力面板上的 **worst-case HD95（mm）**。原生 Dice 是非劣性守门；Surface Dice、平均 Dice、volume bias、ECE、prediction consistency 均为次要终点。

统计单位是病例，不是重采样视图。所有 grid variants 必须留在同一个病例 split 内。对每个病例先跨预注册扰动取 worst case，再做方法间配对 bootstrap；种子作为第二层随机效应。次要终点使用 Holm 校正。测试集不能再依据任何结果调整 loss 权重、滤波核或成功阈值。

### 阶段 4：决定能不能写论文的四个 falsifier

1. **算子正确性与错误算子：** 每个几何先数值验证 `P²≈P`、加权 `P*=P`、`A(I−P)≈0`；再故意使用错误 spacing/phase/footprint。若错误算子仍同样有效，物理采样解释失败。
2. **可逆变换对照：** 对 flip/90° rotation，OGC 不应优于普通 equivariant consistency；若优势只在非可逆 grid change 出现，论点才成立。
3. **信息损失梯度与 residual-matching：** 随 spacing 增大，full-consistency 对 fine-only 高频边界的梯度占比应增加；OGC 应显著抑制该部分。反向强制匹配 null residual 应恶化 fine-grid HD95，却不改善 observable error。
4. **可逆/带限与架构交叉：** 在可逆或严格带限的 pair 上，projected 与 full consistency 应收敛；否则机制失败。如果只在 static Mamba 有效而在 dynamic Mamba/CNN 无效，方法应改写成特定交互现象，不可声称一般原理。

## 六、成功概率与决策规则

任何人承诺“极大概率既出正结果、又有强创新、又被接收”都不诚实。最稳妥的做法是让每个便宜实验都能尽早杀死错误假设。

| 目标 | 当前主观先验 | 含义 |
|---|---:|---|
| OGC 胜过无 consistency | 75%–90% | 容易，但创新证据弱 |
| OGC 在未见联合 grid 的 worst-case HD95 胜过 full consistency | 55%–70% | 最关键的效果门槛 |
| `A_wrong/Q_wrong` 明显削弱收益 | 45%–60% | 最关键的机制门槛 |
| 两数据集、两 backbone 均保持方向一致 | 40%–55% | 决定泛化强度 |
| 完成全部门槛后，在中等竞争度会议形成可接收论文 | 50%–65% | 条件概率，不是当前概率 |

若阶段 1 不过门，立即停止 OGC；若阶段 2 的 B2 不胜 B1，保留现稿为工程结果，不再宣称新机制；若 B2 胜出但 `A_wrong/Q_wrong` 也胜出，改写成一般的定向低通 consistency，不写采样算子机制；只有效果门槛和 falsifier 同时通过，才进入两数据集主实验。

## 七、建议的新论文形态

候选题目：

> **Consistency Only Where the Grid Can See: Observable-Grid Regularization for Robust 3D Medical Image Segmentation**

论文主线应是：

1. 不可逆重采样使 full-field equivariance/consistency 在数学上过约束；
2. 现有 GridCons 的 R2 成功与 R4 失败提供经验异常；
3. OGC 只比较共同可观测分量；
4. 错误算子、可逆变换和梯度频带实验共同验证机制；
5. 在 Mamba 和 CNN、MRI 两个数据集上验证未见联合网格的物理边界稳健性。

现有 static-delta 结果最多放到补充材料，作为“backbone parameterization audit”，不要再放在标题和主贡献第一条。

## 八、执行优先级

第一周只做三件事：补 `dynamic+full`；保存全概率图并完成阶段 1；先在嵌套对齐网格实现 fine-to-coarse 体积平均 OGC 与 `A_wrong`。三步通过后再实现一般 `Q_ab`。这决定该项目应继续还是止损；在通过前，不应扩充模型、不应加更多 Mamba 模块、不应重新润色现稿。

## 九、2026-07-23 实际执行结果

### 9.1 缺失的 `dynamic delta + full consistency` 已完成

严格复用了原训练集、验证集、40 例确认集、5 个种子、2500 updates、loss 权重与 checkpoint 选择规则。新臂的结果为：

| 方法 | R1 Dice | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| dynamic，无 consistency | 0.8469 | 0.4384 | 0.4309 | 0.5942 | 0.0024 |
| static，无 consistency | 0.8455 | 0.4966 | 0.4837 | 0.6563 | 0.0068 |
| static + full consistency | 0.8467 | 0.8531 | 0.8150 | 0.9555 | 0.1186 |
| **dynamic + full consistency** | **0.8463** | **0.8541** | **0.8182** | **0.9587** | **0.1123** |

dynamic-full 相对 static-full：R2 consistency `+0.0009 [-0.0092,+0.0106]`，R2 mapped Dice `+0.0032 [-0.0032,+0.0094]`，Surface Dice `+0.0032 [-0.0022,+0.0085]`。没有证据表明 static-full 更好。

更关键的 `delta × consistency` difference-in-differences 为：R2 consistency `-0.0591 [-0.1201,-0.0012]`。因此“static delta 是 consistency 的关键载体”不仅没有支持，点估计和区间方向还与该叙事相反。dynamic-full 相对 dynamic-none 的 R2 consistency 增益为 `+0.4157 [0.3419,0.4890]`，而 R1 Dice 差为 `-0.0006 [-0.0061,+0.0042]`。旧结果的主体明确来自 consistency loss。

### 9.2 OGC 的嵌套/对齐最小版本已有完整负结果

工作区既有 `measure_consistent_grid` 实验已经实现了 OGC 的最低成本特殊情形：把 R1 soft probability 按精确轴向体素重叠保守推送到随机原生粗网格，再与粗网格预测做 consistency（P）；对照 R 是当前 candidate-to-R1 三线性 full consistency。该实验使用单种子、20 例 development screen，并保持相同 schedule、训练预算和 R1 checkpoint 规则。

- P−R Extra Dmap：`-0.023217`，80% CI `[-0.033781,-0.012464]`，仅 6/20 病例为正；
- P−R Extra Smap：`-0.029004`，80% CI `[-0.041314,-0.016531]`；
- P 的 worst-grid Dmap：0.190987，低于 R 的 0.200233；
- 原生 Dnative 提高约 0.0081，但不足以抵消外推网格性能下降。

体素占据诊断本身成立：mixed-cell fraction 从 R2 的 0.495 增至 R4/R5 的 0.776/0.810，且保守传输保持体积；但把这个正确测量原则用于训练并没有转化成更好的分割。预注册决策为 `STOP_NO_CONSERVATIVE_GAIN`，37 个产物的 SHA256 完整性检查全部通过，确认集未被访问。

### 9.3 执行后的最终决策

1. 删除 static-carrier 机制声明；现有 GridCons 最多只能写成普通 full consistency 的受控效果。
2. 不把 simple OGC 扩到三种子、确认集或一般 `Q_ab`；其开发门槛已经明确失败，继续扩展属于结果追逐。
3. 不再给当前 OGC 55%–70% 的正向先验；真实单种子开发证据把它更新为低优先级候选。
4. 当前项目没有通过“高概率且有创新性”的继续门槛。下一篇方法论文需要新的、独立于 static delta 和保守概率传输的机制假设，而不是继续微调这两个方向。
