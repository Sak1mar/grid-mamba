# 可直接交给另一个 Codex 的写作 Prompt

你现在接手的是一篇面向 CCF-C 级别会议的英文医学图像分割论文。请直接在当前解压目录中完成写作，不要先空泛讨论，不要为了提高“创新感”捏造机制或扩大结论。

## 任务目标

基于本材料包，写出一篇完整、客观、可投稿前继续润色的英文论文初稿，题目暂定：

**Paired-Grid Consistency for Resampling-Stable 3D Medical Image Segmentation**

论文定位是“受控问题研究 + 极简训练期一致性正则”，不是新 Mamba 架构论文。目标是诚实利用现有强证据达到 CCF-C 的完整度，而不是假装达到 MICCAI/CVPR 级方法创新。

## 开始前必须按顺序完整阅读

1. `00_START_HERE.md`
2. `01_core_guidance/FACT_SHEET.md`
3. `01_core_guidance/CCFC_EXPERIMENT_ADDENDUM.md`
4. `02_task04_primary/CONTROL_REPORT.md`
5. `02_task04_primary/CONTROL_PROTOCOL_PRETRAINING.json`
6. `03_task09_external/EXTERNAL_REPORT.md`
7. `01_core_guidance/FINAL_RESEARCH_AUDIT_ZH.md` 的第九节
8. `06_related_work/novelty_audit_original.md`，但其中 static-delta 结论已被后续 factorial 实验推翻，只能用于找相关文献，不能继承旧结论
9. 方法细节不确定时，查 `05_method_and_statistics_code/run_paired_full.py`、`control_matrix.py` 和 `control_statistics.py`

若任何材料冲突，以 `FACT_SHEET.md` 中的 evidence hierarchy 和 canonical 数字为准。

## 不可违反的科学约束

- 核心正结果只支持 MSD Task04 上 controlled same-anatomy resampling stability。
- 必须把 dynamic/static delta × consistency 的完整 Mamba 2×2 因果矩阵放入主文。
- 必须把 3D U-Net ± consistency 放入主文，证明效果跨骨干，但只可表述为本实验中的 backbone-independent evidence。
- 必须明确写出 Mamba interaction 为负；static delta 不是必要条件，也不是贡献。
- 必须报告 R1 native Dice guardrail、R2 consistency、R2 mapped Dice、R2 Surface Dice@2mm 和 R4 consistency。
- R4 虽显著改善但绝对值仍很低，必须作为未解决的 severe-resampling failure。
- Task09 是负外部验证。可以放正文 Discussion/Limitations 和补充表，但绝不可以写成成功泛化。
- R2 标签未用于训练或 checkpoint 选择，但用于确认阶段的 mapped-label evaluation；必须区分清楚。
- consistency loss 是已有思想的直接、简单应用。创新定位只能是问题定义、受控设计、因果消融、跨骨干验证和边界报告。
- 不能写 SOTA、first spacing-aware Mamba、metric-calibrated Mamba、static-timescale carrier、token-wise delta causes instability、clinical robustness 或 cross-dataset generalization。
- 不得发明额外数据集、baseline、超参数、显著性检验、伦理审批、代码链接、作者单位或实验结果。
- 不得从均值和 CI 推导材料中没有给出的 p 值。
- 不得把 95% CI 写成标准差，也不得把 case × seed 样本数错误写成独立样本数 200。

## 建议论文主线

3D 分割研究通常只评价单一网格上的准确率，但同一解剖在不同层厚重采样后可能得到显著不同的预测。本文建立一个物理对齐的 R1/R2/R4 受控协议，并研究一个训练期 paired-grid consistency loss。Task04 的五种子确认实验表明，该损失在 dynamic-delta Mamba、static-delta Mamba 和 3D U-Net 上都大幅提高 R2 稳定性及标签参照指标，同时不显著改变 native R1 Dice。完整 factorial 分析排除了 static timescale 解释。Task09 阴性结果进一步表明，这一结论只适用于受控同病例重采样，不能外推到异质真实采集。

## 输出文件

在新建的 `paper_draft/` 下生成：

1. `main.md`：完整英文论文，约 4,000–5,500 词，不含参考文献；包含 Title、Abstract、Keywords、Introduction、Related Work、Method、Experiments、Results、Discussion、Limitations、Conclusion。
2. `references.bib`：只收录已核验的真实文献。优先从 `06_related_work/papers/` 的论文首页和 `novelty_audit_original.md` 中提取；缺失元数据时可以联网查论文/出版社/会议官方页面，但不能猜作者、年份、页码、DOI。
3. `claim_audit.md`：逐项列出摘要、贡献点、主要结果和局限性中的承重 claim，并标明其证据文件与表格/字段；同时列出仍需作者填写的内容。
4. `supplementary.md`：至少包括完整 Task09 表、每种子结果或其索引、数据划分与防泄漏说明、bootstrap 说明、完整性/复现材料索引。

如果没有明确会议模板，不要擅自创建 LaTeX 模板。先完成可审阅的 Markdown；作者、单位、通讯作者、基金、代码 URL、最终会议名使用明确的 `[TO BE FILLED]` 占位符。

## 正文详细要求

### Abstract

- 180–230 英文词。
- 按 problem → method → protocol → strongest Task04 evidence → U-Net evidence → external boundary → scoped conclusion 展开。
- 至少给出 dynamic Mamba 的 R2 mapped Dice 0.4309→0.8189、Surface Dice 0.5942→0.9580、R1 变化 -0.0003，以及 U-Net 的 mapped Dice 0.5652→0.8536。
- 不写“novel architecture”或“generalizable”。

### Introduction

- 说明 native-grid Dice 不能度量同一解剖跨网格预测是否稳定。
- 区分受控重采样稳定性与 domain generalization、scanner shift、super-resolution。
- 用 3–4 条贡献结束，贡献措辞严格采用 `FACT_SHEET.md` 的 defensible language。

### Related Work

- 分三类：transformation/consistency regularization；cross-resolution/spacing-aware medical segmentation；Mamba/SSM medical segmentation。
- 明确承认 Bortsova transformation consistency、CR-GLoCo、Consispace、Mamba-Sea 等先例。
- 用 TIDES 说明不能把物理步长迁移本身当成本文创新；TIDES 不必成为主要对手。
- 只引用真正读过或已核验元数据的文献。相关工作部分禁止把 title-level novelty audit 当成全文事实。

### Method

- 给出 R1/R2/R4 构建和共同物理范围的定义。
- 明确定义 `Align`、stop-gradient teacher、foreground soft-Dice consistency、500-step warm-up 至 0.1。
- 说明 supervised segmentation loss 的组成，以协议/代码为准。
- 说明训练时需要 paired view，推理时仅单次普通前向，没有附加模块。
- Mamba 和 U-Net 仅作为两个 carrier backbones；static/dynamic delta 是受控因素，不是方法贡献。

### Experiments and Statistics

- 完整说明 Task04 数据划分、开发/确认隔离、五种子、训练预算、checkpoint 选择和 R2 标签禁用规则。
- 定义五个主要报告指标，避免把 prediction consistency Dice 与 mapped label Dice 混为一谈。
- 解释 paired hierarchical bootstrap：病例和种子层级重采样，10,000 次；不要称 200 个 case-seed cell 为 200 个独立病例。
- 描述六个 Task04 arms 和预定义 comparisons。
- Task09 单独写成 external boundary study，说明 5 folds × 3 seeds × 41 outer-test cases。

### Results

- 主表 1 使用 `FACT_SHEET.md` 的六臂均值。
- 主表 2 使用四个 paired comparisons 和 95% CI。
- 先报告 dynamic Mamba 配对效应，再报告 static Mamba、interaction、U-Net。
- 明确说明 R1 CI 跨 0，因而结论是“没有观察到 material native-grid degradation”，不是“证明完全不影响准确率”。
- 明确指出 R4 consistency 的低绝对值。
- 效率只写“同一 backbone 内无额外推理参数/分支”；延迟数字若写，必须来自 `PERFORMANCE.json`，不要宣称加速。

### Discussion and Limitations

- 讨论为什么同病例一致性监督能改善受控 R2，但不要写成已经验证的因果生物学/信号处理机制。
- 正面解释 factorial 结果：收益属于 consistency，而不是 static delta。
- Task09 阴性结果必须出现，并使用谨慎措辞限制 external validity。
- 至少写明：一个小型 MRI task；compact backbones；synthetic controlled grids；R4 未解决；external CT 未复现；没有与所有最新 segmentation architecture 做精度竞赛；一致性思想本身并不新。

## 写作质量要求

- 英文应紧凑、客观，避免宣传式形容词，如 revolutionary、dramatic、unprecedented、universally robust。
- 每个承重数值必须可追溯到 canonical report/JSON。
- 表格标题中写清 40 confirmation cases、5 seeds、hierarchical paired 95% CI。
- 保持术语一致：native-grid Dice、prediction-consistency Dice、mapped-label Dice、Surface Dice@2mm。
- 不能用“accuracy”笼统替代 Dice，除非句子明确是泛指。
- 在最终提交前自行做一次数字一致性扫描和 forbidden-claim 扫描。

## 完成标准

完成后不要只汇报“写好了”。请先检查四个文件存在且非空，再在回复中给出：各文件路径、main.md 英文词数、参考文献条目数、是否发现未决数字冲突、所有 `[TO BE FILLED]` 项。若材料不足，使用占位符并在 `claim_audit.md` 标红，禁止自行补造。

