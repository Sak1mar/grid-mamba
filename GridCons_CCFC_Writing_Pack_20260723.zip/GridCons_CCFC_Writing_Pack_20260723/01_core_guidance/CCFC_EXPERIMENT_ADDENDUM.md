# CCF-C 投稿版实验补充（可直接并入稿件）

## 推荐题目

**Paired-Grid Consistency for Resampling-Stable 3D Medical Image Segmentation**

不要再在题目中出现 `Static State Timescales`、`Metric Mamba` 或 `Spacing-aware Mamba`。

## 论文定位

本文不再把 static delta 作为新机制，而定位为一项问题驱动的受控研究：3D 医学分割模型在同一解剖经过不同层厚重采样后会产生显著不一致；一个简单、只在训练期使用的 paired-grid consistency regularizer 可以在 Mamba 和 3D U-Net 上显著改善受控重采样稳定性，而不增加推理开销或破坏原生网格精度。

## 可直接替换的英文摘要

Volumetric segmentation models can produce substantially different masks when the same anatomy is represented on voxel grids with different through-plane sampling. We study this failure mode through a controlled same-case resampling protocol and introduce a training-only paired-grid consistency regularizer. A labeled prediction on the native grid serves as a stop-gradient target for an unlabeled prediction obtained from a coarser view of the same volume. We evaluate the regularizer on MSD Task04 Hippocampus using a compact six-direction 3D Mamba and a 3D U-Net, with five random seeds and a disjoint 40-case confirmation split. On the dynamic-delta Mamba, paired-grid consistency improves R2 mapped Dice from 0.4309 to 0.8189 and Surface Dice@2mm from 0.5942 to 0.9580, while native-grid Dice changes by only -0.0003. On 3D U-Net, it improves R2 mapped Dice from 0.5652 to 0.8536 with a +0.0016 native-grid Dice change. A complete delta-by-consistency factorial analysis shows that the effect does not require static Mamba timescales. These results establish paired-grid consistency as a simple backbone-independent intervention for controlled resampling stability, while an additional real-spacing Task09 Spleen study identifies its limitation under heterogeneous cross-dataset conditions.

## 推荐贡献点

1. We formulate and evaluate same-anatomy resampling instability as a distinct robustness problem in 3D medical segmentation, using physically aligned R1/R2/R4 views and label-referenced mapped metrics.
2. We study a minimal training-only paired-grid consistency regularizer that requires no auxiliary inference branch and no labels on the coarse training view.
3. A five-seed factorial Mamba experiment and an independent 3D U-Net control show that the gain is produced by consistency regularization rather than static state timescales or a Mamba-specific interaction.
4. We report both a disjoint confirmation study and a negative real-spacing external validation, defining the supported scope of the method instead of extrapolating beyond the evidence.

## 主文表 1：完整因果矩阵与跨骨干结果

所有数值均为 40 例确认集 × 5 seeds 的平均值。

| Backbone / arm | R1 Dice | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Mamba, dynamic delta | 0.8469 | 0.4384 | 0.4309 | 0.5942 | 0.0024 |
| Mamba, dynamic delta + consistency | 0.8467 | 0.8525 | 0.8189 | 0.9580 | 0.1048 |
| Mamba, static delta | 0.8455 | 0.4966 | 0.4837 | 0.6563 | 0.0068 |
| Mamba, static delta + consistency | 0.8467 | 0.8531 | 0.8150 | 0.9555 | 0.1186 |
| 3D U-Net | 0.8739 | 0.5883 | 0.5652 | 0.7438 | 0.0149 |
| 3D U-Net + consistency | **0.8755** | **0.9141** | **0.8536** | **0.9807** | **0.1970** |

## 主文表 2：预先定义的配对效应

| Comparison | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R1 Dice guardrail | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Dynamic Mamba + consistency − Dynamic Mamba | +0.4141 [0.3380, 0.4896] | +0.3881 [0.3104, 0.4655] | +0.3638 [0.2851, 0.4462] | -0.0003 [-0.0057, 0.0044] | +0.1023 [0.0741, 0.1338] |
| Static Mamba + consistency − Static Mamba | +0.3566 [0.2997, 0.4130] | +0.3313 [0.2766, 0.3857] | +0.2991 [0.2451, 0.3542] | +0.0012 [-0.0028, 0.0049] | +0.1118 [0.0725, 0.1538] |
| 3D U-Net + consistency − 3D U-Net | +0.3258 [0.2539, 0.3983] | +0.2884 [0.2207, 0.3594] | +0.2369 [0.1757, 0.3042] | +0.0016 [-0.0019, 0.0051] | +0.1821 [0.1270, 0.2404] |
| Mamba delta × consistency interaction | -0.0576 [-0.1213, -0.0010] | -0.0567 [-0.1258, 0.0038] | -0.0646 [-0.1427, 0.0029] | +0.0015 [-0.0037, 0.0067] | +0.0095 [-0.0312, 0.0523] |

正文解释：

> Paired-grid consistency produced large and reproducible gains for both Mamba parameterizations and for 3D U-Net. The Mamba interaction estimate was not positive; for R2 consistency it was significantly negative. Static delta is therefore neither necessary nor supported as a privileged carrier of the regularization effect. We consequently treat delta parameterization as a controlled factor rather than a contribution.

## 外部 Task09 Spleen：放补充材料或 limitations

该实验为独立 CT 数据、真实 heterogeneous spacing、5 outer folds、3 seeds、41 outer-test cases。不要把它写成成功泛化。

| Arm | Consistency | Native Dice | Mapped Dice | Surface Dice@2mm |
|---|---:|---:|---:|---:|
| dynamic delta | 0.7684 | 0.4441 | 0.4335 | 0.2482 |
| static delta | 0.7457 | 0.4513 | 0.4496 | 0.2444 |
| static delta + consistency | 0.7601 | 0.4484 | 0.4405 | 0.2430 |

相对 dynamic baseline，consistency arm 的 consistency 差为 `-0.0083 [-0.0327,+0.0098]`，mapped Dice 差为 `+0.0070 [-0.0296,+0.0467]`，Surface Dice 差为 `-0.0052 [-0.0283,+0.0238]`。预注册外部规则失败。

可直接使用的 limitation：

> The controlled Task04 gains did not transfer to the Task09 real-spacing experiment. Unlike the paired synthetic grids, Task09 combines acquisition, anatomy, intensity, and spacing variation, and its native segmentation accuracy was substantially lower. We therefore restrict our conclusion to controlled same-anatomy resampling and do not claim general robustness to heterogeneous clinical acquisition.

## 方法段应保留的最小描述

For a labeled native-grid image `x1` and an unlabeled coarse-grid rendering `x2` of the same physical volume, the network predicts foreground probabilities `p1` and `p2`. After cropping padding and mapping `p2` to the R1 frame, training minimizes

`L = Lseg(f(x1), y1) + lambda(t) [1 - SoftDice(stopgrad(p1), Align(p2))]`,

where `lambda(t)` warms linearly to 0.1 during the first 500 updates. Coarse-view labels are not used for training, and checkpoints are selected exclusively by R1 validation Dice. The regularizer is removed at inference.

不要加入 OGC、物理 delta、额外模块或新的推理分支。

## Results 段落

On the dynamic-delta Mamba, paired-grid consistency increased R2 prediction consistency by 0.4141 (95% CI 0.3380–0.4896), mapped Dice by 0.3881 (0.3104–0.4655), and Surface Dice@2mm by 0.3638 (0.2851–0.4462). Native R1 Dice changed by -0.0003 (-0.0057–0.0044). All five seeds improved on the R2 endpoints. Similar effects were observed for the static-delta Mamba. However, the delta-by-consistency interaction for R2 consistency was -0.0576 (-0.1213–-0.0010), rejecting the interpretation that static delta is required for the gain.

The independent 3D U-Net control showed the same qualitative behavior: consistency increased R2 mapped Dice by 0.2884 (0.2207–0.3594), Surface Dice@2mm by 0.2369 (0.1757–0.3042), and R4 consistency by 0.1821 (0.1270–0.2404), while native R1 Dice changed by +0.0016 (-0.0019–0.0051). The improvement is therefore not specific to Mamba.

## 必须删除或改写

- 删除：`static channel-wise state timescale is a useful carrier for paired-grid consistency`。
- 删除：`we isolate token-wise delta adaptation as a source of grid sensitivity` 作为主结论。
- 删除：任何 `first spacing-aware Mamba`、`metric-calibrated`、`millimetre-scaled state transition` 表述。
- 将 `GridCons-Mamba` 改为方法实现名或 Mamba 实例，不再作为一般方法名。
- 将 novelty 定位为 problem formulation + controlled evidence + simple regularizer，而不是新架构 primitive。

## 推荐稿件结构

1. Introduction：重采样导致同一解剖预测不稳定；现有精度指标忽略该问题。
2. Method：paired-grid construction、one-line consistency loss、无推理开销。
3. Controlled protocol：R1/R2/R4、物理对齐、确认集、5 seeds、case-and-seed bootstrap。
4. Results：Mamba 2×2 因果矩阵、U-Net 跨骨干结果、R4 失败压力测试。
5. External boundary：Task09 负结果及适用范围。
6. Discussion：方法简单有效，但仅支持 controlled same-anatomy resampling，不支持一般临床 domain generalization。

