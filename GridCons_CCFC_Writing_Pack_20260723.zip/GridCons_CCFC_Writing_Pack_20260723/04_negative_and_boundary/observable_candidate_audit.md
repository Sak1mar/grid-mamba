# Observable-grid consistency: immediate novelty/mechanism audit

## Verdict

**Revise — Level 3 (Medium Overlap).** The research problem and medical-segmentation domain overlap strongly with transformation consistency and cross-resolution learning, but none of the inspected named works restricts prediction consistency to the exact mutually observable row-space of a non-invertible sampling operator. The core mechanism is therefore defensible after a mathematical correction; it is not ready to advance as currently written.

## Mathematical premise

The premise is valid, but generally **not** with arbitrary `P_s = U_s D_s` and not most cleanly on logits. `UD` is a projection only when `DU=I` on the coarse space; it is an orthogonal projection only under the corresponding weighted inner product. For arbitrary spacing, phase, and overlap geometry, use probabilities and the voxel-volume-weighted projector

\[
P_s=D_s^{*}(D_sD_s^{*})^{-1}D_s
\]

(or a numerically equivalent weighted pseudoinverse), and define the two-view comparison on `range(D_a*) ∩ range(D_b*)`. A common grid is valid only if each comparison cell is exactly observable from both samplings. Then `D_s(I-P_s)=0`, so the residual is genuinely unobservable. Do not conflate the image reconstruction kernel used to generate a view with the probability-measurement operator, and do not claim that fine residuals are correct—only that coarse consistency cannot identify them; fine labels/boundary loss must supervise them.

## Closest prior art and delta

- [Bortsova et al. 2019](https://arxiv.org/abs/1911.01218) is closest conceptually: align transformed predictions and penalize full-output disagreement. It does not handle the null space created by non-invertible sampling.
- [CR-GLoCo 2026](https://doi.org/10.1016/j.compmedimag.2026.102742) exchanges pseudo-supervision between low-resolution global and high-resolution local branches over a shared field of view; it does not derive an observable quotient space.
- [Consispace 2026](https://arxiv.org/abs/2606.31839) learns a semantic resampler; [CROWn 2026](https://openaccess.thecvf.com/content/CVPR2026/papers/Huang_CROWn_A_Unified_Framework_for_Anti-Aliased_Downsampling_and_Phase-Calibrated_Fusion_CVPR_2026_paper.pdf) performs internal anti-aliasing and phase-calibrated fusion; neither changes what an output-consistency loss is allowed to identify.
- [Tunable Soft Equivariance 2026](https://openaccess.thecvf.com/content/CVPR2026/papers/Rahman_Tunable_Soft_Equivariance_with_Guarantees_CVPR_2026_paper.pdf) projects weights toward equivariant subspaces, not predictions onto a sampling-operator row space.

**Safe novelty sentence:** Unlike full transformation consistency and learned resampling/anti-aliasing methods, we compare cross-grid class probabilities only after exact physical-overlap projection into the row-space observable from both voxel lattices, leaving sampling-null residuals to fine-label supervision.

## Required falsification controls

1. Verify numerically `P²≈P`, weighted `P*=P`, and `D(I−P)≈0` for every geometry.
2. Compare no consistency, full aligned consistency, exact projected consistency, and trilinear/naive-`UD` projection.
3. Add a residual-matching control; the prediction is worse fine-grid boundary HD95 without improved coarse-observable error.
4. On invertible or band-limited pairs, projected and full consistency should converge; otherwise the mechanism claim fails.
5. On held-out joint spacing–phase–kernel shifts, projected consistency must lower worst-case HD95 while preserving native-grid Dice; show that the gain tracks label-correlated null-space boundary energy, not merely weaker regularization.
