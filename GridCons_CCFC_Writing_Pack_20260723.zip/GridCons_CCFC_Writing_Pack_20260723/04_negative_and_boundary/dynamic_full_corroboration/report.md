# Dynamic-delta + full-consistency causal audit

This is a post-hoc completion of the missing delta × consistency factorial arm.

| Method | R1 Dice | R2 consistency | R2 mapped Dice | R2 surface@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| dynamic_delta | 0.8469 | 0.4384 | 0.4309 | 0.5942 | 0.0024 |
| static_delta | 0.8455 | 0.4966 | 0.4837 | 0.6563 | 0.0068 |
| gridcons_mamba | 0.8467 | 0.8531 | 0.8150 | 0.9555 | 0.1186 |
| dynamic_full_consistency | 0.8463 | 0.8541 | 0.8182 | 0.9587 | 0.1123 |

## Dynamic-full minus static-full

| Metric | Difference [95% CI] |
|---|---:|
| r2_consistency | +0.0009 [-0.0092, +0.0106] |
| r2_mapped_dice | +0.0032 [-0.0032, +0.0094] |
| r2_surface_dice_2mm | +0.0032 [-0.0022, +0.0085] |
| r1_dice | -0.0004 [-0.0112, +0.0081] |
| r4_consistency | -0.0063 [-0.0537, +0.0415] |

## Factorial interaction: (static-full − static-none) − (dynamic-full − dynamic-none)

| Metric | Interaction [95% CI] |
|---|---:|
| r2_consistency | -0.0591 [-0.1201, -0.0012] |
| r2_mapped_dice | -0.0560 [-0.1225, +0.0041] |
| r2_surface_dice_2mm | -0.0653 [-0.1407, +0.0032] |
| r1_dice | +0.0018 [-0.0036, +0.0074] |
| r4_consistency | +0.0019 [-0.0435, +0.0493] |

Flags: `{"dynamic_consistency_main_effect": true, "full_arms_r2_consistency_equivalent_0p01": false, "static_carrier_interaction_supported": false}`
