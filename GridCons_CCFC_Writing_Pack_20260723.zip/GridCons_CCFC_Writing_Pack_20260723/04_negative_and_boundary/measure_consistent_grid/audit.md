# Audit

## Random-K1 statistical/optimization source

Random-K1 and IID Random-K2-mean optimize the same expected auxiliary objective; they differ in Monte Carlo gradient variance, compute, and optimization trajectory.

- seed 17: K1−K2 Extra Dmap +0.024064; K1−soft-worst +0.006364.
- seed 29: K1−K2 Extra Dmap -0.009559; K1−soft-worst -0.034895.
- seed 41: K1−K2 Extra Dmap -0.043554; K1−soft-worst -0.057928.

K1 exceeded K2 in all three seeds: False. K2 mean-loss scaling, effective lambda, case order, and spacing_1 schedule all passed exact checks.

## Zero-cost diagnostic

Decision: GO_MEASURE_IMPLEMENTATION. R2/R4/R5 median mixed-cell fractions were 0.495225/0.775634/0.810471; R4/R5 NN–occupancy disagreement was 0.061725/0.085711.

## Scientific result

P did not exceed R; O did not exceed R or H. Final decision: STOP_NO_CONSERVATIVE_GAIN.
