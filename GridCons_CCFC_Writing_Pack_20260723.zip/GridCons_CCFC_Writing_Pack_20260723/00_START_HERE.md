# GridCons CCF-C writing pack

This directory is a curated, self-contained evidence pack for drafting an English CCF-C-level paper. Start with:

1. `01_core_guidance/CODEX_WRITING_PROMPT_ZH.md` — the prompt to give another Codex.
2. `01_core_guidance/FACT_SHEET.md` — canonical facts, numbers, and forbidden claims.
3. `01_core_guidance/CCFC_EXPERIMENT_ADDENDUM.md` — paper-ready title, abstract, tables, and paragraphs.
4. `02_task04_primary/CONTROL_REPORT.md` — the primary five-seed confirmatory evidence.
5. `03_task09_external/EXTERNAL_REPORT.md` — the negative external boundary result.

## Evidence hierarchy

If two files conflict, use this order:

1. `02_task04_primary/CONTROL_REPORT.md` and `CONTROL_RESULTS.json` for Task04 paper numbers.
2. `03_task09_external/EXTERNAL_REPORT.md` and `EXTERNAL_RESULTS.json` for Task09.
3. `01_core_guidance/FACT_SHEET.md` and `CCFC_EXPERIMENT_ADDENDUM.md` for interpretation.
4. Machine-readable CSV/JSON files for audits or extra analyses.
5. `07_legacy_superseded/` only for historical context; its static-timescale narrative is invalid.

## What is intentionally excluded

Datasets, cached volumes, checkpoints, virtual environments, and console logs are excluded. They are not needed to write the paper and would make the pack unnecessarily large. The pack retains reports, protocols, per-case metrics, integrity records, implementation code, tests, and the most relevant papers.

## Supported paper claim

Paired-grid consistency is a simple training-only regularizer that strongly improves controlled same-anatomy R1/R2 resampling stability on MSD Task04 for both a compact 3D Mamba and 3D U-Net, without a material native-grid Dice change. The evidence does **not** support static Mamba timescales as the cause and does **not** establish general robustness to heterogeneous real clinical spacing.

