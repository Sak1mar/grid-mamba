# GridCons-Mamba execution audit

All timestamps are Asia/Shanghai on 2026-07-19 unless stated otherwise.

## Protocol chain

- The original training protocol was written at `22:36:22.260901795`; its SHA-256 was `f0ed35807c33ce64d5d2c747f2b94ee600ca72bf9cbcfdf14bbd16c4a614ace5` and its size was 2,233 bytes.
- Before regenerating the downstream protocol, that file was copied byte-for-byte to `protocol_pretraining.json`. `cmp` returned equality and both files had the same SHA-256 before regeneration. The snapshot's filesystem mtime is the copy time, not the original protocol time.
- The final downstream protocol was written at `23:22:34.654874430`, before the development screen (`23:22:56.912456739`) and confirmatory metrics (`23:25:22.606722605`). Its SHA-256 is `c2aa3089e674f32f973bbcecba0942c337d93bc6880fc9587cbd8abc3102195d`.
- The final protocol freezes the development release rule, confirmatory outcome rules, source/confirm manifest hashes, source checkpoint hashes, data budget, GPU, model size, and all relevant downstream code hashes.
- The confirm manifest was written before training at `22:36:22.077905229`. Its file SHA-256 is `ae909321483b277a216011d73c1cdc730d809d795cc656af4d3a2a0a4a891d96`; its internal content hash is `f35f8135c42dc22bebe01368824c36003bd5748e7799f6e2e1a9780cb182bd42`.

## Training-code audit

- Five parallel training processes launched at approximately `22:36:40` and completed at `23:20:01`, all on physical GPU0.
- A read-only reconstruction of the launch-time `run_paired_full.py` gives SHA-256 `c31d138ea60413409cc4826428b9c33dd4d2b93fc445c8d635e770630790b3e8`.
- The current and launch-time source segments for `CONSISTENCY_WEIGHT`, `UPDATES`, `VALIDATE_EVERY`, `crop`, `paired_grid_consistency_loss`, and `train` are exact matches. The launch/current `train` segment begins with SHA-256 prefix `41782aa36f6a4450`; the paired-loss segment begins with `44315afe04ba6cca`.
- Post-launch source changes were confined to development screening, confirmatory gating, reporting, validity checks, and time/hash metadata. `model.py` and `run_probe.py` were unchanged. Therefore checkpoint semantics match the training protocol despite the whole-file runner hash changing later.

## Proposed checkpoints

| Seed | Checkpoint SHA-256 | Training complete | Validation records |
|---:|---|:---:|---:|
| 17 | `63aaa2643b893099653532fa743fdeadaa62712386199847ccb6fea486084bc1` | yes | 10 |
| 29 | `d5e65402ae5d2c289d4fd86b5ae70b2b23ce7396404ab46e3d17d4ea4bc34c06` | yes | 10 |
| 41 | `9a04c5445ee3bd8d041ce4eadc083b8eb7b7ce71e2663d7e24a1850055f45ea1` | yes | 10 |
| 53 | `4e30f9fc268e5ce091352c4dbbd7b2b6a1418382e055d6b53014d38680800605` | yes | 10 |
| 67 | `3187ea6756007e1d2644e02aa8a7112223ae59ad90b8eb20500c7ecd721cb491` | yes | 10 |

Every checkpoint hash matches its training log. Every checkpoint was selected only by R1 validation Dice. No R2 label entered training.

## Observation order

1. Training protocol and 40-case confirm manifest were materialized.
2. Five parallel GridCons models trained to completion.
3. Final outcome rules/code hashes were materialized before any development screen or confirmatory evaluation.
4. Development screen SHA-256: `9a46f494123187da35057f1f2567201cb5ec84c9aba6cd870e6d79d01abc8287`; both release gates passed.
5. Immediately before confirmation, `metrics.csv`, `evaluation.json`, `results.json`, and `report.md` were checked and found absent.
6. Confirmation ran once through the released path and wrote 3,600 rows with zero failures.
7. Report aggregation used 10,000 hierarchical paired bootstrap replicates with seed 7301.

## Final artifact hashes before this audit file

| Artifact | SHA-256 |
|---|---|
| `metrics.csv` | `067d3e94b87ebfd7febe21d208a22eb15d1444acc7ecc4b1e7cba464f5533368` |
| `evaluation.json` | `732284cdceb650ba779df8d6c00cf706478c9cad6bd1ebe01c4eab3b0fc2281b` |
| `results.json` | `9d24dfae571b2fb7b5b4ec193581e4369011369b4e59850aa0416e576d3c8ad7` |
| `report.md` | `52b8ee1a918b4cce6602e258cc6f65de30e534272f42bc238f2db336f4cbb568` |

The SHA-256 stored in `evaluation.json` equals the current `metrics.csv` hash. An independent post-report check also verified: 3,600 unique rows, 40 cases, five seeds, three methods, three spacings, all finite values, exact R1 self-consistency, all four outcome flags true, and all 14 validity gates true.

## Known audit limitation

`evaluation.json` records row count, failures, GPU use, and the output metrics hash, but it does not embed every input/checkpoint/protocol hash. Those bindings are distributed across `protocol.json`, `dev_screen.json`, the five training logs, and `results.json`; this document makes that chain explicit. The original protocol content is preserved byte-for-byte, but its original mtime survives as an observed audit record rather than snapshot metadata.

