# GridCons-Mamba full results

All values are held-out means over a newly frozen 40-case confirmatory split × 5 seeds; CIs use hierarchical paired bootstrap over cases and seeds.

| Method | R1 Dice | R2 consistency | R2 mapped Dice | R2 surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| dynamic_delta | 0.8469 | 0.4384 | 0.4309 | 0.5942 | 0.0024 |
| static_delta | 0.8455 | 0.4966 | 0.4837 | 0.6563 | 0.0068 |
| gridcons_mamba | 0.8467 | 0.8531 | 0.8150 | 0.9555 | 0.1186 |

## Per-class means

| Method | Class | R1 Dice | R2 consistency | R2 mapped Dice | R2 surface@2mm | R4 consistency |
|---|---|---:|---:|---:|---:|---:|
| dynamic_delta | anterior | 0.8533 | 0.4301 | 0.4227 | 0.5437 | 0.0001 |
| dynamic_delta | posterior | 0.8405 | 0.4466 | 0.4390 | 0.6447 | 0.0047 |
| static_delta | anterior | 0.8551 | 0.5299 | 0.5210 | 0.6553 | 0.0101 |
| static_delta | posterior | 0.8358 | 0.4633 | 0.4463 | 0.6574 | 0.0035 |
| gridcons_mamba | anterior | 0.8555 | 0.8630 | 0.8250 | 0.9560 | 0.1364 |
| gridcons_mamba | posterior | 0.8378 | 0.8433 | 0.8051 | 0.9550 | 0.1008 |

## Paired differences (candidate − reference; hierarchical 95% CI)

| Comparison | R2 consistency | R2 mapped Dice | R2 surface@2mm | R1 Dice | R4 consistency |
|---|---:|---:|---:|---:|---:|
| static_delta vs dynamic_delta | +0.0582 [-0.0002, +0.1260] | +0.0528 [-0.0099, +0.1244] | +0.0621 [-0.0076, +0.1421] | -0.0015 [-0.0101, +0.0081] | +0.0043 [-0.0023, +0.0128] |
| gridcons_mamba vs dynamic_delta | +0.4148 [+0.3371, +0.4934] | +0.3842 [+0.3049, +0.4641] | +0.3613 [+0.2826, +0.4444] | -0.0002 [-0.0087, +0.0093] | +0.1162 [+0.0757, +0.1569] |
| gridcons_mamba vs static_delta | +0.3566 [+0.2997, +0.4130] | +0.3313 [+0.2766, +0.3857] | +0.2991 [+0.2451, +0.3542] | +0.0012 [-0.0028, +0.0049] | +0.1118 [+0.0725, +0.1538] |

- Proposed vs dynamic R2 consistency: +0.4148, 95% CI [0.3371007519734817, 0.49341521269670385], seeds {'17': 0.34759939339066037, '29': 0.4291464044127909, '41': 0.5301299182347611, '53': 0.29712908913093516, '67': 0.469953295564994}.
- Proposed vs static R2 consistency: +0.3566, 95% CI [0.2996664358249545, 0.41300028460683297], seeds {'17': 0.2761184939373753, '29': 0.4272059207282955, '41': 0.35163599707769644, '53': 0.318994573506041, '67': 0.40889078213685276}.
- Proposed vs dynamic R1 Dice: -0.0002, 95% CI [-0.008709899462500302, 0.009334021322013265].
- Approximate single-GPU wall time: 0.757 h; summed process time: 3.643 h on NVIDIA PG506-230.
- Official dataset archive/extracted size: 28425216 / 27936125 bytes (<6GB: True).
- Label-resampling oracle Dice: {'R2': {'anterior': 0.9276936475052929, 'posterior': 0.9081983758777861}, 'R4': {'anterior': 0.8559103168386687, 'posterior': 0.8182523045690229}}.
- Frozen outcome flags: {'primary_incremental_success': True, 'static_addon_success': True, 'strong_primary_evidence': True, 'at_least_four_of_five_primary_seed_gains_positive': True}.

## Validity gates
- confirm_has_40_unique_cases: PASS
- confirm_disjoint_from_120_case_development_split: PASS
- all_five_trainings_complete: PASS
- ten_validation_records_per_training: PASS
- checkpoint_hashes_match_training_logs: PASS
- checkpoint_selection_uses_r1_validation_only: PASS
- r2_labels_excluded_from_training: PASS
- development_screen_released_confirm: PASS
- development_screen_checkpoint_hashes_match: PASS
- source_checkpoint_hashes_unchanged: PASS
- code_hashes_match_frozen_protocol: PASS
- evaluation_complete_without_failures: PASS
- all_metrics_finite: PASS
- official_archive_under_6gb: PASS
