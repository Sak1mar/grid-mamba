# Superseded material — do not inherit its conclusion

These files record the original three-arm paper shape. They are retained for provenance and method details only.

The later full Mamba factorial experiment added `dynamic delta + consistency` and showed that static delta is not required. Therefore the following legacy claims are invalid:

- static state timescales are a useful or necessary carrier for the consistency effect;
- token-wise delta adaptation is isolated as the source of grid sensitivity;
- the combined static-delta implementation is the paper's general method.

Use the canonical six-arm results in `../02_task04_primary/CONTROL_REPORT.md`, not the legacy paper recommendation.

