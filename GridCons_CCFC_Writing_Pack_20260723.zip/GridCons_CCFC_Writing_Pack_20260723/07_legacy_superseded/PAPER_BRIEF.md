# GridCons-Mamba paper and experiment brief

## Decision

**GO for an incremental MMM submission.** On the untouched 40-case confirmatory split, GridCons-Mamba improves R2 prediction consistency over the dynamic-delta baseline by **+0.4148** (hierarchical paired 95% CI **[+0.3371, +0.4934]**) while changing native R1 Dice by only **-0.0002** (95% CI **[-0.0087, +0.0093]**). It also improves over the independently trained static-delta arm by **+0.3566** (**[+0.2997, +0.4130]**). All five seeds improve. All four outcome flags and all 14 validity gates pass.

Working title:

> **GridCons-Mamba: Static State Timescales and Paired-Grid Consistency for Robust 3D Medical Image Segmentation**

The strongest paper shape is not “static delta is new.” It is a controlled, compact study showing that a static channel-wise state timescale is a useful carrier for paired-grid consistency, which sharply reduces same-anatomy prediction disagreement without sacrificing native-grid accuracy.

## Research question and contribution

The question is whether a 3D Mamba segmenter should give materially different predictions when the same anatomy is represented on grids with different through-plane sampling. The three controlled arms are:

1. `dynamic_delta`: token/content-dependent positive delta; B and C remain content-dependent.
2. `static_delta`: learned positive channel-wise delta shared across tokens and all six scan directions; B and C remain content-dependent.
3. `gridcons_mamba`: the same static-delta model plus one label-free paired-grid consistency term during training.

The paper-safe contribution statement is:

> A controlled combination of token-independent channel-wise Mamba timescales and paired-grid consistency for 3D resampling stability, evaluated with native-grid accuracy guardrails, five seeds, and a disjoint confirmatory split.

Do not claim that static delta, six-direction sharing, consistency regularization, or common-frame alignment is individually novel. Do not call the implementation spacing-aware, metric-calibrated, or millimetre-scaled.

## Method

For channel `c` and token `t`, the dynamic baseline uses content-dependent `delta[t,c]`; the static arms use

```text
delta[t,c] = softplus(theta[c]).
```

The same selective recurrence is shared over forward/backward scans of the depth, height, and width axes. The compact carrier has 99,411 trainable parameters.

For a labeled R1 image and its label-free R2 view, let `P1` and `P2` denote softmax probabilities after removing padding. R2 is trilinearly aligned to the R1 shape with `align_corners=True`. Training minimizes

```text
L = Lseg(f(x_R1), y_R1)
    + lambda_t * [1 - mean_c (
        (2 <stopgrad(P1_c), align(P2)_c> + eps)
        / (||stopgrad(P1_c)||^2 + ||align(P2)_c||^2 + eps)
      )],

lambda_t = 0.1 * min(1, update / 500).
```

Only foreground channels enter the consistency Dice. R2 labels are never used for training, and checkpoint selection uses R1 validation Dice only.

## Experimental protocol

- Dataset: Medical Segmentation Decathlon Task04 Hippocampus, 260 labeled MRI cases and two foreground classes (anterior/posterior).
- Splits from one frozen `numpy.default_rng(20260718)` shuffle: 80 train, 20 validation, 20 development screen, 40 untouched confirmation; the remaining 100 cases are unused.
- Grids: R1, R2, and R4 have 1, 2, and 4 mm through-plane spacing, 1 mm in-plane spacing, and matched physical bounds.
- Training: 2,500 updates, validation every 250 updates, AdamW (`lr=3e-4`, `weight_decay=1e-5`), bfloat16, seeds 17/29/41/53/67.
- Execution: five new GridCons runs in parallel on physical GPU0 (`NVIDIA PG506-230`); approximately 0.757 h critical-path training-plus-confirm time and 3.643 summed process-hours.
- Data budget: official archive 28,425,216 bytes, extracted files 27,936,125 bytes, cache 112,240,256 bytes; safely below 6 GB.
- Statistics: classes are averaged within each case/seed cell; 10,000 paired hierarchical bootstrap replicates resample cases and seeds.

The original ten dynamic/static five-seed trainings and their hashes were validated, then all three methods were evaluated through the same confirmatory path.

## Confirmatory results

All numbers below are means over 40 cases, two classes, and five seeds.

| Method | R1 Dice | R2 consistency | R2 mapped Dice | R2 surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Dynamic delta | 0.8469 | 0.4384 | 0.4309 | 0.5942 | 0.0024 |
| Static delta | 0.8455 | 0.4966 | 0.4837 | 0.6563 | 0.0068 |
| **GridCons-Mamba** | **0.8467** | **0.8531** | **0.8150** | **0.9555** | **0.1186** |

Paired candidate-minus-reference effects:

| Comparison | R2 consistency | R2 mapped Dice | R2 surface@2mm | R1 Dice | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Static - dynamic | +0.0582 [-0.0002, +0.1260] | +0.0528 [-0.0099, +0.1244] | +0.0621 [-0.0076, +0.1421] | -0.0015 [-0.0101, +0.0081] | +0.0043 [-0.0023, +0.0128] |
| **GridCons - dynamic** | **+0.4148 [+0.3371, +0.4934]** | **+0.3842 [+0.3049, +0.4641]** | **+0.3613 [+0.2826, +0.4444]** | -0.0002 [-0.0087, +0.0093] | **+0.1162 [+0.0757, +0.1569]** |
| **GridCons - static** | **+0.3566 [+0.2997, +0.4130]** | **+0.3313 [+0.2766, +0.3857]** | **+0.2991 [+0.2451, +0.3542]** | +0.0012 [-0.0028, +0.0049] | **+0.1118 [+0.0725, +0.1538]** |

Both classes contribute: dynamic-to-GridCons R2 consistency changes from 0.4301 to 0.8630 for anterior and from 0.4466 to 0.8433 for posterior.

## Seed stability

| Seed | GridCons R1 Dice | GridCons R2 consistency | Gain vs dynamic | Gain vs static |
|---:|---:|---:|---:|---:|
| 17 | 0.8436 | 0.8528 | +0.3476 | +0.2761 |
| 29 | 0.8498 | 0.8579 | +0.4291 | +0.4272 |
| 41 | 0.8525 | 0.8512 | +0.5301 | +0.3516 |
| 53 | 0.8434 | 0.8492 | +0.2971 | +0.3190 |
| 67 | 0.8441 | 0.8546 | +0.4700 | +0.4089 |

## Development screen versus confirmation

The old 20-case test was explicitly reclassified as development evidence. Before viewing it, the release rule required GridCons R2 consistency to exceed dynamic delta while keeping R1 Dice within 0.01; the addon rule made the analogous comparison with static delta.

| Development method | R1 Dice | R2 consistency |
|---|---:|---:|
| Dynamic delta | 0.8426 | 0.4458 |
| Static delta | 0.8411 | 0.5006 |
| GridCons-Mamba | 0.8443 | 0.8453 |

Both gates passed, releasing the already frozen, disjoint 40-case confirmation set. Confirmation produced 3,600 unique metric rows with zero failures.

## Novelty position

The structured prior-art audit covers 56 candidate papers and returns **Level 2: high overlap, no exact scoop**. That is enough meat for an incremental MMM paper, provided the claim stays narrow.

The closest distinction is from CR-GLoCo: that work exchanges cross-resolution pseudo-supervision between separate global and local 3D U-Nets, whereas GridCons-Mamba uses one six-direction 3D Mamba, a positive channel-wise delta shared across tokens/grids, and a label-free R2 prediction aligned to a stop-gradient R1 target. Consispace and transformation-consistency work establish common-space consistency as prior art; Mamba-Sea establishes that Mamba plus consistency training is not itself new.

Recommended novelty wording:

> We isolate token-wise state-step parameterization as a controlled source of grid sensitivity and show that static channel-wise timescales plus paired-grid consistency yield reproducible 3D resampling stability at matched native-grid accuracy.

## Limitations to state plainly

- The experiment uses one small MRI dataset and a compact research carrier, not a full production segmentation backbone.
- R1/R2/R4 are controlled resamplings of the same scans, not independent scanners or external-domain acquisitions.
- Static delta alone has a positive mean but its confirmatory CI crosses zero; the strong result belongs to the combined GridCons method.
- R4 consistency improves significantly but remains low in absolute terms (0.1186), so robustness to severe 4 mm sampling is not solved.
- R2 mapped Dice (0.8150) remains below native R1 Dice and below the approximately 0.918 label-resampling oracle.
- The design isolates the consistency addon against static delta but does not include a full factorial dynamic-delta-plus-consistency arm.
- The implementation consumes grid spacing only for construction/alignment checks; spacing does not scale the state transition.

## Suggested MMM paper structure

1. Introduce resampling-grid instability as the practical failure mode.
2. Use the dynamic-versus-static delta experiment as the mechanistic motivation, without overselling its standalone significance.
3. Present GridCons as one minimal training-only addon with no inference-time branch.
4. Lead results with R2 consistency, mapped Dice, surface Dice, R1 guardrail, and five-seed paired CIs.
5. Keep R4 as an honest stress test and use the residual failure to motivate future work.
6. Put the full prior-art table, per-seed results, hashes, and split audit in supplementary material.

## Reproducibility map

- Full result report: `report.md`
- Machine-readable aggregate: `results.json`
- All 3,600 metric rows: `metrics.csv`
- Evaluation ledger: `evaluation.json`
- Frozen final protocol: `protocol.json`
- Byte-identical snapshot of the pretraining protocol: `protocol_pretraining.json`
- Development screen: `dev_screen.json`
- Confirmatory split manifest: `confirm_manifest.json`
- Complete novelty audit: `novelty/final_report.md`
- Main runner: `../../run_paired_full.py`
- One-command reproduction: `../../reproduce_paired_full.sh`
- Execution/hash audit: `EXECUTION_AUDIT.md`

