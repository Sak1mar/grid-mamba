# Related-Work Map

## Use in the paper

- **Bortsova et al.**: transformation-aligned prediction consistency in medical segmentation; establishes that the basic consistency idea is not new.
- **Consispace**: semantic-aware volumetric resampling and arbitrary spacing; contrast a learned upstream resampler with our fixed resampling and training-exposure question.
- **CROWn**: anti-aliased downsampling and phase-calibrated fusion inside 3D segmentation; contrast architecture/operator changes with our unchanged backbone.
- **TIDES**: physical time intervals in selective state-space models; use only to explain why Physical-Step is neither retained nor claimed as novel.
- **MSD, 3D U-Net, Mamba, nnU-Net**: foundational dataset/backbone/preprocessing context.

## Do not cite as evidence for our results

The papers explain neighboring problems; all numerical claims about this study must cite files under `06_EVIDENCE/`. `novelty_audit_original.md` is a routing document and contains superseded mechanism language.

## Bibliography status

`references_verified.bib` contains records whose title/author/year or identifier can be checked from the included paper text or stable foundational records. Preprints remain marked as arXiv. Before submission, verify final venue, pages, DOI, and author spelling against publisher pages; do not guess missing fields.

