# Scoop Check — GridCons-Mamba

Timestamp: 2026-07-19T22:56:26+08:00

## 1. Verdict

**Level 2 — High Overlap.** CR-GLoCo, transformation-consistent medical segmentation, Mamba-Sea, S4ND, S³Mamba, and Consispace each cover large pieces of the proposal, so static delta, Mamba-plus-consistency, common-frame consistency, and resolution-aware SSMs cannot be claimed individually. No inspected paper combines all four axes: a single six-direction 3D medical Mamba, positive channel-wise token-independent delta with B/C still input-dependent, same-case R1/R2 physical alignment, and a stop-gradient consistency target that excludes R2 labels. The contribution is therefore a defensible combination-level controlled study, not a new primitive and not an exact scoop.

Safe claim before seeing confirmatory results: **“To our knowledge, this is the first controlled 3D medical-Mamba study that isolates token-wise delta adaptation as a variable in resampling-grid stability.”** Replace “studies/tests” with “shows” only if the frozen confirmatory experiment improves grid consistency without a material native-Dice loss.

## 2. Delta

> Unlike CR-GLoCo, which enforces cross-resolution pseudo-supervision between separate global and local 3D U-Nets to exchange anatomical context, GridCons-Mamba uses one six-direction 3D Mamba with a positive channel-wise delta shared across tokens and grids, then aligns a label-free R2 prediction to a stop-gradient R1 target, yielding a directly testable reduction in same-anatomy cross-grid disagreement at matched native-grid Dice.

## 3. Decomposed claim

- **Research problem:** A 3D Mamba segmenter can give different hippocampus masks when the same physical MRI anatomy is represented on different through-plane voxel grids, because the selective recurrence's token-dependent discretization and the token grid both change.
- **Problem framing:** Supervised 3D hippocampus segmentation on one labeled R1 grid; robustness is tested by rendering the same anatomy on R2/R4 grids and mapping predictions back to the shared physical R1 frame. Primary evidence is prediction-consistency Dice, guarded by native R1 Dice, mapped-label Dice, and surface Dice.
- **Core mechanism:** Keep Mamba's input-dependent B/C projections but replace token-dependent delta with one learned positive delta per channel, then add a training-only stop-gradient foreground soft-Dice term between R1 predictions and label-free R2 predictions aligned by physical endpoints. The weight warms linearly to 0.1 over 500 updates.
- **Key insight:** Content selectivity and numerical step size need not be tied. B/C can retain content-dependent routing while a channelwise delta removes a source of grid-dependent state decay; paired-grid consistency then teaches the same network to preserve the foreground under a deterministic change of discretization without using extra R2 labels.
- **Application domain:** Compact 3D Mamba-style medical image segmentation, evaluated on official MSD Task04 Hippocampus MRI with a newly frozen, disjoint 40-case confirmatory split.

Provisional novelty sentence: GridCons-Mamba is the combination of token-independent channelwise delta and label-free, physically aligned paired-grid consistency for 3D Mamba segmentation; neither generic static-delta ablation nor generic consistency training alone is claimed as new.

## 4. Structured papers

## Evidence policy and proposed-work axes

- The three raw CLI logs contain titles, years, venues, and URLs, but do not print abstracts. Every API-search record below is therefore explicitly labeled metadata/title-level triage; no title-only inference is presented as if an abstract or full paper had been read.
- Seven model-recall additions come from the verified summaries recorded in step2.md; three additional directly relevant/classic precedents were supplied in the Step 3 audit. All ten are labeled model-recall, with the evidence basis stated per record.
- Problem framing axis: same-case R1/R2 resampled-grid 3D medical image segmentation with aligned prediction stability.
- Core mechanism axis: learned channel-wise, token-independent static Delta inside the state-space/Mamba path, plus aligned R1/R2 prediction consistency.
- Key insight axis: removing token/grid dependence from Delta and aligning same-case predictions should reduce sensitivity to resampling resolution.
- Application-domain axis: 3D medical image segmentation.
- Overlap score is the number of these four axes that plausibly match at triage time. Partial or ambiguous matches count only when the available metadata gives a concrete reason; the score is a prioritization signal, not a verdict.

## Deduplicated API-search papers

### 1. API-search candidate

- Title: A residual dense vision transformer for medical image super-resolution with segmentation-based perceptual loss fine-tuning
- Date: 2023
- Problem framing: [metadata/title-level triage] Medical-image super-resolution with segmentation used as a perceptual objective, rather than same-case paired-grid segmentation.
- Core mechanism: [metadata/title-level triage] Residual dense vision transformer and perceptual fine-tuning; no Mamba, static Delta, or aligned prediction-consistency mechanism is stated.
- Key insight: [metadata/title-level triage] Segmentation supervision may preserve task-relevant detail during super-resolution; this is only adjacent to resolution robustness.
- Application domain: [metadata/title-level triage] Medical image super-resolution and segmentation-assisted reconstruction.
- Overlap score: 2/4 — resolution-related imaging and medical application are adjacent; problem setup and mechanism differ.
- Source: arXiv — http://arxiv.org/abs/2302.11184v2

### 2. API-search candidate

- Title: Adapting Visual State Space Model for Medical Image Segmentation: A Hybrid-Rank Approach
- Date: 2025
- Problem framing: [metadata/title-level triage] Medical image segmentation; dimensionality, supervision regime, and paired-resolution setup are not stated in the metadata.
- Core mechanism: [metadata/title-level triage] Hybrid-rank adaptation of a visual state-space model; Delta parameterization is not exposed by the title.
- Key insight: [metadata/title-level triage] Rank-structured adaptation is presented as the route to adapting the visual SSM, not explicit grid consistency.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 3/4 — segmentation, SSM mechanism, and domain plausibly overlap; the resolution-stability insight is not evidenced.
- Source: Semantic Scholar — https://www.semanticscholar.org/paper/4adeb7267c8f669573a629f5ee1f6c4cb0ccdd9b

### 3. API-search candidate

- Title: Attention Mechanisms in Medical Image Segmentation: A Survey
- Date: 2023
- Problem framing: [metadata/title-level triage] Survey of medical image segmentation rather than a paired-grid segmentation method.
- Core mechanism: [metadata/title-level triage] Attention mechanisms; no specific Mamba Delta or paired-resolution objective is stated.
- Key insight: [metadata/title-level triage] Taxonomic review of attention-based segmentation approaches.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 2/4 — broad task and domain match only.
- Source: arXiv — http://arxiv.org/abs/2305.17937v1

### 4. API-search candidate

- Title: Bi-Mamba+: Bidirectional Mamba for Time Series Forecasting
- Date: 2024
- Problem framing: [metadata/title-level triage] Time-series forecasting, not image segmentation or paired spatial grids.
- Core mechanism: [metadata/title-level triage] Bidirectional Mamba; no evidence of token-independent static Delta.
- Key insight: [metadata/title-level triage] Bidirectional sequence context for forecasting, not resolution consistency.
- Application domain: [metadata/title-level triage] Time-series forecasting.
- Overlap score: 1/4 — Mamba is the only plausible shared axis.
- Source: arXiv — http://arxiv.org/abs/2404.15772v3

### 5. API-search candidate

- Title: CR-GLoCo: Cross-Resolution Learning via Global-Local Context Consistency for semi-supervised 3D medical segmentation
- Date: 2026
- Problem framing: [metadata/title-level triage] Semi-supervised 3D medical segmentation with explicit cross-resolution learning; whether R1/R2 are same-case resamplings is not stated.
- Core mechanism: [metadata/title-level triage] Global-local context consistency across resolutions; no Mamba or static-Delta component is visible in the metadata.
- Key insight: [metadata/title-level triage] Cross-resolution global/local agreement should stabilize segmentation across scales.
- Application domain: [metadata/title-level triage] Semi-supervised 3D medical image segmentation.
- Overlap score: 4/4 — all four axes plausibly overlap, although the static-Delta half of the proposed mechanism is not evidenced.
- Source: Crossref — https://doi.org/10.1016/j.compmedimag.2026.102742

### 6. API-search candidate

- Title: Cross-dimensional transfer learning in medical image segmentation with deep learning
- Date: 2023
- Problem framing: [metadata/title-level triage] Medical segmentation with cross-dimensional transfer rather than explicit same-case resolution pairing.
- Core mechanism: [metadata/title-level triage] Cross-dimensional transfer learning; no Mamba or prediction-consistency mechanism is stated.
- Key insight: [metadata/title-level triage] Knowledge can transfer between dimensional representations; this is adjacent to grid robustness but not equivalent.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 3/4 — task/domain and a cross-representation stability idea plausibly overlap; mechanism differs.
- Source: arXiv — http://arxiv.org/abs/2307.15872v1

### 7. API-search candidate

- Title: Cross-pyramid consistency regularization for semi-supervised medical image segmentation
- Date: Unknown; the Crossref record printed no year
- Problem framing: [metadata/title-level triage] Semi-supervised medical segmentation using multiple pyramid levels; 3D and same-case R1/R2 construction are not stated.
- Core mechanism: [metadata/title-level triage] Cross-pyramid consistency regularization; no Mamba or static Delta is visible.
- Key insight: [metadata/title-level triage] Agreement between pyramid-scale predictions can regularize segmentation across scale.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 4/4 — all axes are plausibly related at title level, with exact grid alignment and Delta behavior unresolved.
- Source: Crossref/SSRN — https://doi.org/10.2139/ssrn.6020538

### 8. API-search candidate

- Title: CTS: A Consistency-Based Medical Image Segmentation Model
- Date: 2025
- Problem framing: [metadata/title-level triage] Medical image segmentation with an unspecified consistency setup.
- Core mechanism: [metadata/title-level triage] Consistency-based training; Mamba, static Delta, and paired-grid alignment are not stated.
- Key insight: [metadata/title-level triage] Prediction consistency is used to improve segmentation, but the source and coordinate system of the paired views are unknown.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 3/4 — task, consistency mechanism, and domain plausibly overlap; resolution-specific insight is unverified.
- Source: Crossref — https://doi.org/10.1109/icra55743.2025.11128236

### 9. API-search candidate

- Title: Deep Mamba Multi-modal Learning
- Date: 2024
- Problem framing: [metadata/title-level triage] Generic multimodal learning, not paired-resolution medical segmentation.
- Core mechanism: [metadata/title-level triage] Deep Mamba for multimodal fusion; Delta parameterization is unstated.
- Key insight: [metadata/title-level triage] Mamba-based multimodal learning rather than resolution invariance.
- Application domain: [metadata/title-level triage] Multimodal machine learning.
- Overlap score: 1/4 — only the use of Mamba plausibly overlaps.
- Source: arXiv — http://arxiv.org/abs/2406.18007v1

### 10. API-search candidate

- Title: Design and Research of Medical Image Segmentation Network Based on State-Space Model
- Date: 2025
- Problem framing: [metadata/title-level triage] Medical image segmentation; 3D, resampling, and supervision details are absent.
- Core mechanism: [metadata/title-level triage] State-space-model segmentation network; selective versus static Delta is unknown.
- Key insight: [metadata/title-level triage] SSMs are applied to segmentation, with no title-level evidence of resolution consistency.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 3/4 — task, SSM mechanism, and domain match broadly.
- Source: Semantic Scholar — https://www.semanticscholar.org/paper/1b9e090cc912b02378b15407738befb279d04862

### 11. API-search candidate

- Title: Differential Mamba
- Date: 2025
- Problem framing: [metadata/title-level triage] Generic sequence/modeling method; no medical segmentation framing is stated.
- Core mechanism: [metadata/title-level triage] A differential modification of Mamba, but the title does not establish whether it changes the selective Delta pathway.
- Key insight: [metadata/title-level triage] Differential processing is intended to improve Mamba behavior; exact relation to grid-independent dynamics is unknown.
- Application domain: [metadata/title-level triage] General sequence modeling.
- Overlap score: 2/4 — the Mamba mechanism and a possible dynamics-related insight warrant inspection; task and domain differ.
- Source: arXiv — http://arxiv.org/abs/2507.06204v2

### 12. API-search candidate

- Title: Exploring the Limitations of Mamba in COPY and CoT Reasoning
- Date: 2024
- Problem framing: [metadata/title-level triage] COPY and chain-of-thought reasoning diagnostics, not segmentation.
- Core mechanism: [metadata/title-level triage] Analysis of Mamba limitations rather than a static-Delta segmentation method.
- Key insight: [metadata/title-level triage] Characterizes reasoning and copying limitations; no resolution-stability claim is stated.
- Application domain: [metadata/title-level triage] Language/reasoning tasks.
- Overlap score: 1/4 — Mamba is the only shared axis.
- Source: arXiv — http://arxiv.org/abs/2410.03810v3

### 13. API-search candidate

- Title: Fréchet Radiomic Distance (FRD): A Versatile Metric for Comparing Medical Imaging Datasets
- Date: 2024
- Problem framing: [metadata/title-level triage] Comparison of medical imaging datasets rather than segmentation.
- Core mechanism: [metadata/title-level triage] A radiomic distance metric; no Mamba or consistency training.
- Key insight: [metadata/title-level triage] Radiomic distributions can quantify dataset difference, not paired-grid prediction alignment.
- Application domain: [metadata/title-level triage] Medical imaging dataset evaluation.
- Overlap score: 1/4 — medical imaging domain is the only plausible overlap.
- Source: arXiv — http://arxiv.org/abs/2412.01496v2

### 14. API-search candidate

- Title: GAN-GA: A Generative Model based on Genetic Algorithm for Medical Image Generation
- Date: 2023
- Problem framing: [metadata/title-level triage] Medical image generation, not segmentation.
- Core mechanism: [metadata/title-level triage] GAN plus genetic algorithm; no SSM or paired-grid consistency.
- Key insight: [metadata/title-level triage] Evolutionary optimization of a generative model.
- Application domain: [metadata/title-level triage] Medical image generation.
- Overlap score: 1/4 — only the broad medical-imaging domain is adjacent.
- Source: arXiv — http://arxiv.org/abs/2401.00314v1

### 15. API-search candidate

- Title: Geometrical Cross-Attention and Nonvoid Voxelization for Efficient 3D Medical Image Segmentation
- Date: 2026
- Problem framing: [metadata/title-level triage] Efficient 3D medical image segmentation, without an explicit paired-resolution regime.
- Core mechanism: [metadata/title-level triage] Geometrical cross-attention and nonvoid voxelization; no Mamba or aligned consistency objective is stated.
- Key insight: [metadata/title-level triage] Geometric voxel handling may preserve sparse spatial structure, adjacent to grid representation but not proven resolution consistency.
- Application domain: [metadata/title-level triage] 3D medical image segmentation.
- Overlap score: 3/4 — problem, voxel/grid insight, and domain plausibly overlap; mechanism differs.
- Source: arXiv — http://arxiv.org/abs/2604.05515v1

### 16. API-search candidate

- Title: H2M-UNet: Hierarchical Memory Mamba-Driven UNet Collaborative Optimization Based on Long-Range Forgetting Mitigation and Fine-Grained Feature Capture
- Date: 2026
- Problem framing: [metadata/title-level triage] Medical image segmentation inferred from venue/result context; resolution pairing is not stated.
- Core mechanism: [metadata/title-level triage] Hierarchical-memory Mamba UNet targeting long-range forgetting and fine-grained features; Delta behavior is unknown.
- Key insight: [metadata/title-level triage] Hierarchical memory mitigates forgetting while retaining detail, not explicit grid invariance.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 3/4 — segmentation, Mamba, and medical domain plausibly overlap.
- Source: Semantic Scholar — https://www.semanticscholar.org/paper/33caa113301cf2092e527bfe4ba3b3ac3786d699

### 17. API-search candidate

- Title: InceptionMamba: Efficient Multi-Stage Feature Enhancement with Selective State Space Model for Microscopic Medical Image Segmentation
- Date: 2025
- Problem framing: [metadata/title-level triage] Microscopic medical image segmentation with multi-stage processing, not explicitly paired R1/R2 grids.
- Core mechanism: [metadata/title-level triage] Selective SSM/Mamba feature enhancement; the title suggests standard selectivity rather than token-independent static Delta.
- Key insight: [metadata/title-level triage] Multi-stage enhancement gathers features at multiple processing stages, plausibly adjacent to scale robustness.
- Application domain: [metadata/title-level triage] Microscopic medical image segmentation.
- Overlap score: 4/4 — all axes are plausibly adjacent, but exact resolution consistency and Delta parameterization are unverified.
- Source: Semantic Scholar — https://www.semanticscholar.org/paper/2ac70247015308ee4b20404e9bea1eb0362ffafa

### 18. API-search candidate

- Title: Leveraging Labelled Data Knowledge: A Cooperative Rectification Learning Network for Semi-supervised 3D Medical Image Segmentation
- Date: 2025
- Problem framing: [metadata/title-level triage] Semi-supervised 3D medical segmentation, without explicit paired-resolution inputs.
- Core mechanism: [metadata/title-level triage] Cooperative rectification from labeled-data knowledge; no Mamba is stated, while prediction correction may be consistency-adjacent.
- Key insight: [metadata/title-level triage] Labeled knowledge rectifies semi-supervised predictions, which may improve stability but is not explicitly resolution-based.
- Application domain: [metadata/title-level triage] Semi-supervised 3D medical image segmentation.
- Overlap score: 4/4 — task/domain and a consistency-like mechanism/insight plausibly overlap.
- Source: arXiv — http://arxiv.org/abs/2502.11456v1

### 19. API-search candidate

- Title: M3D: Advancing 3D Medical Image Analysis with Multi-Modal Large Language Models
- Date: 2024
- Problem framing: [metadata/title-level triage] Broad 3D medical image analysis with multimodal LLMs, not a paired-grid segmentation method.
- Core mechanism: [metadata/title-level triage] Multimodal large language model; no Mamba/static Delta or prediction consistency.
- Key insight: [metadata/title-level triage] Language-vision multimodality for 3D medical analysis.
- Application domain: [metadata/title-level triage] 3D medical image analysis.
- Overlap score: 1/4 — only the broad 3D medical domain overlaps.
- Source: arXiv — http://arxiv.org/abs/2404.00578v1

### 20. API-search candidate

- Title: Mamba-based Segmentation Model for Speaker Diarization
- Date: 2024
- Problem framing: [metadata/title-level triage] Speaker diarization framed as sequence segmentation, not spatial medical segmentation.
- Core mechanism: [metadata/title-level triage] Mamba-based temporal segmentation; Delta parameterization is unstated.
- Key insight: [metadata/title-level triage] State-space sequence modeling for speaker boundaries.
- Application domain: [metadata/title-level triage] Speech and speaker diarization.
- Overlap score: 1/4 — Mamba is the only plausible shared axis.
- Source: arXiv — http://arxiv.org/abs/2410.06459v2

### 21. API-search candidate

- Title: Mamba-Sea: A Mamba-based Framework with Global-to-Local Sequence Augmentation for Generalizable Medical Image Segmentation
- Date: 2025
- Problem framing: [metadata/title-level triage] Generalizable medical image segmentation; 3D and same-case resolution pairs are not stated.
- Core mechanism: [metadata/title-level triage] Mamba with global-to-local sequence augmentation; static Delta and aligned R1/R2 consistency are not stated.
- Key insight: [metadata/title-level triage] Sequence augmentation across global/local views improves generalization, plausibly adjacent to resolution robustness.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 4/4 — task, Mamba, robustness insight, and domain plausibly overlap.
- Source: arXiv — http://arxiv.org/abs/2504.17515v1

### 22. API-search candidate

- Title: MambaMIM: Pre-training Mamba with State Space Token Interpolation and its Application to Medical Image Segmentation
- Date: 2024
- Problem framing: [metadata/title-level triage] Mamba pretraining followed by medical segmentation; paired R1/R2 prediction training is not stated.
- Core mechanism: [metadata/title-level triage] State-space token interpolation during Mamba pretraining; whether interpolation changes or bypasses selective Delta is unknown.
- Key insight: [metadata/title-level triage] Interpolating state-space tokens can support representation learning and is directly adjacent to token/grid changes.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 4/4 — all axes are plausibly related, with exact static Delta and aligned prediction consistency unresolved.
- Source: arXiv — http://arxiv.org/abs/2408.08070v2; duplicate Semantic Scholar record: https://www.semanticscholar.org/paper/26bec7ab1396ddb2323ed6f9a8f6640403f2d3b7

### 23. API-search candidate

- Title: MCC-Net: Mamba based Consistency Constraints Network for Semi-Supervised 3D Medical Image Segmentation
- Date: 2025
- Problem framing: [metadata/title-level triage] Semi-supervised 3D medical segmentation; whether its consistency views are same-case R1/R2 grids is unknown.
- Core mechanism: [metadata/title-level triage] Mamba plus consistency constraints; neither static channel-wise Delta nor coordinate-aligned resampling is visible in the metadata.
- Key insight: [metadata/title-level triage] Consistency can regularize Mamba predictions under limited labels; the type of perturbation remains unknown.
- Application domain: [metadata/title-level triage] Semi-supervised 3D medical image segmentation.
- Overlap score: 4/4 — all four axes plausibly overlap and require full-paper verification.
- Source: Crossref — https://doi.org/10.1109/ijcnn64981.2025.11228815

### 24. API-search candidate

- Title: Medical Image Segmentation based on Deep Active Contour and Mean Curvature Loss Function
- Date: 2026
- Problem framing: [metadata/title-level triage] Medical image segmentation without a paired-resolution setup.
- Core mechanism: [metadata/title-level triage] Deep active contour with mean-curvature loss; no Mamba or cross-grid consistency.
- Key insight: [metadata/title-level triage] Curvature regularization improves contour geometry rather than resolution invariance.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 2/4 — segmentation problem and medical domain match.
- Source: arXiv — http://arxiv.org/abs/2607.12586v1

### 25. API-search candidate

- Title: MiM-ISTD: Mamba-in-Mamba for Efficient Infrared Small Target Detection
- Date: 2024
- Problem framing: [metadata/title-level triage] Infrared small-target detection, not medical segmentation.
- Core mechanism: [metadata/title-level triage] Nested Mamba architecture; static Delta is not stated.
- Key insight: [metadata/title-level triage] Mamba-in-Mamba improves efficient small-target modeling, not paired-grid consistency.
- Application domain: [metadata/title-level triage] Infrared target detection.
- Overlap score: 1/4 — Mamba is the only plausible overlap.
- Source: arXiv — http://arxiv.org/abs/2403.02148v4

### 26. API-search candidate

- Title: Monte Carlo Simulation of Angular Response of GRID Detectors for GRID Mission
- Date: 2024
- Problem framing: [metadata/title-level triage] Detector simulation for an astronomy mission; GRID is an acronym unrelated to voxel grids.
- Core mechanism: [metadata/title-level triage] Monte Carlo detector-response simulation.
- Key insight: [metadata/title-level triage] Models angular response of physical detectors.
- Application domain: [metadata/title-level triage] High-energy/space instrumentation.
- Overlap score: 0/4 — keyword collision only.
- Source: arXiv — http://arxiv.org/abs/2410.13402v1

### 27. API-search candidate

- Title: MS-DS3net: Research on a Multi-Scale Medical Image Segmentation Model Based on State Space Models
- Date: 2025
- Problem framing: [metadata/title-level triage] Multi-scale medical image segmentation; 3D and paired-resampling details are not stated.
- Core mechanism: [metadata/title-level triage] Multi-scale state-space segmentation model; selective/static Delta behavior is unknown.
- Key insight: [metadata/title-level triage] Multi-scale SSM features improve segmentation across scale, adjacent to resolution stability.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 4/4 — all axes plausibly overlap at title level.
- Source: Semantic Scholar — https://www.semanticscholar.org/paper/14acc1bb3ef63910e7805f42f07a0fdf7667c9fb

### 28. API-search candidate

- Title: Mtcl: Multi-Task Consistency Learning for Semi-Supervised 3D Medical Image Segmentation
- Date: Unknown; the Crossref record printed no year
- Problem framing: [metadata/title-level triage] Semi-supervised 3D medical segmentation, without explicit R1/R2 inputs.
- Core mechanism: [metadata/title-level triage] Multi-task consistency learning; no Mamba/static Delta is stated.
- Key insight: [metadata/title-level triage] Agreement across auxiliary tasks regularizes segmentation, rather than explicitly across resampling grids.
- Application domain: [metadata/title-level triage] Semi-supervised 3D medical image segmentation.
- Overlap score: 4/4 — all axes are plausibly related through task/domain and consistency, although the exact mechanism differs or is unknown.
- Source: Crossref/SSRN — https://doi.org/10.2139/ssrn.5332983

### 29. API-search candidate

- Title: Multi-Faceted Consistency learning with active cross-labeling for barely-supervised 3D medical image segmentation
- Date: 2025
- Problem framing: [metadata/title-level triage] Barely supervised 3D medical segmentation, without explicit paired-resolution inputs.
- Core mechanism: [metadata/title-level triage] Multiple consistency signals with active cross-labeling; no Mamba/static Delta is stated.
- Key insight: [metadata/title-level triage] Cross-label exchange and consistency exploit scarce annotations; whether views differ by grid resolution is unknown.
- Application domain: [metadata/title-level triage] Barely supervised 3D medical image segmentation.
- Overlap score: 4/4 — task/domain and a consistency mechanism/insight plausibly overlap.
- Source: Crossref — https://doi.org/10.1016/j.media.2025.103744

### 30. API-search candidate

- Title: Multi-Scale Consistency Adversarial Learning for Semi-Supervised 3D Medical Image Segmentation
- Date: Unknown; the Crossref record printed no year
- Problem framing: [metadata/title-level triage] Semi-supervised 3D medical segmentation with multiple scales; same-case R1/R2 resampling is not established.
- Core mechanism: [metadata/title-level triage] Multi-scale consistency plus adversarial learning; no Mamba/static Delta is stated.
- Key insight: [metadata/title-level triage] Agreement across scales, reinforced adversarially, can regularize predictions.
- Application domain: [metadata/title-level triage] Semi-supervised 3D medical image segmentation.
- Overlap score: 4/4 — all axes plausibly overlap except that the exact static-Delta component is absent from the metadata.
- Source: Crossref/SSRN — https://doi.org/10.2139/ssrn.4844506

### 31. API-search candidate

- Title: Online learning for robust voltage control under uncertain grid topology
- Date: 2023
- Problem framing: [metadata/title-level triage] Electrical-grid voltage control, not voxel-grid segmentation.
- Core mechanism: [metadata/title-level triage] Online robust control.
- Key insight: [metadata/title-level triage] Handles uncertainty in power-grid topology.
- Application domain: [metadata/title-level triage] Power systems.
- Overlap score: 0/4 — GRID is a keyword collision.
- Source: arXiv — http://arxiv.org/abs/2306.16674v4

### 32. API-search candidate

- Title: PVCL: A semi-supervised 3D medical image segmentation method based on prototype-voxel contrastive learning
- Date: Unknown; the Crossref record printed no year
- Problem framing: [metadata/title-level triage] Semi-supervised 3D medical segmentation.
- Core mechanism: [metadata/title-level triage] Prototype-voxel contrastive learning; no Mamba or aligned paired-grid consistency is stated.
- Key insight: [metadata/title-level triage] Prototype-to-voxel contrast can structure unlabeled representations; voxel-level reasoning is adjacent to grid alignment.
- Application domain: [metadata/title-level triage] Semi-supervised 3D medical image segmentation.
- Overlap score: 3/4 — problem, voxel/grid-related insight, and domain plausibly overlap; mechanism differs.
- Source: Crossref/SSRN — https://doi.org/10.2139/ssrn.6463645

### 33. API-search candidate

- Title: ResMamba-ULite: A lightweight model for medical image segmentation with residual visual state space and multiple attention
- Date: 2025
- Problem framing: [metadata/title-level triage] Lightweight medical image segmentation; 3D/resampling regime is unstated.
- Core mechanism: [metadata/title-level triage] Residual visual SSM/Mamba plus multiple attention modules; Delta parameterization is unknown.
- Key insight: [metadata/title-level triage] Residual state-space and attention paths preserve accuracy under lightweight computation, not explicit resolution consistency.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 3/4 — segmentation, Mamba/SSM, and medical domain plausibly overlap.
- Source: Semantic Scholar — https://www.semanticscholar.org/paper/de0ddf351dc27ead6f0381926f299a6546f473f7

### 34. API-search candidate

- Title: SCFMUNet: A fusion architecture based on multi-scale state space model and channel attention for medical image segmentation
- Date: 2025
- Problem framing: [metadata/title-level triage] Multi-scale medical image segmentation; explicit same-case R1/R2 resampling is not stated.
- Core mechanism: [metadata/title-level triage] Multi-scale SSM fused with channel attention; this is adjacent to channel-wise state dynamics, but static Delta is not evidenced.
- Key insight: [metadata/title-level triage] Multi-scale state-space features and channel selection improve fusion across spatial scales.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 4/4 — all axes are plausibly adjacent and warrant follow-up.
- Source: Semantic Scholar — https://www.semanticscholar.org/paper/2b43c1a74b221908e026be872814fca10474293c

### 35. API-search candidate

- Title: Segment Anything Model for Medical Image Analysis: an Experimental Study
- Date: 2023
- Problem framing: [metadata/title-level triage] Experimental evaluation of SAM in medical image analysis/segmentation, not a paired-grid training method.
- Core mechanism: [metadata/title-level triage] Segment Anything Model evaluation; no Mamba/static Delta or consistency mechanism.
- Key insight: [metadata/title-level triage] Tests general-purpose promptable segmentation on medical images.
- Application domain: [metadata/title-level triage] Medical image analysis and segmentation.
- Overlap score: 2/4 — segmentation task and medical domain overlap.
- Source: arXiv — http://arxiv.org/abs/2304.10517v3

### 36. API-search candidate

- Title: Semi-Mamba-UNet: Pixel-level contrastive and cross-supervised visual Mamba-based UNet for semi-supervised medical image segmentation
- Date: 2024
- Problem framing: [metadata/title-level triage] Semi-supervised medical segmentation; 3D and R1/R2 resampling are not stated.
- Core mechanism: [metadata/title-level triage] Visual Mamba UNet with pixel-level contrastive and cross-supervised learning; exact Delta and view construction are unknown.
- Key insight: [metadata/title-level triage] Pixel contrast and cross-supervision align predictions/representations across branches or views.
- Application domain: [metadata/title-level triage] Semi-supervised medical image segmentation.
- Overlap score: 4/4 — all axes plausibly overlap, although resolution-specific pairing is unverified.
- Source: Crossref — https://doi.org/10.1016/j.knosys.2024.112203

### 37. API-search candidate

- Title: Test-time generative augmentation for medical image segmentation
- Date: 2024
- Problem framing: [metadata/title-level triage] Medical segmentation under test-time augmentation rather than paired-grid training.
- Core mechanism: [metadata/title-level triage] Generative test-time augmentation; no Mamba/static Delta.
- Key insight: [metadata/title-level triage] Multiple generated test views may stabilize predictions, adjacent to view consistency but not explicitly resolution-aligned.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 3/4 — segmentation, robustness insight, and medical domain plausibly overlap.
- Source: arXiv — http://arxiv.org/abs/2406.17608v2

### 38. API-search candidate

- Title: Triple collaborative consistency with Mamba for semi-supervised 3D medical image segmentation
- Date: 2026
- Problem framing: [metadata/title-level triage] Semi-supervised 3D medical segmentation; the three consistency views are not identified in the metadata.
- Core mechanism: [metadata/title-level triage] Mamba with triple collaborative consistency; static Delta and same-case grid alignment remain unknown.
- Key insight: [metadata/title-level triage] Multiple cooperating consistency signals improve semi-supervised Mamba segmentation.
- Application domain: [metadata/title-level triage] Semi-supervised 3D medical image segmentation.
- Overlap score: 4/4 — all four axes plausibly overlap and require full-paper verification.
- Source: Crossref — https://doi.org/10.1002/mp.70390

### 39. API-search candidate

- Title: Triple Consistency-based Self-ensembling Model for Unsupervised Domain Adaption in Medical Image Segmentation
- Date: 2023
- Problem framing: [metadata/title-level triage] Unsupervised domain adaptation for medical segmentation, not explicitly resolution adaptation.
- Core mechanism: [metadata/title-level triage] Triple-consistency self-ensembling; no Mamba/static Delta is stated.
- Key insight: [metadata/title-level triage] Multiple consistency signals stabilize domain-adapted predictions.
- Application domain: [metadata/title-level triage] Medical image segmentation under domain shift.
- Overlap score: 4/4 — segmentation, consistency, robustness insight, and medical domain plausibly overlap, while the shift type differs.
- Source: Crossref — https://doi.org/10.1109/ijcnn54540.2023.10192037

### 40. API-search candidate

- Title: UNETR++ with Voxel-Focused Attention: Efficient 3D Medical Image Segmentation with Linear-Complexity Transformers
- Date: 2025
- Problem framing: [metadata/title-level triage] Efficient 3D medical image segmentation, without a paired-resolution regime.
- Core mechanism: [metadata/title-level triage] Voxel-focused attention in a linear-complexity transformer; no Mamba/static Delta or consistency objective.
- Key insight: [metadata/title-level triage] Focusing attention on voxels improves efficient volumetric modeling, adjacent to grid representation but not resolution invariance.
- Application domain: [metadata/title-level triage] 3D medical image segmentation.
- Overlap score: 3/4 — problem, voxel/grid insight, and domain plausibly overlap; mechanism differs.
- Source: Crossref — https://doi.org/10.3390/app152011034

### 41. API-search candidate

- Title: Unified Cross-Task and Cross-Model Consistency for Boundary-Aware Semi-Supervised Medical Image Segmentation
- Date: Unknown; the Crossref record printed no year
- Problem framing: [metadata/title-level triage] Boundary-aware semi-supervised medical segmentation; 3D and paired resolution are unstated.
- Core mechanism: [metadata/title-level triage] Cross-task and cross-model consistency; no Mamba/static Delta is stated.
- Key insight: [metadata/title-level triage] Agreement across tasks/models improves boundary-aware predictions.
- Application domain: [metadata/title-level triage] Semi-supervised medical image segmentation.
- Overlap score: 4/4 — task/domain and a consistency mechanism/robustness insight plausibly overlap.
- Source: Crossref/SSRN — https://doi.org/10.2139/ssrn.4495469

### 42. API-search candidate

- Title: Vision Mamba: A Comprehensive Survey and Taxonomy
- Date: 2024
- Problem framing: [metadata/title-level triage] Survey/taxonomy of visual Mamba rather than a medical segmentation method.
- Core mechanism: [metadata/title-level triage] Reviews visual Mamba mechanisms but contributes no title-level static-Delta method.
- Key insight: [metadata/title-level triage] Organizes visual state-space designs and may index relevant mechanism papers.
- Application domain: [metadata/title-level triage] General computer vision.
- Overlap score: 1/4 — Mamba mechanism background is the only direct overlap.
- Source: arXiv — http://arxiv.org/abs/2405.04404v1

### 43. API-search candidate

- Title: VMS2-UNet: A Lightweight Non-Causal Vision Mamba2 Model with State Space Duality for Medical Image Segmentation
- Date: 2025
- Problem framing: [metadata/title-level triage] Lightweight medical segmentation; 3D and paired-grid training are not stated.
- Core mechanism: [metadata/title-level triage] Non-causal Vision Mamba2 with state-space duality; Delta/static parameterization is not exposed.
- Key insight: [metadata/title-level triage] Non-causal SSD/Mamba2 can support efficient bidirectional visual context, not explicit resolution stability.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 3/4 — segmentation, Mamba2/SSM, and medical domain plausibly overlap.
- Source: Crossref — https://doi.org/10.1109/ijcnn64981.2025.11229229; duplicate Semantic Scholar record: https://www.semanticscholar.org/paper/3e8749fa93d79db702129f88201a05229d0d8d7a

### 44. API-search candidate

- Title: WaveSeq: Frequency-Aware Fusion with Sequential State-Space Consistency for Polyp Segmentation
- Date: 2026
- Problem framing: [metadata/title-level triage] Polyp segmentation with frequency-aware processing; likely 2D and not explicitly paired R1/R2 grids.
- Core mechanism: [metadata/title-level triage] Frequency-aware fusion plus sequential state-space consistency; whether consistency is internal-state or cross-prediction is unknown.
- Key insight: [metadata/title-level triage] Frequency and sequential state consistency may improve scale/detail robustness.
- Application domain: [metadata/title-level triage] Medical polyp segmentation.
- Overlap score: 4/4 — all axes plausibly overlap at a broad level despite likely dimensionality and mechanism differences.
- Source: Crossref — https://doi.org/10.1109/ispp69262.2026.11543101

### 45. API-search candidate

- Title: Weakly-Supervised 3D Medical Image Segmentation using Geometric Prior and Contrastive Similarity
- Date: 2023
- Problem framing: [metadata/title-level triage] Weakly supervised 3D medical segmentation.
- Core mechanism: [metadata/title-level triage] Geometric prior and contrastive similarity; no Mamba/static Delta or explicit paired-grid consistency.
- Key insight: [metadata/title-level triage] Geometry and contrastive agreement compensate for weak labels, adjacent to spatial alignment.
- Application domain: [metadata/title-level triage] Weakly supervised 3D medical image segmentation.
- Overlap score: 3/4 — problem, geometric/alignment insight, and domain plausibly overlap.
- Source: arXiv — http://arxiv.org/abs/2302.02125v1

### 46. API-search candidate

- Title: YMamba: A Dual-Branch Network Fusing State Space Model and CNN for Medical Image Segmentation
- Date: 2024
- Problem framing: [metadata/title-level triage] Medical image segmentation; 3D and resolution pairing are unstated.
- Core mechanism: [metadata/title-level triage] Dual-branch SSM/Mamba and CNN fusion; Delta behavior and consistency objective are unknown.
- Key insight: [metadata/title-level triage] Complementary state-space and local CNN features improve segmentation.
- Application domain: [metadata/title-level triage] Medical image segmentation.
- Overlap score: 3/4 — segmentation, Mamba/SSM, and domain plausibly overlap.
- Source: Semantic Scholar — https://www.semanticscholar.org/paper/e31305553cc6659f333151b0f6efc2bdc9a865c2

## Verified model-recall additions

### 47. Model-recall candidate

- Title: S4ND: Modeling Images and Videos as Multidimensional Signals Using State Spaces
- Date: 2022-10
- Problem framing: [verified model-recall summary] Multidimensional image/video signal modeling with evaluation of resolution generalization, not medical segmentation.
- Core mechanism: [verified model-recall summary] Continuous multidimensional state-space layers with scale-aware discretization; not Mamba and not paired-prediction consistency.
- Key insight: [verified model-recall summary] Continuous SSM parameterization and discretization can generalize across sampling resolutions.
- Application domain: [verified model-recall summary] General images and videos.
- Overlap score: 2/4 — state-space discretization and the resolution-generalization insight overlap; task and medical domain differ.
- Source: model-recall, verified arXiv — https://arxiv.org/abs/2210.06583

### 48. Model-recall candidate

- Title: S³Mamba: Arbitrary-Scale Super-Resolution via Scaleable State Space Model
- Date: 2024-11
- Problem framing: [verified model-recall summary] Arbitrary-scale image super-resolution, not segmentation.
- Core mechanism: [verified model-recall summary] Scale-conditioned state-space/Mamba discretization for arbitrary output scales; unlike the proposed token-independent static Delta, scale is an explicit condition.
- Key insight: [verified model-recall summary] Conditioning SSM dynamics on requested scale supports arbitrary-scale reconstruction.
- Application domain: [verified model-recall summary] Natural-image super-resolution.
- Overlap score: 2/4 — state-space discretization and resolution handling overlap; problem and domain differ.
- Source: model-recall, verified arXiv — https://arxiv.org/abs/2411.11906

### 49. Model-recall candidate

- Title: HyperSpace: Hypernetworks for spacing-adaptive image segmentation
- Date: 2024-07
- Problem framing: [verified model-recall summary] Medical image segmentation that adapts to voxel spacing, directly adjacent to multi-resolution/spacing robustness.
- Core mechanism: [verified model-recall summary] A hypernetwork conditions segmentation behavior on voxel spacing; no Mamba/static Delta or paired-grid consistency.
- Key insight: [verified model-recall summary] Explicit spacing conditioning lets one segmenter adapt across acquisition grids.
- Application domain: [verified model-recall summary] Medical image segmentation.
- Overlap score: 3/4 — problem, resolution/spacing insight, and domain overlap; core mechanism differs.
- Source: model-recall, verified MICCAI/arXiv — https://arxiv.org/abs/2407.03681

### 50. Model-recall candidate

- Title: Towards Voxel Spacing Consistency for Medical Image Segmentation
- Date: 2026-06
- Problem framing: [verified model-recall summary] Medical segmentation under voxel-spacing changes, directly targeting spacing consistency.
- Core mechanism: [verified model-recall summary] Learned INR/ODE resampling and spacing harmonization rather than Mamba static Delta plus aligned prediction consistency.
- Key insight: [verified model-recall summary] Harmonizing representations/images through a learned continuous resampler can reduce voxel-spacing inconsistency.
- Application domain: [verified model-recall summary] Medical image segmentation.
- Overlap score: 3/4 — problem, resolution-consistency insight, and domain overlap; mechanism differs.
- Source: model-recall, verified arXiv — https://arxiv.org/abs/2606.31839

### 51. Model-recall candidate

- Title: Demystify Mamba in Vision: A Linear Attention Perspective
- Date: 2024-05
- Problem framing: [verified model-recall summary] Theoretical/mechanistic analysis of Mamba in vision, not medical segmentation.
- Core mechanism: [verified model-recall summary] Interprets Mamba as linear attention and input-dependent Delta as input/forget gating, directly informing what is removed by a token-independent static Delta.
- Key insight: [verified model-recall summary] Mamba selectivity can be understood through data-dependent gating; this is mechanistically relevant to the proposed static alternative.
- Application domain: [verified model-recall summary] General computer vision and Mamba analysis.
- Overlap score: 2/4 — core mechanism and key insight overlap; problem and medical domain differ.
- Source: model-recall, verified NeurIPS/arXiv — https://arxiv.org/abs/2405.16605

### 52. Model-recall candidate

- Title: UD-Mamba: A pixel-level uncertainty-driven Mamba model for medical image segmentation
- Date: 2025-02
- Problem framing: [verified model-recall summary] Medical image segmentation with uncertainty-aware training; dimensionality and R1/R2 resampling are not established by the Step 2 summary.
- Core mechanism: [verified model-recall summary] Mamba segmentation with an internal scan-consistency loss driven by pixel-level uncertainty; static channel-wise Delta is not reported in the available summary.
- Key insight: [verified model-recall summary] Uncertainty-guided agreement across scans can regularize Mamba predictions.
- Application domain: [verified model-recall summary] Medical image segmentation.
- Overlap score: 4/4 — task, Mamba-plus-consistency mechanism, stability insight, and domain plausibly overlap.
- Source: model-recall, verified arXiv — https://arxiv.org/abs/2502.02024

### 53. Model-recall candidate

- Title: A Comprehensive Analysis of Mamba for 3D Volumetric Medical Image Segmentation
- Date: 2025-03
- Problem framing: [verified model-recall summary] Direct study of Mamba for 3D volumetric medical segmentation.
- Core mechanism: [verified model-recall summary] Compares/analyzes Mamba axial scan designs; the available summary does not report token-independent static Delta or paired-grid consistency.
- Key insight: [verified model-recall summary] Scan direction/design materially affects volumetric Mamba behavior, potentially informing resolution sensitivity.
- Application domain: [verified model-recall summary] 3D volumetric medical image segmentation.
- Overlap score: 4/4 — problem, Mamba mechanism, scan/grid insight, and domain plausibly overlap.
- Source: model-recall, verified arXiv — https://arxiv.org/abs/2503.19308

### 54. Model-recall candidate

- Title: Mamba: Linear-Time Sequence Modeling with Selective State Spaces
- Date: 2023-12
- Problem framing: [model-recall, canonical paper] General sequence modeling with content-dependent state-space dynamics, not image segmentation.
- Core mechanism: [model-recall, canonical paper] Introduces selective state-space models in which input-dependent parameters include Delta; this is the direct mechanism that the proposed token-independent static Delta alters.
- Key insight: [model-recall, canonical paper] Data-dependent selectivity lets the recurrent state retain or discard information according to the current token while preserving linear sequence complexity.
- Application domain: [model-recall, canonical paper] General sequence modeling, with language and other sequence modalities rather than 3D medical segmentation.
- Overlap score: 2/4 — core mechanism and the selectivity/gating insight directly overlap; problem and application domain differ.
- Source: model-recall, canonical arXiv — https://arxiv.org/abs/2312.00752

### 55. Model-recall candidate

- Title: BiSegMamba: shared six-direction 3D Mamba
- Date: 2026-05
- Problem framing: [model-recall, supplied direct precedent] 3D segmentation with a Mamba architecture; paired R1/R2 resampling is not stated in the supplied evidence.
- Core mechanism: [model-recall, supplied direct precedent] Shared six-direction 3D Mamba scanning; static channel-wise Delta and aligned prediction consistency are not reported in the supplied description.
- Key insight: [model-recall, supplied direct precedent] Sharing information across six volumetric scan directions is intended to improve 3D spatial modeling and reduce directional bias.
- Application domain: [model-recall, supplied direct precedent] 3D segmentation, treated as directly relevant to volumetric medical segmentation pending full-paper verification.
- Overlap score: 4/4 — 3D segmentation, Mamba mechanism, scan/grid insight, and volumetric application plausibly overlap.
- Source: model-recall, arXiv — https://arxiv.org/abs/2605.30972

### 56. Model-recall candidate

- Title: Semi-supervised Medical Image Segmentation via Learning Consistency under Transformations
- Date: 2019-11; retained outside the 2023–2026 search window as a classic direct consistency precedent
- Problem framing: [model-recall, classic precedent] Semi-supervised medical image segmentation using paired transformed views of the same image.
- Core mechanism: [model-recall, classic precedent] Enforces prediction consistency/equivariance after geometrically aligning outputs under transformations; it does not use Mamba or static Delta.
- Key insight: [model-recall, classic precedent] A segmentation model should produce correspondingly transformed predictions when the input is transformed, enabling unlabeled same-case views to provide supervision.
- Application domain: [model-recall, classic precedent] Medical image segmentation.
- Overlap score: 4/4 — same-case aligned consistency, the transformation-stability insight, and medical segmentation strongly overlap; the Mamba/static-Delta half differs.
- Source: model-recall, Bortsova et al., arXiv — https://arxiv.org/abs/1911.01218

## Excluded non-paper Crossref metadata

The following three normalized raw-result titles are retained for auditability but excluded from the 56-paper triage set because the returned URLs identify peer-review or decision artifacts rather than papers.

### Excluded artifact 1

- Title: Review for "Dual-Branch Network for Spatial-Channel Stream Modeling Based on the State-Space Model for Remote Sensing Image Segmentation"
- Date: 2024/2025 across returned review versions
- Source: Crossref review artifact — https://doi.org/10.1109/tgrs.2025.3544736/v1/review1
- Exclusion reason: Peer-review metadata, not the canonical paper record. The underlying paper title should be resolved separately before any overlap analysis.

### Excluded artifact 2

- Title: Review for "Dynamic Token Augmentation Mamba for Cross-Scene Classification of Hyperspectral Image"
- Date: 2024
- Source: Crossref review artifact — https://doi.org/10.1109/tgrs.2024.3506749/v1/review1
- Exclusion reason: Peer-review metadata, not the canonical paper record. The underlying paper may be mechanism-relevant but is not represented by this review object.

### Excluded artifact 3

- Title: Decision letter for "Dynamic Token Augmentation Mamba for Cross-Scene Classification of Hyperspectral Image"
- Date: 2024
- Source: Crossref decision artifact — https://doi.org/10.1109/tgrs.2024.3506749/v1/decision1
- Exclusion reason: Editorial decision metadata for the same underlying work as artifact 2, not an independent paper.

## 5. Comparison result

Partial matches are conservatively counted when a reviewer could reasonably describe the axis with the same broad phrase. This makes the level a worst-case overlap audit, not a claim that the technical implementations are identical.

- **Proposed work**
  - Title: GridCons-Mamba (working title)
  - Date: 2026-07
  - Source: local frozen protocol and implementation
  - Problem framing: One 3D hippocampus segmenter is evaluated on the same physical anatomy rendered at R1/R2/R4 grids; predictions are mapped to R1 and compared at matched ordinary Dice.
  - Core mechanism: Replace token-dependent delta with one learned positive value per channel while retaining input-dependent B/C, then train with stop-gradient R1-to-aligned-R2 foreground prediction consistency without R2 labels.
  - Key insight: Content selection and the recurrence timescale can be decoupled; a shared timescale plus paired-grid supervision may reduce lattice-dependent forgetting without sacrificing native-grid segmentation.
  - Application domain: Compact six-direction 3D Mamba medical image segmentation.

- **Prior work A**
  - Title: CR-GLoCo: Cross-Resolution Learning via Global-Local Context Consistency for semi-supervised 3D medical segmentation
  - Date: 2026-03
  - Source: https://doi.org/10.1016/j.compmedimag.2026.102742
  - Problem framing: Cross-resolution semi-supervised 3D segmentation, using resolution to couple global and local fields of view.
  - Core mechanism: Separate low-resolution global and high-resolution local 3D U-Nets exchange confidence-filtered pseudo-labels over an overlapping FOV.
  - Key insight: Global anatomy and local boundaries are complementary under scarce labels, rather than token-wise delta causing physical-grid instability.
  - Application domain: 3D medical image segmentation.
  - Axes matching: 3/4 (problem, aligned cross-resolution mechanism in part, domain).
  - Level: **Level 2 — High Overlap** (*one axis differs*).

- **Prior work B**
  - Title: Semi-Supervised Medical Image Segmentation via Learning Consistency under Transformations
  - Date: 2019-11
  - Source: https://arxiv.org/abs/1911.01218
  - Problem framing: Same medical image under two spatial transformations with predictions compared in a common frame.
  - Core mechanism: Shared-weight branches plus differentiable output alignment and consistency loss; no Mamba or delta intervention.
  - Key insight: Equivariance under known transforms yields an unlabeled learning signal, rather than diagnosing recurrence-timescale sensitivity.
  - Application domain: Medical image segmentation (2D chest radiographs).
  - Axes matching: 3/4 (same-case transformed-view framing, aligned prediction mechanism in part, domain).
  - Level: **Level 2 — High Overlap** (*one axis differs*).

- **Prior work C**
  - Title: Mamba-Sea: A Mamba-based Framework with Global-to-Local Sequence Augmentation for Generalizable Medical Image Segmentation
  - Date: 2025-04
  - Source: https://arxiv.org/abs/2504.17515
  - Problem framing: Robust medical segmentation when appearance/style changes across acquisition domains.
  - Core mechanism: VM-UNet with global and local style perturbations plus MSE prediction consistency between original and augmented images; both views are label-supervised.
  - Key insight: Appearance consistency prevents domain-specific information from accumulating in Mamba's input-dependent matrices, not that delta should be static across sampling grids.
  - Application domain: Medical image segmentation, primarily 2D images/slices.
  - Axes matching: 3/4 (robust paired-view framing in part, Mamba-plus-consistency mechanism in part, domain).
  - Level: **Level 2 — High Overlap** (*one axis differs*).

- **Prior work D**
  - Title: Mamba: Linear-Time Sequence Modeling with Selective State Spaces
  - Date: 2023-12
  - Source: https://arxiv.org/abs/2312.00752
  - Problem framing: General content-selective sequence modelling.
  - Core mechanism: Input-dependent delta/B/C selective recurrence, with static/selective ablations.
  - Key insight: Delta-driven admission/forgetting is the most important part of selectivity while B/C contribute synergistically.
  - Application domain: General sequence modelling, not medical segmentation.
  - Axes matching: 2/4 (core intervention target and delta/selectivity insight).
  - Level: **Level 3 — Medium Overlap** (*two axes differ*).

- **Prior work E**
  - Title: S4ND: Modeling Images and Videos as Multidimensional Signals Using State Spaces
  - Date: 2022-10
  - Source: https://arxiv.org/abs/2210.06583
  - Problem framing: Image/video recognition across changed sampling resolutions.
  - Core mechanism: Learned token-independent LTI-S4 steps and continuous kernels; delta is externally rescaled with resolution and kernels are bandlimited.
  - Key insight: State-space discretization must respect the sampling lattice for resolution transfer.
  - Application domain: Natural image/video classification.
  - Axes matching: 3/4 (resolution framing, static/scale-related state step, sampling-geometry insight).
  - Level: **Level 2 — High Overlap** (*one axis differs*).

- **Prior work F**
  - Title: S³Mamba: Arbitrary-Scale Super-Resolution via Scaleable State Space Model
  - Date: 2024-11
  - Source: https://arxiv.org/abs/2411.11906
  - Problem framing: The same natural scene reconstructed at arbitrary scales.
  - Core mechanism: Scale/coordinate factors modulate token-dependent delta and B; the step is not shared across views.
  - Key insight: Pixel distance changes with scale and should enter Mamba discretization.
  - Application domain: Natural-image super-resolution.
  - Axes matching: 3/4 (cross-scale framing, delta intervention, sampling-geometry insight).
  - Level: **Level 2 — High Overlap** (*one axis differs*).

- **Prior work G**
  - Title: Towards Voxel Spacing Consistency for Medical Image Segmentation
  - Date: 2026-06
  - Source: https://arxiv.org/abs/2606.31839
  - Problem framing: 3D medical segmentation under heterogeneous voxel spacing.
  - Core mechanism: An INR/ODE resampling preprocessor harmonizes spacing before supervised segmentation.
  - Key insight: Preserving semantic information while normalizing spacing improves downstream consistency.
  - Application domain: 3D medical image segmentation.
  - Axes matching: 3/4 (problem, spacing-consistency insight, domain).
  - Level: **Level 2 — High Overlap** (*one axis differs*).

Worst-case minimum level: **Level 2 — High Overlap**. No paper matches all four axes, so no exact/full scoop was found.

