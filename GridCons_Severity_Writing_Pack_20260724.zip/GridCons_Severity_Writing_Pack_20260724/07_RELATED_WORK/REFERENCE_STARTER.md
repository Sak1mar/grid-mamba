# Reference starter and usage notes

This is a routing list, not a finished bibliography. Verify author order, venue, pages, and DOI from each paper or an official publisher/conference page before adding a BibTeX entry.

## Core related work

- Bortsova et al., transformation-consistent self-ensembling for semi-supervised medical image segmentation: https://arxiv.org/abs/1911.01218 — establishes aligned transformation consistency in medical segmentation. Included as PDF and text.
- CR-GLoCo, cross-resolution global-local context consistency for semi-supervised 3D medical segmentation: https://doi.org/10.1016/j.compmedimag.2026.102742 — close cross-resolution medical segmentation precedent.
- Mamba-Sea: https://arxiv.org/abs/2504.17515 — establishes that Mamba plus consistency/domain-generalization training is not itself new.
- Consispace: https://arxiv.org/abs/2606.31839 — semantic resampling across spacing; included as PDF and text.
- CROWn, CVPR 2026: https://openaccess.thecvf.com/content/CVPR2026/html/Huang_CROWn_A_Unified_Framework_for_Anti-Aliased_Downsampling_and_Phase-Calibrated_Fusion_CVPR_2026_paper.html — sampling-aware downsampling/fusion; included as PDF and text.
- TIDES: https://arxiv.org/abs/2605.09742 — selective SSM with observed physical intervals; included as PDF and text. It blocks a physical-step novelty claim.
- Tunable Soft Equivariance with Guarantees, CVPR 2026: https://openaccess.thecvf.com/content/CVPR2026/html/Rahman_Tunable_Soft_Equivariance_with_Guarantees_CVPR_2026_paper.html — useful conceptual boundary, not the same output-space method.

## Foundational references that the writer should verify

- Medical Segmentation Decathlon dataset/task paper.
- U-Net and/or 3D U-Net, depending on how the implemented baseline is described.
- Mamba/selective state-space model paper if Mamba mechanics are explained.
- Dice/Surface Dice metric references if required by the target venue.
- Bootstrap methodology reference only if the venue expects one; the actual implementation is documented in the supplied protocol and statistics code.

## Important caution

`novelty_audit_original.md` contains title-level triage for many papers and an obsolete static-delta narrative. It is useful for finding candidates, not as a source of detailed claims about papers that were not read in full.

