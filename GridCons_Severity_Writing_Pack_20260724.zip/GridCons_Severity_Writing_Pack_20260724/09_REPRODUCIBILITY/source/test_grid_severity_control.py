import inspect
import json
import os
import unittest
from argparse import Namespace
from pathlib import Path

import torch

import run_grid_severity_control as severity_control
from model import TinyMetricMamba


class SeverityControlTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = severity_control.Context(Namespace(project_root=Path(os.environ["SEVERITY_PROJECT"]), data_root=Path(os.environ["SEVERITY_DATA"]), legacy_root=Path(os.environ["SEVERITY_LEGACY"]), evidence_root=Path(os.environ["SEVERITY_EVIDENCE"]), output_root=Path(os.environ["SEVERITY_OUTPUT"])))

    def test_C_mean_formula(self):
        loss, weights = severity_control.aggregate(torch.tensor([1.0, 3.0]), torch.tensor([1.0, 3.0]), "C")
        self.assertEqual(loss.item(), 2.0); self.assertTrue(torch.equal(weights, torch.tensor([0.5, 0.5])))

    def test_D_error_softmax_and_stop_gradient(self):
        errors = torch.tensor([0.2, 0.6], requires_grad=True)
        _, weights = severity_control.aggregate(errors, torch.tensor([1.0, 3.0]), "D")
        self.assertTrue(torch.allclose(weights, torch.softmax(5.0 * errors.detach(), 0))); self.assertFalse(weights.requires_grad)

    def test_S_selects_only_larger_spacing_and_detaches(self):
        errors = torch.tensor([9.0, 1.0], requires_grad=True)
        loss, weights = severity_control.aggregate(errors, torch.tensor([1.2, 2.4]), "S")
        self.assertEqual(loss.item(), 1.0); self.assertTrue(torch.equal(weights, torch.tensor([0.0, 1.0]))); self.assertFalse(weights.requires_grad)

    def test_W_normalized_log_spacing_tau_five_and_stop_gradient(self):
        errors = torch.tensor([1.0, 2.0], requires_grad=True)
        spacings = torch.tensor([1.0, 3.0])
        _, weights = severity_control.aggregate(errors, spacings, "W")
        expected = torch.softmax(5.0 * torch.log(spacings) / torch.log(torch.tensor(3.0)), 0)
        self.assertTrue(torch.allclose(weights, expected)); self.assertEqual(severity_control.TAU, 5.0); self.assertFalse(weights.requires_grad)

    def test_same_candidates_only_aggregation_differs(self):
        errors, spacings = torch.tensor([0.1, 0.3]), torch.tensor([1.2, 2.7])
        values = [severity_control.aggregate(errors, spacings, arm)[0] for arm in severity_control.ARMS]
        self.assertEqual(len(values), 4); self.assertTrue(all(x.isfinite() for x in values))

    def test_equal_spacing_S_mean_W_half(self):
        errors, spacings = torch.tensor([0.2, 0.6]), torch.tensor([2.0, 2.0])
        s_loss, s_weights = severity_control.aggregate(errors, spacings, "S")
        _, w_weights = severity_control.aggregate(errors, spacings, "W")
        self.assertAlmostEqual(s_loss.item(), 0.4); self.assertTrue(torch.equal(s_weights, torch.tensor([0.5, 0.5]))); self.assertTrue(torch.equal(w_weights, torch.tensor([0.5, 0.5])))

    def test_order_swap_invariance(self):
        errors, spacings = torch.tensor([0.2, 0.6]), torch.tensor([1.2, 2.6])
        for arm in severity_control.ARMS:
            loss, weights = severity_control.aggregate(errors, spacings, arm)
            swapped_loss, swapped_weights = severity_control.aggregate(errors.flip(0), spacings.flip(0), arm)
            self.assertTrue(torch.allclose(loss, swapped_loss)); self.assertTrue(torch.allclose(weights, swapped_weights.flip(0)))

    def test_spacing_is_mm_not_tensor_depth(self):
        with self.assertRaisesRegex(ValueError, "mm"):
            severity_control.severity(torch.tensor([32.0, 64.0]))

    def test_schedule_parity_all_seeds(self):
        result = severity_control.audit_schedules(self.ctx)
        self.assertEqual(set(result), {"17", "29", "41"}); self.assertTrue(all(x["updates"] == 2500 and x["C_D_exact"] for x in result.values()))

    def test_initialization_parity(self):
        protocol = json.loads((self.ctx.output / "protocol.json").read_text())
        for seed in severity_control.SEEDS:
            severity_control.seed_all(seed)
            self.assertEqual(severity_control.state_sha256(TinyMetricMamba("separated_physical_delta")), protocol["initialization_sha256"][str(seed)])

    def test_checkpoint_selection_only_R1_validation(self):
        source = inspect.getsource(severity_control.train)
        self.assertIn("validation_dice(ctx, model, device)", source); self.assertIn("score > best", source); self.assertNotIn("development", source)

    def test_confirm_denylist_and_development(self):
        blocked = severity_control.denylist(self.ctx)
        self.assertEqual(len(blocked), 40)
        self.assertFalse(any(__import__("hashlib").sha256(x.encode()).hexdigest() in blocked for x in self.ctx.manifest["split"]["test"]))
        self.assertEqual(severity_control.raw_confirm_hits(self.ctx, blocked), 0)

    def test_forward_backward_gradient_finite(self):
        severity_control.seed_all(7)
        model = TinyMetricMamba("separated_physical_delta")
        logits = model(torch.randn(1, 1, 4, 4, 4), torch.ones(1, 3))
        errors = torch.stack((logits.square().mean(), logits.abs().mean()))
        loss, _ = severity_control.aggregate(errors, torch.tensor([1.0, 3.0]), "W")
        loss.backward()
        self.assertTrue(torch.isfinite(logits).all()); self.assertTrue(all(torch.isfinite(x.grad).all() for x in model.parameters() if x.grad is not None))

    def test_legacy_source_unchanged(self):
        protocol = json.loads((self.ctx.output / "protocol.json").read_text())
        current = severity_control.source_snapshot(self.ctx)
        for path, digest in protocol["source_sha256"].items():
            if not path.endswith(("run_grid_severity_control.py", "test_grid_severity_control.py")):
                self.assertEqual(current[path], digest)

    def test_resume_state_is_complete_and_atomic(self):
        source = inspect.getsource(severity_control.train)
        for field in ("model_state", "optimizer_state", "update", "history", "python_rng_state", "numpy_rng_state", "torch_rng_state", "cuda_rng_states"):
            self.assertIn(field, source)
        self.assertIn("os.replace(temporary, resume_path)", source)

    def test_final_integrity_recomputes_confirm_hits(self):
        source = inspect.getsource(severity_control.write_hashes)
        self.assertIn("confirm_hits", source)
        self.assertIn("token in blocked", source)


if __name__ == "__main__":
    unittest.main()
