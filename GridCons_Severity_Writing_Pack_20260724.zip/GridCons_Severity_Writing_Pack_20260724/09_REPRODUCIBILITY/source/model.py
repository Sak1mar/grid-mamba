"""Tiny 3D segmenter with token-independent delta overrides."""

from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F


class SelectiveRecurrence(nn.Module):
    def __init__(self, channels: int, parameterization: str, state_dim: int = 4):
        super().__init__()
        if parameterization not in {"content_delta", "separated_physical_delta"}:
            raise ValueError(f"unknown parameterization: {parameterization}")
        self.parameterization = parameterization
        self.channels = channels
        self.state_dim = state_dim
        self.norm = nn.LayerNorm(channels)
        self.bc_proj = nn.Linear(channels, 2 * channels * state_dim)
        self.out_proj = nn.Linear(channels, channels, bias=False)
        nn.init.normal_(self.out_proj.weight, std=0.02)
        self.A_log = nn.Parameter(torch.log(torch.arange(1, state_dim + 1).float()).repeat(channels, 1))
        self.D_skip = nn.Parameter(torch.ones(channels))
        if parameterization == "content_delta":
            self.delta_proj = nn.Linear(channels, channels)
            nn.init.zeros_(self.delta_proj.weight)
            nn.init.constant_(self.delta_proj.bias, math.log(math.expm1(0.1)))
        else:
            self.theta_channel = nn.Parameter(torch.full((channels,), math.log(math.expm1(0.1))))

    def delta(self, u: torch.Tensor, delta_override: torch.Tensor | None = None) -> torch.Tensor:
        if delta_override is None:
            if self.parameterization == "content_delta":
                return F.softplus(self.delta_proj(u).float())
            return F.softplus(self.theta_channel.float())[None, None].expand_as(u)
        override = torch.as_tensor(delta_override, device=u.device, dtype=torch.float32)
        if override.shape == (self.channels,):
            override = override[None, None].expand_as(u)
        elif override.shape != u.shape:
            raise ValueError(f"delta_override must be [{self.channels}] or {list(u.shape)}, got {list(override.shape)}")
        if not torch.isfinite(override).all() or (override <= 0).any():
            raise ValueError("delta_override must contain finite positive post-softplus values")
        return override

    def projections(
        self, sequence: torch.Tensor, delta_override: torch.Tensor | None = None
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        u = self.norm(sequence)
        n, length, channels = u.shape
        bc = self.bc_proj(u).float().reshape(n, length, 2, channels, self.state_dim)
        return u, bc[:, :, 0], bc[:, :, 1], self.delta(u, delta_override)

    def forward(self, sequence: torch.Tensor, delta_override: torch.Tensor | None = None) -> torch.Tensor:
        dtype = sequence.dtype
        u, B, C, delta = self.projections(sequence, delta_override)
        n, length, channels = u.shape
        A = -torch.exp(self.A_log.float())
        state = torch.zeros(n, channels, self.state_dim, device=u.device, dtype=torch.float32)
        outputs = []
        u32 = u.float()
        for t in range(length):
            scaled_A = delta[:, t, :, None] * A[None]
            decay = torch.exp(scaled_A)
            input_gain = torch.expm1(scaled_A) / A[None]
            state = decay * state + input_gain * B[:, t] * u32[:, t, :, None]
            outputs.append((state * C[:, t]).sum(-1) + self.D_skip.float()[None] * u32[:, t])
        return self.out_proj(torch.stack(outputs, dim=1).to(dtype))


class SixDirectionBlock(nn.Module):
    def __init__(self, channels: int, parameterization: str):
        super().__init__()
        self.scan = SelectiveRecurrence(channels, parameterization)

    @staticmethod
    def lines(x: torch.Tensor, axis: int) -> tuple[torch.Tensor, list[int], list[int]]:
        if axis not in (0, 1, 2):
            raise ValueError("axis must be D, H, or W")
        perm = [0] + [2 + i for i in range(3) if i != axis] + [2 + axis, 1]
        shape = [x.shape[i] for i in perm]
        return x.permute(perm).contiguous().reshape(-1, x.shape[2 + axis], x.shape[1]), perm, shape

    @staticmethod
    def grid(lines: torch.Tensor, perm: list[int], shape: list[int]) -> torch.Tensor:
        inverse = [perm.index(i) for i in range(5)]
        return lines.reshape(shape).permute(inverse).contiguous()

    def forward(
        self,
        x: torch.Tensor,
        spacing_dhw: torch.Tensor,
        delta_override: torch.Tensor | None = None,
    ) -> torch.Tensor:
        if spacing_dhw.shape != (x.shape[0], 3):
            raise ValueError("spacing must be [B,3] in D,H,W order")
        if not torch.isfinite(spacing_dhw).all() or (spacing_dhw <= 0).any():
            raise ValueError("spacing must be finite and positive")
        if delta_override is not None and torch.as_tensor(delta_override).shape != (self.scan.channels,):
            raise ValueError("token-level delta_override is scoped to SelectiveRecurrence; SixDirectionBlock accepts [channels]")
        restored = []
        for axis in range(3):
            lines, perm, shape = self.lines(x, axis)
            forward = self.scan(lines, delta_override)
            backward = self.scan(lines.flip(1), delta_override).flip(1)
            restored.extend((self.grid(forward, perm, shape), self.grid(backward, perm, shape)))
        return x + torch.stack(restored).mean(0)


def block(in_channels: int, out_channels: int, stride: int = 1) -> nn.Sequential:
    groups = min(6, out_channels)
    while out_channels % groups:
        groups -= 1
    return nn.Sequential(
        nn.Conv3d(in_channels, out_channels, 3, stride=stride, padding=1),
        nn.GroupNorm(groups, out_channels),
        nn.SiLU(),
    )


class TinyMetricMamba(nn.Module):
    def __init__(self, parameterization: str):
        super().__init__()
        self.parameterization = parameterization
        self.stem = block(1, 12)
        self.selective = SixDirectionBlock(12, parameterization)
        self.down1 = block(12, 24, 2)
        self.down2 = block(24, 48, 2)
        self.decode1 = block(48 + 24, 24)
        self.decode2 = block(24 + 12, 12)
        self.out = nn.Conv3d(12, 3, 1)

    def forward(
        self,
        image: torch.Tensor,
        spacing_dhw: torch.Tensor,
        delta_override: torch.Tensor | None = None,
    ) -> torch.Tensor:
        x0 = self.selective(self.stem(image), spacing_dhw, delta_override)
        x1 = self.down1(x0)
        x2 = self.down2(x1)
        x = F.interpolate(x2, size=x1.shape[2:], mode="trilinear", align_corners=False)
        x = self.decode1(torch.cat((x, x1), 1))
        x = F.interpolate(x, size=x0.shape[2:], mode="trilinear", align_corners=False)
        return self.out(self.decode2(torch.cat((x, x0), 1)))


def parameter_count(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
