"""Differentiable affine-aware 3-D resampling in NIfTI xyz coordinates."""

from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class AffineResampler3D(nn.Module):
    """Map target voxel centres through world space into a source tensor."""

    align_corners = False

    @staticmethod
    def _batch_affine(affine: torch.Tensor, batch: int, device: torch.device) -> torch.Tensor:
        value = torch.as_tensor(affine, dtype=torch.float64, device=device)
        if value.shape == (4, 4):
            value = value.unsqueeze(0).expand(batch, -1, -1)
        if value.shape != (batch, 4, 4) or not torch.isfinite(value).all():
            raise ValueError("affine must be finite [4,4] or [B,4,4]")
        return value

    def grid(
        self,
        source_shape_dhw: tuple[int, int, int],
        source_affine_xyz: torch.Tensor,
        target_shape_dhw: tuple[int, int, int],
        target_affine_xyz: torch.Tensor,
        batch: int,
        device: torch.device,
    ) -> torch.Tensor:
        sd, sh, sw = source_shape_dhw
        td, th, tw = target_shape_dhw
        if min(sd, sh, sw, td, th, tw) <= 0:
            raise ValueError("source and target shapes must be positive")
        source_affine = self._batch_affine(source_affine_xyz, batch, device)
        target_affine = self._batch_affine(target_affine_xyz, batch, device)
        d, h, w = torch.meshgrid(
            torch.arange(td, dtype=torch.float64, device=device),
            torch.arange(th, dtype=torch.float64, device=device),
            torch.arange(tw, dtype=torch.float64, device=device),
            indexing="ij",
        )
        # NIfTI indexes are xyz; tensor indexes are dhw, hence [w,h,d,1].
        target_xyz1 = torch.stack((w, h, d, torch.ones_like(d)), -1).reshape(-1, 4)
        transform = torch.linalg.solve(source_affine, target_affine)
        source_xyz = torch.einsum("bij,nj->bni", transform, target_xyz1)[..., :3]
        sizes_xyz = (sw, sh, sd)
        normalized = torch.stack(
            tuple(
                2.0 * (source_xyz[..., axis] + 0.5) / size - 1.0
                for axis, size in enumerate(sizes_xyz)
            ),
            -1,
        )
        # align_corners=False maps integer voxel centres to
        # 2*(i+0.5)/size-1. Unlike align_corners=True, this also preserves
        # affine out-of-bounds coordinates when a source axis has size one.
        return normalized.reshape(batch, td, th, tw, 3).to(torch.float32)

    def forward(
        self,
        source: torch.Tensor,
        source_affine_xyz: torch.Tensor,
        target_shape_dhw: tuple[int, int, int] | list[int],
        target_affine_xyz: torch.Tensor,
        mode: str = "bilinear",
    ) -> torch.Tensor:
        if source.ndim != 5 or mode not in {"bilinear", "nearest"}:
            raise ValueError("source must be [B,C,D,H,W]; mode must be bilinear or nearest")
        if not torch.isfinite(source).all():
            raise FloatingPointError("source contains NaN or Inf")
        target_shape = tuple(int(n) for n in target_shape_dhw)
        grid = self.grid(tuple(source.shape[2:]), source_affine_xyz, target_shape, target_affine_xyz, source.shape[0], source.device)
        result = F.grid_sample(source, grid, mode=mode, padding_mode="zeros", align_corners=self.align_corners)
        if not torch.isfinite(result).all():
            raise FloatingPointError("resampled result contains NaN or Inf")
        return result

    def image(self, source: torch.Tensor, source_affine_xyz: torch.Tensor, target_shape_dhw, target_affine_xyz) -> torch.Tensor:
        return self(source, source_affine_xyz, target_shape_dhw, target_affine_xyz, "bilinear")

    def probability(self, source: torch.Tensor, source_affine_xyz: torch.Tensor, target_shape_dhw, target_affine_xyz) -> torch.Tensor:
        mapped = self(source, source_affine_xyz, target_shape_dhw, target_affine_xyz, "bilinear").clamp_min(0)
        total = mapped.sum(1, keepdim=True)
        background = torch.zeros_like(mapped)
        background[:, 0] = 1
        return torch.where(total > 1e-7, mapped / total.clamp_min(1e-7), background)

    def label(self, source: torch.Tensor, source_affine_xyz: torch.Tensor, target_shape_dhw, target_affine_xyz) -> torch.Tensor:
        return self(source.float(), source_affine_xyz, target_shape_dhw, target_affine_xyz, "nearest").to(source.dtype)
