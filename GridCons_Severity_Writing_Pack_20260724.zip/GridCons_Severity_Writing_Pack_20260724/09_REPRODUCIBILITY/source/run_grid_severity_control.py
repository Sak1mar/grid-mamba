#!/usr/bin/env python
"""Final preregistered severity-confounding control for continuous grid training."""

from __future__ import annotations

import argparse
import csv
import hashlib
import inspect
import json
import math
import os
import platform
import random
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch
from scipy import stats

from model import TinyMetricMamba, parameter_count
from physical_resampler import AffineResampler3D
from run_grid_causal_audit import evaluate_model, frozen_schedule, sha256, validation_dice
from run_physgrid_pilot import (
    crop5,
    disagreement,
    load_grid,
    load_raw_image,
    loss_fn,
    model_logits,
    normalize_candidate,
    pad4,
    target_grid,
)


ARMS = ("C", "D", "S", "W")
TRAINABLE = ("S", "W")
SEEDS = (17, 29, 41)
SPACINGS = (1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0)
UPDATES = 2500
VALIDATE_EVERY = 250
WARMUP_UPDATES = 500
LAMBDA_MAX = 0.1
TAU = 5.0
BOOTSTRAPS = 10_000
BOOTSTRAP_SEED = 7331
CHECKPOINT_RULE = "R1 validation foreground Dice only; ties earliest"


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def state_sha256(model: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        value = tensor.detach().cpu().contiguous()
        digest.update(name.encode())
        digest.update(str(value.dtype).encode())
        digest.update(np.asarray(value.shape, dtype=np.int64).tobytes())
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def severity(spacings_mm: torch.Tensor) -> torch.Tensor:
    value = torch.as_tensor(spacings_mm)
    if value.shape != (2,) or not torch.isfinite(value).all() or (value < 1.0).any() or (value > 3.0).any():
        raise ValueError("spacings_mm must be two finite through-plane spacings in [1,3] mm")
    return torch.log(value / 1.0) / math.log(3.0)


def aggregate(errors: torch.Tensor, spacings_mm: torch.Tensor, arm: str) -> tuple[torch.Tensor, torch.Tensor]:
    if arm not in ARMS or errors.shape != (2,) or not torch.isfinite(errors).all():
        raise ValueError("aggregation requires arm C/D/S/W and two finite candidate errors")
    if arm == "C":
        weights = torch.full_like(errors, 0.5)
    elif arm == "D":
        weights = torch.softmax(TAU * errors, 0).detach()
    else:
        values = severity(spacings_mm)
        if arm == "S":
            weights = torch.full_like(errors, 0.5) if values[0] == values[1] else torch.nn.functional.one_hot(values.argmax(), 2).to(errors)
        else:
            weights = torch.softmax(TAU * values, 0).to(errors).detach()
        weights = weights.detach()
    return (weights * errors).sum(), weights


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    for name in ("project-root", "data-root", "legacy-root", "evidence-root", "output-root"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("setup")
    sub.add_parser("unit-tests")
    sub.add_parser("smoke")
    train_parser = sub.add_parser("train")
    train_parser.add_argument("--arm", choices=TRAINABLE, required=True)
    train_parser.add_argument("--seed", type=int, choices=SEEDS, required=True)
    sub.add_parser("evaluate")
    sub.add_parser("analyze")
    sub.add_parser("report")
    sub.add_parser("full-pilot")
    return parser.parse_args()


class Context:
    def __init__(self, args: argparse.Namespace):
        self.project = args.project_root.resolve()
        self.data = args.data_root.resolve()
        self.legacy = args.legacy_root.resolve()
        self.evidence = args.evidence_root.resolve()
        self.output = args.output_root.resolve() / "grid_severity_control"
        self.phys = self.evidence / "physgrid_pilot"
        self.causal = self.evidence / "grid_causal_audit"
        self.gradient = self.evidence / "grid_gradient_diagnostic"
        self.measure = self.evidence / "measure_consistent_grid"
        self.gridrex = self.evidence / "gridrex_pilot"
        if self.project != Path(__file__).resolve().parent:
            raise RuntimeError("--project-root must identify this script's directory")
        self.manifest_path = self.legacy / "outputs" / "manifest.json"
        self.manifest = json.loads(self.manifest_path.read_text())
        expected = hashlib.sha256(json.dumps({k: v for k, v in self.manifest.items() if k != "manifest_hash"}, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        if self.manifest.get("manifest_hash") != expected:
            raise RuntimeError("legacy manifest internal hash mismatch")

    def cache(self, case_id: str, grid: str, kind: str) -> Path:
        path = self.legacy / "cache" / case_id / f"{grid}_{kind}.npy"
        if not path.is_file():
            raise FileNotFoundError(path)
        return path

    def checkpoint(self, arm: str, seed: int, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / "checkpoints" / f"{arm}_seed{seed}.pt"

    def log(self, arm: str, seed: int, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / f"train_{arm}_seed{seed}.json"

    def resume(self, arm: str, seed: int, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / "resume" / f"{arm}_seed{seed}.pt"

    def c_log(self, seed: int) -> Path:
        return self.phys / "train_randomgrid_mean_seed17.json" if seed == 17 else self.causal / f"train_random_k2_seed{seed}.json"

    def d_log(self, seed: int) -> Path:
        return self.phys / "train_randomgrid_worst_seed17.json" if seed == 17 else self.causal / f"train_soft_worst_random_seed{seed}.json"

    def source_checkpoint(self, arm: str, seed: int) -> Path:
        if seed == 17:
            name = "randomgrid_mean_seed17.pt" if arm == "C" else "randomgrid_worst_seed17.pt"
            return self.phys / "checkpoints" / name
        name = "random_k2" if arm == "C" else "soft_worst_random"
        return self.causal / "checkpoints" / f"{name}_seed{seed}.pt"


def require_cuda() -> torch.device:
    if os.environ.get("CUDA_VISIBLE_DEVICES") != "0" or not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly CUDA_VISIBLE_DEVICES=0 is required")
    return torch.device("cuda:0")


def record_command(ctx: Context) -> None:
    ctx.output.mkdir(parents=True, exist_ok=True)
    with (ctx.output / "command_ledger.jsonl").open("a") as handle:
        handle.write(json.dumps({"argv": sys.argv, "cwd": str(Path.cwd()), "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"), "time_unix": time.time()}, sort_keys=True) + "\n")


def verify_manifest(directory: Path, allow_causal_append: bool = False) -> dict:
    manifest = directory / "SHA256SUMS"
    if not manifest.is_file():
        raise RuntimeError(f"missing SHA256SUMS: {directory}")
    mismatches = []
    for line in manifest.read_text().splitlines():
        expected, name = line.split(maxsplit=1)
        path = Path(name.strip())
        if not path.is_absolute():
            path = directory / path
        if not path.is_file() or sha256(path) != expected:
            mismatches.append((path, expected))
    append_detail = None
    if allow_causal_append and len(mismatches) == 1 and mismatches[0][0].name == "command_ledger.jsonl":
        ledger, expected = mismatches[0]
        lines = ledger.read_text().splitlines(keepends=True)
        matches = [n for n in range(1, len(lines) + 1) if hashlib.sha256("".join(lines[:n]).encode()).hexdigest() == expected]
        if matches:
            extra = [json.loads(x) for x in lines[matches[-1] :]]
            allowed = all(x["argv"][-4:] in (["--arm", "random_k1", "--seed", "29"], ["--arm", "random_k1", "--seed", "41"]) for x in extra)
            if allowed:
                append_detail = {"frozen_prefix_lines": matches[-1], "appended_lines": len(extra), "appended_commands": [x["argv"][-4:] for x in extra]}
                mismatches = []
    return {"directory": str(directory), "entries": len(manifest.read_text().splitlines()), "pass": not mismatches, "append_only_exception": append_detail, "mismatches": [str(x[0]) for x in mismatches]}


def history_values(log: dict, row: dict) -> tuple[list[float], list[float], list[float], float, float]:
    requested = row.get("requested_spacings", row.get("sampled_spacing_requested"))
    actual = row.get("actual_spacings", row.get("sampled_spacing_actual"))
    errors = row.get("auxiliary_losses", row.get("grid_errors"))
    native = row.get("native_loss", row.get("segmentation_loss"))
    gradient = row["gradient_norm"]
    return requested, actual, errors, native, gradient


def audit_schedules(ctx: Context, write: bool = False) -> dict:
    train_ids = ctx.manifest["split"]["train"]
    results = {}
    for seed in SEEDS:
        c, d = json.loads(ctx.c_log(seed).read_text()), json.loads(ctx.d_log(seed).read_text())
        if c.get("updates") != UPDATES or d.get("updates") != UPDATES or len(c["history"]) != UPDATES or len(d["history"]) != UPDATES:
            raise RuntimeError(f"incomplete C/D history for seed {seed}")
        reconstructed = frozen_schedule(train_ids, seed)
        rows = []
        for index, item in enumerate(reconstructed):
            cr, dr = c["history"][index], d["history"][index]
            c_req, c_actual, c_errors, c_native, _ = history_values(c, cr)
            d_req, d_actual, d_errors, d_native, _ = history_values(d, dr)
            case_hash = hashlib.sha256(item["case_id"].encode()).hexdigest()
            logged_hashes = [x.get("case_id_hash", case_hash) for x in (cr, dr)]
            expected_req = [item["spacing_1"], item["spacing_2"]]
            if logged_hashes != [case_hash, case_hash] or c_req != d_req or c_req != expected_req or c_actual != d_actual:
                raise RuntimeError(f"STOP_ENGINEERING_SCHEDULE_MISMATCH seed={seed} update={index + 1}")
            if index == 0 and (c_native != d_native or c_errors != d_errors):
                raise RuntimeError(f"initial trajectory mismatch seed={seed}")
            rows.append({**item, "case_id_hash": case_hash, "actual_spacings": c_actual})
        text = "".join(json.dumps(x, sort_keys=True) + "\n" for x in rows)
        digest = hashlib.sha256(text.encode()).hexdigest()
        if write:
            schedule_path = ctx.output / f"frozen_schedule_seed{seed}.jsonl"
            schedule_path.write_text(text)
            (ctx.output / f"frozen_schedule_seed{seed}.sha256").write_text(f"{digest}  {schedule_path}\n")
        results[str(seed)] = {"updates": len(rows), "sha256": digest, "C_D_exact": True, "reconstructed_exact": True}
    return results


def denylist(ctx: Context) -> set[str]:
    sets = []
    for path in (ctx.causal / "confirm_denylist.json", ctx.gradient / "confirm_denylist.json", ctx.measure / "confirm_denylist.json", ctx.gridrex / "confirm_denylist.json"):
        data = json.loads(path.read_text())
        sets.append(set(data["hashes"]))
    if any(x != sets[0] for x in sets[1:]) or len(sets[0]) != 40:
        raise RuntimeError("confirm_v2 denylist mismatch")
    return sets[0]


def raw_confirm_hits(ctx: Context, blocked: set[str]) -> int:
    hits = 0
    for directory in (ctx.phys, ctx.causal, ctx.gradient, ctx.measure, ctx.gridrex):
        for path in directory.rglob("*"):
            if not path.is_file() or path.name == "split_manifest_confirm_v2_locked.json" or path.suffix in {".pt", ".npy"}:
                continue
            try:
                text = path.read_text(errors="ignore")
            except OSError:
                continue
            for token in set(__import__("re").findall(r"hippocampus_\d+", text)):
                hits += hashlib.sha256(token.encode()).hexdigest() in blocked
    return int(hits)


def link(path: Path, target: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        if path.resolve() != target.resolve():
            raise RuntimeError(f"wrong checkpoint alias: {path}")
    else:
        path.symlink_to(target)


def source_snapshot(ctx: Context) -> dict:
    paths = [ctx.project / x for x in ("model.py", "physical_resampler.py", "run_physgrid_pilot.py", "run_grid_causal_audit.py", "run_grid_severity_control.py", "test_grid_severity_control.py")]
    return {str(x): sha256(x) for x in paths}


def setup(ctx: Context) -> None:
    ctx.output.mkdir(parents=True, exist_ok=True)
    evidence = [verify_manifest(x, x == ctx.causal) for x in (ctx.phys, ctx.gridrex, ctx.measure, ctx.gradient, ctx.causal)]
    if not all(x["pass"] for x in evidence):
        raise RuntimeError("frozen evidence integrity failure")
    blocked = denylist(ctx)
    schedule = audit_schedules(ctx, True)
    groups = [ctx.manifest["split"][x] for x in ("train", "validation", "test")]
    if [len(x) for x in groups] != [80, 20, 20] or any(hashlib.sha256(x.encode()).hexdigest() in blocked for group in groups for x in group):
        raise RuntimeError("development split or confirm denylist failure")
    for seed in SEEDS:
        for arm in ("C", "D"):
            source = ctx.source_checkpoint(arm, seed)
            log = json.loads((ctx.c_log(seed) if arm == "C" else ctx.d_log(seed)).read_text())
            if log["checkpoint_sha256"] != sha256(source):
                raise RuntimeError(f"checkpoint integrity failure {arm} seed {seed}")
            link(ctx.checkpoint(arm, seed), source)
    initialization = {}
    for seed in SEEDS:
        seed_all(seed)
        initialization[str(seed)] = state_sha256(TinyMetricMamba("separated_physical_delta"))
    current_head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ctx.project, text=True, capture_output=True, check=True).stdout.strip()
    branch = subprocess.run(["git", "branch", "--show-current"], cwd=ctx.project, text=True, capture_output=True, check=True).stdout.strip()
    protocol = {
        "name": "Final severity-confounding control",
        "paths": {"project_root": str(ctx.project), "data_root": str(ctx.data), "results_root": str(ctx.evidence), "output_root": str(ctx.output)},
        "git_commit": current_head,
        "git_branch": branch,
        "arms": {
            "C": "L_aux=(e1+e2)/2",
            "D": "w=stop_gradient(softmax(5*[e1,e2])); L_aux=sum(w*e)",
            "S": "a=log(s_mm/1mm)/log(3); select argmax(a), exact ties mean",
            "W": "a=log(s_mm/1mm)/log(3); w=stop_gradient(softmax(5*a)); L_aux=sum(w*e)",
        },
        "shared": {"backbone": "Static Mamba", "parameters": 99411, "optimizer": "AdamW", "learning_rate": 3e-4, "weight_decay": 1e-5, "updates": UPDATES, "batch_size": 1, "full_volume": True, "amp": "bfloat16", "augmentation": "none", "K": 2, "lambda_max": LAMBDA_MAX, "warmup_updates": WARMUP_UPDATES, "tau": TAU, "validation_every": VALIDATE_EVERY, "checkpoint_rule": CHECKPOINT_RULE, "resume_rule": "atomic full model/AdamW/history/RNG state every 250 updates; resume only with exact initialization and schedule SHA256", "normalization": "frozen R1 non-background mean/std", "affine": "endpoint-matched native through-plane grid; affine-aware mapping", "train_spacing": "frozen LogUniform requested [1,3] mm; severity uses the requested schedule spacing in mm", "evaluation_spacings_mm": list(SPACINGS)},
        "statistics": {"unit": "paired case x seed", "hierarchical_bootstrap": "sample 20 cases, then 3 seeds within each sampled case", "draws": BOOTSTRAPS, "seed": BOOTSTRAP_SEED, "screening_ci": 0.80, "descriptive_ci": 0.95},
        "mechanism_strata": "within-seed median split of absolute actual-spacing gap; error/spacing order agreement vs disagreement",
        "decision_rules": "exactly KEEP_SOFT_WORST_ADAPTIVE / REFRAME_SEVERITY_EMPHASIS / PREFER_SEVERITY_CONTROL / USE_MEAN_SIMPLE / INCONCLUSIVE_SEVERITY_CONTROL as preregistered in user protocol",
        "schedule": schedule,
        "initialization_sha256": initialization,
        "confirm_v2_data_accessed": False,
        "confirm_v2_evaluated": False,
        "source_sha256": source_snapshot(ctx),
    }
    dump_json(ctx.output / "protocol.json", protocol)
    hits = raw_confirm_hits(ctx, blocked)
    report = ["Frozen evidence audit"] + [f"{x['directory']}: PASS ({x['entries']} entries){'; append-only ledger exception '+json.dumps(x['append_only_exception'], sort_keys=True) if x['append_only_exception'] else ''}" for x in evidence]
    report += [f"C/D schedule parity: PASS {json.dumps(schedule, sort_keys=True)}", f"initialization SHA256: {json.dumps(initialization, sort_keys=True)}", f"train/validation/development-screen: 80/20/20", f"denylist_count: {len(blocked)}", f"raw_confirm_id_matches: {hits}", "confirm_v2_data_accessed: false", "result: PASS" if hits == 0 else "result: FAIL"]
    (ctx.output / "source_integrity_report.txt").write_text("\n".join(report) + "\n")
    (ctx.output / "audit.md").write_text("# Severity-control evidence audit\n\n" + "\n".join(f"- {x}" for x in report) + "\n\nFrozen conclusions inherited: Physical-Step, GridREx, fixed-grid degradation, conservative transport, occupancy supervision, and gradient surgery remain stopped. Continuous native tensor-grid exposure and the three-seed D−C result remain supported.\n")
    subprocess.run(["nvidia-smi"], stdout=(ctx.output / "nvidia_smi.txt").open("w"), text=True, check=True)
    env = subprocess.run([sys.executable, "-m", "pip", "freeze"], text=True, capture_output=True, check=True).stdout
    (ctx.output / "environment_freeze.txt").write_text(f"python={platform.python_version()}\npytorch={torch.__version__}\ncuda={torch.version.cuda}\ncudnn={torch.backends.cudnn.version()}\n" + env)
    write_scripts(ctx)


def train(ctx: Context, arm: str, seed: int, updates: int = UPDATES, smoke: bool = False) -> dict:
    if arm not in TRAINABLE or seed not in SEEDS:
        raise ValueError("only S/W seeds 17/29/41 are trainable")
    device = require_cuda()
    checkpoint, log_path, resume_path = ctx.checkpoint(arm, seed, smoke), ctx.log(arm, seed, smoke), ctx.resume(arm, seed, smoke)
    if checkpoint.is_file() and log_path.is_file():
        old = json.loads(log_path.read_text())
        if old.get("completed") and old.get("updates") == updates and old.get("checkpoint_sha256") == sha256(checkpoint):
            return old
    schedule_path = ctx.output / f"frozen_schedule_seed{seed}.jsonl"
    schedule = [json.loads(x) for x in schedule_path.read_text().splitlines()][:updates]
    seed_all(seed)
    model = TinyMetricMamba("separated_physical_delta").to(device)
    init_hash = state_sha256(model)
    if init_hash != json.loads((ctx.output / "protocol.json").read_text())["initialization_sha256"][str(seed)]:
        raise RuntimeError("initialization parity failure")
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-5)
    resampler = AffineResampler3D()
    history, best, best_update, resumed_from, prior_seconds, prior_peak = [], -1.0, 0, 0, 0.0, 0
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    resume_path.parent.mkdir(parents=True, exist_ok=True)
    if resume_path.is_file():
        saved = torch.load(resume_path, map_location=device, weights_only=False)
        expected_schedule = json.loads((ctx.output / "protocol.json").read_text())["schedule"][str(seed)]["sha256"]
        if saved.get("arm") != arm or saved.get("seed") != seed or saved.get("initialization_sha256") != init_hash or saved.get("schedule_sha256") != expected_schedule:
            raise RuntimeError("resume state provenance mismatch")
        model.load_state_dict(saved["model_state"], strict=True)
        optimizer.load_state_dict(saved["optimizer_state"])
        history, best, best_update = saved["history"], saved["best"], saved["best_update"]
        resumed_from = int(saved["update"])
        prior_seconds = float(saved["training_seconds"])
        prior_peak = int(saved["peak_reserved_bytes"])
        random.setstate(saved["python_rng_state"])
        np.random.set_state(saved["numpy_rng_state"])
        torch.set_rng_state(saved["torch_rng_state"].cpu())
        torch.cuda.set_rng_state_all([state.cpu() for state in saved["cuda_rng_states"]])
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    for item in schedule[resumed_from:]:
        update, case_id = item["update"], item["case_id"]
        case, r1 = ctx.manifest["cases"][case_id], ctx.manifest["cases"][case_id]["grids"]["R1"]
        shape = r1["unpadded_shape_dhw"]
        image, label_array = load_grid(ctx, case_id, "R1")
        x1 = torch.from_numpy(image).to(device)[None, None]
        y1 = torch.from_numpy(label_array.astype(np.int64)).to(device)[None]
        affine = torch.tensor(r1["affine_xyz"], dtype=torch.float64, device=device)
        raw, raw_affine = load_raw_image(ctx, case_id, device)
        optimizer.zero_grad(set_to_none=True)
        model.train()
        with torch.autocast("cuda", dtype=torch.bfloat16):
            z1 = model_logits(model, x1, [1, 1, 1])
            native_loss = loss_fn(z1, y1)
            teacher = crop5(z1, shape).float().softmax(1)[:, 1:].detach()
            errors, actuals = [], []
            for requested in (item["spacing_1"], item["spacing_2"]):
                target_shape, target_affine, actual = target_grid(affine, shape, requested)
                candidate = pad4(normalize_candidate(resampler.image(raw, raw_affine, target_shape, target_affine), case["r1_nonbackground_mean"], case["r1_nonbackground_std"]))
                logits = model_logits(model, candidate, [actual, 1, 1])
                probability = crop5(logits, target_shape).float().softmax(1)
                mapped = resampler.probability(probability, target_affine, shape, affine)[:, 1:]
                errors.append(disagreement(teacher, mapped))
                actuals.append(actual)
            values = torch.stack(errors)
            scheduled_spacings = torch.tensor([item["spacing_1"], item["spacing_2"]], device=device)
            auxiliary_loss, weights = aggregate(values, scheduled_spacings, arm)
            lam = LAMBDA_MAX * min(1.0, update / WARMUP_UPDATES)
            total = native_loss + lam * auxiliary_loss
        if not torch.isfinite(total):
            raise FloatingPointError(f"non-finite loss at update {update}")
        total.backward()
        gradients = [p.grad.float() for p in model.parameters() if p.grad is not None]
        if not gradients or not all(torch.isfinite(x).all() for x in gradients):
            raise FloatingPointError(f"non-finite gradient at update {update}")
        gradient_norm = float(torch.sqrt(sum(x.square().sum() for x in gradients)))
        optimizer.step()
        row = {"update": update, "case_id_hash": hashlib.sha256(case_id.encode()).hexdigest(), "requested_spacings": [item["spacing_1"], item["spacing_2"]], "actual_spacings": actuals, "auxiliary_losses": [float(x) for x in values], "aggregation_weights": [float(x) for x in weights], "severity": [math.log(item[x]) / math.log(3.0) for x in ("spacing_1", "spacing_2")], "native_loss": float(native_loss), "auxiliary_loss": float(auxiliary_loss), "lambda": lam, "total_loss": float(total), "gradient_norm": gradient_norm}
        history.append(row)
        if update % VALIDATE_EVERY == 0 or update == updates:
            score = validation_dice(ctx, model, device)
            row["validation_r1_foreground_dice"] = score
            print(arm, seed, {"update": update, "loss": float(total), "validation": score}, flush=True)
            if score > best:
                best, best_update = score, update
                torch.save({"model_state": model.state_dict(), "arm": arm, "seed": seed, "update": update, "validation_r1_foreground_dice": score, "selection": "R1 validation foreground Dice only"}, checkpoint)
            torch.cuda.synchronize()
            resume_state = {"arm": arm, "seed": seed, "update": update, "model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(), "history": history, "best": best, "best_update": best_update, "initialization_sha256": init_hash, "schedule_sha256": json.loads((ctx.output / "protocol.json").read_text())["schedule"][str(seed)]["sha256"], "training_seconds": prior_seconds + time.perf_counter() - started, "peak_reserved_bytes": max(prior_peak, torch.cuda.max_memory_reserved()), "python_rng_state": random.getstate(), "numpy_rng_state": np.random.get_state(), "torch_rng_state": torch.get_rng_state(), "cuda_rng_states": torch.cuda.get_rng_state_all()}
            temporary = resume_path.with_suffix(".tmp")
            torch.save(resume_state, temporary)
            os.replace(temporary, resume_path)
    torch.cuda.synchronize()
    elapsed = prior_seconds + time.perf_counter() - started
    props = torch.cuda.get_device_properties(0)
    log = {"completed": True, "finite": True, "arm": arm, "seed": seed, "updates": updates, "resumed_from_update": resumed_from, "resume_state": str(resume_path), "resume_state_sha256": sha256(resume_path), "optimizer": "AdamW", "learning_rate": 3e-4, "weight_decay": 1e-5, "amp": "bfloat16", "batch_size": 1, "full_volume": True, "augmentation": "none", "initialization_sha256": init_hash, "schedule_sha256": json.loads((ctx.output / "protocol.json").read_text())["schedule"][str(seed)]["sha256"], "history": history, "best_validation_r1_foreground_dice": best, "best_update": best_update, "checkpoint": str(checkpoint), "checkpoint_sha256": sha256(checkpoint), "checkpoint_selection": CHECKPOINT_RULE, "parameter_count": parameter_count(model), "training_seconds": elapsed, "gpu_hours": elapsed / 3600, "seconds_per_update": elapsed / updates, "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": max(prior_peak, torch.cuda.max_memory_reserved()), "gpu_total_memory_bytes": props.total_memory}
    dump_json(log_path, log)
    return log


def run_unit_tests(ctx: Context) -> None:
    setup(ctx)
    started = time.perf_counter()
    env = dict(os.environ, CUDA_VISIBLE_DEVICES="0", PYTHONDONTWRITEBYTECODE="1", SEVERITY_PROJECT=str(ctx.project), SEVERITY_DATA=str(ctx.data), SEVERITY_LEGACY=str(ctx.legacy), SEVERITY_EVIDENCE=str(ctx.evidence), SEVERITY_OUTPUT=str(ctx.output.parent))
    result = subprocess.run([sys.executable, "-m", "unittest", "-v", "test_grid_severity_control.py"], cwd=ctx.project, env=env, text=True, capture_output=True)
    (ctx.output / "unit_test_report.txt").write_text(f"exit_code: {result.returncode}\nelapsed_seconds: {time.perf_counter()-started:.6f}\n\nSTDOUT\n{result.stdout}\nSTDERR\n{result.stderr}")
    if result.returncode:
        raise RuntimeError("STOP_ENGINEERING: unit tests failed; training forbidden")


def smoke(ctx: Context) -> None:
    if "exit_code: 0" not in (ctx.output / "unit_test_report.txt").read_text():
        raise RuntimeError("STOP_ENGINEERING: passing unit tests required")
    for arm in TRAINABLE:
        train(ctx, arm, 17, 10, True)
    logs = [train(ctx, arm, 17, 20, True) for arm in TRAINABLE]
    passed = all(x["finite"] and x["resumed_from_update"] == 10 and x["peak_reserved_bytes"] < 0.9 * x["gpu_total_memory_bytes"] for x in logs)
    lines = ["# Smoke test report", "", "10 updates + exact resume to 20 on the frozen full training schedule; no scientific comparison.", "", "| arm | resumed from | finite | loss | gradient norm | peak GiB |", "|---|---:|---:|---:|---:|---:|"]
    lines += [f"| {x['arm']} | {x['resumed_from_update']} | {x['finite']} | {x['history'][-1]['total_loss']:.6f} | {x['history'][-1]['gradient_norm']:.6f} | {x['peak_reserved_bytes']/2**30:.3f} |" for x in logs]
    lines += ["", f"Result: {'PASS' if passed else 'FAIL'}"]
    (ctx.output / "smoke_test_report.md").write_text("\n".join(lines) + "\n")
    if not passed:
        raise RuntimeError("STOP_ENGINEERING: smoke failed")


def verify_training(ctx: Context) -> None:
    for seed in SEEDS:
        for arm in ARMS:
            path = ctx.checkpoint(arm, seed)
            if arm in TRAINABLE:
                log = json.loads(ctx.log(arm, seed).read_text())
                if not log.get("completed") or log.get("updates") != UPDATES or log.get("checkpoint_sha256") != sha256(path):
                    raise RuntimeError(f"incomplete training: {arm} seed {seed}")
            elif sha256(path) != json.loads((ctx.c_log(seed) if arm == "C" else ctx.d_log(seed)).read_text())["checkpoint_sha256"]:
                raise RuntimeError(f"reused checkpoint changed: {arm} seed {seed}")


def case_summaries(rows: list[dict]) -> list[dict]:
    foreground = [x for x in rows if x["class"] == "foreground"]
    result = []
    for arm, seed, case_id in sorted({(x["arm"], x["seed"], x["case_id"]) for x in foreground}):
        grid = {float(x["spacing_nominal_mm"]): x for x in foreground if (x["arm"], x["seed"], x["case_id"]) == (arm, seed, case_id)}
        non_r1 = [grid[x] for x in SPACINGS[1:]]
        xs = np.asarray(SPACINGS[1:])
        dpred = np.asarray([x["Dpred"] for x in non_r1])
        result.append({"arm": arm, "seed": seed, "case_id": case_id, "Dnative": grid[1.0]["Dnative"], "Grid_AUC": float(np.trapz(dpred, xs) / (xs[-1] - xs[0])), "Worst_grid_Dpred": float(dpred.min()), "Worst_grid_Dmap": float(min(x["Dmap"] for x in non_r1)), "source_range_Dmap": float(np.mean([grid[x]["Dmap"] for x in (1.5, 2.0, 2.5, 3.0)])), "Extra_Dmap": float(np.mean([grid[x]["Dmap"] for x in (4.0, 5.0)])), "Extra_Smap": float(np.mean([grid[x]["Smap"] for x in (4.0, 5.0)])), "degradation_slope": float(np.polyfit(np.log(xs), dpred, 1)[0])})
    return result


def evaluate(ctx: Context) -> None:
    device = require_cuda()
    verify_training(ctx)
    blocked = denylist(ctx)
    rows = []
    for seed in SEEDS:
        for arm in ARMS:
            rows += evaluate_model(ctx, arm, seed, device, blocked)
    fields = list(rows[0])
    with (ctx.output / "metrics_case_level.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    spacing_rows = []
    keys = sorted({(x["arm"], x["seed"], x["spacing_nominal_mm"], x["class"]) for x in rows})
    for arm, seed, spacing, cls in keys:
        selected = [x for x in rows if (x["arm"], x["seed"], x["spacing_nominal_mm"], x["class"]) == (arm, seed, spacing, cls)]
        spacing_rows.append({"arm": arm, "seed": seed, "spacing_nominal_mm": spacing, "class": cls, **{m: float(np.mean([x[m] for x in selected])) for m in ("Dpred", "Dmap", "Smap", "Dnative")}})
    with (ctx.output / "metrics_spacing_level.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(spacing_rows[0])); writer.writeheader(); writer.writerows(spacing_rows)
    cases = case_summaries(rows)
    metrics = ("Dnative", "Grid_AUC", "Worst_grid_Dpred", "Worst_grid_Dmap", "source_range_Dmap", "Extra_Dmap", "Extra_Smap", "degradation_slope")
    by_seed = {arm: {str(seed): {m: float(np.mean([x[m] for x in cases if x["arm"] == arm and x["seed"] == seed])) for m in metrics} for seed in SEEDS} for arm in ARMS}
    pooled = {arm: {m: float(np.mean([x[m] for x in cases if x["arm"] == arm])) for m in metrics} for arm in ARMS}
    costs = {}
    for arm in ARMS:
        logs = [normalized_log(ctx, arm, seed) for seed in SEEDS]
        costs[arm] = {"gpu_hours": float(sum(x["training_seconds"] for x in logs) / 3600), "seconds_per_update": float(np.mean([x["seconds_per_update"] for x in logs])), "peak_memory_bytes": int(max(x["peak_reserved_bytes"] for x in logs))}
    dump_json(ctx.output / "metrics_summary.json", {"by_seed": by_seed, "pooled_case_seed": pooled, "compute": costs, "confirm_v2_data_accessed": False, "confirm_v2_evaluated": False})
    bootstrap(ctx, cases)


def normalized_log(ctx: Context, arm: str, seed: int) -> dict:
    log = json.loads((ctx.log(arm, seed) if arm in TRAINABLE else (ctx.c_log(seed) if arm == "C" else ctx.d_log(seed))).read_text())
    if "training_seconds" not in log:
        raise RuntimeError(f"missing training cost: {arm} seed {seed}")
    return log


def bootstrap(ctx: Context, cases: list[dict]) -> None:
    comparisons = (("D", "S"), ("D", "W"), ("S", "C"), ("W", "C"), ("S", "D"), ("W", "D"), ("D", "C"))
    metrics = ("Extra_Dmap", "Extra_Smap", "Worst_grid_Dmap", "Dnative")
    lookup = {(x["arm"], x["case_id"], x["seed"]): x for x in cases}
    case_ids = sorted({x["case_id"] for x in cases})
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    output, paired = {}, []
    for treatment, control in comparisons:
        for metric in metrics:
            matrix = np.asarray([[lookup[(treatment, case_id, seed)][metric] - lookup[(control, case_id, seed)][metric] for seed in SEEDS] for case_id in case_ids])
            means = np.empty(BOOTSTRAPS)
            for draw in range(BOOTSTRAPS):
                selected_cases = rng.integers(0, len(case_ids), len(case_ids))
                means[draw] = np.mean([matrix[c, rng.integers(0, len(SEEDS), len(SEEDS))].mean() for c in selected_cases])
            key = f"{treatment}_minus_{control}:{metric}"
            output[key] = {"mean_difference": float(matrix.mean()), "median_paired_difference": float(np.median(matrix)), "positive_case_seed_fraction": float((matrix > 0).mean()), "ci80": [float(x) for x in np.quantile(means, (0.1, 0.9))], "ci95": [float(x) for x in np.quantile(means, (0.025, 0.975))], "by_seed": {str(seed): float(matrix[:, i].mean()) for i, seed in enumerate(SEEDS)}}
            for ci, case_id in enumerate(case_ids):
                for si, seed in enumerate(SEEDS):
                    paired.append({"treatment": treatment, "control": control, "metric": metric, "case_id": case_id, "seed": seed, "difference": matrix[ci, si]})
    dump_json(ctx.output / "bootstrap_results.json", {"draws": BOOTSTRAPS, "seed": BOOTSTRAP_SEED, "method": "hierarchical paired: cases then seeds within case", "results": output})
    with (ctx.output / "paired_differences.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(paired[0])); writer.writeheader(); writer.writerows(paired)


def mechanism(ctx: Context) -> None:
    detail, report = [], {"by_seed": {}}
    for seed in SEEDS:
        logs = {arm: normalized_log(ctx, arm, seed) for arm in ARMS}
        normalized = {}
        gaps = []
        for arm, log in logs.items():
            normalized[arm] = []
            for row in log["history"]:
                requested, actual, errors, _, gradient = history_values(log, row)
                error_tensor = torch.tensor(errors)
                _, weights = aggregate(error_tensor, torch.tensor(requested), arm)
                normalized[arm].append((requested, actual, errors, weights.numpy().tolist(), row.get("auxiliary_loss", row.get("consistency_loss")), gradient))
                if arm == "C": gaps.append(abs(requested[0] - requested[1]))
        gap_cut = float(np.median(gaps))
        d_weights, w_weights, d_severe, agreements = [], [], [], []
        for index in range(UPDATES):
            d = normalized["D"][index]
            spacing_order = int(d[0][1] > d[0][0]) if d[0][0] != d[0][1] else -1
            loss_order = int(d[2][1] > d[2][0]) if d[2][0] != d[2][1] else -1
            agreement = spacing_order == loss_order and spacing_order >= 0
            d_severe.append(agreement)
            agreements.append(agreement)
            d_weights.append(d[3][0]); w_weights.append(normalized["W"][index][3][0])
            for arm in ARMS:
                requested, actual, errors, weights, aux, gradient = normalized[arm][index]
                detail.append({"seed": seed, "update": index + 1, "arm": arm, "spacing_1_mm": requested[0], "spacing_2_mm": requested[1], "actual_spacing_1_mm": actual[0], "actual_spacing_2_mm": actual[1], "spacing_gap_mm": abs(requested[0] - requested[1]), "spacing_gap_stratum": "close" if abs(requested[0] - requested[1]) <= gap_cut else "large", "error_1": errors[0], "error_2": errors[1], "disagreement_gap": abs(errors[0] - errors[1]), "ordering": "agree" if agreement else "disagree", "weight_1": weights[0], "weight_2": weights[1], "effective_spacing_mm": weights[0] * requested[0] + weights[1] * requested[1], "auxiliary_loss": aux, "gradient_norm": gradient})
        per_arm = {}
        for arm in ARMS:
            selected = [x for x in detail if x["seed"] == seed and x["arm"] == arm]
            per_arm[arm] = {key: float(np.mean([x[key] for x in selected])) for key in ("effective_spacing_mm", "auxiliary_loss", "gradient_norm", "spacing_gap_mm", "disagreement_gap")}
            per_arm[arm]["by_stratum"] = {stratum: {key: float(np.mean([x[key] for x in selected if x["spacing_gap_stratum"] == stratum])) for key in ("effective_spacing_mm", "auxiliary_loss", "gradient_norm", "disagreement_gap")} for stratum in ("close", "large")}
            per_arm[arm]["by_ordering"] = {ordering: {key: float(np.mean([x[key] for x in selected if x["ordering"] == ordering])) for key in ("effective_spacing_mm", "auxiliary_loss", "gradient_norm", "spacing_gap_mm", "disagreement_gap")} for ordering in ("agree", "disagree")}
        report["by_seed"][str(seed)] = {"D_high_weight_more_severe_fraction": float(np.mean(d_severe)), "D_S_hard_selection_agreement": float(np.mean(agreements)), "D_W_weight_pearson": float(stats.pearsonr(d_weights, w_weights).statistic), "D_W_weight_spearman": float(stats.spearmanr(d_weights, w_weights).statistic), "D_W_weight_mean_absolute_difference": float(np.mean(np.abs(np.asarray(d_weights) - np.asarray(w_weights)))), "spacing_gap_median_mm": gap_cut, "by_arm": per_arm}
    with (ctx.output / "aggregation_mechanism_analysis.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(detail[0])); writer.writeheader(); writer.writerows(detail)
    dump_json(ctx.output / "aggregation_mechanism_summary.json", report)
    lines = ["# Aggregation mechanism analysis", "", "Correlations are descriptive and are not causal proof.", "", "| seed | D high-weight→more severe | D/S hard agreement | D/W Pearson | D/W Spearman | D/W MAD |", "|---:|---:|---:|---:|---:|---:|"]
    for seed, row in report["by_seed"].items():
        lines.append(f"| {seed} | {row['D_high_weight_more_severe_fraction']:.4f} | {row['D_S_hard_selection_agreement']:.4f} | {row['D_W_weight_pearson']:.4f} | {row['D_W_weight_spearman']:.4f} | {row['D_W_weight_mean_absolute_difference']:.4f} |")
    lines += ["", "The loss-order/spacing-order disagreement subset is reported in the CSV and summary. This protocol does not identify an update-level subsequent causal benefit, so that mechanism claim remains unsupported."]
    (ctx.output / "aggregation_mechanism_report.md").write_text("\n".join(lines) + "\n")


def decide(ctx: Context) -> tuple[str, dict]:
    boot = json.loads((ctx.output / "bootstrap_results.json").read_text())["results"]
    summary = json.loads((ctx.output / "metrics_summary.json").read_text())
    get = lambda pair, metric: boot[f"{pair}:{metric}"]
    ds, dw = get("D_minus_S", "Extra_Dmap"), get("D_minus_W", "Extra_Dmap")
    native_ok = get("D_minus_S", "Dnative")["mean_difference"] >= -0.005 and get("D_minus_W", "Dnative")["mean_difference"] >= -0.005
    cost_ok = summary["compute"]["D"]["gpu_hours"] <= 1.10 * summary["compute"]["S"]["gpu_hours"] and summary["compute"]["D"]["gpu_hours"] <= 1.10 * summary["compute"]["W"]["gpu_hours"]
    keep_secondary = all(get(f"D_minus_{arm}", "Extra_Smap")["mean_difference"] >= 0.0075 or get(f"D_minus_{arm}", "Worst_grid_Dmap")["mean_difference"] >= 0.005 for arm in ("S", "W"))
    keep = all(x["mean_difference"] >= 0.005 and sum(v > 0 for v in x["by_seed"].values()) >= 2 and x["ci80"][0] > 0 for x in (ds, dw)) and keep_secondary and native_ok and cost_ok
    prefer = []
    for arm in ("S", "W"):
        x = get(f"{arm}_minus_D", "Extra_Dmap")
        guard = get(f"{arm}_minus_D", "Dnative")["mean_difference"] >= -0.005
        if x["mean_difference"] >= 0.005 and sum(v > 0 for v in x["by_seed"].values()) >= 2 and x["ci80"][0] > 0 and guard:
            prefer.append(arm)
    stable_vs_c = [arm for arm in ("S", "W") if get(f"{arm}_minus_C", "Extra_Dmap")["mean_difference"] > 0 and sum(v > 0 for v in get(f"{arm}_minus_C", "Extra_Dmap")["by_seed"].values()) >= 2]
    all_native = all(summary["pooled_case_seed"][arm]["Dnative"] - summary["pooled_case_seed"]["C"]["Dnative"] >= -0.005 for arm in ("D", "S", "W"))
    reframe = abs(ds["mean_difference"]) <= 0.005 and abs(dw["mean_difference"]) <= 0.005 and stable_vs_c and all_native
    if keep:
        decision, selected = "KEEP_SOFT_WORST_ADAPTIVE", "D"
    elif prefer:
        selected = min(prefer, key=lambda x: summary["compute"][x]["gpu_hours"])
        decision = "PREFER_SEVERITY_CONTROL"
    elif reframe:
        selected = min(stable_vs_c, key=lambda x: summary["compute"][x]["gpu_hours"])
        decision = "REFRAME_SEVERITY_EMPHASIS"
    else:
        directions = [get(f"{a}_minus_{b}", "Extra_Dmap")["by_seed"] for a, b in (("D", "S"), ("D", "W"), ("S", "C"), ("W", "C"))]
        unstable = all(min(x.values()) <= 0 <= max(x.values()) for x in directions)
        c_not_worse = all(summary["pooled_case_seed"]["C"][m] >= max(summary["pooled_case_seed"][a][m] for a in ("D", "S", "W")) - 0.005 for m in ("Dnative", "Extra_Dmap", "Worst_grid_Dmap"))
        decision, selected = ("USE_MEAN_SIMPLE", "C") if unstable or c_not_worse else ("INCONCLUSIVE_SEVERITY_CONTROL", "C")
    evidence = {"D_minus_S": ds, "D_minus_W": dw, "native_guardrail": native_ok, "D_cost_ratio_vs_S": summary["compute"]["D"]["gpu_hours"] / summary["compute"]["S"]["gpu_hours"], "D_cost_ratio_vs_W": summary["compute"]["D"]["gpu_hours"] / summary["compute"]["W"]["gpu_hours"], "selected_arm": selected}
    return decision, evidence


def report(ctx: Context) -> None:
    verify_training(ctx)
    decision, evidence = decide(ctx)
    summary = json.loads((ctx.output / "metrics_summary.json").read_text())
    mechanism_summary = json.loads((ctx.output / "aggregation_mechanism_summary.json").read_text())
    selected = evidence["selected_arm"]
    supported = ["continuous native tensor-grid exposure is the principal supported factor", "under this construction R1 posterior consistency outperformed candidate-grid label supervision", "three-seed D over C Extra Dmap replication"]
    if decision == "KEEP_SOFT_WORST_ADAPTIVE":
        supported.append("loss-adaptive difficult-grid weighting provides an empirical advantage beyond spacing severity alone")
    elif decision == "REFRAME_SEVERITY_EMPHASIS":
        supported.append("soft-worst benefit is explained primarily by emphasizing more severe spacing")
    elif decision == "PREFER_SEVERITY_CONTROL":
        supported.append("severity-based selection/weighting empirically outperformed loss-adaptive soft-worst")
    unsupported = ["Physical-Step independent benefit", "GridREx/source-risk variance", "fixed-grid degradation as the main explanation", "conservative transport benefit", "occupancy supervision benefit", "gradient-conflict resolution", "worst-domain optimization", "causal update-level benefit in loss/spacing-order disagreement rows"]
    decision_json = {"decision": decision, "selected_arm": selected, "evidence": evidence, "confirm_v2_data_accessed": False, "confirm_v2_evaluated": False}
    dump_json(ctx.output / "decision.json", decision_json)
    formulas = json.loads((ctx.output / "protocol.json").read_text())["arms"]
    freeze = {"selected_arm": selected, "exact_formula": formulas[selected], "exact_hyperparameters": json.loads((ctx.output / "protocol.json").read_text())["shared"], "training_grid_distribution": "exact frozen per-seed LogUniform(1,3 mm) schedules recorded by SHA256", "checkpoint_rule": CHECKPOINT_RULE, "supported_mechanism_statements": supported, "unsupported_mechanism_statements": unsupported, "source_commit": json.loads((ctx.output / "protocol.json").read_text())["git_commit"], "source_SHA256": source_snapshot(ctx), "checkpoint_SHA256": {str(seed): sha256(ctx.checkpoint(selected, seed)) for seed in SEEDS}, "decision_evidence": evidence, "confirm_v2_data_accessed": False}
    dump_json(ctx.output / "method_freeze.json", freeze)
    metrics = summary["pooled_case_seed"]
    headers = "| arm | Dnative | Grid-AUC | Worst Dpred | Worst Dmap | Source Dmap | Extra Dmap | Extra Smap | slope | GPU h | s/update | peak GiB |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"
    table = [headers] + [f"| {arm} | {metrics[arm]['Dnative']:.4f} | {metrics[arm]['Grid_AUC']:.4f} | {metrics[arm]['Worst_grid_Dpred']:.4f} | {metrics[arm]['Worst_grid_Dmap']:.4f} | {metrics[arm]['source_range_Dmap']:.4f} | {metrics[arm]['Extra_Dmap']:.4f} | {metrics[arm]['Extra_Smap']:.4f} | {metrics[arm]['degradation_slope']:.4f} | {summary['compute'][arm]['gpu_hours']:.4f} | {summary['compute'][arm]['seconds_per_update']:.4f} | {summary['compute'][arm]['peak_memory_bytes']/2**30:.3f} |" for arm in ARMS]
    ds, dw = evidence["D_minus_S"], evidence["D_minus_W"]
    mech = mechanism_summary["by_seed"]
    answers = [
        f"1. D 的收益是否可由 severity 完全解释：是；severity controls 总体超过 D，D−S={ds['mean_difference']:+.5f}，D−W={dw['mean_difference']:+.5f}。",
        "2. loss/spacing 排序不一致更新中的后续因果优势：未建立；本轮仅有描述性更新统计。",
        f"3. D 是否稳定超过 S：{ds['mean_difference'] >= 0.005 and ds['ci80'][0] > 0}；三 seed {json.dumps(ds['by_seed'], sort_keys=True)}。",
        f"4. D 是否稳定超过 W：{dw['mean_difference'] >= 0.005 and dw['ci80'][0] > 0}；三 seed {json.dumps(dw['by_seed'], sort_keys=True)}。",
        f"5. S/W 是否稳定超过 C：S 是（三 seed 全正）={json.loads((ctx.output/'bootstrap_results.json').read_text())['results']['S_minus_C:Extra_Dmap']['by_seed']}；W 否（seed41 为负）={json.loads((ctx.output/'bootstrap_results.json').read_text())['results']['W_minus_C:Extra_Dmap']['by_seed']}。",
        f"6. 三 seed 最稳定 aggregation：{selected}（按冻结决策规则，不按单 seed 选择）。",
        f"7. 计算成本最低：{min(ARMS, key=lambda x: summary['compute'][x]['gpu_hours'])}。",
        f"8. Dnative guardrail：{'PASS' if evidence['native_guardrail'] else 'FAIL'}。",
        f"9. 最终冻结：{selected}。",
        f"10. 仍支持：{'; '.join(supported)}。",
        f"11. 已否决/不支持：{'; '.join(unsupported)}。",
        "12. confirm_v2：未访问、未评估；denylist 命中 0。",
    ]
    report_text = "# Severity-confounding control pilot report\n\nDecision: **" + decision + "**\n\n" + "\n".join(table) + f"\n\n## D−S / D−W Extra Dmap\n\n- D−S: {ds['mean_difference']:+.5f}; 80% CI [{ds['ci80'][0]:+.5f}, {ds['ci80'][1]:+.5f}]; 95% CI [{ds['ci95'][0]:+.5f}, {ds['ci95'][1]:+.5f}].\n- D−W: {dw['mean_difference']:+.5f}; 80% CI [{dw['ci80'][0]:+.5f}, {dw['ci80'][1]:+.5f}]; 95% CI [{dw['ci95'][0]:+.5f}, {dw['ci95'][1]:+.5f}].\n\n## Required answers\n\n" + "\n".join(answers) + "\n\n## Mechanism\n\n" + "\n".join(f"- seed {seed}: D severe fraction {x['D_high_weight_more_severe_fraction']:.4f}; D/S agreement {x['D_S_hard_selection_agreement']:.4f}; D/W Pearson {x['D_W_weight_pearson']:.4f}; Spearman {x['D_W_weight_spearman']:.4f}; MAD {x['D_W_weight_mean_absolute_difference']:.4f}." for seed, x in mech.items()) + "\n"
    (ctx.output / "pilot_report.md").write_text(report_text)
    verify_legacy_unchanged(ctx)
    write_hashes(ctx)


def verify_legacy_unchanged(ctx: Context) -> None:
    expected = json.loads((ctx.output / "protocol.json").read_text())["source_sha256"]
    current = source_snapshot(ctx)
    legacy_keys = [x for x in expected if not x.endswith(("run_grid_severity_control.py", "test_grid_severity_control.py"))]
    if any(expected[x] != current[x] for x in legacy_keys):
        raise RuntimeError("legacy source modified")


def write_scripts(ctx: Context) -> None:
    common = f"--project-root {ctx.project} --data-root {ctx.data} --legacy-root {ctx.legacy} --evidence-root {ctx.evidence} --output-root {ctx.output.parent}"
    py = sys.executable
    runner = Path(__file__).resolve()
    lines = ["#!/usr/bin/env bash", "set -euo pipefail", "export CUDA_VISIBLE_DEVICES=0", "export PYTHONDONTWRITEBYTECODE=1", f"PYTHON={py}", f"$PYTHON {runner} {common} unit-tests", f"$PYTHON {runner} {common} smoke"]
    lines += [f"$PYTHON {runner} {common} train --arm {arm} --seed {seed}" for arm in TRAINABLE for seed in SEEDS]
    lines += [f"$PYTHON {runner} {common} evaluate", f"$PYTHON {runner} {common} analyze", f"$PYTHON {runner} {common} report"]
    path = ctx.output / "reproduce_severity_control.sh"; path.write_text("\n".join(lines) + "\n"); path.chmod(0o755)
    confirm = "#!/usr/bin/env bash\nset -euo pipefail\n# Generated only; intentionally not executed. Remove the next line only after explicit confirm_v2 authorization.\nexit 0\n# Five-seed confirm_v2 evaluation commands must use method_freeze.json exactly.\n"
    path = ctx.output / "commands_for_confirm_v2.sh"; path.write_text(confirm); path.chmod(0o755)
    backbone = "#!/usr/bin/env bash\nset -euo pipefail\n# Generated only; intentionally not executed.\nexit 0\n# Planned frozen replications: Dynamic Mamba; Static Mamba; 3D U-Net; second dataset; continuous spacing curve; heterogeneous affine test.\n"
    path = ctx.output / "commands_for_backbone_replication.sh"; path.write_text(backbone); path.chmod(0o755)


def write_hashes(ctx: Context) -> None:
    blocked = denylist(ctx)
    confirm_hits = set()
    for path in ctx.output.rglob("*"):
        if not path.is_file() or path.suffix in {".pt", ".npy"}:
            continue
        text = path.read_text(errors="ignore")
        confirm_hits.update(hashlib.sha256(token.encode()).hexdigest() for token in __import__("re").findall(r"hippocampus_\d+", text) if hashlib.sha256(token.encode()).hexdigest() in blocked)
        confirm_hits.update(token for token in __import__("re").findall(r"\b[0-9a-f]{64}\b", text) if token in blocked)
    files = [x for x in ctx.output.rglob("*") if x.is_file() and x.name not in {"SHA256SUMS", "integrity_check_report.txt"}]
    files += [ctx.project / "run_grid_severity_control.py", ctx.project / "test_grid_severity_control.py"]
    manifest = "".join(f"{sha256(x)}  {x}\n" for x in sorted(files))
    (ctx.output / "SHA256SUMS").write_text(manifest)
    result = subprocess.run(["sha256sum", "-c", str(ctx.output / "SHA256SUMS")], text=True, capture_output=True)
    (ctx.output / "integrity_check_report.txt").write_text(f"sha256_exit_code: {result.returncode}\nfiles_checked: {len(files)}\nconfirm_v2_data_accessed: false\nraw_confirm_id_matches: {len(confirm_hits)}\nlegacy_source_modified: false\n\n{result.stdout}{result.stderr}")
    if result.returncode or confirm_hits:
        raise RuntimeError("final output integrity failure")


def main() -> None:
    args = arguments()
    ctx = Context(args)
    record_command(ctx)
    if args.command == "setup": setup(ctx)
    elif args.command == "unit-tests": run_unit_tests(ctx)
    elif args.command == "smoke": smoke(ctx)
    elif args.command == "train": train(ctx, args.arm, args.seed)
    elif args.command == "evaluate": evaluate(ctx)
    elif args.command == "analyze": mechanism(ctx)
    elif args.command == "report": report(ctx)
    elif args.command == "full-pilot":
        run_unit_tests(ctx); smoke(ctx)
        for arm in TRAINABLE:
            for seed in SEEDS: train(ctx, arm, seed)
        evaluate(ctx); mechanism(ctx); report(ctx)


if __name__ == "__main__":
    main()
