#!/usr/bin/env python
"""Causal source audit for grid-resampling training effects."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import random
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from model import TinyMetricMamba, parameter_count
from physical_resampler import AffineResampler3D
from run_physgrid_pilot import (
    binary_dice,
    crop5,
    disagreement,
    load_grid,
    load_raw_image,
    loss_fn,
    model_logits,
    normalize_candidate,
    pad4,
    surface_dice,
    target_grid,
)


ARMS = (
    "fixed_k1",
    "fixed_k2",
    "random_k1",
    "random_k2",
    "degrade_on_r1",
    "native_random",
    "label_supervised_random",
    "soft_worst_random",
)
TRAINABLE = ("random_k1", "degrade_on_r1", "label_supervised_random", "random_k2", "soft_worst_random")
NEW_SEED17 = ("random_k1", "degrade_on_r1", "label_supervised_random")
SPACINGS = (1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0)
UPDATES = 2500
VALIDATE_EVERY = 250
LAMBDA_MAX = 0.1
TAU = 5.0
BOOTSTRAPS = 10_000
BOOTSTRAP_SEED = 7321


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def object_hash(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def seed_all(seed: int) -> None:
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False; torch.backends.cudnn.deterministic = True


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    for name in ("project-root", "data-root", "legacy-root", "previous-output", "output-root"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("setup")
    sub.add_parser("unit-tests")
    smoke = sub.add_parser("smoke"); smoke.add_argument("--arm", choices=NEW_SEED17 + ("all",), default="all")
    train = sub.add_parser("train"); train.add_argument("--arm", choices=TRAINABLE, required=True); train.add_argument("--seed", type=int, default=17)
    sub.add_parser("evaluate")
    sub.add_parser("three-seed-dc")
    sub.add_parser("report")
    sub.add_parser("full-pilot")
    return parser.parse_args()


class Context:
    def __init__(self, args: argparse.Namespace):
        self.project = args.project_root.resolve(); self.data = args.data_root.resolve(); self.legacy = args.legacy_root.resolve()
        self.previous = args.previous_output.resolve(); self.output = args.output_root.resolve() / "grid_causal_audit"
        if self.project != Path(__file__).resolve().parent:
            raise RuntimeError("--project-root must identify this script's directory")
        if self.output in (self.project, self.data, self.legacy, self.previous):
            raise RuntimeError("output directory must be independent of frozen inputs")
        self.manifest_path = self.legacy / "outputs" / "manifest.json"
        self.manifest = json.loads(self.manifest_path.read_text())
        if self.manifest.get("manifest_hash") != object_hash({k: v for k, v in self.manifest.items() if k != "manifest_hash"}):
            raise RuntimeError("legacy manifest internal hash mismatch")

    def cache(self, case_id: str, grid: str, kind: str) -> Path:
        path = self.legacy / "cache" / case_id / f"{grid}_{kind}.npy"
        if not path.is_file(): raise FileNotFoundError(path)
        return path

    def checkpoint(self, arm: str, seed: int = 17, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / "checkpoints" / f"{arm}_seed{seed}.pt"

    def log(self, arm: str, seed: int = 17, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / f"train_{arm}_seed{seed}.json"


def require_cuda() -> torch.device:
    if os.environ.get("CUDA_VISIBLE_DEVICES") != "0" or not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly CUDA_VISIBLE_DEVICES=0 is required")
    return torch.device("cuda:0")


def record_command(ctx: Context) -> None:
    ctx.output.mkdir(parents=True, exist_ok=True)
    with (ctx.output / "command_ledger.jsonl").open("a") as handle:
        handle.write(json.dumps({"argv": sys.argv, "cwd": str(Path.cwd()), "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"), "time_unix": time.time()}, sort_keys=True) + "\n")


def frozen_schedule(case_ids: list[str], seed: int, updates: int = UPDATES) -> list[dict]:
    case_rng, grid_rng, order, rows = np.random.default_rng(seed), np.random.default_rng(seed + 1), [], []
    for update in range(1, updates + 1):
        if not order: order = case_rng.permutation(len(case_ids)).tolist()
        rows.append({"update": update, "case_id": case_ids[order.pop()], "spacing_1": float(np.exp(grid_rng.uniform(0.0, math.log(3.0)))), "spacing_2": float(np.exp(grid_rng.uniform(0.0, math.log(3.0))))})
    return rows


def verify_frozen(ctx: Context) -> tuple[list[str], set[str]]:
    check = subprocess.run(["sha256sum", "-c", str(ctx.previous / "SHA256SUMS")], cwd=ctx.previous, stdout=subprocess.DEVNULL)
    if check.returncode: raise RuntimeError("previous pilot SHA256 check failed")
    dev = json.loads((ctx.previous / "split_manifest_dev.json").read_text())["split"]
    locked = json.loads((ctx.previous / "split_manifest_confirm_v2_locked.json").read_text())
    groups = [set(dev[x]) for x in ("train", "validation", "development_screen")] + [set(locked["case_ids"])]
    if [len(x) for x in groups] != [80, 20, 20, 40] or any(groups[i] & groups[j] for i in range(4) for j in range(i + 1, 4)):
        raise RuntimeError("data isolation failure")
    deny = {hashlib.sha256(x.encode()).hexdigest() for x in locked["case_ids"]}
    return dev["development_screen"], deny


def link(path: Path, target: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        if path.resolve() != target.resolve(): raise RuntimeError(f"wrong existing alias: {path}")
    else: path.symlink_to(target)


def setup(ctx: Context) -> None:
    development, deny = verify_frozen(ctx)
    train_ids = ctx.manifest["split"]["train"]
    schedule = frozen_schedule(train_ids, 17)
    prior_mean = json.loads((ctx.previous / "train_randomgrid_mean_seed17.json").read_text())["history"]
    if any([row["spacing_1"], row["spacing_2"]] != prior_mean[i]["sampled_spacing_requested"] for i, row in enumerate(schedule)):
        raise RuntimeError("reconstructed seed17 spacing schedule differs from frozen current C")
    with (ctx.output / "grid_schedule_seed17.jsonl").open("w") as handle:
        for row in schedule: handle.write(json.dumps(row, sort_keys=True) + "\n")
    (ctx.output / "grid_schedule_seed17.sha256").write_text(f"{sha256(ctx.output / 'grid_schedule_seed17.jsonl')}  {ctx.output / 'grid_schedule_seed17.jsonl'}\n")
    dump_json(ctx.output / "confirm_denylist.json", {"algorithm": "sha256(case_id UTF-8)", "count": len(deny), "hashes": sorted(deny), "confirm_data_accessed": False})
    aliases = {
        "fixed_k1": ctx.previous / "checkpoints" / "legacy_fixed_gridcons_seed17.pt",
        "fixed_k2": ctx.previous / "checkpoints" / "legacy_fixed_gridcons_seed17.pt",
        "random_k2": ctx.previous / "checkpoints" / "randomgrid_mean_seed17.pt",
        "native_random": ctx.previous / "checkpoints" / "randomgrid_mean_seed17.pt",
        "soft_worst_random": ctx.previous / "checkpoints" / "randomgrid_worst_seed17.pt",
    }
    for arm, target in aliases.items(): link(ctx.checkpoint(arm), target)
    provenance = {
        arm: {"alias": str(target), "checkpoint_sha256": sha256(target), "completed": True, "seed": 17, "updates": UPDATES, "checkpoint_selection": "R1 validation foreground Dice only"}
        for arm, target in aliases.items()
    }
    for arm, value in provenance.items(): dump_json(ctx.log(arm), value)
    commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ctx.project, text=True, capture_output=True, check=True).stdout.strip()
    branch = subprocess.run(["git", "branch", "--show-current"], cwd=ctx.project, text=True, capture_output=True, check=True).stdout.strip()
    protocol = {
        "name": "Grid resampling causal source audit", "git_commit": commit, "git_branch": branch, "seed17_arms": list(ARMS), "updates": UPDATES,
        "backbone": "Static Mamba, 99,411 parameters", "optimizer": "AdamW", "learning_rate": 3e-4, "weight_decay": 1e-5,
        "batch_size": 1, "amp": "bfloat16", "augmentation": "none", "lambda_max": LAMBDA_MAX, "warmup_updates": 500,
        "checkpoint_selection": "R1 validation foreground Dice only; ties earliest", "evaluation_spacings_mm": list(SPACINGS),
        "arm_definitions": {
            "fixed_k1": "one fixed native 2mm consistency view; frozen original baseline",
            "fixed_k2": "two identical fixed 2mm views; exact mean-loss/gradient alias of fixed_k1 because the model has no stochastic layers",
            "random_k1": "first frozen continuous-spacing draw; one native-grid consistency view",
            "random_k2": "both frozen continuous-spacing draws; mean consistency; frozen current C",
            "degrade_on_r1": "both frozen spacing draws downsample raw image then restore raw image to R1 before normalization/forward; R1 tensor grid",
            "native_random": "exact alias of random_k2/current C; direct native-grid forwards",
            "label_supervised_random": "both native random grids with nearest-neighbor in-memory R1-label resampling and ordinary segmentation loss",
            "soft_worst_random": "both native random grids, stop-gradient softmax(5*error) weighting; frozen current D",
        },
        "preregistered_interpretation": {
            "material_native_geometry_gain": "native_random - degrade_on_r1 extrapolation Dmap >= 0.010 and 80% paired-bootstrap CI lower > 0",
            "degradation_dominant": "material native geometry gain fails and absolute extrapolation Dmap difference < 0.010",
            "label_supervision_not_weaker": "label_supervised_random - random_k2 extrapolation Dmap >= -0.005 and 80% paired-bootstrap CI lower >= -0.005",
            "soft_worst_reproducible": "D-C extrapolation Dmap difference > 0 for each of seeds 17,29,41 and three-seed mean >= 0.010",
        },
        "bootstrap": {"iterations": BOOTSTRAPS, "seed": BOOTSTRAP_SEED, "unit": "case"},
        "confirm_v2_evaluated": False, "confirm_v2_data_accessed": False,
        "source_sha256": {name: sha256(ctx.project / name) for name in ("model.py", "physical_resampler.py", "run_physgrid_pilot.py", "run_grid_causal_audit.py", "test_grid_causal_audit.py")},
        "frozen_previous_sha256sum_sha256": sha256(ctx.previous / "SHA256SUMS"), "manifest_sha256": sha256(ctx.manifest_path), "development_cases": len(development),
    }
    dump_json(ctx.output / "protocol.json", protocol)
    subprocess.run(["nvidia-smi"], stdout=(ctx.output / "nvidia_smi.txt").open("w"), text=True, check=True)
    subprocess.run([sys.executable, "-m", "pip", "freeze"], stdout=(ctx.output / "environment_freeze.txt").open("w"), text=True, check=True)
    common = f"--project-root {ctx.project} --data-root {ctx.data} --legacy-root {ctx.legacy} --previous-output {ctx.previous} --output-root {ctx.output.parent}"
    lines = ["#!/usr/bin/env bash", "set -euo pipefail", "export CUDA_VISIBLE_DEVICES=0", "export PYTHONDONTWRITEBYTECODE=1", f"PYTHON={sys.executable}", f"$PYTHON {Path(__file__)} {common} unit-tests", f"$PYTHON {Path(__file__)} {common} smoke --arm all"]
    lines += [f"$PYTHON {Path(__file__)} {common} train --arm {arm} --seed 17" for arm in NEW_SEED17]
    lines += [f"$PYTHON {Path(__file__)} {common} evaluate", f"$PYTHON {Path(__file__)} {common} three-seed-dc", f"$PYTHON {Path(__file__)} {common} report"]
    path = ctx.output / "reproduce_audit.sh"; path.write_text("\n".join(lines) + "\n"); path.chmod(0o755)


def load_schedule(ctx: Context, seed: int, smoke: bool = False) -> list[dict]:
    case_ids = ctx.manifest["split"]["train"][:2] if smoke else ctx.manifest["split"]["train"]
    if seed == 17 and not smoke:
        rows = [json.loads(x) for x in (ctx.output / "grid_schedule_seed17.jsonl").read_text().splitlines()]
        if [x["case_id"] for x in rows] != [x["case_id"] for x in frozen_schedule(case_ids, seed)]: raise RuntimeError("schedule case order mismatch")
        return rows
    return frozen_schedule(case_ids, seed, 20 if smoke else UPDATES)


@torch.inference_mode()
def validation_dice(ctx: Context, model: torch.nn.Module, device: torch.device) -> float:
    scores = []; model.eval()
    for case_id in ctx.manifest["split"]["validation"]:
        image, label = load_grid(ctx, case_id, "R1"); shape = ctx.manifest["cases"][case_id]["grids"]["R1"]["unpadded_shape_dhw"]
        with torch.autocast("cuda", dtype=torch.bfloat16): hard = crop5(model_logits(model, torch.from_numpy(image).to(device)[None, None], [1, 1, 1]), shape).argmax(1)[0].cpu().numpy()
        slices = tuple(slice(0, n) for n in shape)
        scores += [binary_dice(hard == cls, label[slices] == cls) for cls in (1, 2)]
    return float(np.mean(scores))


def train(ctx: Context, arm: str, seed: int, updates: int = UPDATES, smoke: bool = False) -> dict:
    if arm not in TRAINABLE: raise ValueError(arm)
    if seed == 17 and arm in ("random_k2", "soft_worst_random") and not smoke: return json.loads(ctx.log(arm).read_text())
    device = require_cuda(); checkpoint, log_path = ctx.checkpoint(arm, seed, smoke), ctx.log(arm, seed, smoke)
    if checkpoint.is_file() and log_path.is_file():
        old = json.loads(log_path.read_text())
        if old.get("completed") and old.get("updates") == updates and old.get("checkpoint_sha256") == sha256(checkpoint): return old
    seed_all(seed); model = TinyMetricMamba("separated_physical_delta").to(device); optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-5)
    resampler = AffineResampler3D(); schedule = load_schedule(ctx, seed, smoke); history, best, best_update = [], -1.0, 0
    checkpoint.parent.mkdir(parents=True, exist_ok=True); torch.cuda.reset_peak_memory_stats(); torch.cuda.synchronize(); started = time.perf_counter()
    for item in schedule[:updates]:
        update, case_id = item["update"], item["case_id"]
        case, r1 = ctx.manifest["cases"][case_id], ctx.manifest["cases"][case_id]["grids"]["R1"]
        shape = r1["unpadded_shape_dhw"]; image, label_array = load_grid(ctx, case_id, "R1")
        x1 = torch.from_numpy(image).to(device)[None, None]; y1 = torch.from_numpy(label_array.astype(np.int64)).to(device)[None]
        affine = torch.tensor(r1["affine_xyz"], dtype=torch.float64, device=device); raw, raw_affine = load_raw_image(ctx, case_id, device)
        optimizer.zero_grad(set_to_none=True); model.train()
        with torch.autocast("cuda", dtype=torch.bfloat16):
            z1 = model_logits(model, x1, [1, 1, 1]); native_loss = loss_fn(z1, y1); teacher = crop5(z1, shape).float().softmax(1)[:, 1:].detach()
            requested = [item["spacing_1"]] if arm == "random_k1" else [item["spacing_1"], item["spacing_2"]]
            auxiliary, actuals = [], []
            for spacing in requested:
                target_shape, target_affine, actual = target_grid(affine, shape, spacing)
                raw_candidate = resampler.image(raw, raw_affine, target_shape, target_affine)
                if arm == "degrade_on_r1":
                    restored = resampler.image(raw_candidate, target_affine, shape, affine)
                    candidate = pad4(normalize_candidate(restored, case["r1_nonbackground_mean"], case["r1_nonbackground_std"]))
                    logits = model_logits(model, candidate, [1, 1, 1]); mapped = crop5(logits, shape).float().softmax(1)[:, 1:]
                    auxiliary.append(disagreement(teacher, mapped))
                else:
                    candidate = pad4(normalize_candidate(raw_candidate, case["r1_nonbackground_mean"], case["r1_nonbackground_std"]))
                    logits = model_logits(model, candidate, [actual, 1, 1])
                    if arm == "label_supervised_random":
                        source_label = crop5(y1[:, None], shape)
                        candidate_label = resampler.label(source_label, affine, target_shape, target_affine)[:, 0].long()
                        auxiliary.append(loss_fn(crop5(logits, target_shape), candidate_label))
                    else:
                        probability = crop5(logits, target_shape).float().softmax(1)
                        mapped = resampler.probability(probability, target_affine, shape, affine)[:, 1:]
                        auxiliary.append(disagreement(teacher, mapped))
                actuals.append(actual)
            values = torch.stack(auxiliary)
            weights = torch.softmax(TAU * values, 0).detach() if arm == "soft_worst_random" else torch.full_like(values, 1 / len(values))
            aux = (weights * values).sum(); weight = LAMBDA_MAX * min(1.0, update / 500); total = native_loss + weight * aux
        if not torch.isfinite(total): raise FloatingPointError(f"non-finite loss at {update}")
        total.backward(); gradients = [p.grad.float() for p in model.parameters() if p.grad is not None]
        if not gradients or not all(torch.isfinite(x).all() for x in gradients): raise FloatingPointError(f"non-finite gradient at {update}")
        grad_norm = float(torch.sqrt(sum(x.square().sum() for x in gradients))); optimizer.step()
        row = {"update": update, "case_id_hash": hashlib.sha256(case_id.encode()).hexdigest(), "requested_spacings": requested, "actual_spacings": actuals, "native_loss": float(native_loss), "auxiliary_losses": [float(x) for x in values], "auxiliary_loss": float(aux), "lambda": weight, "total_loss": float(total), "gradient_norm": grad_norm}
        history.append(row)
        if update % VALIDATE_EVERY == 0 or update == updates:
            score = validation_dice(ctx, model, device); row["validation_r1_foreground_dice"] = score
            print(arm, seed, {"update": update, "loss": float(total), "validation": score}, flush=True)
            if score > best:
                best, best_update = score, update
                torch.save({"model_state": model.state_dict(), "arm": arm, "seed": seed, "update": update, "validation_r1_foreground_dice": score, "selection": "R1 validation foreground Dice only"}, checkpoint)
    torch.cuda.synchronize(); elapsed = time.perf_counter() - started; props = torch.cuda.get_device_properties(0)
    log = {"completed": True, "finite": True, "arm": arm, "seed": seed, "updates": updates, "history": history, "best_validation_r1_foreground_dice": best, "best_update": best_update, "checkpoint": str(checkpoint), "checkpoint_sha256": sha256(checkpoint), "checkpoint_selection": "R1 validation foreground Dice only", "parameter_count": parameter_count(model), "training_seconds": elapsed, "seconds_per_update": elapsed / updates, "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved(), "gpu_total_memory_bytes": props.total_memory}
    dump_json(log_path, log); return log


def run_unit_tests(ctx: Context) -> None:
    setup(ctx); env = dict(os.environ, CUDA_VISIBLE_DEVICES="0", PYTHONDONTWRITEBYTECODE="1"); started = time.perf_counter()
    result = subprocess.run([sys.executable, "-m", "unittest", "-v", "test_grid_causal_audit.py"], cwd=ctx.project, env=env, text=True, capture_output=True)
    (ctx.output / "unit_test_report.txt").write_text(f"exit_code: {result.returncode}\nelapsed_seconds: {time.perf_counter()-started:.6f}\n\nSTDOUT\n{result.stdout}\nSTDERR\n{result.stderr}")
    if result.returncode: raise RuntimeError("unit tests failed; training forbidden")


def smoke(ctx: Context, arm: str) -> None:
    if "exit_code: 0" not in (ctx.output / "unit_test_report.txt").read_text(): raise RuntimeError("passing tests required")
    selected = NEW_SEED17 if arm == "all" else (arm,); logs = [train(ctx, x, 17, 20, True) for x in selected]
    passed = all(x["finite"] and x["peak_reserved_bytes"] < 0.9 * x["gpu_total_memory_bytes"] for x in logs)
    lines = ["# Smoke test", "", "| arm | loss | gradient norm | peak GiB | resume/hash |", "|---|---:|---:|---:|---|"]
    for x in logs:
        resumed = train(ctx, x["arm"], 17, 20, True)
        lines.append(f"| {x['arm']} | {x['history'][-1]['total_loss']:.6f} | {x['history'][-1]['gradient_norm']:.6f} | {x['peak_reserved_bytes']/2**30:.3f} | {'PASS' if resumed['checkpoint_sha256']==x['checkpoint_sha256'] else 'FAIL'} |")
    lines += ["", f"Result: {'PASS' if passed else 'FAIL'}"]
    (ctx.output / "smoke_test_report.md").write_text("\n".join(lines) + "\n")
    if not passed: raise RuntimeError("smoke failed")


def load_model(ctx: Context, arm: str, seed: int, device: torch.device) -> torch.nn.Module:
    path = ctx.checkpoint(arm, seed); saved = torch.load(path, map_location=device, weights_only=False)
    model = TinyMetricMamba("separated_physical_delta").to(device); model.load_state_dict(saved["model_state"], strict=True); return model.eval()


@torch.inference_mode()
def evaluate_model(ctx: Context, arm: str, seed: int, device: torch.device, deny: set[str]) -> list[dict]:
    model = load_model(ctx, arm, seed, device); resampler = AffineResampler3D(); rows = []
    for case_id in ctx.manifest["split"]["test"]:
        if hashlib.sha256(case_id.encode()).hexdigest() in deny: raise RuntimeError("denylisted case requested")
        case, r1 = ctx.manifest["cases"][case_id], ctx.manifest["cases"][case_id]["grids"]["R1"]
        shape = r1["unpadded_shape_dhw"]; image, padded_label = load_grid(ctx, case_id, "R1"); label = padded_label[tuple(slice(0, n) for n in shape)]
        affine = torch.tensor(r1["affine_xyz"], dtype=torch.float64, device=device); raw, raw_affine = load_raw_image(ctx, case_id, device)
        with torch.autocast("cuda", dtype=torch.bfloat16): r1_probability = crop5(model_logits(model, torch.from_numpy(image).to(device)[None, None], [1, 1, 1]), shape).float().softmax(1)
        r1_hard = r1_probability.argmax(1)[0].cpu().numpy()
        for nominal in SPACINGS:
            if nominal == 1: mapped, actual = r1_probability, 1.0
            else:
                target_shape, target_affine, actual = target_grid(affine, shape, nominal); raw_candidate = resampler.image(raw, raw_affine, target_shape, target_affine)
                candidate = pad4(normalize_candidate(raw_candidate, case["r1_nonbackground_mean"], case["r1_nonbackground_std"]))
                with torch.autocast("cuda", dtype=torch.bfloat16): probability = crop5(model_logits(model, candidate, [actual, 1, 1]), target_shape).float().softmax(1)
                mapped = resampler.probability(probability, target_affine, shape, affine)
            hard = mapped.argmax(1)[0].cpu().numpy()
            for cls, name in ((0, "foreground"), (1, "anterior"), (2, "posterior")):
                prediction = hard != 0 if cls == 0 else hard == cls; reference = r1_hard != 0 if cls == 0 else r1_hard == cls; truth = label != 0 if cls == 0 else label == cls
                rows.append({"case_id": case_id, "arm": arm, "seed": seed, "spacing_nominal_mm": nominal, "spacing_actual_mm": actual, "class": name, "Dpred": binary_dice(prediction, reference), "Dmap": binary_dice(prediction, truth), "Smap": surface_dice(prediction, truth), "Dnative": binary_dice(reference, truth)})
    return rows


def prior_rows(ctx: Context) -> list[dict]:
    mapping = {"legacy_fixed_gridcons": ("fixed_k1", "fixed_k2"), "randomgrid_mean": ("random_k2", "native_random"), "randomgrid_worst": ("soft_worst_random",)}; rows = []
    with (ctx.previous / "metrics_case_level.csv").open() as handle:
        for source in csv.DictReader(handle):
            if source["method"] not in mapping: continue
            for arm in mapping[source["method"]]:
                row = {"case_id": source["case_id"], "arm": arm, "seed": 17, "spacing_nominal_mm": float(source["spacing_nominal_mm"]), "spacing_actual_mm": float(source["spacing_actual_mm"]), "class": source["class"]}
                row.update({k: float(source[k]) for k in ("Dpred", "Dmap", "Smap", "Dnative")}); rows.append(row)
    return rows


def case_summary(rows: list[dict]) -> list[dict]:
    foreground = [x for x in rows if x["class"] == "foreground"]; result = []
    for (arm, seed, case_id) in sorted({(x["arm"], x["seed"], x["case_id"]) for x in foreground}):
        grid = {float(x["spacing_nominal_mm"]): x for x in foreground if (x["arm"], x["seed"], x["case_id"]) == (arm, seed, case_id)}
        source = [grid[x] for x in (1.5, 2.0, 2.5, 3.0)]; extra = [grid[x] for x in (4.0, 5.0)]; non_r1 = [grid[x] for x in SPACINGS[1:]]
        result.append({"arm": arm, "seed": seed, "case_id": case_id, "Dnative": grid[1.0]["Dnative"], "grid_auc_dpred": float(np.trapz([x["Dpred"] for x in non_r1], SPACINGS[1:]) / 3.5), "worst_grid_Dpred": min(x["Dpred"] for x in non_r1), "worst_grid_Dmap": min(x["Dmap"] for x in non_r1), "source_mean_Dmap": float(np.mean([x["Dmap"] for x in source])), "extrapolation_Dmap": float(np.mean([x["Dmap"] for x in extra])), "extrapolation_Smap": float(np.mean([x["Smap"] for x in extra]))})
    return result


def evaluate(ctx: Context) -> None:
    device = require_cuda(); _, deny = verify_frozen(ctx); rows = prior_rows(ctx)
    for arm in NEW_SEED17:
        log = json.loads(ctx.log(arm).read_text())
        if not log.get("completed") or log.get("checkpoint_sha256") != sha256(ctx.checkpoint(arm)): raise RuntimeError(f"incomplete training: {arm}")
        rows += evaluate_model(ctx, arm, 17, device, deny)
    with (ctx.output / "metrics_case_level.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    cases = case_summary(rows)
    with (ctx.output / "metrics_case_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(cases[0])); writer.writeheader(); writer.writerows(cases)


def bootstrap_difference(cases: list[dict], treatment: str, control: str, metric: str) -> dict:
    a = {x["case_id"]: x[metric] for x in cases if x["arm"] == treatment and x["seed"] == 17}; b = {x["case_id"]: x[metric] for x in cases if x["arm"] == control and x["seed"] == 17}
    ids = sorted(a); values = np.asarray([a[x] - b[x] for x in ids]); rng = np.random.default_rng(BOOTSTRAP_SEED); means = np.asarray([values[rng.integers(0, len(values), len(values))].mean() for _ in range(BOOTSTRAPS)])
    return {"treatment": treatment, "control": control, "metric": metric, "mean_difference": float(values.mean()), "median_difference": float(np.median(values)), "positive_cases": int((values > 0).sum()), "ci80": [float(x) for x in np.quantile(means, [0.1, 0.9])], "ci95": [float(x) for x in np.quantile(means, [0.025, 0.975])], "per_case": values.tolist()}


def three_seed_dc(ctx: Context) -> None:
    device = require_cuda(); _, deny = verify_frozen(ctx); rows = []
    previous = prior_rows(ctx); rows += [x for x in previous if x["arm"] in ("random_k2", "soft_worst_random")]
    for seed in (29, 41):
        for arm in ("random_k2", "soft_worst_random"):
            train(ctx, arm, seed); rows += evaluate_model(ctx, arm, seed, device, deny)
    cases = case_summary(rows)
    with (ctx.output / "dc_three_seed_case_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(cases[0])); writer.writeheader(); writer.writerows(cases)
    summary = {}
    for seed in (17, 29, 41):
        d = [x["extrapolation_Dmap"] for x in cases if x["seed"] == seed and x["arm"] == "soft_worst_random"]
        c = [x["extrapolation_Dmap"] for x in cases if x["seed"] == seed and x["arm"] == "random_k2"]
        summary[str(seed)] = {"D_minus_C_extrapolation_Dmap": float(np.mean(np.asarray(d) - np.asarray(c))), "positive_cases": int(np.sum(np.asarray(d) - np.asarray(c) > 0))}
    values = [x["D_minus_C_extrapolation_Dmap"] for x in summary.values()]
    dump_json(ctx.output / "dc_three_seed_summary.json", {"by_seed": summary, "mean_D_minus_C_extrapolation_Dmap": float(np.mean(values)), "reproduced_positive_all_three": all(x > 0 for x in values), "passes_preregistered_rule": bool(all(x > 0 for x in values) and np.mean(values) >= 0.010)})


def report(ctx: Context) -> None:
    with (ctx.output / "metrics_case_summary.csv").open() as handle: cases = list(csv.DictReader(handle))
    for row in cases:
        row["seed"] = int(row["seed"])
        for key in row.keys() - {"arm", "case_id", "seed"}: row[key] = float(row[key])
    metrics = ("Dnative", "grid_auc_dpred", "worst_grid_Dpred", "worst_grid_Dmap", "source_mean_Dmap", "extrapolation_Dmap", "extrapolation_Smap")
    summary = {arm: {metric: float(np.mean([x[metric] for x in cases if x["arm"] == arm])) for metric in metrics} for arm in ARMS}
    comparisons = [bootstrap_difference(cases, a, b, m) for a, b in (("native_random", "degrade_on_r1"), ("label_supervised_random", "random_k2"), ("random_k2", "random_k1"), ("soft_worst_random", "random_k2"), ("soft_worst_random", "random_k1")) for m in ("extrapolation_Dmap", "extrapolation_Smap", "worst_grid_Dmap")]
    lookup = {(x["treatment"], x["control"], x["metric"]): x for x in comparisons}; geometry = lookup[("native_random", "degrade_on_r1", "extrapolation_Dmap")]; labels = lookup[("label_supervised_random", "random_k2", "extrapolation_Dmap")]
    random_views = lookup[("random_k2", "random_k1", "extrapolation_Dmap")]
    soft_worst = lookup[("soft_worst_random", "random_k2", "extrapolation_Dmap")]
    soft_vs_k1 = lookup[("soft_worst_random", "random_k1", "extrapolation_Dmap")]
    dc = json.loads((ctx.output / "dc_three_seed_summary.json").read_text()) if (ctx.output / "dc_three_seed_summary.json").is_file() else None
    conclusions = {
        "native_geometry_material": geometry["mean_difference"] >= 0.010 and geometry["ci80"][0] > 0,
        "degradation_dominant": abs(geometry["mean_difference"]) < 0.010 and not (geometry["mean_difference"] >= 0.010 and geometry["ci80"][0] > 0),
        "ordinary_label_supervision_not_weaker": labels["mean_difference"] >= -0.005 and labels["ci80"][0] >= -0.005,
        "soft_worst_three_seed_reproducible": None if dc is None else dc["passes_preregistered_rule"],
    }
    dump_json(ctx.output / "metrics_summary.json", {"by_arm": summary, "comparisons": comparisons, "conclusions": conclusions, "confirm_v2_evaluated": False})
    headers = "| arm | Dnative | Grid-AUC | Worst Dpred | Worst Dmap | Source Dmap | Extra Dmap | Extra Smap |\n|---|---:|---:|---:|---:|---:|---:|---:|"
    table = [headers] + [f"| {arm} | {summary[arm]['Dnative']:.4f} | {summary[arm]['grid_auc_dpred']:.4f} | {summary[arm]['worst_grid_Dpred']:.4f} | {summary[arm]['worst_grid_Dmap']:.4f} | {summary[arm]['source_mean_Dmap']:.4f} | {summary[arm]['extrapolation_Dmap']:.4f} | {summary[arm]['extrapolation_Smap']:.4f} |" for arm in ARMS]
    report_text = f"""# Grid resampling causal source audit

{chr(10).join(table)}

## Preregistered comparisons

- Native-random - Degrade-on-R1 extrapolation Dmap: {geometry['mean_difference']:+.4f}, 80% CI [{geometry['ci80'][0]:+.4f}, {geometry['ci80'][1]:+.4f}], positive cases {geometry['positive_cases']}/20.
- Label-supervised random - Random-K2 extrapolation Dmap: {labels['mean_difference']:+.4f}, 80% CI [{labels['ci80'][0]:+.4f}, {labels['ci80'][1]:+.4f}], positive cases {labels['positive_cases']}/20.
- Random-K2 - Random-K1 extrapolation Dmap: {random_views['mean_difference']:+.4f}, 80% CI [{random_views['ci80'][0]:+.4f}, {random_views['ci80'][1]:+.4f}], positive cases {random_views['positive_cases']}/20.
- Soft-worst - Random-K2 extrapolation Dmap at seed17: {soft_worst['mean_difference']:+.4f}, 80% CI [{soft_worst['ci80'][0]:+.4f}, {soft_worst['ci80'][1]:+.4f}], positive cases {soft_worst['positive_cases']}/20.
- Descriptive Soft-worst - Random-K1 extrapolation Dmap at seed17: {soft_vs_k1['mean_difference']:+.4f}, 80% CI [{soft_vs_k1['ci80'][0]:+.4f}, {soft_vs_k1['ci80'][1]:+.4f}], positive cases {soft_vs_k1['positive_cases']}/20.
- Fixed-K2 is an exact deterministic duplicate-view alias of Fixed-K1; Native-random is the definition-identical alias of Random-K2. Their checkpoint hashes and metrics are identical by construction.
- Three-seed D-C: {'not run' if dc is None else json.dumps(dc, sort_keys=True)}.

## Conclusions

- Tensor-grid geometry provides a material independent gain: {conclusions['native_geometry_material']}.
- Resampling degradation/frequency change is sufficient under the preregistered 0.010 margin: {conclusions['degradation_dominant']}.
- Ordinary random-grid label supervision is not weaker than consistency: {conclusions['ordinary_label_supervision_not_weaker']}.
- Adding the second mean-consistency view improves extrapolation Dmap: {random_views['mean_difference'] > 0 and random_views['ci80'][0] > 0}.
- Soft-worst D-C reproduces under the three-seed rule: {conclusions['soft_worst_three_seed_reproducible']}.
- Soft-worst beats the simpler Random-K1 at seed17: {soft_vs_k1['mean_difference'] > 0 and soft_vs_k1['ci80'][0] > 0}.
- confirm_v2 remained locked and was not evaluated.
"""
    (ctx.output / "audit_report.md").write_text(report_text, encoding="utf-8")
    write_hashes(ctx)


def write_hashes(ctx: Context) -> None:
    previous = subprocess.run(["sha256sum", "-c", str(ctx.previous / "SHA256SUMS")], cwd=ctx.previous, stdout=subprocess.DEVNULL)
    if previous.returncode: raise RuntimeError("frozen inputs changed")
    files = [ctx.project / "run_grid_causal_audit.py", ctx.project / "test_grid_causal_audit.py"] + [x for x in ctx.output.rglob("*") if x.is_file() and x.name not in {"SHA256SUMS", "integrity_check_report.txt"}]
    (ctx.output / "SHA256SUMS").write_text("".join(f"{sha256(x)}  {x}\n" for x in sorted(files)))
    current = subprocess.run(["sha256sum", "-c", str(ctx.output / "SHA256SUMS")], stdout=subprocess.DEVNULL)
    (ctx.output / "integrity_check_report.txt").write_text(f"frozen_inputs: {'PASS' if previous.returncode == 0 else 'FAIL'}\ncurrent_outputs: {'PASS' if current.returncode == 0 else 'FAIL'}\nentries: {len(files)}\n")
    if current.returncode: raise RuntimeError("output hash failure")


def main() -> None:
    args = arguments(); ctx = Context(args); record_command(ctx)
    if args.command == "setup": setup(ctx)
    elif args.command == "unit-tests": run_unit_tests(ctx)
    elif args.command == "smoke": smoke(ctx, args.arm)
    elif args.command == "train": train(ctx, args.arm, args.seed)
    elif args.command == "evaluate": evaluate(ctx)
    elif args.command == "three-seed-dc": three_seed_dc(ctx)
    elif args.command == "report": report(ctx)
    elif args.command == "full-pilot":
        run_unit_tests(ctx); smoke(ctx, "all")
        for arm in NEW_SEED17: train(ctx, arm, 17)
        evaluate(ctx); three_seed_dc(ctx); report(ctx)


if __name__ == "__main__": main()
