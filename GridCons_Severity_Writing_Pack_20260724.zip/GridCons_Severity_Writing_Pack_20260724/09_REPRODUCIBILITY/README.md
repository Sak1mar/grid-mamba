# Reproducibility Contents

- `source/`: exact core source snapshots used by the final control.
- `reproduce_severity_control.sh`: original reproduction entry point; requires the original Linux/GPU paths and is not intended to run on Mac.
- `build_materials.py`: standard-library script that regenerates writing tables, figure data, and SVGs from the copied evidence.
- `environment_freeze.txt`, `command_ledger.jsonl`: original runtime provenance.
- `SHA256SUMS`: original severity-control output manifest, retained as evidence.

On Mac, the only expected runnable script is:

```bash
python3 09_REPRODUCIBILITY/build_materials.py
```

It does not train or evaluate a model and does not access any dataset.

