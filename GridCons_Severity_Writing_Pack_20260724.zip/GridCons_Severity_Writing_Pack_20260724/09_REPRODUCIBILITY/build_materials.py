#!/usr/bin/env python3
"""Regenerate paper tables, chart data, and editable SVGs from frozen evidence."""

from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from xml.sax.saxutils import escape


ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "06_EVIDENCE"
TABLES = ROOT / "03_TABLES"
FIGURES = ROOT / "04_FIGURES"
DATA = FIGURES / "source_data"
ARMS = ("C", "D", "S", "W")
COLORS = {"C": "#3568a8", "D": "#d47a28", "S": "#6f7f2c", "W": "#b44f7a"}
DASH = {"C": "", "D": "9 5", "S": "", "W": "3 4"}
MARKER = {"C": "circle", "D": "square", "S": "diamond", "W": "triangle"}


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_csv(path: Path, rows: list[dict], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = fields or list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def fmt(value: float) -> str:
    return f"{value:.5f}"


def make_tables() -> dict[str, list[dict]]:
    severity = load_json(EVIDENCE / "severity_control" / "metrics_summary.json")
    bootstrap = load_json(EVIDENCE / "severity_control" / "bootstrap_results.json")["results"]
    mechanism = load_json(EVIDENCE / "severity_control" / "aggregation_mechanism_summary.json")["by_seed"]
    source = load_json(EVIDENCE / "continuous_grid_audit" / "metrics_summary.json")["by_arm"]

    definitions = [
        {"arm": "C", "name": "mean", "formula": "(e1+e2)/2", "selection_input": "none", "adaptive_to_model": "no"},
        {"arm": "D", "name": "error soft-worst", "formula": "sum(stopgrad(softmax(5e))*e)", "selection_input": "prediction disagreement", "adaptive_to_model": "yes"},
        {"arm": "S", "name": "hard severity select", "formula": "e_argmax(log(s_mm)/log(3)); ties mean", "selection_input": "requested spacing in mm", "adaptive_to_model": "no"},
        {"arm": "W", "name": "soft severity weight", "formula": "sum(stopgrad(softmax(5a))*e), a=log(s_mm)/log(3)", "selection_input": "requested spacing in mm", "adaptive_to_model": "no"},
    ]
    write_csv(TABLES / "table1_aggregation_definitions.csv", definitions)

    source_rows = []
    for arm in ("degrade_on_r1", "native_random", "label_supervised_random", "random_k2", "random_k1", "soft_worst_random"):
        x = source[arm]
        source_rows.append({
            "arm": arm,
            "Dnative": fmt(x["Dnative"]),
            "Grid_AUC": fmt(x["grid_auc_dpred"]),
            "Worst_Dmap": fmt(x["worst_grid_Dmap"]),
            "Source_Dmap": fmt(x["source_mean_Dmap"]),
            "Extra_Dmap": fmt(x["extrapolation_Dmap"]),
            "Extra_Smap": fmt(x["extrapolation_Smap"]),
            "evidence_level": "seed17 development source audit",
        })
    write_csv(TABLES / "table2_source_audit.csv", source_rows)

    summary_rows = []
    for arm in ARMS:
        x, c = severity["pooled_case_seed"][arm], severity["compute"][arm]
        summary_rows.append({
            "arm": arm,
            "Dnative": fmt(x["Dnative"]),
            "Grid_AUC": fmt(x["Grid_AUC"]),
            "Worst_Dpred": fmt(x["Worst_grid_Dpred"]),
            "Worst_Dmap": fmt(x["Worst_grid_Dmap"]),
            "Source_Dmap": fmt(x["source_range_Dmap"]),
            "Extra_Dmap": fmt(x["Extra_Dmap"]),
            "Extra_Smap": fmt(x["Extra_Smap"]),
            "degradation_slope": fmt(x["degradation_slope"]),
            "seconds_per_update": fmt(c["seconds_per_update"]),
            "GPU_hours_3seeds": fmt(c["gpu_hours"]),
            "peak_GiB": f"{c['peak_memory_bytes'] / 2**30:.3f}",
        })
    write_csv(TABLES / "table3_severity_summary.csv", summary_rows)

    contrast_rows = []
    for contrast in ("D_minus_C", "S_minus_C", "S_minus_D", "W_minus_D"):
        for metric in ("Extra_Dmap", "Extra_Smap", "Worst_grid_Dmap", "Dnative"):
            x = bootstrap[f"{contrast}:{metric}"]
            contrast_rows.append({
                "contrast": contrast.replace("_minus_", "−"),
                "metric": metric,
                "mean_difference": fmt(x["mean_difference"]),
                "median_paired_difference": fmt(x["median_paired_difference"]),
                "ci80_low": fmt(x["ci80"][0]),
                "ci80_high": fmt(x["ci80"][1]),
                "ci95_low": fmt(x["ci95"][0]),
                "ci95_high": fmt(x["ci95"][1]),
                "positive_case_seed_fraction": f"{x['positive_case_seed_fraction']:.3f}",
                "seed17": fmt(x["by_seed"]["17"]),
                "seed29": fmt(x["by_seed"]["29"]),
                "seed41": fmt(x["by_seed"]["41"]),
            })
    write_csv(TABLES / "table4_key_contrasts.csv", contrast_rows)

    seed_rows = []
    for arm in ARMS:
        for seed, x in severity["by_seed"][arm].items():
            seed_rows.append({"arm": arm, "seed": seed, **{k: fmt(v) for k, v in x.items()}})
    write_csv(TABLES / "tableS1_by_seed.csv", seed_rows)

    mech_rows = []
    for seed, x in mechanism.items():
        mech_rows.append({
            "seed": seed,
            "D_high_weight_more_severe_fraction": fmt(x["D_high_weight_more_severe_fraction"]),
            "D_S_hard_selection_agreement": fmt(x["D_S_hard_selection_agreement"]),
            "D_W_weight_pearson": fmt(x["D_W_weight_pearson"]),
            "D_W_weight_spearman": fmt(x["D_W_weight_spearman"]),
            "D_W_weight_MAD": fmt(x["D_W_weight_mean_absolute_difference"]),
            **{f"effective_spacing_{arm}_mm": fmt(x["by_arm"][arm]["effective_spacing_mm"]) for arm in ARMS},
        })
    write_csv(TABLES / "tableS2_mechanism.csv", mech_rows)

    negatives = [
        {"direction": "Physical-Step", "decision": "STOP", "key_result": "no independent robustness gain", "paper_consequence": "no spacing-aware Mamba mechanism"},
        {"direction": "GridREx", "decision": "STOP_GRIDREX_DIAGNOSTIC", "key_result": "pooled partial Spearman -0.4229", "paper_consequence": "no source-risk variance loss"},
        {"direction": "fixed-grid degradation", "decision": "insufficient explanation", "key_result": "native-random minus degrade Extra Dmap +0.3211", "paper_consequence": "native tensor geometry is material"},
        {"direction": "conservative transport", "decision": "STOP_NO_CONSERVATIVE_GAIN", "key_result": "P-R Extra Dmap -0.02322", "paper_consequence": "no finite-volume transport method"},
        {"direction": "occupancy supervision", "decision": "STOP", "key_result": "O-H Extra Dmap -0.01855", "paper_consequence": "no partial-volume labels"},
        {"direction": "gradient surgery", "decision": "STOP_GRID_GRADIENT_DIAGNOSTIC", "key_result": "no stable joint native/worst improvement", "paper_consequence": "no conflict-resolution claim"},
    ]
    write_csv(TABLES / "tableS3_negative_controls.csv", negatives)

    pending = [{"split": "confirm_v2", "backbone": b, "arm": a, "seeds": "5", "Dnative": "", "Grid_AUC": "", "Worst_Dmap": "", "Extra_Dmap": "", "Extra_Smap": "", "status": "NOT RUN"} for b in ("Static Mamba", "Dynamic Mamba", "3D U-Net") for a in ("C", "S")]
    write_csv(TABLES / "table_pending_confirmation.csv", pending)

    spacing_acc: dict[tuple[str, float], list[dict]] = defaultdict(list)
    with (EVIDENCE / "severity_control" / "metrics_spacing_level.csv").open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            if row["class"] == "foreground":
                spacing_acc[(row["arm"], float(row["spacing_nominal_mm"]))].append(row)
    spacing_rows = []
    for (arm, spacing), rows in sorted(spacing_acc.items(), key=lambda z: (z[0][0], z[0][1])):
        spacing_rows.append({
            "arm": arm,
            "spacing_mm": f"{spacing:g}",
            **{metric: fmt(sum(float(r[metric]) for r in rows) / len(rows)) for metric in ("Dpred", "Dmap", "Smap", "Dnative")},
            "cases": "20",
            "seeds": "3",
            "split": "development",
        })
    write_csv(DATA / "spacing_curve.csv", spacing_rows)
    write_csv(DATA / "aggregation_summary.csv", summary_rows)
    write_csv(DATA / "by_seed.csv", seed_rows)
    write_csv(DATA / "key_contrasts.csv", contrast_rows)
    return {"summary": summary_rows, "spacing": spacing_rows, "seeds": seed_rows, "mechanism": mech_rows}


def svg_text(x, y, text, size=16, anchor="start", weight="normal", fill="#252a31", rotate=None):
    transform = f' transform="rotate({rotate} {x} {y})"' if rotate is not None else ""
    return f'<text x="{x:.1f}" y="{y:.1f}" font-family="Arial,Helvetica,sans-serif" font-size="{size}" text-anchor="{anchor}" font-weight="{weight}" fill="{fill}"{transform}>{escape(str(text))}</text>'


def marker(x, y, arm, size=6):
    color = COLORS[arm]
    if MARKER[arm] == "square":
        return f'<rect x="{x-size}" y="{y-size}" width="{2*size}" height="{2*size}" fill="white" stroke="{color}" stroke-width="2"/>'
    if MARKER[arm] == "diamond":
        return f'<path d="M{x},{y-size-1} L{x+size+1},{y} L{x},{y+size+1} L{x-size-1},{y} Z" fill="white" stroke="{color}" stroke-width="2"/>'
    if MARKER[arm] == "triangle":
        return f'<path d="M{x},{y-size-2} L{x+size+2},{y+size} L{x-size-2},{y+size} Z" fill="white" stroke="{color}" stroke-width="2"/>'
    return f'<circle cx="{x}" cy="{y}" r="{size}" fill="white" stroke="{color}" stroke-width="2"/>'


def svg_frame(width, height, title, subtitle):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">', '<rect width="100%" height="100%" fill="white"/>', svg_text(54, 42, title, 24, weight="bold"), svg_text(54, 68, subtitle, 14, fill="#59636f")]


def write_svg(path: Path, parts: list[str]):
    path.write_text("\n".join(parts + ["</svg>"]) + "\n", encoding="utf-8")


def figure_protocol():
    w, h = 1200, 700
    p = svg_frame(w, h, "Severity-selected native-grid consistency", "Frozen arm S; all geometry and schedules shared with C/D/W")
    p += ['<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#59636f"/></marker></defs>']
    boxes = [
        (55, 220, 250, 120, "R1 image + label", "native segmentation loss"),
        (365, 110, 255, 100, "Candidate g1", "native grid, s1 in mm"),
        (365, 350, 255, 100, "Candidate g2", "native grid, s2 in mm"),
        (685, 110, 250, 340, "Shared network", "same parameters\nmap probabilities to R1"),
        (985, 150, 170, 170, "Select max(s1,s2)", "ties: mean\nLaux = e_selected"),
    ]
    for x, y, bw, bh, title, sub in boxes:
        p.append(f'<rect x="{x}" y="{y}" width="{bw}" height="{bh}" rx="14" fill="#f6f8fa" stroke="#8a949e" stroke-width="2"/>')
        p.append(svg_text(x+bw/2, y+38, title, 18, "middle", "bold"))
        for i, line in enumerate(sub.split("\n")):
            p.append(svg_text(x+bw/2, y+70+24*i, line, 14, "middle", fill="#59636f"))
    for x1, y1, x2, y2 in [(305,280,685,280),(620,160,685,160),(620,400,685,400),(935,235,985,235)]:
        p.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#59636f" stroke-width="2.5" marker-end="url(#arrow)"/>')
    p.append(svg_text(520, 500, "R1 posterior teacher = stop-gradient foreground softmax", 17, "middle", "bold", "#3568a8"))
    p.append(svg_text(600, 555, "Training spacings: LogUniform(1,3 mm)   |   Evaluation: 1, 1.5, 2, 2.5, 3, 4, 5 mm", 17, "middle"))
    p.append(svg_text(600, 605, "No spacing embedding, learned resampler, extra parameters, or inference-time branch", 16, "middle", fill="#59636f"))
    p.append(svg_text(600, 660, "Development method-selection protocol; confirm_v2 remains untouched", 15, "middle", weight="bold", fill="#9b4d25"))
    write_svg(FIGURES / "figure1_protocol.svg", p)


def figure_spacing(rows):
    w, h = 1050, 680
    left, right, top, bottom = 100, 60, 100, 95
    pw, ph = w-left-right, h-top-bottom
    p = svg_frame(w, h, "Mapped Dice across through-plane spacing", "Development screen; 20 cases × 3 seeds; foreground class average")
    xval = lambda s: left + (s-1) / 4 * pw
    yval = lambda v: top + (0.9-v) / 0.9 * ph
    p.append(f'<rect x="{xval(1)}" y="{top}" width="{xval(3)-xval(1)}" height="{ph}" fill="#eef4fb"/>')
    p.append(f'<rect x="{xval(4)}" y="{top}" width="{xval(5)-xval(4)}" height="{ph}" fill="#fbf3e7"/>')
    for v in [0, .2, .4, .6, .8]:
        y = yval(v); p.append(f'<line x1="{left}" y1="{y}" x2="{w-right}" y2="{y}" stroke="#d8dde3"/>'); p.append(svg_text(left-12, y+5, f"{v:.1f}", 13, "end"))
    for s in [1,1.5,2,2.5,3,4,5]:
        x=xval(s); p.append(f'<line x1="{x}" y1="{top+ph}" x2="{x}" y2="{top+ph+6}" stroke="#252a31"/>'); p.append(svg_text(x, top+ph+28, f"{s:g}", 13, "middle"))
    p.append(f'<line x1="{left}" y1="{top}" x2="{left}" y2="{top+ph}" stroke="#252a31" stroke-width="1.5"/><line x1="{left}" y1="{top+ph}" x2="{w-right}" y2="{top+ph}" stroke="#252a31" stroke-width="1.5"/>')
    by_arm=defaultdict(list)
    for row in rows: by_arm[row["arm"]].append((float(row["spacing_mm"]),float(row["Dmap"])))
    for arm in ARMS:
        pts=sorted(by_arm[arm]); xy=[(xval(s),yval(v)) for s,v in pts]
        dash=f' stroke-dasharray="{DASH[arm]}"' if DASH[arm] else ""
        p.append(f'<polyline points="{" ".join(f"{x:.1f},{y:.1f}" for x,y in xy)}" fill="none" stroke="{COLORS[arm]}" stroke-width="3"{dash}/>')
        for x,y in xy: p.append(marker(x,y,arm))
    p.append(svg_text(left+pw/2, h-30, "Nominal through-plane spacing (mm)", 16, "middle", "bold"))
    p.append(svg_text(28, top+ph/2, "Mapped Dice (Dmap)", 16, "middle", "bold", rotate=-90))
    p.append(svg_text(xval(2), top+22, "training range", 13, "middle", fill="#3568a8")); p.append(svg_text(xval(4.5), top+22, "extra range", 13, "middle", fill="#9b4d25"))
    for i,arm in enumerate(ARMS):
        lx=660+(i%2)*170; ly=38+(i//2)*28; p.append(f'<line x1="{lx}" y1="{ly}" x2="{lx+38}" y2="{ly}" stroke="{COLORS[arm]}" stroke-width="3"/>'); p.append(marker(lx+19,ly,arm,5)); p.append(svg_text(lx+48,ly+5,arm,14,weight="bold"))
    write_svg(FIGURES / "figure2_dmap_spacing.svg", p)


def figure_summary(rows):
    w,h=1200,650; p=svg_frame(w,h,"Aggregation summary","Development pooled means; bars start at zero; exact values shown")
    metrics=[("Extra_Dmap","Extra Dmap",0.45),("Worst_Dmap","Worst-grid Dmap",0.28),("Dnative","Native Dice",1.0)]
    panel_w=330; gap=45; left0=70; top=120; ph=390
    for pi,(key,label,ymax) in enumerate(metrics):
        x0=left0+pi*(panel_w+gap); p.append(svg_text(x0+panel_w/2,100,label,17,"middle","bold"))
        for tick in range(5):
            v=ymax*tick/4; y=top+ph*(1-v/ymax); p.append(f'<line x1="{x0}" y1="{y}" x2="{x0+panel_w}" y2="{y}" stroke="#e0e4e8"/>'); p.append(svg_text(x0-8,y+4,f"{v:.2f}",11,"end"))
        bw=55; inner=panel_w/4
        for i,row in enumerate(rows):
            v=float(row[key]); x=x0+i*inner+(inner-bw)/2; y=top+ph*(1-v/ymax); p.append(f'<rect x="{x}" y="{y}" width="{bw}" height="{top+ph-y}" fill="{COLORS[row["arm"]]}" stroke="#252a31"/>'); p.append(svg_text(x+bw/2,y-8,f"{v:.3f}",12,"middle","bold")); p.append(svg_text(x+bw/2,top+ph+25,row["arm"],14,"middle","bold"))
        p.append(f'<line x1="{x0}" y1="{top+ph}" x2="{x0+panel_w}" y2="{top+ph}" stroke="#252a31"/>')
    p.append(svg_text(w/2,600,"S improves extra and worst-grid mapped accuracy while native Dice remains comparable",16,"middle","bold",fill="#6f7f2c"))
    write_svg(FIGURES / "figure3_aggregation_summary.svg",p)


def figure_seeds(rows):
    w,h=1050,650; left,right,top,bottom=105,60,110,100; pw,ph=w-left-right,h-top-bottom
    p=svg_frame(w,h,"Extra mapped Dice by seed","Development screen; every seed shown; horizontal bar marks the three-seed mean")
    ymin,ymax=.30,.45; xloc={arm:left+(i+.5)*pw/4 for i,arm in enumerate(ARMS)}; y=lambda v:top+(ymax-v)/(ymax-ymin)*ph
    for v in [.30,.325,.35,.375,.40,.425,.45]:
        yy=y(v);p.append(f'<line x1="{left}" y1="{yy}" x2="{w-right}" y2="{yy}" stroke="#dfe3e7"/>');p.append(svg_text(left-10,yy+4,f"{v:.3f}",12,"end"))
    offsets={"17":-18,"29":0,"41":18}; shapes={"17":"circle","29":"square","41":"triangle"}
    for arm in ARMS:
        vals=[]
        for row in rows:
            if row["arm"]!=arm: continue
            v=float(row["Extra_Dmap"]);vals.append(v);x=xloc[arm]+offsets[row["seed"]];yy=y(v)
            if shapes[row["seed"]]=="circle": p.append(f'<circle cx="{x}" cy="{yy}" r="7" fill="white" stroke="{COLORS[arm]}" stroke-width="2.5"/>')
            elif shapes[row["seed"]]=="square": p.append(f'<rect x="{x-7}" y="{yy-7}" width="14" height="14" fill="white" stroke="{COLORS[arm]}" stroke-width="2.5"/>')
            else: p.append(f'<path d="M{x},{yy-9} L{x+8},{yy+7} L{x-8},{yy+7} Z" fill="white" stroke="{COLORS[arm]}" stroke-width="2.5"/>')
        mean=sum(vals)/len(vals);p.append(f'<line x1="{xloc[arm]-42}" y1="{y(mean)}" x2="{xloc[arm]+42}" y2="{y(mean)}" stroke="{COLORS[arm]}" stroke-width="4"/>');p.append(svg_text(xloc[arm],top+ph+32,arm,16,"middle","bold"));p.append(svg_text(xloc[arm],y(mean)-12,f"mean {mean:.3f}",12,"middle",fill=COLORS[arm]))
    p.append(svg_text(28,top+ph/2,"Extra Dmap (4/5 mm mean)",16,"middle","bold",rotate=-90))
    for i,(seed,shape) in enumerate(shapes.items()):
        xx=730+i*105
        if shape=="circle": p.append(f'<circle cx="{xx}" cy="82" r="6" fill="white" stroke="#59636f" stroke-width="2"/>')
        elif shape=="square": p.append(f'<rect x="{xx-6}" y="76" width="12" height="12" fill="white" stroke="#59636f" stroke-width="2"/>')
        else: p.append(f'<path d="M{xx},75 L{xx+7},88 L{xx-7},88 Z" fill="white" stroke="#59636f" stroke-width="2"/>')
        p.append(svg_text(xx+12,87,f"seed {seed}",13,"start"))
    write_svg(FIGURES / "figure4_seed_stability.svg",p)


def validate(outputs):
    assert len(outputs["summary"]) == 4
    assert len(outputs["spacing"]) == 28
    assert len(outputs["seeds"]) == 12
    s = next(x for x in outputs["summary"] if x["arm"] == "S")
    assert math.isclose(float(s["Extra_Dmap"]), 0.3970418507, abs_tol=5e-6)
    for name in ("figure1_protocol.svg", "figure2_dmap_spacing.svg", "figure3_aggregation_summary.svg", "figure4_seed_stability.svg"):
        text = (FIGURES / name).read_text(encoding="utf-8")
        assert text.startswith("<svg") and text.rstrip().endswith("</svg>")


def main():
    TABLES.mkdir(exist_ok=True); DATA.mkdir(parents=True, exist_ok=True)
    outputs = make_tables()
    figure_protocol(); figure_spacing(outputs["spacing"]); figure_summary(outputs["summary"]); figure_seeds(outputs["seeds"])
    validate(outputs)
    print("PASS: regenerated 8 tables/data files and 4 editable SVG figures")


if __name__ == "__main__":
    main()
