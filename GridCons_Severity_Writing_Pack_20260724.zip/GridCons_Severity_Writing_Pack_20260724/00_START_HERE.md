# GridCons / Severity-Selected Native-Grid Consistency 写作母包

这是 2026-07-24 冻结后的论文写作入口。它不是新的实验目录，也不替代原始结果；它把现有证据整理成可直接复制到 Mac、离线阅读和继续写作的材料包。

## 先记住结论

- 论文中心不再是新的 Mamba 模块，也不是 soft-worst。
- 当前最有证据支持的解释是：**真正改变 tensor depth、voxel lattice、pooling trajectory 和物理感受野轨迹的连续 native-grid exposure，是跨 spacing 稳定性的主要有效因素。**
- 最终冻结方法是 **S：severity-selected native-grid posterior consistency**。每次采样两个 `[1,3] mm` native grids，只对 requested spacing 更大的候选计算辅助一致性；完全相同 spacing 时退化为均值。
- S 在三种子 development screen 上优于 mean C 和 loss-adaptive soft-worst D，但这仍是方法选择证据，不是最终独立确认。
- `confirm_v2` 保持未访问、未评估。没有确认结果前，论文不能声称 held-out confirmation、跨骨干复现或跨数据集泛化。

## Mac 上的阅读顺序

1. `01_POSITIONING/PAPER_BLUEPRINT_ZH.md`
2. `01_POSITIONING/CANONICAL_FACT_SHEET.md`
3. `01_POSITIONING/CLAIM_EVIDENCE_MATRIX.md`
4. `02_MANUSCRIPT/main_draft_en.md`
5. `03_TABLES/TABLE_INDEX.md`
6. `04_FIGURES/FIGURE_PLAN.md`
7. `05_METHODS_AND_STATS/`
8. `08_PENDING_CONFIRMATION/EXPERIMENT_LOCK.md`
9. `10_INTEGRITY/VALIDATION_REPORT.md`

## 证据优先级

发生冲突时按以下顺序处理：

1. `06_EVIDENCE/severity_control/method_freeze.json` 与 `decision.json`
2. `06_EVIDENCE/severity_control/metrics_summary.json`、`bootstrap_results.json`
3. `06_EVIDENCE/continuous_grid_audit/metrics_summary.json` 与 `audit_report.md`
4. 各负控制的最终报告
5. `06_EVIDENCE/legacy_equal_exposure/`，只用于固定 R1/R2 背景和已完成的边界证据
6. `07_RELATED_WORK/novelty_audit_original.md` 仅用于检索线索，其中旧机制结论已失效

## 当前能完成到什么程度

现在可以完成题目、引言、相关工作、完整方法、开发阶段实验、机制审计、限制、图表和补充材料框架。投稿摘要、主结果结论、跨骨干和第二数据集段落必须保留占位符，直到冻结后的确认计划被单独授权和执行。

## 不要做的事

- 不增加新 loss、模块、backbone 或 grid sampler。
- 不用开发集结果重开方法选择。
- 不把相关性写成因果证明。
- 不把 D 的效果解释为梯度冲突解决或 worst-domain optimization。
- 不把旧固定 R1/R2 的大增益归因于 consistency loss 单独产生。
- 不访问 `confirm_v2`，本包中的两个命令脚本仍以 `exit 0` 锁住。

