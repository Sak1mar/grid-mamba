# Allowed and Forbidden Language

## Allowed

- “In the controlled Task04 development audit, native tensor-grid exposure produced a large advantage over degradation applied on the fixed R1 tensor.”
- “Under the current construction and training protocol, R1 posterior consistency outperformed candidate-grid label supervision.”
- “Loss-adaptive soft-worst weighting largely tracked spacing severity.”
- “Severity-selected consistency provided an empirical development-set advantage over loss-adaptive weighting.”
- “The result motivates freezing S for independent confirmation.”

## Required qualifiers

- Use `development`, `screening`, or `method-selection` for all current S results.
- Use `controlled resampling` rather than `clinical acquisition shift`.
- Use `associated with` for update-level weight/error/spacing relations.
- Report both pooled effects and seed directions.
- When citing 80% CIs, say they were preregistered screening intervals; 95% CIs are descriptive.

## Forbidden

- “solves gradient conflict”
- “optimizes the worst domain”
- “theoretically optimal”
- “general clinical robustness”
- “state of the art”
- “all consistency is superior to ground-truth supervision”
- “spacing embedding” or “physical-step Mamba” as the final method
- “soft-worst independently detects the correct difficult grid”
- any confirmation, cross-backbone, or second-dataset claim before those cells are filled
- any claim based on one favorable seed while hiding seed 41

