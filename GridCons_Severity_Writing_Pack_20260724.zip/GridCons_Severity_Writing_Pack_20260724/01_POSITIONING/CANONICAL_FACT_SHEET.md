# Canonical Fact Sheet

## Study status

- Final development decision: `PREFER_SEVERITY_CONTROL`.
- Frozen selected arm: `S`.
- Current evidence level: 20-case development screen, three seeds (17, 29, 41).
- Additional held-out `confirm_v2`: 40 cases, not accessed and not evaluated.
- Source commit: `19aee2728471ce4c14a6baf8e6a574defe916690`.

## Data and training

- Dataset: MSD Task04 Hippocampus MRI, two foreground classes.
- Frozen split used by the continuous-grid work: 80 train, 20 validation, 20 development screen, 40 locked confirm_v2; groups are disjoint.
- Backbone in the method-selection study: Static Mamba, 99,411 parameters.
- Full-volume batch size 1; 2,500 updates; validation every 250 updates.
- AdamW, learning rate `3e-4`, weight decay `1e-5`, bfloat16, no augmentation.
- Checkpoint: highest R1 validation foreground Dice; ties keep earliest.
- Candidate schedule: K=2, requested spacings sampled LogUniform over `[1,3] mm`; exact per-seed schedules frozen.
- Evaluation spacings: `[1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0] mm`.
- Consistency weight: linear warm-up to `0.1` over 500 updates.

## Frozen method S

Let `p0=softmax(f(x_R1))`, and let the stop-gradient teacher be the foreground channels of `p0`. For candidate native grids `g1,g2`, map each prediction back to R1 and compute foreground soft-Dice disagreement `e1,e2`.

`a_k = log(s_k / 1 mm) / log(3)`.

Choose `k*=argmax(a1,a2)` and set `L_aux=e_k*`. If the requested spacings are exactly equal, use `(e1+e2)/2`.

`L = 0.5 L_Dice + 0.5 L_CE + lambda(t) L_aux`.

Severity uses requested spacing in millimetres, never tensor depth. Selection never reads candidate error, gradient norm, labels or confidence.

## Development pooled means

| Arm | Dnative | Grid-AUC | Worst Dmap | Extra Dmap | Extra Smap | seconds/update |
|---|---:|---:|---:|---:|---:|---:|
| C mean | 0.88016 | 0.65657 | 0.17428 | 0.34754 | 0.49038 | 0.88770 |
| D error soft-worst | 0.88065 | 0.66709 | 0.19113 | 0.36668 | 0.51150 | 0.88410 |
| S hard severity select | 0.88157 | 0.68569 | 0.22832 | 0.39704 | 0.55390 | 0.76581 |
| W soft severity weight | 0.88058 | 0.67568 | 0.20811 | 0.37834 | 0.53409 | 0.78082 |

## Key paired differences

- Native-random − Degrade-on-R1 Extra Dmap: `+0.32113`; 80% CI `[+0.28898,+0.35144]`; 20/20 positive cases. Single seed source audit.
- Random-K2 − Label-supervised-random Extra Dmap: `+0.07733`; equivalent reported reverse contrast is `−0.07733`; 80% CI for reverse `[-0.08412,-0.07031]`; 20/20 favor Random-K2.
- D − C Extra Dmap: `+0.01914`; 80% CI `[+0.01742,+0.02085]`; seeds `+0.01770,+0.02534,+0.01437`.
- S − C Extra Dmap: `+0.04950`; 80% CI `[+0.04153,+0.05759]`; seeds `+0.07111,+0.07033,+0.00707`.
- S − D Extra Dmap: `+0.03037`; 80% CI `[+0.02330,+0.03760]`; seeds `+0.05341,+0.04499,−0.00731`.
- W − D Extra Dmap: `+0.01167`; 80% CI `[+0.00557,+0.01796]`; seeds `+0.03212,+0.02504,−0.02215`.
- S − D Dnative: `+0.00092`; W − D Dnative: `−0.00007`; native guardrails pass.

## Mechanism observations

- D gave the larger weight to the more severe spacing in 88.68%, 89.24%, and 88.60% of updates for seeds 17, 29, and 41.
- D–W weight Pearson correlations: 0.8647, 0.8576, 0.8585.
- D–W weight Spearman correlations: 0.9290, 0.9265, 0.9242.
- These are descriptive associations. No subsequent-benefit causal analysis was established within updates where loss and spacing rankings disagree.

## Frozen negative conclusions

Do not revive Physical-Step, GridREx/source-risk variance, fixed-grid degradation as the main explanation, conservative transport, occupancy supervision, gradient surgery, or loss-adaptive worst-domain language. Full details are preserved in `06_EVIDENCE/negative_controls/`.

