# Claim–Evidence Matrix

| ID | Candidate paper claim | Status | Exact evidence | Where usable |
|---|---|---|---|---|
| C1 | Continuous native tensor-grid exposure materially improves 4/5 mm mapped Dice beyond degradation on a fixed R1 tensor. | Supported in development source audit | Native-random − Degrade-on-R1 Extra Dmap `+0.32113`, 80% CI `[0.28898,0.35144]`, 20/20 positive; `06_EVIDENCE/continuous_grid_audit/metrics_summary.json` | Abstract only after scope says controlled Task04; main Results |
| C2 | The gain is not adequately explained by fixed-grid blur/degradation. | Supported within the tested degradation control | Same contrast as C1; Degrade-on-R1 Extra Dmap `0.01455` vs native-random `0.33567` | Results/Discussion |
| C3 | Under this construction, R1 posterior consistency outperformed candidate-grid label supervision. | Supported, construction-specific | Label-supervised − Random-K2 `−0.07733`, 80% CI `[-0.08412,-0.07031]`, 0/20 positive | Results; never generalize to all ground-truth supervision |
| C4 | Soft-worst D exceeds mean C across three seeds. | Supported development result | D−C Extra Dmap `+0.01914`; each seed positive | Aggregation audit |
| C5 | Soft-worst works by resolving gradient conflict or following a more correct gradient. | Unsupported | Gradient conflict and projection gates failed; `06_EVIDENCE/negative_controls/gradient_diagnostic/diagnostic_report.md` | State only as rejected explanation |
| C6 | D mostly emphasizes the more severe spacing. | Descriptively supported | 88.60%–89.24% update agreement; high D/W rank correlations | Mechanism analysis; not causal proof |
| C7 | Hard severity selection S outperforms D on pooled development Extra Dmap. | Supported development result | S−D `+0.03037`, 80% CI `[0.02330,0.03760]`; 2/3 seeds positive | Results; label development selection |
| C8 | S is more stable than C across the three selected seeds. | Supported development result | S−C seeds all positive; mean `+0.04950`, 80% CI `[0.04153,0.05759]` | Results |
| C9 | S is faster than C/D/W. | Supported for observed training runs | S `0.7658 s/update`; W `0.7808`; D `0.8841`; C `0.8877` | Efficiency table; hardware-specific |
| C10 | S preserves native segmentation. | Guardrail supported in development | pooled Dnative `0.88157`; S−D `+0.00092`; S−C `+0.00141` | Results |
| C11 | S is confirmed on unseen cases. | Not yet available | confirm_v2 untouched | Forbidden until confirmation |
| C12 | S is backbone-independent. | Not yet available | Only Static Mamba trained for S/W | Placeholder only |
| C13 | S generalizes to a second dataset or heterogeneous clinical acquisition. | Not yet available; old Task09 fixed-grid study was negative | `06_EVIDENCE/legacy_equal_exposure/EXTERNAL_REPORT.md` | Limitation; no positive claim |
| C14 | Static Mamba timescales or physical-step recurrence drive the effect. | Rejected | Physical-Step stopped; old factorial interaction does not privilege static delta | Negative result/supplement |
| C15 | Conservative transport or occupancy labels improve extrapolation. | Rejected in preregistered pilots | P−R `−0.02322`; O−H `−0.01855` Extra Dmap | Supplement/limitations |

## Burden-bearing statements for the final abstract

The final abstract may use C1, C3, C6–C10 only with the words “development audit” until C11 is filled. C12 and C13 require new frozen evaluations; do not convert their placeholders into prose from expectation or single-seed observations.

