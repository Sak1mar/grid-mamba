# Table Index

All CSV files in this directory are generated from copied frozen JSON/CSV evidence by `../09_REPRODUCIBILITY/build_materials.py`.

| File | Intended use |
|---|---|
| `table1_aggregation_definitions.csv` | Main Method table; C/D/S/W formulas and information used |
| `table2_source_audit.csv` | Main Results; native geometry, fixed degradation, label supervision controls |
| `table3_severity_summary.csv` | Main Results; pooled C/D/S/W metrics and compute |
| `table4_key_contrasts.csv` | Main Results; paired effects, 80% screening and 95% descriptive CIs |
| `tableS1_by_seed.csv` | Supplement; every seed and arm |
| `tableS2_mechanism.csv` | Supplement; severe-selection fraction and D/W correlations |
| `tableS3_negative_controls.csv` | Supplement; frozen stopped mechanisms |
| `table_pending_confirmation.csv` | Empty submission table; fill only from authorized confirmation outputs |

Do not manually type rounded numbers into the manuscript before deciding the journal/conference precision. Link the table source or regenerate after any formatting change.

