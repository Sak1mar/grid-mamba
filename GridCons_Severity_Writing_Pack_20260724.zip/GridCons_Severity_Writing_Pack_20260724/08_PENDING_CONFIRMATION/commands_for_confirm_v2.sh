#!/usr/bin/env bash
set -euo pipefail
# Generated only; intentionally not executed. Remove the next line only after explicit confirm_v2 authorization.
exit 0
# Five-seed confirm_v2 evaluation commands must use method_freeze.json exactly.
