# Result Templates — Do Not Fill from Development Data

## confirm_v2

| Arm | Seeds | Dnative | Grid-AUC | Worst Dmap | Extra Dmap | Extra Smap |
|---|---:|---:|---:|---:|---:|---:|
| C | 5 | [ ] | [ ] | [ ] | [ ] | [ ] |
| S | 5 | [ ] | [ ] | [ ] | [ ] | [ ] |

| Contrast | Mean | 95% CI | Seeds positive | Native guardrail |
|---|---:|---:|---:|---|
| S−C Extra Dmap | [ ] | [ ] | [ ] | [ ] |
| S−C Worst Dmap | [ ] | [ ] | [ ] | [ ] |
| S−C Dnative | [ ] | [ ] | [ ] | [ ] |

## Backbone replication

| Backbone | Parameters | S−C Extra Dmap | 95% CI | S−C Dnative | Status |
|---|---:|---:|---:|---:|---|
| Static Mamba | [ ] | [ ] | [ ] | [ ] | [ ] |
| Dynamic Mamba | [ ] | [ ] | [ ] | [ ] | [ ] |
| 3D U-Net | [ ] | [ ] | [ ] | [ ] | [ ] |

## Second dataset

| Dataset | Cases/splits | Primary metric | S−C | 95% CI | Scope conclusion |
|---|---|---|---:|---:|---|
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

