# Frozen Post-Selection Experiment Plan

Nothing in this directory has been executed by this writing-pack task.

## Required order

1. confirm_v2 five-seed evaluation of frozen S and frozen comparators.
2. Static Mamba replication.
3. Dynamic Mamba replication.
4. 3D U-Net replication.
5. Second dataset.
6. Continuous spacing curve.
7. Heterogeneous affine test.

## Non-negotiable lock

- `method_freeze.json` is the only method definition.
- No temperature search, new seed selection, extended training, alternate checkpoint, loss modification, new module, or development re-entry.
- confirm_v2 is used once for reporting, never for choosing between C/D/S/W.
- Negative confirmation or replication remains in the paper.
- `commands_for_confirm_v2.sh` and `commands_for_backbone_replication.sh` intentionally begin with `exit 0`; remove it only after explicit authorization and after replacing the placeholder commands with reviewed executable commands.

## What the confirmation must decide

- Does S retain a positive Extra Dmap difference over the prespecified simple comparator?
- Is the native Dice guardrail maintained?
- Are worst-grid and surface metrics directionally compatible?
- Does the result replicate across the fixed three backbone families?
- Does a second dataset support or bound the claim?

