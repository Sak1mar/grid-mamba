# Validation Report

## Overall Assessment: Ready to share as a development-stage writing pack

Question: are the frozen continuous-grid and severity-control results accurately organized for paper writing without overstating confirmation?

Data as of: 2026-07-24. Evidence consists of copied frozen JSON/CSV/reports; no model training, dataset read, or confirm_v2 evaluation is performed by this validation.

## Calculation and Integrity Checks

| Check | Result | Detail |
|---|---|---|
| recompute D-C Extra_Dmap | PASS | +0.019136655828 |
| recompute S-C Extra_Dmap | PASS | +0.049503259385 |
| recompute S-D Extra_Dmap | PASS | +0.030366603557 |
| recompute W-D Extra_Dmap | PASS | +0.011669350297 |
| selected arm S has highest pooled Extra_Dmap | PASS | {'C': 0.347539, 'D': 0.366675, 'S': 0.397042, 'W': 0.378345} |
| confirm flags false in severity evidence | PASS | false/false |
| no symlinks in portable pack | PASS | 0 symlinks expected |
| commands_for_confirm_v2.sh remains execution-locked | PASS | ['set -euo pipefail', 'exit 0'] |
| commands_for_backbone_replication.sh remains execution-locked | PASS | ['set -euo pipefail', 'exit 0'] |
| curated evidence copies match original files | PASS | mismatches=[] |
| confirm_v2 denylist hits in writing pack | PASS | hits=0 |

## Methodology Review

The pack distinguishes the single-seed source audit, three-seed aggregation screen, old fixed-grid confirmation, and still-locked confirm_v2. Current S claims are labeled as development/method-selection evidence. The manuscript defines units, metric formulas, training/evaluation spacing ranges, checkpointing, and hierarchical bootstrap before using the results.

## Required Caveats

- S has not yet been evaluated on confirm_v2.
- S/W were selected with one Static Mamba implementation; cross-backbone statements remain placeholders.
- The source audit's native-versus-degraded and label-versus-posterior controls are seed-17 screens; only D−C was reproduced over three seeds before severity control.
- Controlled voxel-grid stability does not establish robustness to heterogeneous clinical acquisition.
- The old Task09 external study was negative and is retained as a boundary, not evidence for S.

## Incomplete Handoff Blockers for Submission

- confirm_v2 five-seed result
- Static/Dynamic Mamba and 3D U-Net replication
- second dataset
- author/venue/ethics/funding/code metadata

Failed checks: none
