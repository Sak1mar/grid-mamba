#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
sha256sum -c 10_INTEGRITY/SHA256SUMS.txt
echo "PASS: writing pack integrity"
