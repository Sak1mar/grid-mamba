# 在 Mac 上使用

1. 复制整个目录或同名 `.zip` 到 Mac，解压后从 `00_START_HERE.md` 开始。
2. Markdown 可用 VS Code、Typora、Obsidian 或任意文本编辑器打开；CSV 可用 Numbers/Excel；SVG 可直接拖入 Keynote、Pages、Word 或浏览器。
3. `02_MANUSCRIPT/main_draft_en.md` 是工作母稿。建议复制一份再修改，不要直接改 `06_EVIDENCE/`。
4. 图的可编辑源数据在 `04_FIGURES/source_data/`；图表生成脚本只依赖 Python 3 标准库。
5. 校验完整性：在 Terminal 进入目录后运行 `bash 10_INTEGRITY/check_integrity.sh`。

所有路径均为相对路径；包内没有软链接、训练缓存、checkpoint、数据集或虚拟环境。
