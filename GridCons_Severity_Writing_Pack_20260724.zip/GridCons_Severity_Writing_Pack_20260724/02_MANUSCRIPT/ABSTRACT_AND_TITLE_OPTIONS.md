# Titles and Abstract Templates

## Recommended title

**What Drives Stability Across Voxel Grids? Native-Grid Exposure and Severity-Selected Consistency for 3D Medical Image Segmentation**

## Development-stage abstract (safe now)

Volumetric segmentation models can produce different masks for the same anatomy when voxel spacing changes, because resampling alters not only image appearance but also tensor depth, voxel lattice, pooling trajectories, and feature-map discretization. We study this problem under physically aligned through-plane grids on MSD Task04 Hippocampus. A controlled source audit separates native-grid exposure from degradation applied on a fixed tensor and compares posterior consistency with candidate-grid label supervision. Native random grids improve Extra mapped Dice at 4–5 mm by 0.3211 over fixed-tensor degradation (80% paired-bootstrap confidence interval 0.2890–0.3514; 20/20 cases positive), while candidate-grid label supervision is 0.0773 worse than R1-posterior consistency under the tested protocol. We then compare mean, loss-adaptive soft-worst, hard severity selection, and soft severity weighting using identical cases, initializations, grid schedules, and checkpoints across three seeds. Hard selection of the more severe spacing yields the highest development Extra mapped Dice (0.3970), exceeding mean aggregation by 0.0495 and soft-worst by 0.0304 while preserving native Dice. Soft-worst assigns more weight to the severe spacing in about 89% of updates, and no independent gradient-conflict mechanism is supported. We therefore freeze severity-selected native-grid consistency for independent confirmation, without claiming robustness to heterogeneous clinical acquisition.

## Submission abstract template (locked cells)

Use the development abstract as a base, then replace the final two sentences with:

> On the untouched 40-case confirm_v2 set across five seeds, S changed Extra mapped Dice by **[S−C CONFIRM MEAN, 95% CI]** and worst-grid mapped Dice by **[VALUE]**, with native Dice difference **[VALUE]**. The direction was **[CONSISTENT/INCONSISTENT]** across Static Mamba, Dynamic Mamba, and 3D U-Net, and the second-dataset evaluation **[SUPPORTED/DID NOT SUPPORT]** transfer beyond the controlled Task04 setting. These results support **[FINAL SCOPED CLAIM]**.

Do not remove the brackets until the corresponding result files exist and pass integrity checks.

