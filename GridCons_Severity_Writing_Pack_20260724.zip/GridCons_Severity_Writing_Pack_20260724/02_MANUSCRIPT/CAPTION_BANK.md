# Caption Bank

## Figure 1

**Severity-selected native-grid posterior consistency.** The supervised R1 branch supplies a detached foreground posterior. Two endpoint-matched native grids are sampled from LogUniform(1,3 mm), predicted by the same network, and mapped to R1. Arm S applies the auxiliary soft-Dice disagreement only to the candidate with larger requested spacing; exact spacing ties use the mean. The backbone and inference graph are unchanged.

## Figure 2

**Mapped foreground Dice across nominal through-plane spacing on the development screen.** Values average 20 cases and seeds 17, 29, and 41. The blue region marks the 1–3 mm training range and the tan region marks the 4–5 mm extrapolation range. S gives the highest pooled curve, but the result is method-selection evidence rather than independent confirmation.

## Figure 3

**Pooled development metrics for the four aggregation rules.** Extra Dmap averages 4 and 5 mm; worst-grid Dmap takes the minimum over 1.5–5 mm; native Dice is measured on R1. Bars start at zero and exact values are displayed. S improves the extra and worst-grid metrics without an observed native-Dice trade-off.

## Figure 4

**Seed-level Extra Dmap on the development screen.** Each symbol is the mean over 20 cases for one seed; the horizontal segment is the three-seed mean. S exceeds C in all three seeds. S exceeds D in seeds 17 and 29 but is 0.0073 lower in seed 41, which is retained in the figure and the paired analysis.

## Table 2 source audit

**Controlled source-of-gain audit at seed 17.** Native-random and Degrade-on-R1 use the same spacing draws but differ in whether the network receives a true candidate tensor grid. Label-supervised random and Random-K2 use the same native candidates but different supervision targets. These screening controls identify the supported source under the tested construction; only the prespecified D−C comparison was reproduced across three seeds at this stage.

## Table 3 severity control

**Three-seed development comparison of candidate aggregation.** All arms share initialization, case order, grid schedule, candidate images and affines, optimization, validation, and R1-only checkpoint selection. S is the frozen method selected by the preregistered severity-control rule.

