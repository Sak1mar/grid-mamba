# Author-Fill Checklist

- [ ] Authors, order, affiliations, correspondence
- [ ] Target venue and exact page/template constraints
- [ ] Ethics/data-use statement appropriate for public MSD data
- [ ] Funding and conflicts of interest
- [ ] Code/repository URL and anonymization plan
- [ ] confirm_v2 results and integrity receipt
- [ ] backbone replication results
- [ ] second-dataset result, including a negative result if applicable
- [ ] final abstract numbers synchronized with tables
- [ ] bibliography verified against official records
- [ ] figure font sizes checked in the venue two-column layout
- [ ] all `[TO BE FILLED]` and bracketed result tokens removed
- [ ] no forbidden mechanism language introduced during polishing

