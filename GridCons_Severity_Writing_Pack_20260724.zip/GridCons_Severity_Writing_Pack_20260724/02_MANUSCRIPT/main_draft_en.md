# What Drives Stability Across Voxel Grids? Native-Grid Exposure and Severity-Selected Consistency for 3D Medical Image Segmentation

**Authors:** [TO BE FILLED]  
**Affiliations:** [TO BE FILLED]  
**Venue:** [TO BE FILLED]

## Abstract

Use the development-stage abstract in `ABSTRACT_AND_TITLE_OPTIONS.md` while drafting. Replace it with the locked submission template only after confirm_v2 and the preregistered replication studies are complete.

**Keywords:** medical image segmentation; voxel spacing; resampling stability; consistency regularization; native-grid exposure

## 1. Introduction

Three-dimensional medical images are sampled on voxel lattices whose through-plane spacing can vary across reconstruction protocols, scanners, and preprocessing pipelines. A segmentation network therefore sees more than a visually blurred or sharpened version of the same anatomy when spacing changes. The number and physical extent of slices change, encoder pooling follows a different discrete trajectory, and intermediate feature maps represent different physical receptive fields. Yet segmentation studies typically report accuracy on one preprocessing grid, leaving the stability of a prediction under alternative physically aligned grids largely implicit.

This omission matters even in a controlled setting where anatomy, labels, physical bounds, and in-plane spacing are held fixed. A model may achieve high native-grid Dice while producing a substantially different mask after the same volume is rendered on a coarser lattice and mapped back to the reference frame. We refer to this controlled property as voxel-grid stability. It is narrower than scanner or clinical domain robustness: it isolates the consequences of discrete grid construction for the same underlying case.

Our earlier fixed-grid experiments showed that paired R1/R2 training can strongly reduce this instability. However, an equal-exposure control reproduced most of the matched-R2 gain with supervised exposure to both grids. The large gain could therefore not be attributed to the prediction-consistency objective alone. That result changes the central question from whether a particular consistency loss works to which component of paired-grid exposure drives extrapolation beyond the fixed training grid.

We answer this question through a sequence of preregistered controls. First, we compare direct forward passes on randomly sampled native tensor grids with matched degradation that is restored to the fixed R1 tensor before the network. This separates changes in image content from changes in tensor depth, voxel lattice, pooling, and feature-map discretization. Second, we compare R1-posterior consistency with ordinary candidate-grid label supervision under the same native random grids. Third, after observing a reproducible gain from loss-adaptive soft-worst aggregation, we test the remaining confound directly: whether soft-worst is useful because it follows prediction disagreement or merely because high disagreement usually occurs at a more severe spacing.

The resulting method is deliberately simple. At each update we sample two native through-plane grids from a frozen log-uniform distribution over 1–3 mm. Both predictions are aligned to the R1 reference frame. Instead of averaging their posterior disagreements or weighting them by current disagreement, we select the candidate with the larger requested spacing. This severity-selected auxiliary objective contains no spacing embedding, learned resampler, teacher model, uncertainty mask, gradient surgery, or distributionally robust optimizer.

Our current evidence is a three-seed development audit on MSD Task04. Native-grid exposure yields a large advantage over fixed-tensor degradation, and posterior consistency outperforms candidate-grid label supervision under the tested construction. Severity selection then improves 4–5 mm mapped Dice over both mean and soft-worst aggregation while preserving native Dice. Soft-worst weights strongly correlate with spacing severity, whereas gradient diagnostics do not support conflict resolution or a more correct update direction. Based on preregistered rules, we freeze severity selection for independent confirmation; we do not use the development results to introduce further mechanisms.

The contributions are:

1. A continuous, physically aligned evaluation protocol that measures prediction agreement, label-referenced mapped accuracy, and surface accuracy across 1–5 mm through-plane spacings.
2. Controlled evidence separating native tensor-grid exposure from fixed-tensor image degradation and comparing posterior consistency with candidate-grid label supervision.
3. A preregistered aggregation audit showing that a simple severity-selected objective outperforms loss-adaptive soft-worst on the frozen three-seed development screen.
4. Explicit negative evidence that rules out physical-step recurrence, source-risk variance, conservative transport, occupancy supervision, and gradient-conflict explanations within the tested protocols.

## 2. Related Work

### 2.1 Voxel spacing and resampling in medical segmentation

Most segmentation pipelines standardize voxel spacing before training, treating resampling as preprocessing rather than as an experimental factor. Recent work has examined spacing-aware resampling, semantic reconstruction, and anti-aliased downsampling. These approaches primarily improve the resampler or internal sampling operator. Our question is different: we keep the resampling construction fixed and ask how a segmentation model should be exposed to the family of native tensor grids induced by the same anatomy. Consispace and CROWn are the closest included references for semantic resampling and sampling-aware feature processing, respectively; neither supplies the controlled aggregation comparison studied here.

### 2.2 Transformation and prediction consistency

Transformation-consistent learning aligns predictions from transformed inputs and penalizes disagreement. The general idea predates this study and is not claimed as novel. Our use of an R1 posterior teacher is a direct output-space consistency objective. The contribution is the controlled separation of exposure, supervision target, and aggregation under irreversible changes in voxel lattice, together with a continuous-spacing evaluation panel.

### 2.3 State-space and convolutional backbones

Mamba-style state-space models provide a compact 3D backbone in our development study, but no Mamba-specific mechanism is claimed. Physical spacing inserted into the recurrent step did not improve the preregistered robustness metrics, and the final method does not alter the backbone. The frozen replication plan includes Dynamic Mamba, Static Mamba, and 3D U-Net to determine how far the result extends beyond the development backbone.

## 3. Problem Formulation

Let an anatomical volume be represented on a reference grid R1 with 1 mm through-plane spacing and on alternative endpoint-matched grids with nominal spacing `s`. The alternative grid changes tensor depth and affine geometry while preserving the physical field of view. A candidate prediction is mapped back to R1 using the known affine transformation before comparison.

For each case and spacing, `Dpred` is the foreground Dice between the mapped candidate-grid prediction and the R1 prediction. `Dmap` is the foreground Dice between the mapped candidate prediction and the R1 reference label. `Smap@2mm` is the corresponding surface Dice with a 2 mm tolerance. `Dnative` is R1 foreground Dice. We summarize the spacing curve by its trapezoidal area (`Grid-AUC`), its minimum prediction and mapped Dice, the mean mapped Dice over the source range 1.5–3 mm, and `Extra Dmap`/`Extra Smap`, defined as the average at 4 and 5 mm.

This protocol measures controlled resampling stability. It does not model all changes in image acquisition, reconstruction kernels, motion, pathology prevalence, or scanner hardware.

## 4. Severity-Selected Native-Grid Consistency

### 4.1 Native supervision and posterior teacher

For an R1 image `x0` and label `y0`, the network produces logits `f_theta(x0)`. The native loss is the equal-weight sum of foreground Dice loss and cross entropy. The foreground posterior from R1 is detached to form the teacher:

`q = stopgrad(softmax(f_theta(x0))_foreground)`.

For each of two native candidate grids `g_k`, we resample the raw image directly to its endpoint-matched tensor and affine, run the same network, map the softmax probabilities back to R1, and compute foreground soft-Dice disagreement `e_k` with `q`.

### 4.2 Aggregation controls

Mean aggregation C uses `(e1+e2)/2`. Loss-adaptive D uses stop-gradient weights `softmax(5[e1,e2])`. Soft severity weighting W replaces the errors in this softmax with normalized log-spacing severity. The selected method S defines

`a_k = log(s_k / 1 mm) / log(3)`

and uses the error of the candidate with larger `a_k`; exact spacing ties use the mean. Selection depends only on requested spacing in millimetres. It cannot inspect loss, labels, gradient norm, confidence, or tensor depth.

The total objective is

`L = L_native + lambda(t) L_aux`,

where `lambda(t)` increases linearly to 0.1 over 500 updates. S and the controls share the backbone, initialization, case order, candidate images, affines, spacing pairs, optimizer, validation schedule, and checkpoint rule.

## 5. Controlled Audit Design

### 5.1 Data isolation

The continuous-grid development study uses 80 training, 20 validation, and 20 development-screen cases. A disjoint 40-case confirm_v2 split remains protected by a SHA-256 denylist. Checkpoint selection reads only R1 validation foreground Dice, and the development set is used for the preregistered method decision. Confirm_v2 has not been accessed or evaluated.

### 5.2 Source-of-gain controls

The native-random arm forwards the network on tensors constructed at each sampled native spacing. Degrade-on-R1 uses the same spacing draws to degrade the raw image but restores it to the R1 tensor before normalization and inference. Their difference isolates the contribution of changing native tensor geometry beyond fixed-grid degradation under this construction.

The label-supervised random arm uses ordinary segmentation loss on nearest-neighbour-resampled labels at both candidate grids. Random-K2 instead aligns both candidate posteriors to the detached R1 posterior. This is a construction-specific comparison between supervision targets, not a universal comparison between consistency and ground truth.

### 5.3 Training and evaluation

All development models use 2,500 full-volume updates, batch size 1, AdamW with learning rate `3e-4` and weight decay `1e-5`, bfloat16, and no augmentation. Validation occurs every 250 updates; ties keep the earliest checkpoint. Evaluation uses nominal through-plane spacings 1, 1.5, 2, 2.5, 3, 4, and 5 mm.

### 5.4 Statistical analysis

The severity-control comparison treats case × seed as paired observations. A hierarchical paired bootstrap samples 20 cases and then three seeds within each sampled case for 10,000 draws using seed 7331. The 80% interval is the preregistered development screening gate; 95% intervals are descriptive. The source audit used case-paired bootstrap at seed 17 and was followed by three-seed replication only for the prespecified D−C contrast.

## 6. Development Results

### 6.1 Native tensor-grid exposure dominates fixed-tensor degradation

Native-random reaches Extra Dmap 0.3357, compared with 0.0145 for Degrade-on-R1. The paired difference is +0.3211 with an 80% confidence interval of +0.2890 to +0.3514, and all 20 development cases are positive. Thus, the tested fixed-tensor degradation control does not reproduce the benefit of direct native-grid forwards. The supported interpretation is that the changed tensor depth, lattice, pooling path, feature-map discretization, and physical receptive-field trajectory jointly matter; this experiment does not separately identify which of those coupled properties is dominant.

### 6.2 Posterior consistency is stronger than candidate-grid label supervision under the tested construction

Label-supervised random is lower than Random-K2 by 0.0773 Extra Dmap (80% CI −0.0841 to −0.0703), with no positive case. This result is limited to nearest-neighbour candidate labels, the current loss, and the current training protocol. It does not imply that consistency generally dominates supervised learning.

### 6.3 Severity selection outperforms loss-adaptive aggregation on the development screen

Across three seeds, pooled Extra Dmap is 0.3475 for C, 0.3667 for D, 0.3970 for S, and 0.3783 for W. S exceeds C by 0.0495 (80% CI 0.0415–0.0576) and is positive in all three seeds. S exceeds D by 0.0304 (80% CI 0.0233–0.0376); seeds 17 and 29 are positive, whereas seed 41 is −0.0073. W also exceeds D in the pooled comparison by 0.0117 (80% CI 0.0056–0.0180), with the same two-positive, one-negative seed pattern. The preregistered decision is therefore `PREFER_SEVERITY_CONTROL`, with S selected because it gives the strongest and simplest severity-based result.

S also raises worst-grid mapped Dice from 0.1743 for C and 0.1911 for D to 0.2283. Native Dice remains comparable: 0.8802 for C, 0.8807 for D, and 0.8816 for S. On the observed hardware, S has the lowest training cost at 0.7658 seconds per update, compared with 0.8877 for C and 0.8841 for D.

### 6.4 Soft-worst largely tracks spacing severity, not a validated gradient mechanism

D assigns the larger weight to the more severe candidate in 88.60%–89.24% of updates. Its weights correlate strongly with W across seeds (Pearson 0.858–0.865; Spearman 0.924–0.929), although their mean absolute difference remains 0.236–0.244. Separate gradient diagnostics show unstable candidate conflict rates and no joint native/worst-grid advantage from projection. We therefore interpret D as an empirical severity-emphasizing rule in this setting. The update-level subset in which loss and spacing rankings disagree does not establish a subsequent causal benefit for loss-adaptive selection.

## 7. Confirmation and Replication Results

**Locked until execution. Do not fabricate prose.**

- confirm_v2, five seeds: [TO BE FILLED]
- Static Mamba replication: [TO BE FILLED]
- Dynamic Mamba replication: [TO BE FILLED]
- 3D U-Net replication: [TO BE FILLED]
- second dataset: [TO BE FILLED]
- continuous spacing curve and heterogeneous affine test: [TO BE FILLED]

If these results conflict, report the conflict and narrow the conclusion. Do not return to development to modify S.

## 8. Discussion

The experiments identify exposure as the first-order factor in this controlled problem. Degrading an image while preserving the R1 tensor fails to approximate the benefit of forwarding the same anatomy on genuinely different native lattices. This distinction matters because a 3D network is discretization-dependent at every stage: changing depth can alter rounding, pooling, feature-map support, and the mapping between index-space and millimetres even when the physical bounds are matched.

The aggregation audit also changes the interpretation of soft-worst. Its three-seed improvement over mean aggregation is real in the development data, but high-disagreement candidates are usually the coarser candidates. Once spacing-only controls are introduced, both hard and soft severity rules exceed D in the pooled analysis, and the hard rule is faster. The defensible conclusion is not that difficulty adaptation is useless in general; it is that the present evidence does not show independent value beyond spacing severity.

Severity selection intentionally uses a known acquisition variable rather than learning a new representation of spacing. This simplicity limits the mechanism claim but improves auditability. It makes the intervention invariant to candidate order, deterministic for a frozen schedule, and independent of labels and model state. It also avoids inferring a worst domain from noisy per-update loss.

Several negative experiments strengthen the boundary of the result. Multiplying physical spacing into the recurrent step did not add independent value. Source-risk variance was negatively associated with extrapolation risk. Conservative probability transport and occupancy supervision were mathematically well behaved but worsened the preregistered mapped metrics. Gradient projection did not provide stable joint improvements. These failures prevent a broader optimization or physical-dynamics story from being attached to the final method.

## 9. Limitations

The current S result is selected on a 20-case development screen and uses one Static Mamba implementation. Although the case × seed analysis quantifies variability across three seeds, it is not a substitute for independent held-out confirmation. Confirm_v2, cross-backbone replication, and a second dataset are therefore required before submission-level claims are finalized.

The controlled grids change through-plane spacing while matching physical bounds; they do not reproduce every property of clinical acquisition or reconstruction. The earlier heterogeneous Task09 study of the fixed-grid method was negative, so no cross-dataset robustness claim is justified. Candidate label supervision uses nearest-neighbour-resampled labels and one fixed segmentation objective, limiting the scope of the posterior-versus-label comparison. Finally, S identifies severity by spacing magnitude, not by anatomy-dependent information loss, and absolute performance at 5 mm remains low.

## 10. Conclusion

In a controlled Task04 development study, direct exposure to continuous native tensor grids is the principal supported source of resampling stability, whereas fixed-tensor degradation is insufficient. Loss-adaptive soft-worst aggregation improves over a mean objective but mostly follows spacing severity; directly selecting the more severe candidate gives the best frozen development result with no native-accuracy loss and lower observed cost. We freeze this severity-selected objective for independent confirmation and reject broader claims about gradient conflict, worst-domain optimization, Mamba-specific dynamics, or heterogeneous clinical robustness.

## References

See `../07_RELATED_WORK/references_verified.bib` and `REFERENCE_MAP.md`. Bibliographic fields marked as preprints should be updated only from an official venue record.

