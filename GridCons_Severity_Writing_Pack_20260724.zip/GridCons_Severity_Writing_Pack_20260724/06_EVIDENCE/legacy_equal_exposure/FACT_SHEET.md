# Canonical fact sheet

## Paper identity

- Recommended title: **What Drives Resampling Stability? An Equal-Exposure Study of Paired-Grid Training for 3D Medical Image Segmentation**
- Target: a modest CCF-C-level conference paper, not a top-tier method paper.
- Paper type: controlled causal audit of paired-grid training, including a label-free consistency objective and a matched-exposure dual-grid supervised control.
- General intervention: **paired-grid training**. **Paired-grid consistency** names only the label-free objective arm.
- `GridCons-Mamba` may name the Mamba implementation, but not a supposedly novel Mamba primitive.

## Task04 design

- Dataset: Medical Segmentation Decathlon Task04 Hippocampus, MRI, 260 labeled cases, two foreground classes.
- Frozen split from `numpy.default_rng(20260718)`: 80 train, 20 validation, 20 development, 40 untouched confirmation; 100 unused.
- Controlled same-case grids: R1, R2, and R4 use 1, 2, and 4 mm through-plane spacing, 1 mm in-plane spacing, and matched physical bounds.
- Seeds: 17, 29, 41, 53, 67.
- Training: 2,500 updates; validation every 250 updates; AdamW, learning rate `3e-4`, weight decay `1e-5`, bfloat16.
- Checkpoint selection: R1 validation foreground Dice only.
- R2 labels: excluded from training and model selection.
- Statistics: class average within each case/seed cell; 10,000-replicate paired hierarchical bootstrap over cases and seeds.
- Confirmation evidence: 40 cases × 5 seeds.

## Method

For native view `x1`, label `y1`, and label-free coarser rendering `x2` of the same physical volume:

`L = Lseg(f(x1), y1) + lambda(t) [1 - SoftDice(stopgrad(p1), Align(p2))]`

`p1` and `p2` are foreground softmax probabilities. Remove padding, trilinearly resize R2 probabilities to the R1 shape with `align_corners=True`, then renormalize. The consistency weight warms linearly to 0.1 over the first 500 updates. The regularizer is absent at inference, so paired and unpaired arms of the same backbone have identical inference architecture and parameter count.

## Canonical Task04 means

Use these values in the main paper; source: `02_task04_primary/CONTROL_REPORT.md`.

| Backbone / arm | R1 Dice | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Mamba, dynamic delta | 0.8469 | 0.4384 | 0.4309 | 0.5942 | 0.0024 |
| Mamba, dynamic delta + consistency | 0.8467 | 0.8525 | 0.8189 | 0.9580 | 0.1048 |
| Mamba, static delta | 0.8455 | 0.4966 | 0.4837 | 0.6563 | 0.0068 |
| Mamba, static delta + consistency | 0.8467 | 0.8531 | 0.8150 | 0.9555 | 0.1186 |
| 3D U-Net | 0.8739 | 0.5883 | 0.5652 | 0.7438 | 0.0149 |
| 3D U-Net + consistency | 0.8755 | 0.9141 | 0.8536 | 0.9807 | 0.1970 |

## Canonical paired effects with 95% CIs

These contrasts use single-grid baselines. They establish the total effect of adding the paired R2 branch plus its objective, but they do **not** isolate the consistency loss from extra R2 exposure.

| Comparison | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R1 Dice | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Dynamic Mamba + consistency − Dynamic Mamba | +0.4141 [0.3380, 0.4896] | +0.3881 [0.3104, 0.4655] | +0.3638 [0.2851, 0.4462] | -0.0003 [-0.0057, 0.0044] | +0.1023 [0.0741, 0.1338] |
| Static Mamba + consistency − Static Mamba | +0.3566 [0.2997, 0.4130] | +0.3313 [0.2766, 0.3857] | +0.2991 [0.2451, 0.3542] | +0.0012 [-0.0028, 0.0049] | +0.1118 [0.0725, 0.1538] |
| 3D U-Net + consistency − 3D U-Net | +0.3258 [0.2539, 0.3983] | +0.2884 [0.2207, 0.3594] | +0.2369 [0.1757, 0.3042] | +0.0016 [-0.0019, 0.0051] | +0.1821 [0.1270, 0.2404] |
| Mamba delta × consistency interaction | -0.0576 [-0.1213, -0.0010] | -0.0567 [-0.1258, 0.0038] | -0.0646 [-0.1427, 0.0029] | +0.0015 [-0.0037, 0.0067] | +0.0095 [-0.0312, 0.0523] |

The negative interaction means static delta is not a privileged carrier of the effect. Do not reinterpret it as evidence for static delta. Do not describe the large single-grid contrasts as the effect of the consistency loss alone.

## Highest-priority equal-exposure causal audit

Source: `03_task04_equal_exposure/FULL_REPORT.md`. The `DualGrid-Sup` control uses the same R1/R2 exposure, two forward passes, 2,500 updates, loss-weight schedule, validation rule, backbone, and seed set as the corresponding consistency arm, but replaces prediction consistency with supervised R2 segmentation against a nearest-neighbor-resampled R2 label:

`L = Lseg(pred_R1, y_R1) + lambda(t) Lseg(pred_R2, y_R2)`.

It is a strong matched-exposure comparator. Because it uses R2 labels, it tests objective/target choice under matched exposure; it is not a label-free alternative.

| Backbone / arm | R1 Dice | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Dynamic Mamba + consistency | 0.846653 | 0.852491 | 0.818923 | 0.958006 | 0.104750 |
| Dynamic Mamba + DualGrid-Sup | 0.847119 | 0.849174 | 0.814762 | 0.956047 | 0.069635 |
| Static Mamba + consistency | 0.846675 | 0.853143 | 0.815035 | 0.955481 | 0.118601 |
| Static Mamba + DualGrid-Sup | 0.848208 | 0.848704 | 0.812561 | 0.954149 | 0.083155 |
| 3D U-Net + consistency | 0.875486 | 0.914056 | 0.853639 | 0.980681 | 0.197037 |
| 3D U-Net + DualGrid-Sup | 0.874246 | 0.903604 | 0.848333 | 0.977503 | 0.131329 |

Consistency minus matched DualGrid-Sup:

| Backbone | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R1 Dice | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Dynamic Mamba | +0.003317 [-0.000515, 0.007091] | +0.004161 [0.000476, 0.008142] | +0.001959 [-0.001478, 0.005200] | -0.000466 [-0.002819, 0.002085] | +0.035115 [0.022191, 0.047961] |
| Static Mamba | +0.004438 [0.000871, 0.007571] | +0.002474 [-0.000918, 0.005562] | +0.001331 [-0.001349, 0.003917] | -0.001533 [-0.004250, 0.000685] | +0.035446 [0.017829, 0.053685] |
| 3D U-Net | +0.010452 [0.006307, 0.014884] | +0.005306 [0.000039, 0.010241] | +0.003178 [-0.000693, 0.007455] | +0.001239 [-0.002616, 0.004690] | +0.065708 [0.035883, 0.100535] |

Correct interpretation:

- The large R2 improvements versus single-grid training are effects of the **paired-grid training package** and are nearly reproduced by matched dual-grid supervision.
- The dynamic-Mamba primary R2 consistency contrast is inconclusive because its CI crosses zero. Static Mamba and U-Net show statistically positive but small residual R2 consistency differences.
- The consistency objective shows a larger positive residual on unseen severe R4 across all three backbones, but absolute R4 consistency remains low.
- Therefore the audit status is `MECHANISM_RESULT_INCONCLUSIVE`: the shared paired-grid training package reproduces most of the R2 gain; the isolated exposure effect is not identified, while objective-specific differences are small at R2 and more visible at R4.

## Efficiency facts

- Mamba dynamic arms: 99,555 parameters; static arms: 99,411 parameters.
- Consistency adds no inference-time branch and no parameters within a fixed backbone arm.
- Measured batch-1 inference latency and memory are in `02_task04_primary/PERFORMANCE.json` and the report. Do not claim meaningful speed differences between paired and unpaired variants; the observed sub-millisecond differences are measurement noise.

## Task09 external boundary

- Independent MSD Task09 Spleen CT, heterogeneous real spacing.
- Five outer folds, three seeds, 41 outer-test cases.
- The preregistered external scientific rule failed.
- Static-consistency versus dynamic baseline: consistency -0.0083 [-0.0327, 0.0098], native Dice +0.0043 [-0.0290, 0.0437], mapped Dice +0.0070 [-0.0296, 0.0467], Surface Dice@2mm -0.0052 [-0.0283, 0.0238].
- Correct conclusion: Task04 gains do not establish robustness to heterogeneous cross-dataset acquisition.

## Negative mechanism work

- A simple conservative/observable-grid transport pilot failed its preregistered development gate: P−R Extra mapped Dice -0.023217, 80% CI [-0.033781, -0.012464].
- A physical-spacing-scaled Mamba delta idea was invalidated by local controls and is also too close to TIDES.
- Neither idea belongs in the proposed method. Mention them only if useful as future-work cautions, not as contributions.

## Non-negotiable forbidden claims

Do not write any of the following, even in softened form:

- static channel-wise state timescales are the key/useful/necessary carrier of paired-grid consistency;
- token-wise delta adaptation is proven to cause grid sensitivity;
- first spacing-aware Mamba, metric-calibrated Mamba, millimetre-scaled transition, or physical-step Mamba;
- general clinical robustness, cross-dataset generalization, scanner robustness, or real-spacing robustness;
- state of the art, unless a complete and directly comparable benchmark table is added later;
- paired-grid consistency, consistency regularization, common-frame alignment, or Mamba-plus-consistency is individually novel.
- the huge R2 gain is produced by, caused by, or uniquely attributable to the consistency loss;
- consistency clearly dominates matched dual-grid supervision on R2 across all backbones;
- the equal-exposure audit proves that exposure alone is causal—the matched control changes the target to supervised R2 labels, so the defensible conclusion is that the old loss-only attribution is not identifiable.

## Defensible contribution language

1. Formulate and measure controlled same-anatomy resampling instability with physically aligned grids and label-referenced mapped metrics.
2. Audit paired-grid training with a label-free consistency objective and a matched-exposure dual-grid supervised control, separating the total paired-training gain from the objective-specific residual.
3. Provide five-seed Mamba and 3D U-Net evidence showing that static timescales are unnecessary, most R2 improvement is not uniquely attributable to consistency, and consistency retains a larger residual advantage under unseen R4 resampling.
4. Report a disjoint confirmation study and a negative external validation to define the supported scope.

## Known number discrepancy

`04_negative_and_boundary/dynamic_full_corroboration/` contains a separate exact-protocol rerun with R2 consistency 0.8541. The independent full control matrix reports 0.8525. Use **0.8525** and its paired effects in the paper because the control matrix is the canonical integrated analysis. The separate rerun is corroboration only.
