# Mandatory equal-exposure causal correction

This file supersedes every earlier sentence that attributes the large single-grid-to-consistency gain to the consistency loss alone.

## Why the old contrast is confounded

The original baseline trains on one labeled R1 view. The consistency arm processes R1 and R2, adds a second forward pass, and applies an R2-linked objective. Therefore `consistency − single-grid` jointly changes view exposure, computation, and objective. It cannot identify the isolated effect of the consistency loss.

## Matched control

The later `DualGrid-Sup` arm matches the R1/R2 exposure, two forwards, 2,500 updates, warm-up schedule, backbone, validation rule, and seeds, but replaces the stop-gradient prediction-consistency term with R2 segmentation supervision. Full engineering and evaluation status is PASS; all 40 confirmation cases and five seeds are present.

## Result

At R2, DualGrid-Sup nearly reproduces the consistency arms:

- Dynamic Mamba: 0.849174 versus 0.852491 R2 consistency; difference +0.003317, 95% CI [-0.000515, 0.007091].
- Static Mamba: 0.848704 versus 0.853143; difference +0.004438 [0.000871, 0.007571].
- 3D U-Net: 0.903604 versus 0.914056; difference +0.010452 [0.006307, 0.014884].

The objective-specific R2 residual is therefore small and, for dynamic Mamba, statistically inconclusive. The large R2 gain over single-grid training must be called a **total paired-grid training effect**, not a consistency-loss effect.

At unseen R4, consistency retains larger positive residuals over DualGrid-Sup: +0.035115 [0.022191, 0.047961], +0.035446 [0.017829, 0.053685], and +0.065708 [0.035883, 0.100535] for dynamic Mamba, static Mamba, and U-Net, respectively. This supports a cautious extrapolation observation, not a solved severe-spacing claim, because absolute R4 consistency remains only 0.104750–0.197037.

## Required paper language

Use:

> Relative to single-grid training, paired R1/R2 training produced large improvements in controlled R2 stability. However, matched dual-grid supervision recovered nearly all of this gain, showing that the original contrast did not isolate the consistency objective. The residual consistency advantage was small at R2 and inconclusive for dynamic Mamba, but was larger and positive at the unseen R4 stress test across all three backbones.

Do not use:

> The consistency loss caused a 0.3–0.4 improvement.

The final scientific status is **MECHANISM_RESULT_INCONCLUSIVE**, with a positive but bounded R4 extrapolation observation.
