# Task04 independent control matrix

Final status: **PASS_CONTROL_EVIDENCE_COMPLETE**

All confirm values are paired over 40 cases × 5 seeds. Confidence intervals use the frozen hierarchical paired bootstrap over cases and seeds.

## Arm means

| Arm | R1 Dice | R2 consistency | R2 mapped Dice | R2 surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| dynamic_delta | 0.8469 | 0.4384 | 0.4309 | 0.5942 | 0.0024 |
| static_delta | 0.8455 | 0.4966 | 0.4837 | 0.6563 | 0.0068 |
| gridcons_mamba | 0.8467 | 0.8531 | 0.8150 | 0.9555 | 0.1186 |
| dynamic_delta_consistency | 0.8467 | 0.8525 | 0.8189 | 0.9580 | 0.1048 |
| unet3d | 0.8739 | 0.5883 | 0.5652 | 0.7438 | 0.0149 |
| unet3d_consistency | 0.8755 | 0.9141 | 0.8536 | 0.9807 | 0.1970 |

## Required paired comparisons

| Comparison | R2 consistency | R2 mapped Dice | R2 surface@2mm | R1 guardrail | R4 consistency |
|---|---:|---:|---:|---:|---:|
| dynamic_delta_consistency_minus_dynamic_delta | +0.4141 [+0.3380, +0.4896] | +0.3881 [+0.3104, +0.4655] | +0.3638 [+0.2851, +0.4462] | -0.0003 [-0.0057, +0.0044] | +0.1023 [+0.0741, +0.1338] |
| gridcons_mamba_minus_static_delta | +0.3566 [+0.2997, +0.4130] | +0.3313 [+0.2766, +0.3857] | +0.2991 [+0.2451, +0.3542] | +0.0012 [-0.0028, +0.0049] | +0.1118 [+0.0725, +0.1538] |
| unet3d_consistency_minus_unet3d | +0.3258 [+0.2539, +0.3983] | +0.2884 [+0.2207, +0.3594] | +0.2369 [+0.1757, +0.3042] | +0.0016 [-0.0019, +0.0051] | +0.1821 [+0.1270, +0.2404] |
| mamba_difference_in_differences | -0.0576 [-0.1213, -0.0010] | -0.0567 [-0.1258, +0.0038] | -0.0646 [-0.1427, +0.0029] | +0.0015 [-0.0037, +0.0067] | +0.0095 [-0.0312, +0.0523] |

## Five-seed paired differences

- `dynamic_delta_consistency_minus_dynamic_delta` R2 consistency: {'17': 0.35195861701117676, '29': 0.42893493122496107, '41': 0.5191519298374242, '53': 0.2972693051819471, '67': 0.47338411121348567}
- `dynamic_delta_consistency_minus_dynamic_delta` R1 guardrail: {'17': -0.0033177533133362525, '29': 0.001122069307575313, '41': -0.0018284106564653707, '53': -0.0001366025633973339, '67': 0.0028266463714730792}
- `gridcons_mamba_minus_static_delta` R2 consistency: {'17': 0.2761184939373753, '29': 0.4272059207282955, '41': 0.35163599707769644, '53': 0.318994573506041, '67': 0.40889078213685276}
- `gridcons_mamba_minus_static_delta` R1 guardrail: {'17': -0.0034336034473288813, '29': 0.001368336672114226, '41': 0.0020097279359327204, '53': 0.002348280264296565, '67': 0.003812168917845249}
- `unet3d_consistency_minus_unet3d` R2 consistency: {'17': 0.35667430692278207, '29': 0.2105648517524923, '41': 0.4305713656494321, '53': 0.2823755716544498, '67': 0.3487045040752572}
- `unet3d_consistency_minus_unet3d` R1 guardrail: {'17': 0.0024004876203750137, '29': -0.002311901561662563, '41': 0.0017152023419957723, '53': 0.003211543763782376, '67': 0.002822115226396213}
- `mamba_difference_in_differences` R2 consistency: {'17': -0.07584012307380147, '29': -0.001729010496665552, '41': -0.16751593275972776, '53': 0.021725268324093862, '67': -0.06449332907663283}
- `mamba_difference_in_differences` R1 guardrail: {'17': -0.00011585013399262878, '29': 0.00024626736453891294, '41': 0.003838138592398091, '53': 0.002484882827693899, '67': 0.0009855225463721695}

## Parameters, batch-1 latency, and peak allocated memory

Same R1 development case, GPU, bfloat16, batch=1, 20 warmups, 100 synchronized iterations for every arm.
Hardware: NVIDIA PG506-230; 0, GPU-15d0f8e4-76ba-88f5-b6f0-5b264271e97f, NVIDIA PG506-230, 580.159.03, 98304 MiB, 8.0.

| Arm | Parameters | Mean latency (ms) | Median (ms) | p95 (ms) | Peak allocated (bytes) |
|---|---:|---:|---:|---:|---:|
| dynamic_delta | 99555 | 42.711 | 42.595 | 44.688 | 163626496 |
| static_delta | 99411 | 42.022 | 41.785 | 43.896 | 163268608 |
| gridcons_mamba | 99411 | 42.357 | 42.146 | 45.050 | 163268608 |
| dynamic_delta_consistency | 99555 | 42.021 | 42.067 | 43.545 | 163270656 |
| unet3d | 1401299 | 2.560 | 2.523 | 2.638 | 160794624 |
| unet3d_consistency | 1401299 | 2.513 | 2.496 | 2.581 | 160794624 |

## Frozen interpretation

- The Mamba difference-in-differences 95% CI lower bound is not above zero; static delta cannot be claimed as a necessary source of the consistency gain.
- The U-Net control passes: consistency has a cross-backbone effect, so the full gain cannot be attributed to Mamba.

## Validity gates

- protocol_and_source_hashes_unchanged: PASS
- development_gate_released_exact_checkpoints: PASS
- all_15_new_training_runs_complete: PASS
- r2_labels_excluded_from_training_and_selection: PASS
- confirm_7200_rows_complete: PASS
- confirm_metric_identities_exact: PASS
- confirm_evaluation_has_no_failures: PASS
- confirm_metrics_hash_matches: PASS
- all_metrics_finite: PASS
- all_six_performance_records_complete: PASS
- benchmark_protocol_matches_frozen: PASS
- evaluation_bound_to_current_release: PASS
- performance_bound_to_current_release_and_checkpoints: PASS
