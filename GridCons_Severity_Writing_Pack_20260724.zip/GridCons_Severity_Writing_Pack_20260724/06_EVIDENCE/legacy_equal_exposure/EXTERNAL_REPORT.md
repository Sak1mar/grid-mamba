# Task09 external real-spacing validation

Final status: **FAIL_EXTERNAL_SCIENTIFIC**

Evidence axes are intentionally separate:

- engineering_runnable: `True`
- independent_dataset: `True`
- real_heterogeneous_spacing: `True`
- scientific_effect_pass: `False`

All estimates pair 41 cases with seeds 17/29/41; confidence intervals use the frozen hierarchical case-and-seed bootstrap.

## Arm means

| Arm | consistency | native Dice | mapped Dice | surface Dice@2mm |
|---|---:|---:|---:|---:|
| dynamic_delta | 0.7684 | 0.4441 | 0.4335 | 0.2482 |
| static_delta | 0.7457 | 0.4513 | 0.4496 | 0.2444 |
| gridcons_mamba | 0.7601 | 0.4484 | 0.4405 | 0.2430 |

## Paired comparisons

| Comparison | consistency | native Dice guardrail | mapped Dice | surface Dice@2mm |
|---|---:|---:|---:|---:|
| gridcons_mamba_minus_dynamic_delta | -0.0083 [-0.0327, +0.0098] | +0.0043 [-0.0290, +0.0437] | +0.0070 [-0.0296, +0.0467] | -0.0052 [-0.0283, +0.0238] |
| gridcons_mamba_minus_static_delta | +0.0144 [-0.0031, +0.0350] | -0.0029 [-0.0195, +0.0123] | -0.0091 [-0.0278, +0.0058] | -0.0014 [-0.0158, +0.0147] |

## Five outer folds

| Fold | Comparison | consistency | native Dice | mapped Dice | surface Dice@2mm |
|---:|---|---:|---:|---:|---:|
| 0 | gridcons_mamba_minus_dynamic_delta | -0.0118 | -0.0175 | -0.0150 | -0.0264 |
| 0 | gridcons_mamba_minus_static_delta | -0.0059 | -0.0341 | -0.0335 | -0.0211 |
| 1 | gridcons_mamba_minus_dynamic_delta | -0.0365 | -0.0474 | -0.0364 | -0.0401 |
| 1 | gridcons_mamba_minus_static_delta | -0.0045 | -0.0058 | -0.0004 | -0.0031 |
| 2 | gridcons_mamba_minus_dynamic_delta | +0.0324 | +0.0355 | +0.0443 | +0.0406 |
| 2 | gridcons_mamba_minus_static_delta | +0.0299 | +0.0211 | +0.0105 | +0.0172 |
| 3 | gridcons_mamba_minus_dynamic_delta | -0.0169 | +0.0447 | +0.0409 | +0.0264 |
| 3 | gridcons_mamba_minus_static_delta | +0.0176 | +0.0103 | +0.0105 | +0.0095 |
| 4 | gridcons_mamba_minus_dynamic_delta | -0.0081 | +0.0091 | +0.0040 | -0.0239 |
| 4 | gridcons_mamba_minus_static_delta | +0.0377 | -0.0024 | -0.0293 | -0.0070 |

## Severe-spacing stratum (10 cases)

| Comparison | consistency | native Dice | mapped Dice | surface Dice@2mm |
|---|---:|---:|---:|---:|
| gridcons_mamba_minus_dynamic_delta | +0.0156 [-0.0162, +0.0548] | +0.0088 [-0.0339, +0.0752] | +0.0115 [-0.0331, +0.0764] | +0.0005 [-0.0264, +0.0395] |
| gridcons_mamba_minus_static_delta | +0.0259 [-0.0125, +0.0852] | -0.0217 [-0.0869, +0.0402] | -0.0304 [-0.1072, +0.0239] | -0.0066 [-0.0271, +0.0128] |

## Primary rule

- mean_consistency_gain_positive: FAIL
- native_grid_dice_guardrail: PASS
- consistency_ci_lower_above_zero: FAIL

The preregistered external scientific rule fails; Task04 cannot be claimed to generalize across this dataset/real-spacing validation.
