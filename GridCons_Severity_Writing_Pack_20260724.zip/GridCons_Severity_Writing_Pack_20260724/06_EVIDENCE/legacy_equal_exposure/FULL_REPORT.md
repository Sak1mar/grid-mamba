# GRIDCONS_EQEXP_C0 Full report

ENGINEERING_STATUS=PASS
FULL_EXECUTION_STATUS=PASS
SCIENTIFIC_STATUS=MECHANISM_RESULT_INCONCLUSIVE
PAPER_CLAIM_STATUS=MECHANISM_RESULT_INCONCLUSIVE
OUTER_TEST_TOUCHED=true
FAILED_JOBS=none
RERUNS=none
UNSUPPORTED_CLAIMS=none

## Absolute means

| Method | R2 consistency | R2 mapped Dice | R2 surface@2mm | R1 native Dice | R4 consistency |
|---|---:|---:|---:|---:|---:|
| dynamic_delta | 0.438351 | 0.430858 | 0.594208 | 0.846920 | 0.002432 |
| dynamic_delta_consistency | 0.852491 | 0.818923 | 0.958006 | 0.846653 | 0.104750 |
| dynamic_delta_dualgrid_sup | 0.849174 | 0.814762 | 0.956047 | 0.847119 | 0.069635 |
| static_delta | 0.496574 | 0.483693 | 0.656333 | 0.845454 | 0.006772 |
| gridcons_mamba | 0.853143 | 0.815035 | 0.955481 | 0.846675 | 0.118601 |
| static_delta_dualgrid_sup | 0.848704 | 0.812561 | 0.954149 | 0.848208 | 0.083155 |
| unet3d | 0.588278 | 0.565203 | 0.743805 | 0.873918 | 0.014935 |
| unet3d_consistency | 0.914056 | 0.853639 | 0.980681 | 0.875486 | 0.197037 |
| unet3d_dualgrid_sup | 0.903604 | 0.848333 | 0.977503 | 0.874246 | 0.131329 |

## GridCons minus DualGrid-Sup paired results

CIs use 10,000 case × seed hierarchical paired bootstrap samples (seed 7301).

- dynamic_delta_consistency_vs_dynamic_delta_dualgrid_sup: primary +0.003317, 95% CI [-0.0005154039462529039, 0.007090982035908055]; MECHANISM_RESULT_INCONCLUSIVE
  - per-seed paired differences: {'17': 0.0013044574238559952, '29': 0.0023022445623935572, '41': 0.0062919498394527484, '53': 0.0013249955698244997, '67': 0.005359192078739697}
- gridcons_mamba_vs_static_delta_dualgrid_sup: primary +0.004438, 95% CI [0.000870519458561877, 0.007570688850929591]; SUPPORTED_NOT_FULLY_EXPLAINED_BY_DUALGRID_SUP
  - per-seed paired differences: {'17': 0.0029025203133046713, '29': 0.007969520740857845, '41': 0.0049322962080646186, '53': -0.0004240449722129336, '67': 0.006811920120491327}
- unet3d_consistency_vs_unet3d_dualgrid_sup: primary +0.010452, 95% CI [0.006306654421004636, 0.01488410224005933]; SUPPORTED_NOT_FULLY_EXPLAINED_BY_DUALGRID_SUP
  - per-seed paired differences: {'17': 0.01270853160979878, '29': 0.012825446012130745, '41': 0.013989754065105262, '53': 0.004541933330511383, '67': 0.008196735688390402}

Full per-arm/per-seed absolute endpoint means are in `FULL_RESULTS.json` under `seed_means`.
