# CCF-C 投稿版实验补充：等暴露修正版

## 推荐题目

**What Drives Resampling Stability? An Equal-Exposure Study of Paired-Grid Training for 3D Medical Image Segmentation**

## 论文定位

本文是一项受控证据研究，不把巨大增益归因于 consistency loss 单独产生。原始 single-grid 与 consistency arms 同时改变了 R2 暴露、第二次前向计算和训练目标；后续 `DualGrid-Sup` 等暴露对照表明，大部分 R2 增益可由另一种 paired-grid objective 复现。论文的承重点应是：用完整控制拆解 paired-grid training 的总效应、objective-specific residual、静态 delta 假设和跨数据集边界。

## 可直接使用的英文摘要

Volumetric segmentation models can produce different masks when the same anatomy is represented on grids with different through-plane sampling. We investigate this failure mode using physically aligned R1/R2/R4 views and ask what component of paired-grid training drives the apparent robustness gain. On MSD Task04 Hippocampus, we compare single-grid training, label-free prediction consistency, and an equal-exposure dual-grid supervised control across dynamic-delta Mamba, static-delta Mamba, and 3D U-Net, using five seeds and a disjoint 40-case confirmation set. Relative to single-grid training, both paired-grid objectives produce large R2 improvements. However, the supervised control nearly matches prediction consistency: for dynamic Mamba, R2 consistency is 0.4384, 0.8525, and 0.8492 for single-grid, consistency, and equal-exposure supervision, respectively. The matched consistency-minus-supervision difference is only 0.0033 (95% CI -0.0005 to 0.0071), showing that the original large contrast does not isolate the consistency loss. Small positive residuals appear for static Mamba and 3D U-Net, while consistency shows larger advantages on the unseen R4 stress test. A negative Task09 Spleen study further limits external generalization. These results support paired-grid training as an effective controlled intervention while cautioning against loss-only causal attribution.

## 推荐贡献点

1. We formulate same-anatomy resampling instability as a distinct controlled evaluation problem using physically aligned grids and label-referenced mapped metrics.
2. We conduct an equal-exposure audit that separates the total effect of paired R1/R2 training from the residual difference between label-free prediction consistency and dual-grid supervision.
3. Across two Mamba parameterizations and 3D U-Net, we show that the large R2 gain is not uniquely attributable to consistency or static timescales; objective-specific R2 residuals are small, whereas consistency retains larger positive differences on unseen R4.
4. We report a disjoint five-seed confirmation study and a negative real-spacing external validation, explicitly bounding the supported conclusion.

## 主表 1：完整九臂结果

所有数值均为 Task04 40 例确认集 × 5 seeds 的平均值。

| Backbone / arm | R1 Dice | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Mamba, dynamic delta, single-grid | 0.846920 | 0.438351 | 0.430858 | 0.594208 | 0.002432 |
| Mamba, dynamic delta + consistency | 0.846653 | 0.852491 | 0.818923 | 0.958006 | 0.104750 |
| Mamba, dynamic delta + DualGrid-Sup | 0.847119 | 0.849174 | 0.814762 | 0.956047 | 0.069635 |
| Mamba, static delta, single-grid | 0.845454 | 0.496574 | 0.483693 | 0.656333 | 0.006772 |
| Mamba, static delta + consistency | 0.846675 | 0.853143 | 0.815035 | 0.955481 | 0.118601 |
| Mamba, static delta + DualGrid-Sup | 0.848208 | 0.848704 | 0.812561 | 0.954149 | 0.083155 |
| 3D U-Net, single-grid | 0.873918 | 0.588278 | 0.565203 | 0.743805 | 0.014935 |
| 3D U-Net + consistency | 0.875486 | 0.914056 | 0.853639 | 0.980681 | 0.197037 |
| 3D U-Net + DualGrid-Sup | 0.874246 | 0.903604 | 0.848333 | 0.977503 | 0.131329 |

## 主表 2：Consistency − DualGrid-Sup 等暴露差值

95% CI 来自 10,000 次 case × seed hierarchical paired bootstrap。

| Backbone | R2 consistency | R2 mapped Dice | R2 Surface Dice@2mm | R1 Dice guardrail | R4 consistency |
|---|---:|---:|---:|---:|---:|
| Dynamic Mamba | +0.003317 [-0.000515, 0.007091] | +0.004161 [0.000476, 0.008142] | +0.001959 [-0.001478, 0.005200] | -0.000466 [-0.002819, 0.002085] | +0.035115 [0.022191, 0.047961] |
| Static Mamba | +0.004438 [0.000871, 0.007571] | +0.002474 [-0.000918, 0.005562] | +0.001331 [-0.001349, 0.003917] | -0.001533 [-0.004250, 0.000685] | +0.035446 [0.017829, 0.053685] |
| 3D U-Net | +0.010452 [0.006307, 0.014884] | +0.005306 [0.000039, 0.010241] | +0.003178 [-0.000693, 0.007455] | +0.001239 [-0.002616, 0.004690] | +0.065708 [0.035883, 0.100535] |

## 正确结果表达

> Relative to single-grid training, paired R1/R2 training produced large improvements in R2 stability for all three backbones. This total contrast did not isolate the prediction-consistency objective because it also introduced a second grid exposure and forward pass. Under matched exposure, DualGrid-Sup nearly reproduced the R2 results. The consistency-minus-supervision difference in R2 prediction consistency was +0.0033 (-0.0005 to 0.0071) for dynamic Mamba, +0.0044 (0.0009 to 0.0076) for static Mamba, and +0.0105 (0.0063 to 0.0149) for 3D U-Net. Thus, the objective-specific R2 advantage was small and not supported for dynamic Mamba. In contrast, consistency retained larger positive differences on the unseen R4 stress test, although absolute R4 consistency remained low.

## 方法段必须增加的对照定义

Consistency arm:

`L_cons = Lseg(pred_R1, y_R1) + lambda(t) [1 - SoftDice(stopgrad(p_R1), Align(p_R2))]`.

Equal-exposure DualGrid-Sup arm:

`L_sup = Lseg(pred_R1, y_R1) + lambda(t) Lseg(pred_R2, y_R2)`.

两者使用相同 backbone、R1/R2 views、两次前向、2,500 updates、`lambda(t)=0.1 min(1,t/500)`、五个种子、R1 validation checkpoint rule。DualGrid-Sup 使用通过 nearest-neighbor resampling 得到的 R2 label；consistency arm 不使用 R2 label。

该 matched contrast 比较的是“objective/target choice under equal exposure”，不能再称为纯粹证明 exposure 因果，因为监督目标本身也不同。

## Static delta 与 interaction

原 Mamba factorial 仍用于排除 static-timescale 叙事：R2 consistency 的 delta × consistency interaction 为 -0.0576 [-0.1213, -0.0010]。因此 static delta 既不是必要条件，也不能作为贡献。

## Task09 外部边界

Task09 Spleen 为独立 CT、真实 heterogeneous spacing、5 outer folds、3 seeds、41 outer-test cases。预注册规则失败：static-consistency 相对 dynamic baseline 的 consistency 差为 -0.0083 [-0.0327, 0.0098]，mapped Dice 为 +0.0070 [-0.0296, 0.0467]。只能写成阴性外部验证。

## 必须删除的表达

- `the consistency loss produced/caused the 0.3–0.4 gain`；
- `the gain comes from consistency rather than exposure`；
- `consistency consistently dominates equal-exposure supervision at R2`；
- `static timescales are a carrier of the gain`；
- `first spacing-aware/metric-calibrated/millimetre-scaled Mamba`；
- `general clinical or cross-dataset robustness`。

## 推荐稿件结构

1. Introduction：提出同病例重采样不稳定及因果归因问题。
2. Methods：R1/R2/R4、Consistency、DualGrid-Sup、single-grid arms。
3. Controlled protocol：九臂、5 seeds、disjoint confirmation、hierarchical bootstrap。
4. Results：先给 total paired-training contrasts，立即用 equal-exposure comparisons 修正；再报告 static-delta interaction 和 R4。
5. External boundary：Task09 阴性结果。
6. Discussion：R2 大增益主要不是 loss-specific；R4 residual 是有限的正观察，机制总体 `MECHANISM_RESULT_INCONCLUSIVE`。
