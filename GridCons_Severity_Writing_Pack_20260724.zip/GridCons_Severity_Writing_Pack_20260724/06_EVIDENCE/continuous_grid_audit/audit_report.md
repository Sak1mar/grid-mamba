# Grid resampling causal source audit

| arm | Dnative | Grid-AUC | Worst Dpred | Worst Dmap | Source Dmap | Extra Dmap | Extra Smap |
|---|---:|---:|---:|---:|---:|---:|---:|
| fixed_k1 | 0.8754 | 0.4869 | 0.0682 | 0.0667 | 0.7582 | 0.1154 | 0.2375 |
| fixed_k2 | 0.8754 | 0.4869 | 0.0682 | 0.0667 | 0.7582 | 0.1154 | 0.2375 |
| random_k1 | 0.8727 | 0.6601 | 0.2112 | 0.2002 | 0.8168 | 0.3597 | 0.5207 |
| random_k2 | 0.8728 | 0.6494 | 0.1694 | 0.1585 | 0.8131 | 0.3357 | 0.4936 |
| degrade_on_r1 | 0.8812 | 0.2517 | 0.0034 | 0.0037 | 0.5021 | 0.0145 | 0.0566 |
| native_random | 0.8728 | 0.6494 | 0.1694 | 0.1585 | 0.8131 | 0.3357 | 0.4936 |
| label_supervised_random | 0.8713 | 0.6017 | 0.1013 | 0.0942 | 0.7984 | 0.2583 | 0.4035 |
| soft_worst_random | 0.8749 | 0.6600 | 0.1864 | 0.1755 | 0.8168 | 0.3534 | 0.5135 |

## Preregistered comparisons

- Native-random - Degrade-on-R1 extrapolation Dmap: +0.3211, 80% CI [+0.2890, +0.3514], positive cases 20/20.
- Label-supervised random - Random-K2 extrapolation Dmap: -0.0773, 80% CI [-0.0841, -0.0703], positive cases 0/20.
- Random-K2 - Random-K1 extrapolation Dmap: -0.0241, 80% CI [-0.0319, -0.0169], positive cases 4/20.
- Soft-worst - Random-K2 extrapolation Dmap at seed17: +0.0177, 80% CI [+0.0159, +0.0196], positive cases 20/20.
- Descriptive Soft-worst - Random-K1 extrapolation Dmap at seed17: -0.0064, 80% CI [-0.0133, +0.0000], positive cases 9/20.
- Fixed-K2 is an exact deterministic duplicate-view alias of Fixed-K1; Native-random is the definition-identical alias of Random-K2. Their checkpoint hashes and metrics are identical by construction.
- Three-seed D-C: {"by_seed": {"17": {"D_minus_C_extrapolation_Dmap": 0.017699618536479986, "positive_cases": 20}, "29": {"D_minus_C_extrapolation_Dmap": 0.025336049866223797, "positive_cases": 20}, "41": {"D_minus_C_extrapolation_Dmap": 0.014374299081198092, "positive_cases": 19}}, "mean_D_minus_C_extrapolation_Dmap": 0.01913665582796729, "passes_preregistered_rule": true, "reproduced_positive_all_three": true}.

## Conclusions

- Tensor-grid geometry provides a material independent gain: True.
- Resampling degradation/frequency change is sufficient under the preregistered 0.010 margin: False.
- Ordinary random-grid label supervision is not weaker than consistency: False.
- Adding the second mean-consistency view improves extrapolation Dmap: False.
- Soft-worst D-C reproduces under the three-seed rule: True.
- Soft-worst beats the simpler Random-K1 at seed17: False.
- confirm_v2 remained locked and was not evaluated.
