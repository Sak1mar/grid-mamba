# Severity-control evidence audit

- Frozen evidence audit
- /home/yanjingjia/physgrid_pilot: PASS (42 entries)
- /home/yanjingjia/gridrex_pilot: PASS (14 entries)
- /home/yanjingjia/measure_consistent_grid: PASS (37 entries)
- /home/yanjingjia/grid_gradient_diagnostic: PASS (20 entries)
- /home/yanjingjia/grid_causal_audit: PASS (48 entries); append-only ledger exception {"appended_commands": [["--arm", "random_k1", "--seed", "29"], ["--arm", "random_k1", "--seed", "41"]], "appended_lines": 2, "frozen_prefix_lines": 15}
- C/D schedule parity: PASS {"17": {"C_D_exact": true, "reconstructed_exact": true, "sha256": "c06a39642125501cd0b84296cc90d98191afffa523b67fe7b9d2eb72f8864f13", "updates": 2500}, "29": {"C_D_exact": true, "reconstructed_exact": true, "sha256": "86e8f6c9a9394beb7f3ef804eeb3ef15b4ab3a7d71c582c665cf91f3fb4a1734", "updates": 2500}, "41": {"C_D_exact": true, "reconstructed_exact": true, "sha256": "b85fa2b3318906163ac2912e0ca89087e2cdcd707cba482796cbe995740f720a", "updates": 2500}}
- initialization SHA256: {"17": "6fc5f1c7460cf0ff42440518c1d353dbbb5535dbda8eb0c95894f8b968133262", "29": "0ab7f8452f952232b33e336f149edd01861570556503b09d9513a6e082be80ae", "41": "6182af4ac4b850cda9c6532622c74405d10f7627473ecc9e3339b71b05f762f3"}
- train/validation/development-screen: 80/20/20
- denylist_count: 40
- raw_confirm_id_matches: 0
- confirm_v2_data_accessed: false
- result: PASS

Frozen conclusions inherited: Physical-Step, GridREx, fixed-grid degradation, conservative transport, occupancy supervision, and gradient surgery remain stopped. Continuous native tensor-grid exposure and the three-seed D−C result remain supported.
