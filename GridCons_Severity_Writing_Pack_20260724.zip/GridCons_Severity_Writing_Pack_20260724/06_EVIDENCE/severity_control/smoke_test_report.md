# Smoke test report

10 updates + exact resume to 20 on the frozen full training schedule; no scientific comparison.

| arm | resumed from | finite | loss | gradient norm | peak GiB |
|---|---:|---:|---:|---:|---:|
| S | 10 | True | 0.805929 | 0.595181 | 2.100 |
| W | 10 | True | 0.805932 | 0.595192 | 2.102 |

Result: PASS
