# Aggregation mechanism analysis

Correlations are descriptive and are not causal proof.

| seed | D high-weight→more severe | D/S hard agreement | D/W Pearson | D/W Spearman | D/W MAD |
|---:|---:|---:|---:|---:|---:|
| 17 | 0.8868 | 0.8868 | 0.8647 | 0.9290 | 0.2411 |
| 29 | 0.8924 | 0.8924 | 0.8576 | 0.9265 | 0.2436 |
| 41 | 0.8860 | 0.8860 | 0.8585 | 0.9242 | 0.2357 |

The loss-order/spacing-order disagreement subset is reported in the CSV and summary. This protocol does not identify an update-level subsequent causal benefit, so that mechanism claim remains unsupported.
