# Gradient geometry diagnostic

No model was trained. Positive directional derivative means the proposed update locally increases that objective.

| seed | candidate conflict | distinct cases | K1 harm | K2 harm | worst avoids conflict | projection mean/worst |
|---:|---:|---:|---:|---:|---:|---|
| 17 | 0.212 | 18/80 | 0.356 | 0.331 | 0.118 | False/False |
| 29 | 0.037 | 4/80 | 0.225 | 0.231 | 0.833 | False/False |
| 41 | 0.106 | 9/80 | 0.319 | 0.225 | 0.294 | False/False |

## Soft-worst selection properties

| checkpoint | high-loss is more severe | high/low norm | high−low native cosine | high−low 4/5 proxy cosine |
|---|---:|---:|---:|---:|
| C_seed17 | 0.925 | 1.708 | +0.144 | +0.156 |
| C_seed29 | 0.900 | 1.374 | -0.008 | -0.064 |
| C_seed41 | 0.850 | 1.497 | -0.006 | -0.055 |
| D_seed17 | 0.912 | 1.677 | +0.125 | +0.154 |
| D_seed29 | 0.887 | 1.372 | +0.004 | -0.066 |
| D_seed41 | 0.850 | 1.470 | -0.025 | -0.051 |

High loss consistently selects more severe spacing and a larger gradient, but its native/proxy alignment is not stable across seeds. Soft-worst does not consistently avoid candidate conflict.

## Directional derivatives

More negative normalized derivatives are locally better.

| seed | direction | native | worst candidate | any harm |
|---:|---|---:|---:|---:|
| 17 | k1 | -0.954 | -0.159 | 0.356 |
| 17 | mean | -0.970 | -0.195 | 0.331 |
| 17 | worst | -0.966 | -0.193 | 0.338 |
| 17 | projected_mean | -0.970 | -0.193 | 0.338 |
| 17 | projected_worst | -0.967 | -0.191 | 0.344 |
| 29 | k1 | -0.964 | -0.223 | 0.225 |
| 29 | mean | -0.975 | -0.232 | 0.231 |
| 29 | worst | -0.973 | -0.231 | 0.231 |
| 29 | projected_mean | -0.976 | -0.229 | 0.244 |
| 29 | projected_worst | -0.973 | -0.229 | 0.237 |
| 41 | k1 | -0.943 | -0.097 | 0.319 |
| 41 | mean | -0.955 | -0.156 | 0.225 |
| 41 | worst | -0.951 | -0.158 | 0.225 |
| 41 | projected_mean | -0.958 | -0.150 | 0.237 |
| 41 | projected_worst | -0.954 | -0.153 | 0.237 |

Native-anchor projection improves the native derivative but worsens the worst-candidate derivative in every seed, so it does not supply the required joint local improvement.

## Gates

- candidate_conflict_nontrivial: FAIL
- not_case_concentrated: FAIL
- K2_more_harmful_than_K1: FAIL
- soft_worst_avoids_conflict: FAIL
- projection_counterfactual: FAIL
- main_group_consistency: FAIL

Decision: **STOP_GRID_GRADIENT_DIAGNOSTIC**

No J/K implementation or training was launched. The supported conclusion is random native-grid posterior consistency; soft-worst remains an empirical optimization choice rather than a validated gradient-conflict mechanism.
