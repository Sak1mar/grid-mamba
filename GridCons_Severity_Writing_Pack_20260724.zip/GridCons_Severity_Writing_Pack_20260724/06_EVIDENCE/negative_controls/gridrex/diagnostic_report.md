# GridREx Stage 0 diagnostic

Decision: **STOP_GRIDREX_DIAGNOSTIC**

| Frozen checkpoint | Spearman | Partial Spearman | Mean source risk variance | Mean extra risk |
|---|---:|---:|---:|---:|
| randomgrid_mean | -0.1759 | -0.4827 | 0.00130226 | 0.465809 |
| randomgrid_worst | -0.0887 | -0.3583 | 0.00112689 | 0.450523 |

- Pooled partial correlation: -0.4229.
- 90% case-cluster bootstrap CI: [-0.6879, -0.0134] (10,000 resamples, seed 7311).
- Leave-one-case-out positive: 0/20; range [-0.5301, -0.2970].
- Leave-two-cases-out positive: 0/190; range [-0.5900, -0.1169].
- randomgrid_worst − randomgrid_mean source-risk variance: mean -0.00017537, median -0.00009398, negative cases 19/20.
- randomgrid_worst − randomgrid_mean extra risk: mean -0.015286, median -0.015249, negative cases 20/20.
- Driven by one case: no; driven by any pair of cases: no.

## Gates

- FAIL — both_checkpoint_partial_correlations_gt_0
- FAIL — at_least_one_checkpoint_partial_correlation_ge_0.30
- FAIL — pooled_partial_correlation_ge_0.30
- FAIL — pooled_90pct_cluster_bootstrap_ci_lower_gt_0
- FAIL — at_least_18_of_20_leave_one_case_out_gt_0
- PASS — no_nan_inf_empty_foreground_or_coordinate_error

No training loss was implemented and no new training was started before this decision. confirm_v2 images and labels were not accessed.
