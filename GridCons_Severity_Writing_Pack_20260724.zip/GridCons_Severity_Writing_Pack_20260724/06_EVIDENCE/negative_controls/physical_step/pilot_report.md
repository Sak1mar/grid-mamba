# PhysGrid-Mamba pilot report

Decision: **STOP**

## Changes

Added only: physgrid_model.py, physical_resampler.py, run_physgrid_pilot.py, test_physgrid.py. Legacy source and artifacts were not overwritten.

## Aggregate metrics

| Method | Dnative | Grid-AUC | Worst Dpred | Worst Dmap | Extrap Dmap | Extrap Smap | slope |
|---|---:|---:|---:|---:|---:|---:|---:|
| legacy_fixed_gridcons | 0.8754 | 0.4869 | 0.0682 | 0.0667 | 0.1154 | 0.2375 | -0.7766 |
| physstep_fixed_gridcons | 0.8743 | 0.4817 | 0.0615 | 0.0605 | 0.1077 | 0.2286 | -0.7841 |
| randomgrid_mean | 0.8728 | 0.6494 | 0.1694 | 0.1585 | 0.3357 | 0.4936 | -0.5787 |
| randomgrid_worst | 0.8749 | 0.6600 | 0.1864 | 0.1755 | 0.3534 | 0.5135 | -0.5628 |
| physgrid_mamba | 0.8748 | 0.6594 | 0.1845 | 0.1741 | 0.3521 | 0.5119 | -0.5646 |

## All evaluated spacings

| Method | R1 Dpred/Dmap/Smap | R1.5 Dpred/Dmap/Smap | R2 Dpred/Dmap/Smap | R2.5 Dpred/Dmap/Smap | R3 Dpred/Dmap/Smap | R4 Dpred/Dmap/Smap | R5 Dpred/Dmap/Smap |
|---|---:|---:|---:|---:|---:|---:|---:|
| legacy_fixed_gridcons | 1.0000/0.8754/0.9819 | 0.9005/0.8567/0.9800 | 0.8734/0.8362/0.9645 | 0.7872/0.7628/0.9162 | 0.5958/0.5770/0.7563 | 0.1646/0.1595/0.3153 | 0.0743/0.0714/0.1597 |
| physstep_fixed_gridcons | 1.0000/0.8743/0.9814 | 0.9003/0.8561/0.9802 | 0.8721/0.8347/0.9634 | 0.7851/0.7607/0.9146 | 0.5910/0.5718/0.7518 | 0.1556/0.1508/0.3044 | 0.0669/0.0646/0.1528 |
| randomgrid_mean | 1.0000/0.8728/0.9808 | 0.9042/0.8583/0.9829 | 0.8800/0.8393/0.9672 | 0.8342/0.8071/0.9574 | 0.7702/0.7477/0.9094 | 0.5275/0.5128/0.6908 | 0.1694/0.1585/0.2964 |
| randomgrid_worst | 1.0000/0.8749/0.9819 | 0.9056/0.8593/0.9831 | 0.8821/0.8418/0.9684 | 0.8379/0.8106/0.9603 | 0.7793/0.7554/0.9166 | 0.5458/0.5312/0.7094 | 0.1864/0.1755/0.3176 |
| physgrid_mamba | 1.0000/0.8748/0.9818 | 0.9059/0.8596/0.9833 | 0.8822/0.8418/0.9687 | 0.8377/0.8106/0.9600 | 0.7794/0.7553/0.9170 | 0.5448/0.5301/0.7089 | 0.1845/0.1741/0.3149 |

## Per-case paired Grid-AUC differences

| case | method−A | Dnative | grid_auc | worst_grid_dpred | worst_grid_dmap | extrapolation_dmap | extrapolation_smap |
|---|---|---:|---:|---:|---:|---:|---:|
| hippocampus_035 | physstep_fixed_gridcons−A | -0.0015 | -0.0056 | -0.0047 | -0.0040 | -0.0095 | -0.0107 |
| hippocampus_035 | randomgrid_mean−A | -0.0019 | +0.2119 | +0.2117 | +0.1998 | +0.3213 | +0.3405 |
| hippocampus_035 | randomgrid_worst−A | -0.0008 | +0.2217 | +0.2239 | +0.2101 | +0.3331 | +0.3492 |
| hippocampus_035 | physgrid_mamba−A | -0.0009 | +0.2239 | +0.2207 | +0.2074 | +0.3343 | +0.3505 |
| hippocampus_042 | physstep_fixed_gridcons−A | -0.0023 | -0.0054 | -0.0065 | -0.0097 | -0.0150 | -0.0141 |
| hippocampus_042 | randomgrid_mean−A | -0.0002 | +0.1615 | +0.0658 | +0.0429 | +0.1912 | +0.2704 |
| hippocampus_042 | randomgrid_worst−A | +0.0013 | +0.1731 | +0.0907 | +0.0686 | +0.2170 | +0.3061 |
| hippocampus_042 | physgrid_mamba−A | +0.0015 | +0.1718 | +0.0859 | +0.0635 | +0.2160 | +0.3008 |
| hippocampus_048 | physstep_fixed_gridcons−A | +0.0003 | -0.0059 | -0.0053 | -0.0048 | -0.0046 | -0.0166 |
| hippocampus_048 | randomgrid_mean−A | +0.0061 | +0.1853 | +0.0471 | +0.0521 | +0.1974 | +0.2711 |
| hippocampus_048 | randomgrid_worst−A | +0.0052 | +0.1983 | +0.0548 | +0.0635 | +0.2160 | +0.2857 |
| hippocampus_048 | physgrid_mamba−A | +0.0031 | +0.1975 | +0.0500 | +0.0605 | +0.2127 | +0.2790 |
| hippocampus_056 | physstep_fixed_gridcons−A | -0.0005 | -0.0071 | +0.0000 | +0.0002 | -0.0072 | -0.0059 |
| hippocampus_056 | randomgrid_mean−A | -0.0149 | +0.1757 | +0.1704 | +0.1533 | +0.2953 | +0.2793 |
| hippocampus_056 | randomgrid_worst−A | -0.0122 | +0.1825 | +0.1835 | +0.1674 | +0.3092 | +0.2922 |
| hippocampus_056 | physgrid_mamba−A | -0.0114 | +0.1826 | +0.1881 | +0.1718 | +0.3083 | +0.2906 |
| hippocampus_057 | physstep_fixed_gridcons−A | +0.0006 | -0.0090 | -0.0120 | -0.0128 | -0.0142 | -0.0139 |
| hippocampus_057 | randomgrid_mean−A | -0.0008 | +0.1249 | -0.0482 | -0.0452 | +0.1517 | +0.1418 |
| hippocampus_057 | randomgrid_worst−A | +0.0010 | +0.1344 | -0.0349 | -0.0300 | +0.1683 | +0.1640 |
| hippocampus_057 | physgrid_mamba−A | +0.0005 | +0.1333 | -0.0381 | -0.0341 | +0.1644 | +0.1577 |
| hippocampus_068 | physstep_fixed_gridcons−A | -0.0009 | -0.0042 | -0.0192 | -0.0133 | -0.0069 | -0.0133 |
| hippocampus_068 | randomgrid_mean−A | +0.0024 | +0.1807 | +0.2757 | +0.2457 | +0.3218 | +0.2650 |
| hippocampus_068 | randomgrid_worst−A | +0.0032 | +0.1907 | +0.3248 | +0.2942 | +0.3514 | +0.2835 |
| hippocampus_068 | physgrid_mamba−A | +0.0031 | +0.1914 | +0.3297 | +0.3012 | +0.3544 | +0.2846 |
| hippocampus_088 | physstep_fixed_gridcons−A | -0.0015 | -0.0055 | -0.0119 | -0.0125 | -0.0127 | -0.0072 |
| hippocampus_088 | randomgrid_mean−A | -0.0096 | +0.1347 | +0.1192 | +0.1047 | +0.2157 | +0.2141 |
| hippocampus_088 | randomgrid_worst−A | -0.0060 | +0.1443 | +0.1353 | +0.1232 | +0.2339 | +0.2270 |
| hippocampus_088 | physgrid_mamba−A | -0.0070 | +0.1435 | +0.1338 | +0.1215 | +0.2315 | +0.2294 |
| hippocampus_093 | physstep_fixed_gridcons−A | -0.0034 | -0.0088 | -0.0055 | -0.0045 | -0.0096 | -0.0118 |
| hippocampus_093 | randomgrid_mean−A | -0.0091 | +0.2071 | +0.1602 | +0.1408 | +0.2921 | +0.3399 |
| hippocampus_093 | randomgrid_worst−A | -0.0053 | +0.2207 | +0.1715 | +0.1519 | +0.3093 | +0.3567 |
| hippocampus_093 | physgrid_mamba−A | -0.0047 | +0.2197 | +0.1685 | +0.1490 | +0.3067 | +0.3551 |
| hippocampus_108 | physstep_fixed_gridcons−A | -0.0011 | -0.0106 | -0.0057 | -0.0057 | -0.0174 | -0.0189 |
| hippocampus_108 | randomgrid_mean−A | +0.0013 | +0.1433 | +0.1645 | +0.1582 | +0.2309 | +0.2414 |
| hippocampus_108 | randomgrid_worst−A | +0.0036 | +0.1509 | +0.1762 | +0.1704 | +0.2440 | +0.2534 |
| hippocampus_108 | physgrid_mamba−A | +0.0043 | +0.1501 | +0.1731 | +0.1679 | +0.2421 | +0.2495 |
| hippocampus_109 | physstep_fixed_gridcons−A | +0.0000 | -0.0012 | -0.0081 | -0.0082 | -0.0045 | -0.0054 |
| hippocampus_109 | randomgrid_mean−A | -0.0011 | +0.1646 | +0.0853 | +0.0814 | +0.2238 | +0.2452 |
| hippocampus_109 | randomgrid_worst−A | -0.0011 | +0.1683 | +0.1001 | +0.0964 | +0.2346 | +0.2536 |
| hippocampus_109 | physgrid_mamba−A | -0.0013 | +0.1672 | +0.0926 | +0.0888 | +0.2294 | +0.2518 |
| hippocampus_173 | physstep_fixed_gridcons−A | +0.0009 | -0.0007 | -0.0052 | -0.0026 | -0.0001 | +0.0084 |
| hippocampus_173 | randomgrid_mean−A | -0.0036 | +0.0848 | -0.0358 | -0.0223 | +0.0891 | +0.0921 |
| hippocampus_173 | randomgrid_worst−A | +0.0058 | +0.0996 | -0.0323 | -0.0180 | +0.0931 | +0.1064 |
| hippocampus_173 | physgrid_mamba−A | +0.0063 | +0.1012 | -0.0306 | -0.0180 | +0.0976 | +0.1144 |
| hippocampus_204 | physstep_fixed_gridcons−A | -0.0005 | -0.0106 | -0.0183 | -0.0194 | -0.0208 | -0.0161 |
| hippocampus_204 | randomgrid_mean−A | +0.0004 | +0.1254 | +0.0357 | +0.0219 | +0.1413 | +0.1931 |
| hippocampus_204 | randomgrid_worst−A | +0.0014 | +0.1340 | +0.0717 | +0.0575 | +0.1638 | +0.2224 |
| hippocampus_204 | physgrid_mamba−A | +0.0021 | +0.1341 | +0.0764 | +0.0623 | +0.1650 | +0.2244 |
| hippocampus_236 | physstep_fixed_gridcons−A | -0.0022 | -0.0027 | +0.0000 | +0.0000 | +0.0009 | -0.0030 |
| hippocampus_236 | randomgrid_mean−A | +0.0034 | +0.1255 | +0.0072 | +0.0034 | +0.0939 | +0.1432 |
| hippocampus_236 | randomgrid_worst−A | +0.0067 | +0.1466 | +0.0157 | +0.0117 | +0.1181 | +0.1819 |
| hippocampus_236 | physgrid_mamba−A | +0.0073 | +0.1453 | +0.0099 | +0.0067 | +0.1145 | +0.1763 |
| hippocampus_253 | physstep_fixed_gridcons−A | -0.0019 | -0.0025 | +0.0003 | +0.0001 | +0.0005 | -0.0000 |
| hippocampus_253 | randomgrid_mean−A | -0.0083 | +0.0938 | -0.0148 | -0.0138 | +0.0709 | +0.0764 |
| hippocampus_253 | randomgrid_worst−A | -0.0040 | +0.1058 | -0.0120 | -0.0113 | +0.0885 | +0.1026 |
| hippocampus_253 | physgrid_mamba−A | -0.0042 | +0.1076 | -0.0143 | -0.0128 | +0.0914 | +0.1001 |
| hippocampus_288 | physstep_fixed_gridcons−A | -0.0009 | -0.0014 | -0.0019 | -0.0019 | -0.0014 | -0.0007 |
| hippocampus_288 | randomgrid_mean−A | +0.0014 | +0.1349 | +0.1944 | +0.1697 | +0.1905 | +0.2438 |
| hippocampus_288 | randomgrid_worst−A | +0.0020 | +0.1436 | +0.2073 | +0.1824 | +0.2044 | +0.2577 |
| hippocampus_288 | physgrid_mamba−A | +0.0018 | +0.1431 | +0.2062 | +0.1812 | +0.2023 | +0.2578 |
| hippocampus_321 | physstep_fixed_gridcons−A | -0.0014 | -0.0033 | -0.0006 | +0.0010 | -0.0009 | -0.0018 |
| hippocampus_321 | randomgrid_mean−A | -0.0076 | +0.2245 | +0.0802 | +0.0817 | +0.2828 | +0.3777 |
| hippocampus_321 | randomgrid_worst−A | -0.0057 | +0.2371 | +0.1049 | +0.1033 | +0.3055 | +0.4018 |
| hippocampus_321 | physgrid_mamba−A | -0.0057 | +0.2348 | +0.0980 | +0.0964 | +0.3000 | +0.3958 |
| hippocampus_333 | physstep_fixed_gridcons−A | -0.0031 | -0.0016 | +0.0000 | +0.0008 | -0.0000 | +0.0058 |
| hippocampus_333 | randomgrid_mean−A | -0.0077 | +0.1971 | +0.1754 | +0.1759 | +0.3185 | +0.4713 |
| hippocampus_333 | randomgrid_worst−A | -0.0067 | +0.2100 | +0.2038 | +0.2043 | +0.3469 | +0.5058 |
| hippocampus_333 | physgrid_mamba−A | -0.0080 | +0.2088 | +0.2117 | +0.2149 | +0.3495 | +0.5071 |
| hippocampus_350 | physstep_fixed_gridcons−A | -0.0004 | -0.0042 | -0.0127 | -0.0123 | -0.0111 | -0.0202 |
| hippocampus_350 | randomgrid_mean−A | +0.0028 | +0.1838 | +0.0248 | +0.0208 | +0.1827 | +0.2747 |
| hippocampus_350 | randomgrid_worst−A | +0.0038 | +0.1943 | +0.0435 | +0.0399 | +0.2036 | +0.3028 |
| hippocampus_350 | physgrid_mamba−A | +0.0033 | +0.1932 | +0.0371 | +0.0343 | +0.2016 | +0.3012 |
| hippocampus_356 | physstep_fixed_gridcons−A | -0.0009 | -0.0065 | -0.0077 | -0.0075 | -0.0107 | -0.0198 |
| hippocampus_356 | randomgrid_mean−A | +0.0017 | +0.2264 | +0.2640 | +0.2359 | +0.3461 | +0.3691 |
| hippocampus_356 | randomgrid_worst−A | +0.0023 | +0.2332 | +0.2747 | +0.2442 | +0.3558 | +0.3776 |
| hippocampus_356 | physgrid_mamba−A | +0.0019 | +0.2303 | +0.2732 | +0.2444 | +0.3540 | +0.3774 |
| hippocampus_373 | physstep_fixed_gridcons−A | -0.0019 | -0.0062 | -0.0089 | -0.0080 | -0.0097 | -0.0121 |
| hippocampus_373 | randomgrid_mean−A | -0.0062 | +0.1654 | +0.0414 | +0.0283 | +0.2476 | +0.2728 |
| hippocampus_373 | randomgrid_worst−A | -0.0041 | +0.1730 | +0.0611 | +0.0466 | +0.2619 | +0.2900 |
| hippocampus_373 | physgrid_mamba−A | -0.0037 | +0.1715 | +0.0548 | +0.0413 | +0.2583 | +0.2846 |

## Compute

- Actual GPU: NVIDIA PG506-230 (95.147 GiB); requested A100 match: no.
- Identity affine max error: 4.7683716e-07; reference compatibility max error: 0.
- legacy_fixed_gridcons: 99411 parameters; model forward 0.0391 s/volume; end-to-end evaluation 9.38 s.
- physstep_fixed_gridcons: 99411 parameters; model forward 0.0829 s/volume; end-to-end evaluation 15.41 s.
- randomgrid_mean: 99411 parameters; model forward 0.0336 s/volume; end-to-end evaluation 8.56 s.
- randomgrid_worst: 99411 parameters; model forward 0.0344 s/volume; end-to-end evaluation 8.72 s.
- physgrid_mamba: 99411 parameters; model forward 0.0827 s/volume; end-to-end evaluation 15.46 s.
- physstep_fixed_gridcons: train 0.4980 GPU h, 0.7171 s/update, peak 2.053 GiB.
- randomgrid_mean: train 0.6326 GPU h, 0.9109 s/update, peak 2.865 GiB.
- randomgrid_worst: train 0.6315 GPU h, 0.9094 s/update, peak 2.865 GiB.
- physgrid_mamba: train 0.6579 GPU h, 0.9473 s/update, peak 2.934 GiB.
- legacy_fixed_gridcons: train 0.7215 GPU h, 1.0390 s/update, peak 2.012 GiB.

## Go/No-Go gates

- PASS — all_unit_tests_pass
- PASS — no_nan_inf_loss_or_gradient
- PASS — identity_affine_max_error_le_1e-5
- PASS — legacy_compatibility_max_error_le_1e-5
- PASS — confirm_v2_not_evaluated
- PASS — all_required_hashes_recorded_and_valid
- PASS — peak_memory_below_90_percent
- PASS — parameter_counts_equal
- FAIL — requested_gpu_is_A100
- PASS — Dnative_guardrail
- PASS — Grid_AUC_gain
- PASS — worst_grid_Dpred_gain
- PASS — extrapolation_Dmap_gain
- PASS — extrapolation_Smap_gain
- PASS — R2_Dpred_guardrail
- FAIL — E_beats_D
- PASS — D_beats_C_worst
- FAIL — B_independent_gain
- PASS — training_time_below_3x_A

## Component conclusion

- Physical-Step independent contribution: FAIL.
- Worst-grid objective evidence: PASS.
- PhysGrid-Mamba name permitted under the preregistered rules: NO.
- Final: STOP.
