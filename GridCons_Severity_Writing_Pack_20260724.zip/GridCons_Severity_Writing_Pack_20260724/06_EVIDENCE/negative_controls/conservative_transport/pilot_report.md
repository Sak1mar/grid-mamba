# Measure-Consistent Grid Training pilot

Single-seed development-screen result; not a final claim.

| arm | Extra Dmap | Extra Smap | Worst Dmap | Worst Dpred | Dnative | GPU time vs R |
|---|---:|---:|---:|---:|---:|---:|
| R | 0.359737 | 0.520728 | 0.200233 | 0.211185 | 0.872717 | 1.000 |
| P | 0.336520 | 0.491724 | 0.190987 | 0.199907 | 0.880823 | 0.952 |
| H | 0.274780 | 0.423033 | 0.119810 | 0.127185 | 0.873377 | 0.879 |
| O | 0.256228 | 0.402924 | 0.104800 | 0.111032 | 0.874017 | 0.881 |

## Predefined comparisons

- P−R Extra Dmap: -0.023217, 80% CI [-0.033781, -0.012464], positive cases 6/20.
- P−R Extra Smap: -0.029004, 80% CI [-0.041314, -0.016531].
- O−H Extra Dmap: -0.018552, 80% CI [-0.021243, -0.015849].
- P−O Extra Dmap: +0.080292, 80% CI [+0.072401, +0.088641].

P scientific gate: FAIL
O scientific gate: FAIL
Decision: **STOP_NO_CONSERVATIVE_GAIN**

The zero-cost voxel-measure hypothesis was supported, but neither conservative training objective improved Dmap/Smap. O was also worse than H, so partial-volume quantization did not explain the hard-label training deficit in this pilot.

No P+O mixture was trained or selected. confirm_v2 remained inaccessible by denylist.
