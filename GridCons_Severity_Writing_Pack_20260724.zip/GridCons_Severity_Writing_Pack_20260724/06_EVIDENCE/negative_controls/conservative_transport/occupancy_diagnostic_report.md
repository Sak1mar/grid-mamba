# Zero-cost voxel-cell diagnostic

| spacing | mixed-cell fraction median | NN-occupancy disagreement median | disagreement mass in mixed cells |
|---:|---:|---:|---:|
| 1.5 | 0.378639 | 0.025899 | 1.000000 |
| 2.0 | 0.495225 | 0.022462 | 1.000000 |
| 3.0 | 0.516507 | 0.042006 | 1.000000 |
| 4.0 | 0.775634 | 0.061725 | 1.000000 |
| 5.0 | 0.810471 | 0.085711 | 0.992250 |

Decision: **GO_MEASURE_IMPLEMENTATION**

No training result was used in this diagnostic.
