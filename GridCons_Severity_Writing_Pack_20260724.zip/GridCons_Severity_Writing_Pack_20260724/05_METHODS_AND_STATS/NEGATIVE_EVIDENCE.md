# Frozen Negative Evidence

| Direction | Result | Consequence for writing |
|---|---|---|
| Physical-Step recurrence | No independent gain; B vs A predefined robustness metrics decreased, E vs D no gain | Do not claim a spacing-aware Mamba mechanism |
| GridREx/source-risk variance | Pooled partial Spearman `−0.4229`, 90% CI `[-0.6879,−0.0134]` | No risk-variance loss or DG interpretation |
| Fixed-grid degradation | Degrade-on-R1 far below native-random | Blur/anti-aliasing is not the main explanation |
| Conservative transport | P−R Extra Dmap `−0.02322`, 80% CI `[-0.03378,−0.01246]` | Exact conservation is not a beneficial training mechanism here |
| Occupancy supervision | O−H Extra Dmap `−0.01855`, 80% CI `[-0.02124,−0.01585]` | Do not use partial-volume soft labels |
| Gradient surgery | Conflict rates unstable; projection failed joint native/worst improvement | No PCGrad/CAGrad or conflict-resolution claim |
| Soft-worst adaptive mechanism | D tracks severe spacing; S/W exceed D pooled | Reframe D as severity emphasis, freeze S |

These are falsification results, not a list of future modules. They belong in a compact Discussion paragraph and a full supplementary table.

