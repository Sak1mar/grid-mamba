# Statistical Analysis

## Severity-control comparison

- Paired observation grid: 20 development cases × 3 seeds.
- Primary decision metric: Extra Dmap.
- Hierarchical paired bootstrap: sample 20 cases with replacement, then sample three seeds with replacement within each sampled case.
- Draws: 10,000; RNG seed: 7331.
- 80% CI: preregistered screening gate.
- 95% CI: descriptive, not a replacement gate.
- Report pooled mean difference, median paired difference, positive case-seed fraction, and per-seed means.

The 60 case-seed cells are not 60 independent patients. The hierarchical resampling preserves case-level pairing and represents seed variability inside each case draw.

## Continuous-grid source audit

The Native-random/Degrade-on-R1 and label-supervised/Random-K2 controls were screened at seed 17 over 20 paired cases with 10,000 case bootstrap draws. The prespecified D−C comparison was later reproduced for seeds 17, 29, and 41. Do not describe every source-audit arm as a three-seed result.

## Reporting rules

- Always provide the sign convention for a contrast.
- Do not infer p-values from confidence intervals.
- Do not call an 80% interval a conventional confirmatory interval.
- Report negative seed directions and failed secondary metrics.
- Confirmation analyses must follow a separately frozen protocol and cannot reuse these development gates for method changes.

