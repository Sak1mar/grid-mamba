# Splits, Leakage Controls, and Checkpointing

- Train: 80 cases.
- Validation: 20 cases.
- Development screen: 20 cases.
- Locked confirm_v2: 40 cases.
- All four groups were verified disjoint.
- confirm_v2 protection: SHA-256 denylist of case IDs; raw-ID scans of logs and outputs returned zero matches.
- Current status: `confirm_v2_data_accessed=false`, `confirm_v2_evaluated=false`.
- Model selection reads R1 validation foreground Dice only.
- Candidate-grid development metrics, Extra Dmap, and confirm_v2 never select checkpoints.

The old fixed-grid Task04 study has its own previously completed confirmation analysis. Do not confuse that evidence with the still-locked confirm_v2 for the continuous severity-selected method.

