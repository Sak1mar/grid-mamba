# Exact Frozen Method

## Inputs and geometry

- Reference branch: R1, 1 mm nominal through-plane spacing.
- Two candidate grids per update.
- Requested through-plane spacing: frozen per-seed LogUniform `[1,3] mm`.
- Candidate tensors are built directly from the raw image on endpoint-matched native grids.
- Candidate probabilities are affine-mapped back to the R1 lattice.
- Severity reads requested spacing in millimetres. It never substitutes tensor depth or endpoint-rounded actual spacing.

## Loss

For R1 logits `z0`, label `y0`, and detached teacher foreground posterior `q`:

`L_native = 0.5 * DiceLoss(z0,y0) + 0.5 * CrossEntropy(z0,y0)`.

For each candidate `k`:

`p_k = Align_gk_to_R1(softmax(f_theta(x_gk)))_foreground`

`e_k = 1 - SoftDice(q,p_k)`.

For S:

`a_k = log(s_k / 1 mm) / log(3)`

`L_aux = e_argmax(a)`; exact `a1==a2` gives `(e1+e2)/2`.

`L = L_native + lambda(t)L_aux`, with `lambda(t)=0.1*min(1,t/500)`.

## Optimization and selection

- Static Mamba; 99,411 parameters.
- AdamW; lr `3e-4`; weight decay `1e-5`.
- 2,500 updates; full volume; batch size 1; bfloat16; no augmentation.
- Validation every 250 updates.
- Select by R1 validation foreground Dice only; ties keep earliest.
- Full resume state saved every 250 updates; resume requires initialization and schedule SHA-256 parity.

## What is not part of the method

No spacing embedding, Physical-Step, learned resampler, EMA teacher, uncertainty mask, contrastive/boundary/frequency loss, adversarial sampler, GroupDRO/CVaR/REx, new decoder, attention module, new target, new labels, or gradient surgery.

