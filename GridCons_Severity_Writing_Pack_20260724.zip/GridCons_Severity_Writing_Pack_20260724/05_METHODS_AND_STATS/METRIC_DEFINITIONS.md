# Metric Definitions

All foreground metrics first average the two foreground classes within each case/seed cell unless a per-class row is explicitly reported.

- **Dnative:** Dice between the R1 prediction and R1 reference label.
- **Dpred(s):** Dice between the candidate-grid prediction mapped to R1 and the R1 prediction. This measures prediction agreement, not accuracy.
- **Dmap(s):** Dice between the candidate-grid prediction mapped to R1 and the R1 reference label.
- **Smap@2mm(s):** surface Dice at 2 mm between the mapped candidate prediction and R1 reference label.
- **Grid-AUC:** trapezoidal area of Dpred over spacings 1.5–5 mm, divided by the spacing interval length.
- **Worst-grid Dpred/Dmap:** minimum over 1.5, 2, 2.5, 3, 4, and 5 mm.
- **Source-range Dmap:** mean Dmap over 1.5, 2, 2.5, and 3 mm.
- **Extra Dmap/Smap:** mean at 4 and 5 mm, outside the 1–3 mm training range.
- **Degradation slope:** least-squares slope of Dpred against log spacing over 1.5–5 mm; more negative means faster degradation.
- **Effective spacing:** sum of candidate spacing weighted by the aggregation weights; C uses 0.5/0.5, S one-hot, D/W their detached soft weights.

Never call Dpred an accuracy metric. Never report nominal spacing as actual acquisition spacing. The experiment controls only through-plane spacing while in-plane spacing remains 1 mm.

