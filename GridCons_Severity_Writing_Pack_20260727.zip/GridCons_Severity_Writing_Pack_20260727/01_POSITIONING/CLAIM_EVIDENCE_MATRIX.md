# Claim–Evidence Matrix

| ID | Candidate paper claim | Status | Exact evidence | Where usable |
|---|---|---|---|---|
| C1 | Continuous native tensor-grid exposure materially improves 4/5 mm mapped Dice beyond degradation on a fixed R1 tensor. | Supported over three development seeds | Random-K2 − Degrade-on-R1 `+0.33970`, crossed 95% CI `[0.29052,0.38837]`; 3/3 seeds and 60/60 case-seed cells positive | Abstract; main Results |
| C2 | The gain is not adequately explained by fixed-grid blur/degradation. | Supported within the tested degradation control | Same contrast as C1; Degrade-on-R1 Extra Dmap `0.01455` vs native-random `0.33567` | Results/Discussion |
| C3 | Under this construction, R1 posterior consistency outperformed candidate-grid label supervision. | Supported over three development seeds, construction-specific | Random-K2 − Label-supervised `+0.07983`, crossed 95% CI `[0.06756,0.09187]`; 3/3 seeds and 60/60 cells positive | Results; never generalize to all ground-truth supervision |
| C4 | Soft-worst D exceeds mean C across three seeds. | Supported development result | D−C Extra Dmap `+0.01914`; each seed positive | Aggregation audit |
| C5 | Soft-worst works by resolving gradient conflict or following a more correct gradient. | Unsupported | Gradient conflict and projection gates failed; `06_EVIDENCE/negative_controls/gradient_diagnostic/diagnostic_report.md` | State only as rejected explanation |
| C6 | D mostly emphasizes the more severe spacing. | Descriptively supported | 88.60%–89.24% update agreement; high D/W rank correlations | Mechanism analysis; not causal proof |
| C7 | Hard severity selection S outperforms D on pooled development Extra Dmap. | Supported development result | S−D `+0.03037`, 80% CI `[0.02330,0.03760]`; 2/3 seeds positive | Results; label development selection |
| C8 | S is more stable than C across the three selected seeds. | Supported development result | S−C seeds all positive; mean `+0.04950`, 80% CI `[0.04153,0.05759]` | Results |
| C9 | S is faster than C/D/W. | Supported for observed training runs | S `0.7658 s/update`; W `0.7808`; D `0.8841`; C `0.8877` | Efficiency table; hardware-specific |
| C10 | S preserves native segmentation. | Guardrail supported in development | pooled Dnative `0.88157`; S−D `+0.00092`; S−C `+0.00141` | Results |
| C11 | S improves over mean C on unseen Task04 cases without native-Dice loss. | Confirmed | 40 cases × 5 seeds; S−C Extra Dmap `+0.03436`, crossed 95% CI `[0.01013,0.05824]`; native-Dice lower bound `−0.00247 > −0.005` | Abstract and main Results |
| C12 | The S−C direction transfers jointly to a different dataset and 3D U-Net. | Directionally supported, not independently significant | Task09 five-fold Plain 3D U-Net; `+0.01996`, 3/3 seeds positive, 95% CI `[−0.00189,0.03885]` | Results/limitations; do not claim backbone independence |
| C13 | S generalizes to heterogeneous clinical acquisition. | Unsupported | Controlled Task09 grid replication changes dataset+backbone jointly; older real-spacing Task09 study was negative | Limitation; no clinical robustness claim |
| C14 | Static Mamba timescales or physical-step recurrence drive the effect. | Rejected | Physical-Step stopped; old factorial interaction does not privilege static delta | Negative result/supplement |
| C15 | Conservative transport or occupancy labels improve extrapolation. | Rejected in preregistered pilots | P−R `−0.02322`; O−H `−0.01855` Extra Dmap | Supplement/limitations |

## Burden-bearing statements for the final abstract

The final abstract may use C1, C3 and C11. C7 must remain a development selection result because confirm S−D crosses zero. C12 may be described only as directional joint external replication; C13 remains forbidden.
