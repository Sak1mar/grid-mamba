# 论文蓝图

## 一句话论文

在同一 3D 解剖的连续 through-plane voxel grids 上，真正的 native tensor-grid exposure 而非固定张量模糊解释了主要稳定性收益；在两个随机候选中直接强调 spacing 更严重的 grid，比基于当前 prediction disagreement 的 soft-worst 更简单、更快，并在冻结的三种子开发审计中表现更好。

## 推荐标题

首选：

> **What Drives Stability Across Voxel Grids? Native-Grid Exposure and Severity-Selected Consistency for 3D Medical Image Segmentation**

更偏实证审计：

> **Native-Grid Exposure, Not Loss Complexity, Drives Resampling Stability in 3D Medical Image Segmentation**

更偏方法：

> **Severity-Selected Native-Grid Consistency for Stable 3D Medical Image Segmentation Across Voxel Spacings**

不要在标题中使用 `Physical-Step`、`GridREx`、`soft-worst`、`worst-domain` 或 `gradient conflict`。

## 推荐论文类型

这是“受控问题研究 + 简单冻结方法 + 严格负结果边界”的论文，不是新 backbone 论文。40-case 五种子确认已通过，Task09+3D U-Net 联合外部块方向一致但区间跨零，证据强度适合以严格 scoped claim 投稿 CCF-C 医学图像/多媒体应用型会议。

## 主叙事

1. 同一解剖在不同 voxel spacing 和 native lattice 上会沿着不同 tensor depth、pooling 和 feature-map discretization 路径前向传播，单一 R1 accuracy 无法衡量这种稳定性。
2. 早期固定 R1/R2 结果证明 paired-grid training 能大幅改善 matched R2，但 equal-exposure 控制表明该收益不能归因于 consistency loss 单独产生。
3. 连续网格因果审计进一步定位来源：native-random 相比在 R1 tensor 上模拟模糊的 Degrade-on-R1，Extra Dmap 高 `+0.3211`，20/20 cases 为正；因此固定张量 degradation 不是主要解释。
4. 在当前训练构造下，R1 posterior consistency 又优于 candidate-grid label supervision，Extra Dmap 差 `+0.0773`（以 Random-K2 − Label-supervised 表示）。
5. soft-worst D 相比 mean C 的收益在三种子复现，但梯度诊断没有支持冲突缓解或方向更正确的机制。
6. severity controls 显示 D 在约 89% 更新中本来就在强调 spacing 更严重的候选；直接 hard select 的 S 反而比 D 高 `+0.03037` Extra Dmap，并比 C 高 `+0.04950`。
7. 因而冻结 S，机制表述严格限制为：severity-based selection 在当前连续 native-grid 训练协议下优于 loss-adaptive soft-worst。最终 confirm_v2 只验证冻结方法，不再参与方法选择。

## 主文结构

1. Introduction：问题、旧 fixed-grid 归因缺口、连续 grid 问题、贡献。
2. Related Work：resampling/spacing、transformation consistency、sampling-aware networks、3D segmentation backbones；不把普通 consistency 包装成首创。
3. Problem and Metrics：物理对齐 grid、Dpred/Dmap/Smap、source/extra range。
4. Method：R1 supervision、连续 native candidates、posterior alignment、S aggregation。
5. Controlled Audits：native vs degraded、posterior vs label、C/D/S/W、冻结规则。
6. Experiments：Task04 split、训练、评估 spacing、统计、guardrail、防泄漏。
7. Results：三 seed source audit、开发选择、40-case 五 seed confirm、Task09/3D U-Net 外部边界。
8. Discussion：为什么 severity 能解释 D、为什么不是 gradient claim、绝对 5 mm performance 仍低。
9. Limitations：外部块同时改变数据集与骨干且 CI 跨零；受控 resampling 不等于真实 acquisition shift。
10. Conclusion：只总结被支持的范围。

## 主文表图配置

- Fig. 1：训练与评估协议图。
- Fig. 2：C/D/S/W 的 Dmap-spacing 曲线。
- Fig. 3：各方法的 Extra Dmap、Worst Dmap 与 Dnative。
- Fig. 4：三种子 Extra Dmap 稳定性。
- Table 1：四个 aggregation 的精确定义。
- Table 2：连续网格 source audit 的关键对照。
- Table 3：C/D/S/W pooled 开发结果。
- Table 4：S−C、S−D、W−D 的配对差异与区间。
- Supplement：每种子结果、机制统计、全部负控制、旧 fixed-grid/equal-exposure、复现与完整性。

## 投稿前剩余事项

- 实验门槛已完成；不要再增加 arm、seed、backbone 或数据集。
- 补齐作者、单位、基金、伦理/数据使用声明、代码 URL 与会议模板。
- 按目标会议页数压缩负控制到补充材料，不删除 confirm 或外部负向/不确定结果。
