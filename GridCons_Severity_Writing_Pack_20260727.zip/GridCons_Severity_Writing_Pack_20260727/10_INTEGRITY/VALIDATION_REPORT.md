# Validation Report

## Overall Assessment: Ready for venue formatting after author metadata

Question: are the frozen continuous-grid and severity-control results accurately organized for paper writing without overstating confirmation?

Data as of: 2026-07-27. Validation covers copied development evidence, three-seed source replication, frozen confirm_v2, and the Task09/Plain 3D U-Net external block.

## Calculation and Integrity Checks

| Check | Result | Detail |
|---|---|---|
| recompute D-C Extra_Dmap | PASS | +0.019136655828 |
| recompute S-C Extra_Dmap | PASS | +0.049503259385 |
| recompute S-D Extra_Dmap | PASS | +0.030366603557 |
| recompute W-D Extra_Dmap | PASS | +0.011669350297 |
| selected arm S has highest pooled Extra_Dmap | PASS | {'C': 0.347539, 'D': 0.366675, 'S': 0.397042, 'W': 0.378345} |
| confirm flags false in severity evidence | PASS | false/false |
| confirm_v2 primary decision passes | PASS | {'by_seed': {'17': 0.06844443678813084, '29': 0.058404838189912336, '41': -0.002646214151891755, '53': 0.014462118936826012, '67': 0.033129497456841774}, 'ci95': [0.010127112561883053, 0.058240309670140114], 'mean_difference': 0.03435893544396384, 'positive_case_seed_fraction': 0.79} |
| confirm native noninferiority passes | PASS | [-0.0024659416309224928, 0.0025536509360495003] |
| Task09/3D U-Net direction positive in all seeds | PASS | {'by_seed': {'17': 0.03319155799509446, '29': 0.02011868624007698, '41': 0.0065827699136597}, 'ci95': [-0.001894722222176979, 0.03884698122406982], 'mean': 0.01996433804961038} |
| no symlinks in portable pack | PASS | 0 symlinks expected |
| commands_for_confirm_v2.sh remains execution-locked | PASS | ['set -euo pipefail', 'exit 0'] |
| commands_for_backbone_replication.sh remains execution-locked | PASS | ['set -euo pipefail', 'exit 0'] |
| curated evidence copies match original files | PASS | mismatches=[] |
| confirm_v2 denylist hits in writing pack | PASS | hits=0 |

## Methodology Review

The pack separates development selection, three-seed source replication, untouched five-seed confirmation, and joint dataset/backbone replication. Multi-seed intervals use crossed case×seed resampling. The manuscript limits S−D to an inconclusive result and does not turn the uncertain external interval into a generalization claim.

## Required Caveats

- S−D is not confirmed despite a positive pooled point estimate.
- Task09 changes dataset and backbone jointly, and its Extra Dmap interval crosses zero.
- Surface Dice in the external block is evaluated at the prespecified extra spacings 4/5 mm, which are the only spacings used by Extra Smap.
- Controlled voxel-grid stability does not establish robustness to heterogeneous clinical acquisition.
- The old Task09 external study was negative and is retained as a boundary, not evidence for S.

## Incomplete Handoff Blockers for Submission

- author/venue/ethics/funding/code metadata

Failed checks: none
