# Post-Selection Completion Record

The method definition remained `06_EVIDENCE/severity_control/method_freeze.json`; no result was used to alter S, its hyperparameters, checkpoint rule, training distribution, or primary metric.

## Completed

1. `confirm_v2`: 40 untouched Task04 cases, C/D/S, five seeds; PASS for S−C Extra Dmap and native-Dice noninferiority.
2. Source controls: Degrade-on-R1 and candidate-label supervision completed over seeds 17/29/41.
3. Joint external block: Task09 Spleen + Plain 3D U-Net, C/S, five outer folds, three seeds; directionally positive Extra Dmap with a 95% interval crossing zero.

## Scope decision

The broader placeholder list (separate Static/Dynamic Mamba and 3D U-Net replications, heterogeneous affine tests) was not used as a submission gate. The final claim is narrower: confirmed controlled Task04 S−C stability, with bounded joint dataset/backbone evidence. No backbone-independence or heterogeneous-clinical-robustness claim is made.

## Remaining

Only author, affiliation, funding, ethics/data-use, code URL, and venue-template metadata.
