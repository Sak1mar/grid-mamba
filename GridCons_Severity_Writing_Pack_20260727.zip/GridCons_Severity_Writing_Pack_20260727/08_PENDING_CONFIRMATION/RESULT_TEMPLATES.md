# Filled Result Summary

| Block | Contrast | Mean | Crossed 95% CI | Interpretation |
|---|---|---:|---:|---|
| Task04 confirm_v2, 40 cases × 5 seeds | S−C Extra Dmap | +0.03436 | [+0.01013,+0.05824] | confirmed |
| Task04 confirm_v2 | S−D Extra Dmap | +0.00443 | [−0.02495,+0.03387] | no confirmed difference |
| Task04 confirm_v2 | S−C Dnative | +0.00012 | [−0.00247,+0.00255] | noninferior at −0.005 margin |
| Task09 + Plain 3D U-Net, 41 cases × 3 seeds | S−C Extra Dmap | +0.01996 | [−0.00189,+0.03885] | 3/3 seeds positive; uncertain |

Do not replace uncertainty with significance language. Do not call the Task09 block an isolated backbone or dataset effect.
