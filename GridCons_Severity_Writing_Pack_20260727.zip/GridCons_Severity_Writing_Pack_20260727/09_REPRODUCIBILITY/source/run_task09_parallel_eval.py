#!/usr/bin/env python
"""Resumable per-model parallel evaluation for Task09 U-Net C/S runs."""

from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path

import numpy as np
import torch

import run_task09_unet_severity as run

SURFACE_SPACINGS = (4.0, 5.0)


def worker_path(output: Path, arm: str, fold: int, seed: int) -> Path:
    return output / "evaluation_parts" / f"{arm}_fold{fold}_seed{seed}.csv"


def read_rows(path: Path) -> list[dict]:
    with path.open() as handle:
        return list(csv.DictReader(handle))


def complete(rows: list[dict], arm: str, fold: int, seed: int, cases: int) -> bool:
    return len(rows) == cases * len(run.SPACINGS) and {(row["arm"], int(row["fold"]), int(row["seed"])) for row in rows} == {(arm, fold, seed)}


def write_rows(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    with temporary.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    os.replace(temporary, path)


def worker(output: Path, arm: str, fold: int, seed: int) -> None:
    protocol, folds, preprocessing = run.verify_setup(output)
    record = folds["folds"][fold]; path = worker_path(output, arm, fold, seed)
    if path.is_file() and complete(read_rows(path), arm, fold, seed, len(record["outer_test"])):
        return
    device = torch.device("cuda:0"); model = run.load_model(output, arm, fold, seed, device); allowed = set(record["outer_test"]); rows = []
    for identifier in record["outer_test"]:
        meta = preprocessing["native"][identifier]; image = np.load(meta["cache"], mmap_mode="r"); truth = run.ext.load_label_full(identifier, allowed) == 1
        native_probability = run.ext.embed_native_roi(run.sliding_predict(model, image), meta); native_hard = native_probability >= 0.5; dnative = run.ext.binary_dice(native_hard, truth)
        for spacing in run.SPACINGS:
            candidate, candidate_meta = run.target_volume(image, meta, spacing)
            mapped_probability = run.ext.map_pair_to_source(run.sliding_predict(model, candidate), candidate_meta, meta); mapped_hard = mapped_probability >= 0.5
            # ponytail: only 4/5 mm feed Extra Smap; compute the full surface curve if a future figure needs it.
            surface = run.ext.surface_dice_2mm(mapped_hard, truth, meta["source_spacing_dhw"]) if spacing in SURFACE_SPACINGS else float("nan")
            rows.append({"case_id": identifier, "fold": fold, "seed": seed, "arm": arm, "spacing_nominal_mm": spacing, "spacing_actual_mm": candidate_meta["spacing_dhw"][0], "Dnative": dnative, "Dpred": run.ext.binary_dice(mapped_hard, native_hard), "Dmap": run.ext.binary_dice(mapped_hard, truth), "Smap": surface})
        print(f"evaluated {arm} fold{fold} seed{seed} {identifier}", flush=True)
    if not complete(rows, arm, fold, seed, len(record["outer_test"])):
        raise RuntimeError("incomplete worker evaluation")
    write_rows(path, rows)
    run.dump_json(path.with_suffix(".json"), {"protocol_hash": protocol["protocol_hash"], "checkpoint_sha256": run.sha256(run.training_paths(output, arm, fold, seed)[0]), "rows": len(rows), "metrics_sha256": run.sha256(path)})


def merge(output: Path) -> None:
    protocol, folds, _ = run.verify_setup(output); rows = []
    for fold in run.FOLDS:
        cases = len(folds["folds"][fold]["outer_test"])
        for seed in run.SEEDS:
            for arm in run.ARMS:
                path = worker_path(output, arm, fold, seed); part = read_rows(path)
                if not complete(part, arm, fold, seed, cases):
                    raise RuntimeError(f"incomplete evaluation part: {path}")
                rows += part
    if len(rows) != 41 * len(run.SEEDS) * len(run.ARMS) * len(run.SPACINGS):
        raise RuntimeError("incomplete merged Task09 evaluation")
    path = output / "metrics.csv"; write_rows(path, rows)
    run.dump_json(output / "evaluation.json", {"completed": True, "rows": len(rows), "expected_rows": len(rows), "metrics_sha256": run.sha256(path), "protocol_hash": protocol["protocol_hash"], "parallel_parts": 30, "surface_dice_spacings_mm": list(SURFACE_SPACINGS)})


def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--output", type=Path, default=run.DEFAULT_OUTPUT)
    sub = parser.add_subparsers(dest="command", required=True)
    work = sub.add_parser("worker"); work.add_argument("--arm", choices=run.ARMS, required=True); work.add_argument("--fold", choices=run.FOLDS, type=int, required=True); work.add_argument("--seed", choices=run.SEEDS, type=int, required=True)
    sub.add_parser("merge"); args = parser.parse_args(); output = args.output.resolve()
    if args.command == "worker": worker(output, args.arm, args.fold, args.seed)
    else: merge(output)


if __name__ == "__main__":
    main()
