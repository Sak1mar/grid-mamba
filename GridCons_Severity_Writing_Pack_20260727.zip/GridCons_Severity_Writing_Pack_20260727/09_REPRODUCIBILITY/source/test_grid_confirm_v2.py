import unittest
from pathlib import Path

import numpy as np

import run_grid_confirm_v2 as confirm


class ConfirmV2Tests(unittest.TestCase):
    def test_locked_manifest_and_raw_files(self):
        lock = confirm.locked_manifest()
        self.assertEqual(len(lock["case_ids"]), 40)
        confirm.verify_confirm_files(Path("/home/yanjingjia/data/Task04_Hippocampus"), lock)

    def test_crossed_bootstrap_keeps_shared_seed_effect(self):
        cases = []
        for case in range(4):
            for seed, effect in zip(confirm.SEEDS, (-2, -1, 0, 1, 2)):
                for arm in confirm.ARMS:
                    cases.append({"arm": arm, "case_id": str(case), "seed": seed, "score": effect if arm == "S" else 0.0})
        old = confirm.BOOTSTRAPS
        try:
            confirm.BOOTSTRAPS = 1000
            result = confirm.crossed_bootstrap(cases, "S", "C", "score")
        finally:
            confirm.BOOTSTRAPS = old
        self.assertGreater(result["ci95"][1] - result["ci95"][0], 1.0)

    def test_old_seed_schedules_match_frozen_protocol(self):
        ctx = confirm.Context(Path(__file__).resolve().parent, Path("/home/yanjingjia/data/Task04_Hippocampus"), Path("/home/yanjingjia/metric_mamba_gate"), confirm.DEFAULT_OUTPUT)
        confirm.setup(ctx)
        protocol = __import__("json").loads((ctx.output / "protocol.json").read_text())
        self.assertEqual(protocol["new_training_seeds"], [53, 67])
        self.assertEqual(set(protocol["existing_checkpoint_sha256"]), {f"{arm}_seed{seed}" for arm in confirm.ARMS for seed in confirm.SEEDS[:3]})


if __name__ == "__main__":
    unittest.main()
