#!/usr/bin/env python
"""Five-seed confirm_v2 evaluation of frozen C/D/S without touching development evidence."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
from pathlib import Path

import nibabel as nib
import numpy as np
import torch
from nibabel.processing import resample_from_to

import run_grid_severity_control as severity
from run_grid_causal_audit import evaluate_model


ARMS = ("C", "D", "S")
SEEDS = (17, 29, 41, 53, 67)
NEW_SEEDS = (53, 67)
BOOTSTRAPS = 10_000
BOOTSTRAP_SEED = 7361
DEFAULT_OUTPUT = Path("/home/yanjingjia/grid_confirm_v2")
LOCK = Path("/home/yanjingjia/physgrid_pilot/split_manifest_confirm_v2_locked.json")
DEVELOPMENT = Path("/home/yanjingjia/grid_severity_control")

# Reuse the frozen trainer; only its allowed arm/seed sets are broadened.
severity.TRAINABLE = ARMS
severity.SEEDS = SEEDS


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(temporary, path)


def object_hash(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def pad4(array: np.ndarray) -> np.ndarray:
    return np.pad(array, [(0, (-size) % 4) for size in array.shape])


class Context:
    def __init__(self, project: Path, data: Path, legacy: Path, output: Path):
        self.project = project.resolve(); self.data = data.resolve(); self.legacy = legacy.resolve()
        self.evidence = Path("/home/yanjingjia")
        self.output = output.resolve()
        self.manifest = json.loads((legacy / "outputs" / "manifest.json").read_text())

    def cache(self, case_id: str, grid: str, kind: str) -> Path:
        legacy_path = self.legacy / "cache" / case_id / f"{grid}_{kind}.npy"
        path = legacy_path if legacy_path.is_file() else self.output / "cache" / case_id / f"{grid}_{kind}.npy"
        if not path.is_file():
            raise FileNotFoundError(path)
        return path

    def checkpoint(self, arm: str, seed: int, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / "checkpoints" / f"{arm}_seed{seed}.pt"

    def log(self, arm: str, seed: int, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / f"train_{arm}_seed{seed}.json"

    def resume(self, arm: str, seed: int, smoke: bool = False) -> Path:
        root = self.output / "smoke" if smoke else self.output
        return root / "resume" / f"{arm}_seed{seed}.pt"


def link(path: Path, target: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        if path.resolve() != target.resolve():
            raise RuntimeError(f"wrong checkpoint alias: {path}")
    else:
        path.symlink_to(target)


def locked_manifest() -> dict:
    value = json.loads(LOCK.read_text())
    if len(value.get("case_ids", [])) != 40 or not value.get("locked") or value.get("selection") != "same sorted IDs and numpy.default_rng(20260718) permutation; indices[160:200]":
        raise RuntimeError("confirm_v2 lock changed")
    if value.get("manifest_sha256") != object_hash({key: item for key, item in value.items() if key != "manifest_sha256"}):
        raise RuntimeError("confirm_v2 manifest hash mismatch")
    return value


def verify_confirm_files(data: Path, lock: dict) -> None:
    for item in lock["files"]:
        for kind, expected in (("imagesTr", item["image_sha256"]), ("labelsTr", item["label_sha256"])):
            path = data / kind / f"{item['case_id']}.nii.gz"
            if not path.is_file() or severity.sha256(path) != expected:
                raise RuntimeError(f"confirm_v2 file mismatch: {path}")


def setup(ctx: Context) -> None:
    lock = locked_manifest()
    method = json.loads((DEVELOPMENT / "method_freeze.json").read_text())
    if method.get("selected_arm") != "S" or method.get("exact_formula") != "a=log(s_mm/1mm)/log(3); select argmax(a), exact ties mean":
        raise RuntimeError("frozen method changed")
    old_protocol = json.loads((DEVELOPMENT / "protocol.json").read_text())
    schedules, initializations = {}, {}
    train_ids = ctx.manifest["split"]["train"]
    for seed in SEEDS:
        rows = severity.frozen_schedule(train_ids, seed)
        path = ctx.output / f"frozen_schedule_seed{seed}.jsonl"
        text = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
        path.parent.mkdir(parents=True, exist_ok=True); path.write_text(text)
        digest = hashlib.sha256(text.encode()).hexdigest()
        if seed in SEEDS[:3]:
            old_rows = [json.loads(line) for line in (DEVELOPMENT / f"frozen_schedule_seed{seed}.jsonl").read_text().splitlines()]
            fields = lambda row: (row["update"], row["case_id"], row["spacing_1"], row["spacing_2"])
            if [fields(row) for row in rows] != [fields(row) for row in old_rows]:
                raise RuntimeError(f"development schedule parity failure: seed{seed}")
        schedules[str(seed)] = {"sha256": digest, "updates": len(rows)}
        severity.seed_all(seed)
        initializations[str(seed)] = severity.state_sha256(severity.TinyMetricMamba("separated_physical_delta"))
    existing = {}
    for arm in ARMS:
        for seed in SEEDS[:3]:
            target = DEVELOPMENT / "checkpoints" / f"{arm}_seed{seed}.pt"
            if not target.is_file() and not target.is_symlink():
                raise RuntimeError(f"missing development checkpoint: {target}")
            link(ctx.checkpoint(arm, seed), target)
            existing[f"{arm}_seed{seed}"] = severity.sha256(target)
    protocol = {
        "authorized_confirm_v2": True,
        "arms": {arm: old_protocol["arms"][arm] for arm in ARMS},
        "seeds": list(SEEDS),
        "new_training_seeds": list(NEW_SEEDS),
        "shared": old_protocol["shared"],
        "schedule": schedules,
        "initialization_sha256": initializations,
        "method_freeze_sha256": severity.sha256(DEVELOPMENT / "method_freeze.json"),
        "locked_manifest_sha256": severity.sha256(LOCK),
        "existing_checkpoint_sha256": existing,
        "statistics": "paired crossed bootstrap: independently resample cases and seeds",
        "native_noninferiority_margin": -0.005,
        "source_sha256": {"runner": severity.sha256(Path(__file__)), "severity_runner": severity.sha256(ctx.project / "run_grid_severity_control.py")},
    }
    protocol["protocol_hash"] = object_hash(protocol)
    current = ctx.output / "protocol.json"
    if current.is_file():
        previous = json.loads(current.read_text())
        if previous != protocol:
            old_stable = {key: value for key, value in previous.items() if key not in {"source_sha256", "protocol_hash"}}
            new_stable = {key: value for key, value in protocol.items() if key not in {"source_sha256", "protocol_hash"}}
            if old_stable != new_stable:
                raise RuntimeError("confirm protocol drift")
            dump_json(current, protocol)
    else:
        dump_json(current, protocol)


def prepare_confirm(ctx: Context) -> None:
    setup(ctx)
    lock = locked_manifest(); verify_confirm_files(ctx.data, lock)
    cases = {}
    for number, case_id in enumerate(lock["case_ids"], 1):
        image = nib.as_closest_canonical(nib.load(ctx.data / "imagesTr" / f"{case_id}.nii.gz"))
        label = nib.as_closest_canonical(nib.load(ctx.data / "labelsTr" / f"{case_id}.nii.gz"))
        source_affine = np.asarray(image.affine, dtype=np.float64)
        spacing = np.linalg.norm(source_affine[:3, :3], axis=0); direction = source_affine[:3, :3] / spacing
        extent_z = int(math.ceil((image.shape[2] - 1) / 4) * 4)
        shape_xyz = (image.shape[0], image.shape[1], extent_z + 1)
        affine = source_affine.copy(); affine[:3, :3] = direction
        r1_image = np.asarray(resample_from_to(image, (shape_xyz, affine), order=1, mode="constant", cval=0).dataobj, dtype=np.float32).transpose(2, 1, 0)
        r1_label = np.asarray(resample_from_to(label, (shape_xyz, affine), order=0, mode="constant", cval=0).dataobj, dtype=np.uint8).transpose(2, 1, 0)
        foreground = r1_image != 0; mean, std = float(r1_image[foreground].mean()), float(r1_image[foreground].std())
        normalized = np.zeros_like(r1_image); normalized[foreground] = (r1_image[foreground] - mean) / std
        directory = ctx.output / "cache" / case_id; directory.mkdir(parents=True, exist_ok=True)
        np.save(directory / "R1_image.npy", pad4(normalized)); np.save(directory / "R1_label.npy", pad4(r1_label))
        cases[case_id] = {"r1_nonbackground_mean": mean, "r1_nonbackground_std": std, "grids": {"R1": {"unpadded_shape_dhw": list(r1_image.shape), "affine_xyz": affine.tolist()}}}
        print(f"prepared confirm_v2 {number}/40 {case_id}", flush=True)
    manifest = {"split": {"test": lock["case_ids"]}, "cases": cases, "locked_manifest_sha256": severity.sha256(LOCK), "evaluation_permitted_by_user": True}
    manifest["manifest_hash"] = object_hash(manifest)
    dump_json(ctx.output / "confirm_manifest.json", manifest)


def train(ctx: Context, arm: str, seed: int) -> dict:
    if arm not in ARMS or seed not in NEW_SEEDS:
        raise ValueError("confirm training is only C/D/S seeds 53/67")
    setup(ctx)
    return severity.train(ctx, arm, seed)


def verify_training(ctx: Context) -> None:
    protocol = json.loads((ctx.output / "protocol.json").read_text())
    for arm in ARMS:
        for seed in SEEDS:
            checkpoint = ctx.checkpoint(arm, seed)
            if not checkpoint.is_file():
                raise RuntimeError(f"missing checkpoint: {arm} seed{seed}")
            if seed in SEEDS[:3]:
                expected = protocol["existing_checkpoint_sha256"][f"{arm}_seed{seed}"]
            else:
                log = json.loads(ctx.log(arm, seed).read_text())
                if not log.get("completed") or log.get("updates") != severity.UPDATES:
                    raise RuntimeError(f"incomplete training: {arm} seed{seed}")
                expected = log["checkpoint_sha256"]
            if severity.sha256(checkpoint) != expected:
                raise RuntimeError(f"checkpoint hash mismatch: {arm} seed{seed}")


def crossed_bootstrap(cases: list[dict], treatment: str, control: str, metric: str) -> dict:
    lookup = {(row["arm"], row["case_id"], row["seed"]): row for row in cases}
    case_ids = sorted({row["case_id"] for row in cases}); matrix = np.asarray([[lookup[(treatment, case, seed)][metric] - lookup[(control, case, seed)][metric] for seed in SEEDS] for case in case_ids])
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    case_draws = rng.integers(0, len(case_ids), (BOOTSTRAPS, len(case_ids)))
    seed_draws = rng.integers(0, len(SEEDS), (BOOTSTRAPS, len(SEEDS)))
    draws = matrix[case_draws[:, :, None], seed_draws[:, None, :]].mean((1, 2))
    return {"mean_difference": float(matrix.mean()), "ci95": [float(x) for x in np.quantile(draws, (.025, .975))], "by_seed": {str(seed): float(matrix[:, index].mean()) for index, seed in enumerate(SEEDS)}, "positive_case_seed_fraction": float((matrix > 0).mean())}


def evaluate(ctx: Context) -> None:
    setup(ctx); verify_training(ctx)
    if not (ctx.output / "confirm_manifest.json").is_file():
        prepare_confirm(ctx)
    ctx.manifest = json.loads((ctx.output / "confirm_manifest.json").read_text())
    device = severity.require_cuda(); rows = []
    for seed in SEEDS:
        for arm in ARMS:
            rows += evaluate_model(ctx, arm, seed, device, set())
    with (ctx.output / "metrics_case_level.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    cases = severity.case_summaries(rows)
    with (ctx.output / "metrics_case_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(cases[0])); writer.writeheader(); writer.writerows(cases)
    metrics = ("Dnative", "Grid_AUC", "Worst_grid_Dpred", "Worst_grid_Dmap", "source_range_Dmap", "Extra_Dmap", "Extra_Smap", "degradation_slope")
    summary = {arm: {metric: float(np.mean([row[metric] for row in cases if row["arm"] == arm])) for metric in metrics} for arm in ARMS}
    comparisons = {f"{a}_minus_{b}:{metric}": crossed_bootstrap(cases, a, b, metric) for a, b in (("S", "C"), ("S", "D"), ("D", "C")) for metric in metrics}
    dump_json(ctx.output / "results.json", {"confirm_v2_evaluated": True, "cases": 40, "seeds": list(SEEDS), "summary": summary, "comparisons": comparisons, "native_noninferiority_margin": -0.005})


def report(ctx: Context) -> None:
    result = json.loads((ctx.output / "results.json").read_text())
    primary = result["comparisons"]["S_minus_C:Extra_Dmap"]
    adaptive = result["comparisons"]["S_minus_D:Extra_Dmap"]
    native = result["comparisons"]["S_minus_C:Dnative"]
    passed = primary["ci95"][0] > 0 and native["ci95"][0] >= -0.005
    lines = ["# Frozen confirm_v2 report", "", f"Decision: **{'PASS' if passed else 'FAIL'}**", "", f"- S-C Extra Dmap: {primary['mean_difference']:+.5f}, crossed 95% CI [{primary['ci95'][0]:+.5f}, {primary['ci95'][1]:+.5f}].", f"- S-D Extra Dmap: {adaptive['mean_difference']:+.5f}, crossed 95% CI [{adaptive['ci95'][0]:+.5f}, {adaptive['ci95'][1]:+.5f}].", f"- S-C native Dice: {native['mean_difference']:+.5f}, crossed 95% CI [{native['ci95'][0]:+.5f}, {native['ci95'][1]:+.5f}]; noninferiority margin -0.005.", "", "The locked 40-case split was evaluated once after the user explicitly authorized confirm_v2 access. No method selection or tuning used these results."]
    (ctx.output / "report.md").write_text("\n".join(lines) + "\n")
    dump_json(ctx.output / "decision.json", {"decision": "PASS" if passed else "FAIL", "primary": primary, "adaptive": adaptive, "native_guardrail": native})


def smoke(ctx: Context) -> None:
    setup(ctx)
    results = {arm: severity.train(ctx, arm, 53, updates=2, smoke=True) for arm in ARMS}
    if not all(item["finite"] for item in results.values()):
        raise RuntimeError("confirm smoke failed")
    dump_json(ctx.output / "smoke.json", {arm: {"finite": item["finite"], "last_loss": item["history"][-1]["total_loss"]} for arm, item in results.items()})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--data", type=Path, default=Path("/home/yanjingjia/data/Task04_Hippocampus"))
    parser.add_argument("--legacy", type=Path, default=Path("/home/yanjingjia/metric_mamba_gate"))
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    commands = parser.add_subparsers(dest="command", required=True)
    for command in ("setup", "prepare-confirm", "smoke", "evaluate", "report"):
        commands.add_parser(command)
    train_parser = commands.add_parser("train"); train_parser.add_argument("--arm", choices=ARMS, required=True); train_parser.add_argument("--seed", choices=NEW_SEEDS, type=int, required=True)
    args = parser.parse_args(); ctx = Context(args.project, args.data, args.legacy, args.output)
    if args.command == "setup": setup(ctx)
    elif args.command == "prepare-confirm": prepare_confirm(ctx)
    elif args.command == "smoke": smoke(ctx)
    elif args.command == "train": train(ctx, args.arm, args.seed)
    elif args.command == "evaluate": evaluate(ctx)
    else: report(ctx)


if __name__ == "__main__":
    main()
