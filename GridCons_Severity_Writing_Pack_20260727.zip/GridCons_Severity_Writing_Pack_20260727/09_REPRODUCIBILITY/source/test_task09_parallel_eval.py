import unittest

import run_task09_parallel_eval as parallel


class ParallelEvalTests(unittest.TestCase):
    def test_complete_requires_exact_model_and_grid(self):
        rows = [{"arm": "C", "fold": "0", "seed": "17"} for _ in range(2 * len(parallel.run.SPACINGS))]
        self.assertTrue(parallel.complete(rows, "C", 0, 17, 2))
        self.assertFalse(parallel.complete(rows[:-1], "C", 0, 17, 2))
        self.assertFalse(parallel.complete(rows, "S", 0, 17, 2))

    def test_surface_metric_is_scoped_to_extra_range(self):
        self.assertEqual(parallel.SURFACE_SPACINGS, (4.0, 5.0))


if __name__ == "__main__":
    unittest.main()
