import os
import unittest
from pathlib import Path

import torch

import run_task09_unet_severity as run


class Task09UNetSeverityTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.output = Path(os.environ.get("TASK09_UNET_OUTPUT", run.DEFAULT_OUTPUT))
        run.setup(cls.output)

    def test_frozen_scope_and_schedule(self):
        protocol, folds, preprocessing = run.verify_setup(self.output)
        self.assertEqual((run.ARMS, run.SEEDS, run.FOLDS), (("C", "S"), (17, 29, 41), tuple(range(5))))
        self.assertEqual(protocol["fold_hash"], folds["fold_hash"])
        rows = run.make_schedule(folds["folds"][0], preprocessing, 0, 17, 4)
        self.assertEqual(rows, run.make_schedule(folds["folds"][0], preprocessing, 0, 17, 4))
        self.assertTrue(all(len(row["requested_spacings_mm"]) == 2 and all(1 <= x <= 3 for x in row["requested_spacings_mm"]) for row in rows))

    def test_c_and_s_aggregation(self):
        errors = torch.tensor([0.2, 0.8])
        spacings = torch.tensor([2.5, 1.2])
        self.assertAlmostEqual(float(run.aggregate(errors, spacings, "C")[0]), 0.5)
        self.assertAlmostEqual(float(run.aggregate(errors, spacings, "S")[0]), 0.2)
        self.assertAlmostEqual(float(run.aggregate(errors, torch.tensor([2.0, 2.0]), "S")[0]), 0.5)

    def test_endpoint_resampling_and_model_shape(self):
        image = torch.randn(1, 1, 9, 16, 16)
        candidate, actual = run.endpoint_resample_tensor(image, [2.0, 1.0, 1.0], 3.0)
        self.assertEqual(candidate.shape, (1, 1, 6, 16, 16))
        self.assertAlmostEqual(actual, 3.2)
        logits = run.PlainUNet3D(2)(candidate)
        self.assertEqual(logits.shape, (1, 2, 6, 16, 16))
        self.assertTrue(torch.isfinite(run.consistency_error(run.PlainUNet3D(2)(image), logits)))


if __name__ == "__main__":
    unittest.main()
