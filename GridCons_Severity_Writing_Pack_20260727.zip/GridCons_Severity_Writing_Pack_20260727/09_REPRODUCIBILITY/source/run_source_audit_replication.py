#!/usr/bin/env python3
"""Independent three-seed replication of the two causal source contrasts."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

import run_grid_causal_audit as causal


SEEDS = (17, 29, 41)
NEW_MODELS = tuple((arm, seed) for arm in ("degrade_on_r1", "label_supervised_random") for seed in SEEDS[1:])
ARMS = ("random_k2", "degrade_on_r1", "label_supervised_random")
METRICS = ("Dnative", "grid_auc_dpred", "worst_grid_Dpred", "worst_grid_Dmap", "source_mean_Dmap", "extrapolation_Dmap", "extrapolation_Smap")
BOOTSTRAPS = 10_000
BOOTSTRAP_SEED = 7351


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    for name in ("project-root", "data-root", "legacy-root", "previous-output", "output-root"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    for command in ("verify", "evaluate", "report"):
        commands.add_parser(command)
    return parser.parse_args()


class Context:
    def __init__(self, args: argparse.Namespace):
        self.causal = causal.Context(args)
        self.output = args.output_root.resolve() / "source_audit_replication"
        if self.output == self.causal.output:
            raise RuntimeError("replication output must be independent of causal evidence")


def read_csv(path: Path) -> list[dict]:
    with path.open() as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["seed"] = int(row["seed"])
        for key in row.keys() - {"arm", "case_id", "class", "seed"}:
            row[key] = float(row[key])
    return rows


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise RuntimeError(f"refusing to write empty CSV: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def complete_level_rows(rows: list[dict]) -> bool:
    cells = {(x["case_id"], x["spacing_nominal_mm"], x["class"]) for x in rows}
    return len(rows) == len(cells) == 20 * len(causal.SPACINGS) * 3 and {x["spacing_nominal_mm"] for x in rows} == set(causal.SPACINGS) and {x["class"] for x in rows} == {"foreground", "anterior", "posterior"}


def recorded_hash(ctx: Context, path: Path) -> str:
    entries = {}
    for line in (ctx.causal.output / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split(maxsplit=1); entries[Path(name)] = digest
    if path not in entries or causal.sha256(path) != entries[path]:
        raise RuntimeError(f"frozen source hash mismatch: {path}")
    return entries[path]


def source_rows(ctx: Context) -> tuple[list[dict], list[dict], dict]:
    level_path = ctx.causal.output / "metrics_case_level.csv"
    old_case_path = ctx.causal.output / "metrics_case_summary.csv"
    dc_path = ctx.causal.output / "dc_three_seed_case_summary.csv"
    hashes = {path.name: recorded_hash(ctx, path) for path in (level_path, old_case_path, dc_path)}
    level = [x for x in read_csv(level_path) if x["arm"] in ARMS and x["seed"] == 17]
    old_cases = [x for x in read_csv(old_case_path) if x["arm"] in ARMS and x["seed"] == 17]
    dc_cases = [x for x in read_csv(dc_path) if x["arm"] == "random_k2"]
    derived = causal.case_summary(level)
    old = {(x["arm"], x["seed"], x["case_id"]): x for x in old_cases}
    if len(level) != 3 * 20 * len(causal.SPACINGS) * 3 or len(old) != 3 * 20 or len(dc_cases) != len(SEEDS) * 20:
        raise RuntimeError("frozen source rows are incomplete")
    for row in derived:
        reference = old[(row["arm"], row["seed"], row["case_id"])]
        if any(not np.isclose(row[metric], reference[metric], rtol=0, atol=1e-12) for metric in METRICS):
            raise RuntimeError("seed17 row/case summaries disagree")
    dc = {(x["seed"], x["case_id"]): x for x in dc_cases}
    for row in old_cases:
        if row["arm"] == "random_k2" and any(not np.isclose(row[m], dc[(17, row["case_id"])][m], rtol=0, atol=1e-12) for m in METRICS):
            raise RuntimeError("seed17 Random-K2 summaries disagree across frozen sources")
    combined_cases = [x for x in old_cases if x["arm"] != "random_k2"] + dc_cases
    return level, combined_cases, hashes


def verify(ctx: Context) -> dict:
    development, deny = causal.verify_frozen(ctx.causal)
    _, cases, hashes = source_rows(ctx)
    checkpoints = {}
    for arm, seed in NEW_MODELS:
        checkpoint, log_path = ctx.causal.checkpoint(arm, seed), ctx.causal.log(arm, seed)
        if not checkpoint.is_file() or not log_path.is_file():
            raise RuntimeError(f"missing trained model: {arm} seed{seed}")
        log = json.loads(log_path.read_text())
        digest = causal.sha256(checkpoint)
        if not log.get("completed") or log.get("updates") != causal.UPDATES or log.get("checkpoint_sha256") != digest:
            raise RuntimeError(f"incomplete or mismatched trained model: {arm} seed{seed}")
        checkpoints[f"{arm}_seed{seed}"] = digest
    case_ids = {x["case_id"] for x in cases}
    if len(development) != 20 or len(case_ids) != 20 or len(deny) != 40:
        raise RuntimeError("development split isolation failure")
    result = {"status": "PASS", "frozen_source_sha256": hashes, "checkpoint_sha256": checkpoints, "development_cases": len(case_ids), "confirm_denylist_count": len(deny), "confirm_v2_accessed": False}
    causal.dump_json(ctx.output / "verification.json", result)
    return result


def assemble_cases(ctx: Context, new_rows: list[dict]) -> list[dict]:
    _, base_cases, _ = source_rows(ctx)
    combined = sorted(base_cases + causal.case_summary(new_rows), key=lambda x: (x["arm"], x["seed"], x["case_id"]))
    expected = {(arm, seed) for arm in ARMS for seed in SEEDS}
    if {(x["arm"], x["seed"]) for x in combined} != expected or len(combined) != len(expected) * 20:
        raise RuntimeError("three-seed case summary is incomplete")
    return combined


def evaluate(ctx: Context) -> None:
    verification = verify(ctx)
    device = causal.require_cuda()
    level, _, _ = source_rows(ctx)
    metrics_path = ctx.output / "metrics_case_level.csv"
    manifest_path = ctx.output / "evaluation_manifest.json"
    existing = read_csv(metrics_path) if metrics_path.is_file() else []
    manifest = json.loads(manifest_path.read_text()) if manifest_path.is_file() else {"checkpoint_sha256": {}}
    new_rows = [x for x in existing if (x["arm"], x["seed"]) in NEW_MODELS]
    for arm, seed in NEW_MODELS:
        key = f"{arm}_seed{seed}"
        cached = [x for x in new_rows if (x["arm"], x["seed"]) == (arm, seed)]
        complete = complete_level_rows(cached) and manifest["checkpoint_sha256"].get(key) == verification["checkpoint_sha256"][key]
        if not complete:
            new_rows = [x for x in new_rows if (x["arm"], x["seed"]) != (arm, seed)]
            evaluated = causal.evaluate_model(ctx.causal, arm, seed, device, set(json.loads((ctx.causal.output / "confirm_denylist.json").read_text())["hashes"]))
            if not complete_level_rows(evaluated):
                raise RuntimeError(f"incomplete evaluation: {arm} seed{seed}")
            new_rows += evaluated
            manifest["checkpoint_sha256"][key] = verification["checkpoint_sha256"][key]
            write_csv(metrics_path, level + new_rows)
            causal.dump_json(manifest_path, manifest)
    write_csv(metrics_path, level + new_rows)
    write_csv(ctx.output / "metrics_case_summary.csv", assemble_cases(ctx, new_rows))


def crossed_bootstrap_difference(cases: list[dict], treatment: str, control: str, metric: str) -> dict:
    a = {(x["case_id"], x["seed"]): float(x[metric]) for x in cases if x["arm"] == treatment}
    b = {(x["case_id"], x["seed"]): float(x[metric]) for x in cases if x["arm"] == control}
    if set(a) != set(b):
        raise RuntimeError(f"unpaired cells for {treatment}-{control} {metric}")
    case_ids = sorted({case_id for case_id, _ in a}); seeds = sorted({seed for _, seed in a})
    if seeds != list(SEEDS) or len(a) != len(case_ids) * len(seeds):
        raise RuntimeError(f"incomplete crossed design for {treatment}-{control} {metric}")
    differences = np.asarray([[a[(case_id, seed)] - b[(case_id, seed)] for seed in seeds] for case_id in case_ids])
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    case_draws = rng.integers(0, len(case_ids), (BOOTSTRAPS, len(case_ids)))
    seed_draws = rng.integers(0, len(seeds), (BOOTSTRAPS, len(seeds)))
    samples = differences[case_draws[:, :, None], seed_draws[:, None, :]].mean(axis=(1, 2))
    by_seed = {}
    for column, seed in enumerate(seeds):
        value = float(differences[:, column].mean())
        by_seed[str(seed)] = {"mean_difference": value, "direction": "positive" if value > 0 else "negative" if value < 0 else "zero", "positive_cases": int((differences[:, column] > 0).sum())}
    return {"treatment": treatment, "control": control, "metric": metric, "mean_difference": float(differences.mean()), "ci95": [float(x) for x in np.quantile(samples, (0.025, 0.975))], "by_seed": by_seed}


def report(ctx: Context) -> None:
    verification = verify(ctx)
    level = read_csv(ctx.output / "metrics_case_level.csv")
    manifest = json.loads((ctx.output / "evaluation_manifest.json").read_text())
    new_rows = [x for x in level if (x["arm"], x["seed"]) in NEW_MODELS]
    for arm, seed in NEW_MODELS:
        key = f"{arm}_seed{seed}"
        if not complete_level_rows([x for x in new_rows if (x["arm"], x["seed"]) == (arm, seed)]) or manifest["checkpoint_sha256"].get(key) != verification["checkpoint_sha256"][key]:
            raise RuntimeError(f"stale or incomplete evaluation: {arm} seed{seed}")
    cases = assemble_cases(ctx, new_rows)
    write_csv(ctx.output / "metrics_case_summary.csv", cases)
    comparisons = [crossed_bootstrap_difference(cases, "random_k2", control, metric) for control in ("degrade_on_r1", "label_supervised_random") for metric in METRICS]
    by_arm = {arm: {metric: float(np.mean([x[metric] for x in cases if x["arm"] == arm])) for metric in METRICS} for arm in ARMS}
    by_arm_seed = {arm: {str(seed): {metric: float(np.mean([x[metric] for x in cases if x["arm"] == arm and x["seed"] == seed])) for metric in METRICS} for seed in SEEDS} for arm in ARMS}
    causal.dump_json(ctx.output / "metrics_summary.json", {"by_arm": by_arm, "by_arm_seed": by_arm_seed})
    causal.dump_json(ctx.output / "crossed_bootstrap_results.json", {"method": "paired crossed bootstrap: resample development cases and training seeds globally, then average their crossed product", "draws": BOOTSTRAPS, "seed": BOOTSTRAP_SEED, "comparisons": comparisons})
    primary = [x for x in comparisons if x["metric"] == "extrapolation_Dmap"]
    lines = ["# Three-seed causal source replication", "", "Development-screen evidence only; confirm_v2 remained locked.", "", "| arm | Dnative | Grid-AUC | Worst Dpred | Worst Dmap | Source Dmap | Extra Dmap | Extra Smap |", "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for arm in ARMS:
        x = by_arm[arm]; lines.append(f"| {arm} | {x['Dnative']:.4f} | {x['grid_auc_dpred']:.4f} | {x['worst_grid_Dpred']:.4f} | {x['worst_grid_Dmap']:.4f} | {x['source_mean_Dmap']:.4f} | {x['extrapolation_Dmap']:.4f} | {x['extrapolation_Smap']:.4f} |")
    lines += ["", "## Primary contrasts", ""]
    for item in primary:
        directions = ", ".join(f"seed {seed}: {value['mean_difference']:+.4f} ({value['direction']})" for seed, value in item["by_seed"].items())
        lines.append(f"- {item['treatment']} - {item['control']} Extra Dmap: {item['mean_difference']:+.4f}, crossed 95% CI [{item['ci95'][0]:+.4f}, {item['ci95'][1]:+.4f}]; {directions}.")
    lines += ["", "All seven case-level metrics and both contrasts are in the JSON outputs. The four newly trained checkpoints have complete spacing-by-class rows in `metrics_case_level.csv`; Random-K2 seeds 29/41 reuse the frozen case summaries."]
    (ctx.output / "report.md").write_text("\n".join(lines) + "\n")


def main() -> None:
    args = arguments(); ctx = Context(args)
    if args.command == "verify": verify(ctx)
    elif args.command == "evaluate": evaluate(ctx)
    else: report(ctx)


if __name__ == "__main__":
    main()
