#!/usr/bin/env python
"""Independent Task09 PlainUNet3D replication of frozen C versus S."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import sys
import time
from pathlib import Path

import nibabel as nib
import numpy as np
import torch
from nibabel.processing import resample_from_to
from torch.nn import functional as F


PROJECT = Path(__file__).resolve().parent
EXTERNAL = Path("/home/yanjingjia/gridcons_followup_20260720/02_external_spacing")
CONTROL = Path("/home/yanjingjia/gridcons_followup_20260720/01_task04_control_matrix")
sys.path.insert(0, str(EXTERNAL))
sys.path.insert(0, str(CONTROL))
import external_validation as ext  # noqa: E402
from unet3d import PlainUNet3D, parameter_count  # noqa: E402


ARMS = ("C", "S")
SEEDS = (17, 29, 41)
FOLDS = tuple(range(5))
SPACINGS = (1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0)
UPDATES = 2500
VALIDATE_EVERY = 250
WARMUP_UPDATES = 500
LAMBDA_MAX = 0.1
BOOTSTRAPS = 10_000
BOOTSTRAP_SEED = 7331
PATCH_DHW = ext.PATCH_DHW
DEFAULT_OUTPUT = Path("/home/yanjingjia/task09_unet_severity")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def object_hash(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def protocol_path(output: Path) -> Path:
    return output / "PROTOCOL.json"


def schedule_path(output: Path, fold: int, seed: int) -> Path:
    return output / "schedules" / f"fold{fold}_seed{seed}.jsonl"


def training_paths(output: Path, arm: str, fold: int, seed: int) -> tuple[Path, Path, Path]:
    if arm not in ARMS or fold not in FOLDS or seed not in SEEDS:
        raise ValueError("unregistered training run")
    stem = f"{arm}_fold{fold}_seed{seed}"
    return (
        output / "checkpoints" / f"{stem}.pt",
        output / "logs" / f"train_{stem}.json",
        output / "resume" / f"{stem}.pt",
    )


def make_schedule(record: dict, preprocessing: dict, fold: int, seed: int, updates: int = UPDATES) -> list[dict]:
    rng = np.random.default_rng(seed + 1009 * fold)
    order: list[int] = []
    rows = []
    for update in range(1, updates + 1):
        if not order:
            order = rng.permutation(len(record["train"])).tolist()
        identifier = record["train"][order.pop()]
        shape = preprocessing["native"][identifier]["shape_dhw"]
        start = [int(rng.integers(0, size - patch + 1)) for size, patch in zip(shape, PATCH_DHW)]
        requested = np.exp(rng.uniform(0.0, math.log(3.0), 2)).tolist()
        rows.append({"update": update, "case_id": identifier, "start_dhw": start, "requested_spacings_mm": requested})
    return rows


def write_schedule(path: Path, rows: list[dict]) -> str:
    text = "".join(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n" for row in rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return hashlib.sha256(text.encode()).hexdigest()


def read_schedule(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text().splitlines()]


def setup(output: Path) -> None:
    old_protocol = ext.verify_protocol()
    folds = ext.load_json(ext.FOLDS_PATH)
    preprocessing = ext.load_json(ext.PREPROCESSING_PATH)
    ext.validate_folds(folds)
    ext.validate_preprocessing(preprocessing, folds)
    source_hashes = {
        "external_validation.py": sha256(EXTERNAL / "external_validation.py"),
        "FOLDS.json": sha256(ext.FOLDS_PATH),
        "PREPROCESSING.json": sha256(ext.PREPROCESSING_PATH),
        "unet3d.py": sha256(CONTROL / "unet3d.py"),
        "runner": sha256(Path(__file__)),
    }
    if protocol_path(output).is_file():
        value = json.loads(protocol_path(output).read_text())
        if value.get("source_sha256") != source_hashes or value.get("protocol_hash") != object_hash({k: v for k, v in value.items() if k != "protocol_hash"}):
            raise RuntimeError("Task09 U-Net protocol/source drift")
        print(f"validated setup: {value['protocol_hash']}")
        return
    schedules = {}
    for fold, record in enumerate(folds["folds"]):
        for seed in SEEDS:
            rows = make_schedule(record, preprocessing, fold, seed)
            schedules[f"fold{fold}_seed{seed}"] = {
                "path": str(schedule_path(output, fold, seed)),
                "sha256": write_schedule(schedule_path(output, fold, seed), rows),
                "updates": len(rows),
            }
    value = {
        "task": "Task09_Spleen_PlainUNet3D_C_vs_S_external_replication",
        "independent_output": str(output),
        "read_only_upstream": str(EXTERNAL),
        "upstream_protocol_hash": old_protocol["protocol_hash"],
        "fold_hash": folds["fold_hash"],
        "preprocessing_hash": preprocessing["preprocessing_hash"],
        "arms": {"C": "mean of two candidate consistency errors", "S": "error at larger requested spacing; exact tie uses mean"},
        "seeds": list(SEEDS),
        "folds": list(FOLDS),
        "architecture": "PlainUNet3D(out_channels=2)",
        "parameters": parameter_count(PlainUNet3D(2)),
        "optimization": {"optimizer": "AdamW", "lr": 3e-4, "weight_decay": 1e-5, "updates": UPDATES, "validation_every": VALIDATE_EVERY, "amp": "bfloat16", "batch": 1},
        "loss": {"native_segmentation": "0.5 soft-Dice + 0.5 cross-entropy", "K": 2, "requested_spacing_mm": "LogUniform[1,3]", "lambda": "0.1*min(1,update/500)", "teacher": "detached native posterior"},
        "checkpoint_selection": "inner-validation native-grid foreground Dice only; strict greater keeps earliest",
        "evaluation_spacings_mm": list(SPACINGS),
        "bootstrap": {"kind": "independently resample cases and seeds, then average crossed product", "draws": BOOTSTRAPS, "seed": BOOTSTRAP_SEED},
        "candidate_construction": "endpoint-matched through-plane resampling of the frozen normalized native cache; affine-aware probability mapping",
        "schedules": schedules,
        "source_sha256": source_hashes,
    }
    value["protocol_hash"] = object_hash(value)
    dump_json(protocol_path(output), value)
    print(f"created setup: {value['protocol_hash']}")


def verify_setup(output: Path) -> tuple[dict, dict, dict]:
    setup(output)
    protocol = json.loads(protocol_path(output).read_text())
    folds, preprocessing = ext.load_json(ext.FOLDS_PATH), ext.load_json(ext.PREPROCESSING_PATH)
    for fold in FOLDS:
        for seed in SEEDS:
            key = f"fold{fold}_seed{seed}"
            path = schedule_path(output, fold, seed)
            if len(read_schedule(path)) != UPDATES or sha256(path) != protocol["schedules"][key]["sha256"]:
                raise RuntimeError(f"schedule drift: {key}")
    return protocol, folds, preprocessing


def aggregate(errors: torch.Tensor, requested_spacings_mm: torch.Tensor, arm: str) -> tuple[torch.Tensor, torch.Tensor]:
    if arm not in ARMS or errors.shape != (2,) or requested_spacings_mm.shape != (2,) or not torch.isfinite(errors).all():
        raise ValueError("C/S aggregation requires two finite errors and spacings")
    if arm == "C" or requested_spacings_mm[0] == requested_spacings_mm[1]:
        weights = torch.full_like(errors, 0.5)
    else:
        weights = F.one_hot(requested_spacings_mm.argmax(), 2).to(errors)
    return (weights * errors).sum(), weights.detach()


def endpoint_resample_tensor(image: torch.Tensor, native_spacing_dhw: list[float], requested_z_mm: float) -> tuple[torch.Tensor, float]:
    if image.ndim != 5 or requested_z_mm <= 0:
        raise ValueError("expected a positive spacing and [B,C,D,H,W] image")
    extent = (image.shape[2] - 1) * float(native_spacing_dhw[0])
    depth = max(2, int(round(extent / requested_z_mm)) + 1)
    actual = extent / (depth - 1)
    return F.interpolate(image, size=(depth, image.shape[3], image.shape[4]), mode="trilinear", align_corners=True), actual


def consistency_error(native_logits: torch.Tensor, candidate_logits: torch.Tensor) -> torch.Tensor:
    teacher = native_logits.float().softmax(1)[:, 1:].detach()
    student = F.interpolate(candidate_logits.float().softmax(1)[:, 1:], size=native_logits.shape[2:], mode="trilinear", align_corners=True)
    dims = (0, 2, 3, 4)
    intersection = (teacher * student).sum(dims)
    denominator = teacher.square().sum(dims) + student.square().sum(dims)
    return 1.0 - ((2.0 * intersection + 1e-5) / (denominator + 1e-5)).mean()


@torch.inference_mode()
def predict_patch(model: torch.nn.Module, patch: np.ndarray) -> np.ndarray:
    device = next(model.parameters()).device
    tensor = torch.from_numpy(np.asarray(patch, dtype=np.float32))[None, None].to(device)
    with torch.autocast("cuda", dtype=torch.bfloat16):
        probability = model(tensor).softmax(1)[0, 1].float()
    if not torch.isfinite(probability).all():
        raise RuntimeError("non-finite prediction")
    return probability.cpu().numpy()


def sliding_predict(model: torch.nn.Module, image: np.ndarray) -> np.ndarray:
    total = np.zeros(image.shape, dtype=np.float32)
    count = np.zeros(image.shape, dtype=np.uint8)
    for d in ext.sliding_starts(image.shape[0], PATCH_DHW[0]):
        for h in ext.sliding_starts(image.shape[1], PATCH_DHW[1]):
            for w in ext.sliding_starts(image.shape[2], PATCH_DHW[2]):
                patch = ext.extract_padded(image, (d, h, w), PATCH_DHW, -1.0).astype(np.float32)
                probability = predict_patch(model, patch)
                valid = tuple(slice(0, min(size, available - start)) for size, available, start in zip(PATCH_DHW, image.shape, (d, h, w)))
                destination = tuple(slice(start, start + section.stop) for start, section in zip((d, h, w), valid))
                total[destination] += probability[valid]
                count[destination] += 1
    if (count == 0).any():
        raise RuntimeError("sliding prediction coverage failure")
    return total / count


def validation_dice(model: torch.nn.Module, record: dict, preprocessing: dict) -> float:
    scores = []
    allowed = set(record["validation"])
    model.eval()
    for identifier in record["validation"]:
        meta = preprocessing["native"][identifier]
        probability = sliding_predict(model, np.load(meta["cache"], mmap_mode="r"))
        prediction = ext.embed_native_roi(probability, meta) >= 0.5
        truth = ext.load_label_full(identifier, allowed) == 1
        scores.append(ext.binary_dice(prediction, truth))
    return float(np.mean(scores))


def validate_training(output: Path, arm: str, fold: int, seed: int) -> None:
    protocol = json.loads(protocol_path(output).read_text())
    checkpoint, log_path, _ = training_paths(output, arm, fold, seed)
    log = json.loads(log_path.read_text())
    saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if not (
        log.get("completed") is True
        and log.get("updates") == UPDATES
        and log.get("checkpoint_sha256") == sha256(checkpoint)
        and log.get("protocol_hash") == protocol["protocol_hash"]
        and saved.get("arm") == arm
        and saved.get("fold") == fold
        and saved.get("seed") == seed
        and saved.get("selection") == protocol["checkpoint_selection"]
    ):
        raise RuntimeError(f"invalid training evidence: {arm}/fold{fold}/seed{seed}")
    PlainUNet3D(2).load_state_dict(saved["model_state"], strict=True)


def train(output: Path, arm: str, fold: int, seed: int, updates: int = UPDATES, smoke: bool = False) -> dict:
    if not smoke and updates != UPDATES:
        raise ValueError("scientific runs require exactly 2500 updates")
    protocol, folds, preprocessing = verify_setup(output)
    checkpoint, log_path, resume_path = training_paths(output, arm, fold, seed)
    if not smoke and checkpoint.is_file() and log_path.is_file():
        validate_training(output, arm, fold, seed)
        return json.loads(log_path.read_text())
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA required")
    record = folds["folds"][fold]
    schedule = read_schedule(schedule_path(output, fold, seed))[:updates]
    allowed = set(record["train"])
    images = {case: np.load(preprocessing["native"][case]["cache"], mmap_mode="r") for case in record["train"]}
    labels = {case: ext.label_roi(case, preprocessing["native"][case], allowed) for case in record["train"]}
    device = torch.device("cuda:0")
    seed_all(seed)
    model = PlainUNet3D(2).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-5)
    history, best, start_update = [], -1.0, 0
    if not smoke and resume_path.is_file():
        saved = torch.load(resume_path, map_location=device, weights_only=False)
        if (saved.get("arm"), saved.get("fold"), saved.get("seed"), saved.get("protocol_hash")) != (arm, fold, seed, protocol["protocol_hash"]):
            raise RuntimeError("resume provenance mismatch")
        model.load_state_dict(saved["model_state"], strict=True)
        optimizer.load_state_dict(saved["optimizer_state"])
        history, best, start_update = saved["history"], float(saved["best"]), int(saved["update"])
    started = time.perf_counter()
    torch.cuda.reset_peak_memory_stats()
    for item in schedule[start_update:]:
        identifier, start = item["case_id"], item["start_dhw"]
        slices = tuple(slice(value, value + size) for value, size in zip(start, PATCH_DHW))
        x = torch.from_numpy(np.asarray(images[identifier][slices], dtype=np.float32).copy())[None, None].to(device)
        y = torch.from_numpy(np.asarray(labels[identifier][slices], dtype=np.int64).copy())[None].to(device)
        requested = torch.tensor(item["requested_spacings_mm"], device=device)
        model.train()
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            native_logits = model(x)
            native_loss = ext.loss_fn(native_logits, y)
            errors, actual = [], []
            for spacing in item["requested_spacings_mm"]:
                candidate, actual_spacing = endpoint_resample_tensor(x, preprocessing["native"][identifier]["spacing_dhw"], spacing)
                errors.append(consistency_error(native_logits, model(candidate)))
                actual.append(actual_spacing)
            auxiliary, weights = aggregate(torch.stack(errors), requested, arm)
            weight = LAMBDA_MAX * min(1.0, item["update"] / WARMUP_UPDATES)
            loss = native_loss + weight * auxiliary
        if not torch.isfinite(loss):
            raise RuntimeError(f"non-finite loss at update {item['update']}")
        loss.backward()
        if not all(torch.isfinite(parameter.grad).all() for parameter in model.parameters() if parameter.grad is not None):
            raise RuntimeError(f"non-finite gradient at update {item['update']}")
        optimizer.step()
        row = {"update": item["update"], "case_id": identifier, "requested_spacings_mm": item["requested_spacings_mm"], "actual_spacings_mm": actual, "native_loss": float(native_loss.detach()), "candidate_errors": [float(value.detach()) for value in errors], "aggregation_weights": [float(value) for value in weights], "effective_lambda": weight, "total_loss": float(loss.detach())}
        if not smoke and item["update"] % VALIDATE_EVERY == 0:
            score = validation_dice(model, record, preprocessing)
            row["validation_native_dice"] = score
            print(arm, fold, seed, item["update"], score, flush=True)
            if score > best:
                best = score
                checkpoint.parent.mkdir(parents=True, exist_ok=True)
                torch.save({"model_state": model.state_dict(), "arm": arm, "fold": fold, "seed": seed, "update": item["update"], "validation_native_dice": score, "selection": protocol["checkpoint_selection"], "protocol_hash": protocol["protocol_hash"]}, checkpoint)
        history.append(row)
        if not smoke and item["update"] % VALIDATE_EVERY == 0:
            resume_path.parent.mkdir(parents=True, exist_ok=True)
            torch.save({"model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(), "arm": arm, "fold": fold, "seed": seed, "update": item["update"], "best": best, "history": history, "protocol_hash": protocol["protocol_hash"]}, resume_path)
    elapsed = time.perf_counter() - started
    result = {"completed": not smoke and updates == UPDATES, "finite": True, "arm": arm, "fold": fold, "seed": seed, "updates": updates, "history": history, "best_validation_native_dice": best, "protocol_hash": protocol["protocol_hash"], "gpu_seconds": elapsed, "peak_allocated_bytes": int(torch.cuda.max_memory_allocated())}
    if not smoke:
        result.update({"checkpoint": str(checkpoint), "checkpoint_sha256": sha256(checkpoint), "checkpoint_selection": protocol["checkpoint_selection"]})
        dump_json(log_path, result)
        validate_training(output, arm, fold, seed)
    return result


def target_volume(image: np.ndarray, meta: dict, requested_z_mm: float) -> tuple[np.ndarray, dict]:
    source_affine = np.asarray(meta["affine_xyz"], dtype=np.float64)
    source_shape_xyz = np.asarray(image.shape[::-1], dtype=int)
    source_spacing = np.linalg.norm(source_affine[:3, :3], axis=0)
    depth = max(2, int(round((image.shape[0] - 1) * source_spacing[2] / requested_z_mm)) + 1)
    actual = (image.shape[0] - 1) * source_spacing[2] / (depth - 1)
    target_affine = source_affine.copy()
    target_affine[:3, 2] = source_affine[:3, 2] / source_spacing[2] * actual
    target_shape_xyz = (int(source_shape_xyz[0]), int(source_shape_xyz[1]), depth)
    source = nib.Nifti1Image(np.asarray(image).transpose(2, 1, 0), source_affine)
    target = resample_from_to(source, (target_shape_xyz, target_affine), order=1, mode="constant", cval=-1.0)
    array = np.asarray(target.dataobj, dtype=np.float32).transpose(2, 1, 0)
    return array, {"affine_xyz": target_affine.tolist(), "spacing_dhw": [actual, source_spacing[1], source_spacing[0]]}


def load_model(output: Path, arm: str, fold: int, seed: int, device: torch.device) -> torch.nn.Module:
    validate_training(output, arm, fold, seed)
    saved = torch.load(training_paths(output, arm, fold, seed)[0], map_location=device, weights_only=False)
    model = PlainUNet3D(2).to(device)
    model.load_state_dict(saved["model_state"], strict=True)
    return model.eval()


def evaluate(output: Path) -> None:
    protocol, folds, preprocessing = verify_setup(output)
    device = torch.device("cuda:0")
    rows = []
    for record in folds["folds"]:
        fold = int(record["fold"])
        allowed = set(record["outer_test"])
        for seed in SEEDS:
            for arm in ARMS:
                model = load_model(output, arm, fold, seed, device)
                for identifier in record["outer_test"]:
                    meta = preprocessing["native"][identifier]
                    image = np.load(meta["cache"], mmap_mode="r")
                    truth = ext.load_label_full(identifier, allowed) == 1
                    native_roi = sliding_predict(model, image)
                    native_probability = ext.embed_native_roi(native_roi, meta)
                    native_hard = native_probability >= 0.5
                    dnative = ext.binary_dice(native_hard, truth)
                    for spacing in SPACINGS:
                        candidate, candidate_meta = target_volume(image, meta, spacing)
                        candidate_probability = sliding_predict(model, candidate)
                        mapped_probability = ext.map_pair_to_source(candidate_probability, candidate_meta, meta)
                        mapped_hard = mapped_probability >= 0.5
                        rows.append({"case_id": identifier, "fold": fold, "seed": seed, "arm": arm, "spacing_nominal_mm": spacing, "spacing_actual_mm": candidate_meta["spacing_dhw"][0], "Dnative": dnative, "Dpred": ext.binary_dice(mapped_hard, native_hard), "Dmap": ext.binary_dice(mapped_hard, truth), "Smap": ext.surface_dice_2mm(mapped_hard, truth, meta["source_spacing_dhw"])})
                    print(f"evaluated {arm} fold{fold} seed{seed} {identifier}", flush=True)
                del model
    expected = 41 * len(SEEDS) * len(ARMS) * len(SPACINGS)
    if len(rows) != expected or not all(np.isfinite([row[x] for x in ("Dnative", "Dpred", "Dmap", "Smap")]).all() for row in rows):
        raise RuntimeError("incomplete Task09 evaluation")
    path = output / "metrics.csv"
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    dump_json(output / "evaluation.json", {"completed": True, "rows": len(rows), "expected_rows": expected, "metrics_sha256": sha256(path), "protocol_hash": protocol["protocol_hash"]})


def analyze(output: Path) -> None:
    with (output / "metrics.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["seed"] = int(row["seed"])
        row["spacing_nominal_mm"] = float(row["spacing_nominal_mm"])
        for field in ("Dnative", "Dpred", "Dmap", "Smap"):
            row[field] = float(row[field])
    case_ids = sorted({row["case_id"] for row in rows})
    summaries = {}
    for arm in ARMS:
        for case_id in case_ids:
            for seed in SEEDS:
                selected = [row for row in rows if (row["arm"], row["case_id"], row["seed"]) == (arm, case_id, seed)]
                by_spacing = {row["spacing_nominal_mm"]: row for row in selected}
                summaries[(arm, case_id, seed)] = {"Dnative": selected[0]["Dnative"], "Worst_Dmap": min(row["Dmap"] for row in selected), "Extra_Dmap": float(np.mean([by_spacing[x]["Dmap"] for x in (4.0, 5.0)])), "Extra_Smap": float(np.mean([by_spacing[x]["Smap"] for x in (4.0, 5.0)]))}
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    case_samples = rng.integers(0, len(case_ids), size=(BOOTSTRAPS, len(case_ids)))
    seed_samples = rng.integers(0, len(SEEDS), size=(BOOTSTRAPS, len(SEEDS)))
    contrasts = {}
    for field in ("Dnative", "Worst_Dmap", "Extra_Dmap", "Extra_Smap"):
        matrix = np.asarray([[summaries[("S", case, seed)][field] - summaries[("C", case, seed)][field] for seed in SEEDS] for case in case_ids])
        draws = matrix[case_samples[:, :, None], seed_samples[:, None, :]].mean((1, 2))
        contrasts[field] = {"mean": float(matrix.mean()), "ci95": [float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))], "by_seed": {str(seed): float(matrix[:, index].mean()) for index, seed in enumerate(SEEDS)}}
    dump_json(output / "statistics.json", {"comparison": "S-minus-C", "cases": len(case_ids), "seeds": list(SEEDS), "crossed_case_seed_bootstrap": contrasts})


def unit_tests(output: Path) -> None:
    setup(output)
    import subprocess

    result = subprocess.run([sys.executable, "-m", "unittest", "-v", "test_task09_unet_severity.py"], cwd=PROJECT, text=True, capture_output=True, env={**__import__("os").environ, "TASK09_UNET_OUTPUT": str(output)})
    (output / "unit_tests.txt").write_text(result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError("unit tests failed")
    print(result.stdout + result.stderr)


def smoke(output: Path) -> None:
    protocol, folds, preprocessing = verify_setup(output)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA required")
    record = folds["folds"][0]
    item = read_schedule(schedule_path(output, 0, 17))[0]
    identifier, start = item["case_id"], item["start_dhw"]
    meta = preprocessing["native"][identifier]
    image = np.load(meta["cache"], mmap_mode="r")
    label = ext.label_roi(identifier, meta, set(record["train"]))
    slices = tuple(slice(value, value + size) for value, size in zip(start, PATCH_DHW))
    device = torch.device("cuda:0")
    results = {}
    for arm in ARMS:
        seed_all(17)
        model = PlainUNet3D(2).to(device)
        x = torch.from_numpy(np.asarray(image[slices], dtype=np.float32).copy())[None, None].to(device)
        y = torch.from_numpy(np.asarray(label[slices], dtype=np.int64).copy())[None].to(device)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            native = model(x)
            errors = []
            for spacing in item["requested_spacings_mm"]:
                candidate, _ = endpoint_resample_tensor(x, meta["spacing_dhw"], spacing)
                errors.append(consistency_error(native, model(candidate)))
            auxiliary, weights = aggregate(torch.stack(errors), torch.tensor(item["requested_spacings_mm"], device=device), arm)
            loss = ext.loss_fn(native, y) + LAMBDA_MAX / WARMUP_UPDATES * auxiliary
        loss.backward()
        results[arm] = {"loss": float(loss.detach()), "weights": [float(value) for value in weights], "finite": bool(torch.isfinite(loss) and all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None))}
    if not all(value["finite"] for value in results.values()):
        raise RuntimeError("smoke failed")
    dump_json(output / "smoke.json", {"protocol_hash": protocol["protocol_hash"], "one_real_cached_patch": True, "results": results})
    print(json.dumps(results, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("setup")
    sub.add_parser("unit-tests")
    sub.add_parser("smoke")
    train_parser = sub.add_parser("train")
    train_parser.add_argument("--arm", choices=ARMS, required=True)
    train_parser.add_argument("--fold", choices=FOLDS, type=int, required=True)
    train_parser.add_argument("--seed", choices=SEEDS, type=int, required=True)
    sub.add_parser("evaluate")
    sub.add_parser("analyze")
    args = parser.parse_args()
    output = args.output.resolve()
    if args.command == "setup": setup(output)
    elif args.command == "unit-tests": unit_tests(output)
    elif args.command == "smoke": smoke(output)
    elif args.command == "train": train(output, args.arm, args.fold, args.seed)
    elif args.command == "evaluate": evaluate(output)
    elif args.command == "analyze": analyze(output)


if __name__ == "__main__":
    main()
