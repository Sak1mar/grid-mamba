"""Minimal checks for the three-seed causal source replication."""

import unittest

import numpy as np

import run_source_audit_replication as replication


class SourceAuditReplicationTests(unittest.TestCase):
    def test_complete_level_rows_rejects_duplicates(self):
        rows = [{"case_id": str(case), "spacing_nominal_mm": spacing, "class": cls} for case in range(20) for spacing in replication.causal.SPACINGS for cls in ("foreground", "anterior", "posterior")]
        self.assertTrue(replication.complete_level_rows(rows))
        self.assertFalse(replication.complete_level_rows(rows[:-1] + rows[:1]))

    def test_crossed_bootstrap_resamples_seed_effect_globally(self):
        cases = []
        differences = np.asarray([[1.0, 10.0, 100.0], [3.0, 30.0, 300.0]])
        for arm in ("treatment", "control"):
            for case_index, case_id in enumerate(("a", "b")):
                for seed_index, seed in enumerate(replication.SEEDS):
                    value = differences[case_index, seed_index] if arm == "treatment" else 0.0
                    cases.append({"arm": arm, "case_id": case_id, "seed": seed, "score": value})
        result = replication.crossed_bootstrap_difference(cases, "treatment", "control", "score")
        rng = np.random.default_rng(replication.BOOTSTRAP_SEED)
        case_draws = rng.integers(0, 2, (replication.BOOTSTRAPS, 2))
        seed_draws = rng.integers(0, 3, (replication.BOOTSTRAPS, 3))
        expected = differences[case_draws[:, :, None], seed_draws[:, None, :]].mean((1, 2))
        self.assertEqual(result["ci95"], [float(x) for x in np.quantile(expected, (.025, .975))])
        self.assertEqual([x["direction"] for x in result["by_seed"].values()], ["positive"] * 3)

    def test_crossed_bootstrap_rejects_unpaired_cells(self):
        with self.assertRaisesRegex(RuntimeError, "unpaired cells"):
            replication.crossed_bootstrap_difference(
                [{"arm": "a", "case_id": "x", "seed": 17, "score": 1}, {"arm": "b", "case_id": "y", "seed": 17, "score": 0}],
                "a", "b", "score",
            )


if __name__ == "__main__":
    unittest.main()
