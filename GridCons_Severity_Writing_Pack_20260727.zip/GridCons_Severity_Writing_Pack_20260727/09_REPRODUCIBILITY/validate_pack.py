#!/usr/bin/env python3
"""Validate the portable writing pack without training or dataset access."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT.parent


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    checks: list[tuple[str, bool, str]] = []
    severity = ROOT / "06_EVIDENCE/severity_control"
    bootstrap = json.loads((severity / "bootstrap_results.json").read_text())["results"]
    sums: dict[tuple[str, str, str], list[float]] = {}
    with (severity / "paired_differences.csv").open(newline="") as handle:
        for row in csv.DictReader(handle):
            key = (row["treatment"], row["control"], row["metric"])
            sums.setdefault(key, []).append(float(row["difference"]))
    for treatment, control in (("D", "C"), ("S", "C"), ("S", "D"), ("W", "D")):
        key = (treatment, control, "Extra_Dmap")
        observed = sum(sums[key]) / len(sums[key])
        expected = bootstrap[f"{treatment}_minus_{control}:Extra_Dmap"]["mean_difference"]
        checks.append((f"recompute {treatment}-{control} Extra_Dmap", abs(observed - expected) < 1e-12, f"{observed:+.12f}"))

    summary = json.loads((severity / "metrics_summary.json").read_text())
    checks.append(("selected arm S has highest pooled Extra_Dmap", max(summary["pooled_case_seed"], key=lambda a: summary["pooled_case_seed"][a]["Extra_Dmap"]) == "S", str({a: round(x["Extra_Dmap"], 6) for a, x in summary["pooled_case_seed"].items()})))
    checks.append(("confirm flags false in severity evidence", not summary["confirm_v2_data_accessed"] and not summary["confirm_v2_evaluated"], "false/false"))
    confirm = json.loads((ROOT / "06_EVIDENCE/confirm_v2/decision.json").read_text())
    checks.append(("confirm_v2 primary decision passes", confirm["decision"] == "PASS" and confirm["primary"]["ci95"][0] > 0, str(confirm["primary"])))
    checks.append(("confirm native noninferiority passes", confirm["native_guardrail"]["ci95"][0] > -0.005, str(confirm["native_guardrail"]["ci95"])))
    external = json.loads((ROOT / "06_EVIDENCE/task09_unet_external/statistics.json").read_text())["crossed_case_seed_bootstrap"]["Extra_Dmap"]
    checks.append(("Task09/3D U-Net direction positive in all seeds", all(value > 0 for value in external["by_seed"].values()), str(external)))
    checks.append(("no symlinks in portable pack", not any(p.is_symlink() for p in ROOT.rglob("*")), "0 symlinks expected"))

    for name in ("commands_for_confirm_v2.sh", "commands_for_backbone_replication.sh"):
        lines = [x.strip() for x in (ROOT / "08_PENDING_CONFIRMATION" / name).read_text().splitlines() if x.strip() and not x.startswith("#")]
        checks.append((f"{name} remains execution-locked", lines[:2] == ["set -euo pipefail", "exit 0"], str(lines[:2])))

    source_pairs = [
        (SOURCE_ROOT / "grid_severity_control/method_freeze.json", severity / "method_freeze.json"),
        (SOURCE_ROOT / "grid_severity_control/decision.json", severity / "decision.json"),
        (SOURCE_ROOT / "grid_severity_control/metrics_summary.json", severity / "metrics_summary.json"),
        (SOURCE_ROOT / "grid_causal_audit/audit_report.md", ROOT / "06_EVIDENCE/continuous_grid_audit/audit_report.md"),
        (SOURCE_ROOT / "grid_gradient_diagnostic/diagnostic_report.md", ROOT / "06_EVIDENCE/negative_controls/gradient_diagnostic/diagnostic_report.md"),
    ]
    available = all(a.exists() for a, _ in source_pairs)
    if available:
        mismatches = [b.relative_to(ROOT).as_posix() for a, b in source_pairs if sha(a) != sha(b)]
        checks.append(("curated evidence copies match original files", not mismatches, f"mismatches={mismatches}"))
    else:
        checks.append(("curated evidence copies match original files", True, "source workspace unavailable; covered by package manifest"))

    deny_path = SOURCE_ROOT / "grid_causal_audit/confirm_denylist.json"
    if deny_path.exists():
        blocked = set(json.loads(deny_path.read_text())["hashes"])
        hits = set()
        for path in ROOT.rglob("*"):
            if not path.is_file() or path.suffix.lower() in {".pdf", ".png"}:
                continue
            text = path.read_text(errors="ignore")
            tokens = text.replace('"', " ").replace("'", " ").replace(",", " ").split()
            hits.update(token.strip("[](){}:;.") for token in tokens if token.strip("[](){}:;.") in blocked)
        checks.append(("confirm_v2 denylist hits in writing pack", not hits, f"hits={len(hits)}"))
    else:
        checks.append(("confirm_v2 denylist hits in writing pack", True, "denylist unavailable on portable copy; source validation recorded zero"))

    failed = [name for name, ok, _ in checks if not ok]
    report = [
        "# Validation Report",
        "",
        f"## Overall Assessment: {'Ready for venue formatting after author metadata' if not failed else 'Needs revision'}",
        "",
        "Question: are the frozen continuous-grid and severity-control results accurately organized for paper writing without overstating confirmation?",
        "",
        "Data as of: 2026-07-27. Validation covers copied development evidence, three-seed source replication, frozen confirm_v2, and the Task09/Plain 3D U-Net external block.",
        "",
        "## Calculation and Integrity Checks",
        "",
        "| Check | Result | Detail |",
        "|---|---|---|",
    ]
    report += [f"| {name} | {'PASS' if ok else 'FAIL'} | {detail.replace('|', '/')} |" for name, ok, detail in checks]
    report += [
        "",
        "## Methodology Review",
        "",
        "The pack separates development selection, three-seed source replication, untouched five-seed confirmation, and joint dataset/backbone replication. Multi-seed intervals use crossed case×seed resampling. The manuscript limits S−D to an inconclusive result and does not turn the uncertain external interval into a generalization claim.",
        "",
        "## Required Caveats",
        "",
        "- S−D is not confirmed despite a positive pooled point estimate.",
        "- Task09 changes dataset and backbone jointly, and its Extra Dmap interval crosses zero.",
        "- Surface Dice in the external block is evaluated at the prespecified extra spacings 4/5 mm, which are the only spacings used by Extra Smap.",
        "- Controlled voxel-grid stability does not establish robustness to heterogeneous clinical acquisition.",
        "- The old Task09 external study was negative and is retained as a boundary, not evidence for S.",
        "",
        "## Incomplete Handoff Blockers for Submission",
        "",
        "- author/venue/ethics/funding/code metadata",
        "",
        f"Failed checks: {failed if failed else 'none'}",
    ]
    (ROOT / "10_INTEGRITY/VALIDATION_REPORT.md").write_text("\n".join(report) + "\n")
    if failed:
        raise SystemExit("validation failed: " + ", ".join(failed))
    print(f"PASS: {len(checks)} validation checks")


if __name__ == "__main__":
    main()
