# Three-seed causal source replication

Development-screen evidence only; confirm_v2 remained locked.

| arm | Dnative | Grid-AUC | Worst Dpred | Worst Dmap | Source Dmap | Extra Dmap | Extra Smap |
|---|---:|---:|---:|---:|---:|---:|---:|
| random_k2 | 0.8802 | 0.6566 | 0.1824 | 0.1743 | 0.8186 | 0.3475 | 0.4904 |
| degrade_on_r1 | 0.8792 | 0.2001 | 0.0018 | 0.0019 | 0.4215 | 0.0078 | 0.0307 |
| label_supervised_random | 0.8801 | 0.6116 | 0.1134 | 0.1076 | 0.8078 | 0.2677 | 0.3974 |

## Primary contrasts

- random_k2 - degrade_on_r1 Extra Dmap: +0.3397, crossed 95% CI [+0.2905, +0.3884]; seed 17: +0.3211 (positive), seed 29: +0.3615 (positive), seed 41: +0.3364 (positive).
- random_k2 - label_supervised_random Extra Dmap: +0.0798, crossed 95% CI [+0.0676, +0.0919]; seed 17: +0.0773 (positive), seed 29: +0.0896 (positive), seed 41: +0.0725 (positive).

All seven case-level metrics and both contrasts are in the JSON outputs. The four newly trained checkpoints have complete spacing-by-class rows in `metrics_case_level.csv`; Random-K2 seeds 29/41 reuse the frozen case summaries.
