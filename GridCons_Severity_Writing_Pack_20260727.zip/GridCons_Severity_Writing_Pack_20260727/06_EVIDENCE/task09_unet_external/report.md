# Task09 Spleen + Plain 3D U-Net joint external replication

- Design: C versus frozen S, five outer folds, seeds 17/29/41, 41 unique outer-test cases.
- Extra Dmap S−C: `+0.01996`, crossed 95% CI `[−0.00189,+0.03885]`; seed means `+0.03319,+0.02012,+0.00658`.
- Native Dice S−C: `+0.01726`, 95% CI `[−0.00756,+0.03931]`.
- Worst Dmap S−C: `+0.00174`, 95% CI `[−0.02981,+0.02943]`.
- Extra Smap S−C: `+0.00919`, 95% CI `[−0.01552,+0.03024]`.

Interpretation: the primary direction is positive in all three seeds but its interval crosses zero. Because dataset and backbone change jointly, this result bounds rather than proves separate dataset or architecture invariance. Surface Dice is computed at 4/5 mm, the two spacings defining Extra Smap.
