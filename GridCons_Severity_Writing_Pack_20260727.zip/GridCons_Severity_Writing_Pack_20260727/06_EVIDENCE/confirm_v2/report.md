# Frozen confirm_v2 report

Decision: **PASS**

- S-C Extra Dmap: +0.03436, crossed 95% CI [+0.01013, +0.05824].
- S-D Extra Dmap: +0.00443, crossed 95% CI [-0.02495, +0.03387].
- S-C native Dice: +0.00012, crossed 95% CI [-0.00247, +0.00255]; noninferiority margin -0.005.

The locked 40-case split was evaluated once after the user explicitly authorized confirm_v2 access. No method selection or tuning used these results.
