# Severity-confounding control pilot report

Decision: **PREFER_SEVERITY_CONTROL**

| arm | Dnative | Grid-AUC | Worst Dpred | Worst Dmap | Source Dmap | Extra Dmap | Extra Smap | slope | GPU h | s/update | peak GiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| C | 0.8802 | 0.6566 | 0.1824 | 0.1743 | 0.8186 | 0.3475 | 0.4904 | -0.5696 | 1.8494 | 0.8877 | 3.191 |
| D | 0.8807 | 0.6671 | 0.1996 | 0.1911 | 0.8208 | 0.3667 | 0.5115 | -0.5514 | 1.8419 | 0.8841 | 3.191 |
| S | 0.8816 | 0.6857 | 0.2388 | 0.2283 | 0.8276 | 0.3970 | 0.5539 | -0.5189 | 1.5954 | 0.7658 | 3.133 |
| W | 0.8806 | 0.6757 | 0.2184 | 0.2081 | 0.8247 | 0.3783 | 0.5341 | -0.5373 | 1.6267 | 0.7808 | 3.133 |

## D−S / D−W Extra Dmap

- D−S: -0.03037; 80% CI [-0.05173, -0.00967]; 95% CI [-0.05648, +0.00530].
- D−W: -0.01167; 80% CI [-0.03070, +0.00638]; 95% CI [-0.03426, +0.02124].

## Required answers

1. D 的收益是否可由 severity 完全解释：是；severity controls 总体超过 D，D−S=-0.03037，D−W=-0.01167。
2. loss/spacing 排序不一致更新中的后续因果优势：未建立；本轮仅有描述性更新统计。
3. D 是否稳定超过 S：False；三 seed {"17": -0.05341191864903414, "29": -0.04499428879642078, "41": 0.0073063967757765}。
4. D 是否稳定超过 W：False；三 seed {"17": -0.03212283545455593, "29": -0.025039315404977835, "41": 0.02215409996761368}。
5. S/W 是否稳定超过 C：S 是（三 seed 全正）={'17': 0.07111153718551413, '29': 0.07033033866264458, '41': 0.00706790230542159}；W 否（seed41 为负）={'17': 0.04982245399103592, '29': 0.050375365271201636, '41': -0.007779800886415588}。
6. 三 seed 最稳定 aggregation：S（按冻结决策规则，不按单 seed 选择）。
7. 计算成本最低：S。
8. Dnative guardrail：PASS。
9. 最终冻结：S。
10. 仍支持：continuous native tensor-grid exposure is the principal supported factor; under this construction R1 posterior consistency outperformed candidate-grid label supervision; three-seed D over C Extra Dmap replication; severity-based selection/weighting empirically outperformed loss-adaptive soft-worst。
11. 已否决/不支持：Physical-Step independent benefit; GridREx/source-risk variance; fixed-grid degradation as the main explanation; conservative transport benefit; occupancy supervision benefit; gradient-conflict resolution; worst-domain optimization; causal update-level benefit in loss/spacing-order disagreement rows。
12. confirm_v2：未访问、未评估；denylist 命中 0。

## Mechanism

- seed 17: D severe fraction 0.8868; D/S agreement 0.8868; D/W Pearson 0.8647; Spearman 0.9290; MAD 0.2411.
- seed 29: D severe fraction 0.8924; D/S agreement 0.8924; D/W Pearson 0.8576; Spearman 0.9265; MAD 0.2436.
- seed 41: D severe fraction 0.8860; D/S agreement 0.8860; D/W Pearson 0.8585; Spearman 0.9242; MAD 0.2357.
