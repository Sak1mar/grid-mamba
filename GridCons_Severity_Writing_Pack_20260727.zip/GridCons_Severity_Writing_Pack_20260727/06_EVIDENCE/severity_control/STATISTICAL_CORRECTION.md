# Statistical correction after the frozen development decision

The original implementation resampled training seeds independently inside each sampled case. Because one trained seed produces predictions for every case, that estimator attenuated shared seed variability and produced intervals that were too narrow.

Before accessing `confirm_v2`, the implementation was corrected to independently resample cases and seeds once per bootstrap draw and average their crossed product. No model, checkpoint, case split, metric, point estimate, or selection rule changed. The correction widens uncertainty for seed-heterogeneous contrasts; in particular, the development 95% interval for S-D Extra Dmap now crosses zero. S remains the frozen selected arm because its preregistered development gate and S-C comparison remain positive.
