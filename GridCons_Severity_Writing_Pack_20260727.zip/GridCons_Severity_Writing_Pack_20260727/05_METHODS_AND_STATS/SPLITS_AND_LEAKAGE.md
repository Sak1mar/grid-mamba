# Splits, Leakage Controls, and Checkpointing

- Train: 80 cases.
- Validation: 20 cases.
- Development screen: 20 cases.
- Locked confirm_v2: 40 cases.
- All four groups were verified disjoint.
- confirm_v2 protection: SHA-256 denylist of case IDs; raw-ID scans of logs and outputs returned zero matches.
- Final status: confirm_v2 was accessed once after method freeze and evaluated over five seeds; it never selected methods or checkpoints.
- Model selection reads R1 validation foreground Dice only.
- Candidate-grid development metrics, Extra Dmap, and confirm_v2 never select checkpoints.

The old fixed-grid Task04 study has its own confirmation analysis. The continuous severity-selected method has a separate completed confirm_v2 record under `06_EVIDENCE/confirm_v2/`.
