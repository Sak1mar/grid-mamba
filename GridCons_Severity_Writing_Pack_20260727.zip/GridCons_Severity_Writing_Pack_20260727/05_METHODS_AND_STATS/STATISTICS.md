# Statistical Analysis

## Severity-control comparison

- Paired observation grid: 20 development cases × 3 seeds.
- Primary decision metric: Extra Dmap.
- Paired crossed bootstrap: independently sample cases and training seeds with replacement once per draw, then average their crossed product. A shared trained seed is never resampled independently inside each case.
- Draws: 10,000; RNG seed: 7331.
- 80% CI: preregistered screening gate.
- 95% CI: descriptive, not a replacement gate.
- Report pooled mean difference, median paired difference, positive case-seed fraction, and per-seed means.

The 60 case-seed cells are not 60 independent patients. Crossed resampling preserves case pairing and the fact that one trained seed generates predictions for every case. `06_EVIDENCE/severity_control/STATISTICAL_CORRECTION.md` records the correction from the original too-narrow nested-seed implementation.

## Continuous-grid source audit

The Native-random/Degrade-on-R1 and label-supervised/Random-K2 controls were first screened at seed 17, then independently completed for seeds 29 and 41. Final source contrasts use the same crossed case×seed bootstrap over 20 cases and three seeds.

## Confirmation and external replication

- Confirm: 40 paired held-out cases × five seeds; crossed 10,000-draw bootstrap; primary S−C Extra Dmap; native noninferiority margin `−0.005`.
- External: 41 Task09 cases, each appearing once as outer test across five folds, × three seeds; crossed case×seed bootstrap. Dataset and backbone change jointly, so the estimate is not a clean independent effect of either factor.

## Reporting rules

- Always provide the sign convention for a contrast.
- Do not infer p-values from confidence intervals.
- Do not call an 80% interval a conventional confirmatory interval.
- Report negative seed directions and failed secondary metrics.
- Confirmation analyses must follow a separately frozen protocol and cannot reuse these development gates for method changes.
