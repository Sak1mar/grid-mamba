# GridCons / Severity-Selected Native-Grid Consistency 写作母包

这是 2026-07-27 确认与外部复现完成后的投稿写作入口。

## 先记住结论

- 论文中心不再是新的 Mamba 模块，也不是 soft-worst。
- 当前最有证据支持的解释是：**真正改变 tensor depth、voxel lattice、pooling trajectory 和物理感受野轨迹的连续 native-grid exposure，是跨 spacing 稳定性的主要有效因素。**
- 最终冻结方法是 **S：severity-selected native-grid posterior consistency**。每次采样两个 `[1,3] mm` native grids，只对 requested spacing 更大的候选计算辅助一致性；完全相同 spacing 时退化为均值。
- 三种子 source audit 已复现：native-grid exposure 相对 fixed-tensor degradation 的 Extra Dmap 为 `+0.33970`，crossed 95% CI `[+0.29052,+0.38837]`；posterior consistency 相对 candidate-label supervision 为 `+0.07983`，95% CI `[+0.06756,+0.09187]`。
- 40-case `confirm_v2` 已按冻结方法一次性评估五 seeds。S−C Extra Dmap `+0.03436`，crossed 95% CI `[+0.01013,+0.05824]`；native Dice 非劣通过。S−D 未确认有差异。
- Task09 + Plain 3D U-Net 五折外部块方向一致：S−C Extra Dmap `+0.01996`，3/3 seeds 为正，但 95% CI `[-0.00189,+0.03885]`，只能写成方向性外部支持，不能写成独立显著泛化。

## Mac 上的阅读顺序

1. `01_POSITIONING/PAPER_BLUEPRINT_ZH.md`
2. `01_POSITIONING/CANONICAL_FACT_SHEET.md`
3. `01_POSITIONING/CLAIM_EVIDENCE_MATRIX.md`
4. `02_MANUSCRIPT/main_draft_en.md`
5. `03_TABLES/TABLE_INDEX.md`
6. `04_FIGURES/FIGURE_PLAN.md`
7. `05_METHODS_AND_STATS/`
8. `08_PENDING_CONFIRMATION/EXPERIMENT_LOCK.md`
9. `10_INTEGRITY/VALIDATION_REPORT.md`

## 证据优先级

发生冲突时按以下顺序处理：

1. `06_EVIDENCE/severity_control/method_freeze.json` 与 `decision.json`
2. `06_EVIDENCE/confirm_v2/decision.json`、`results.json`
3. `06_EVIDENCE/source_audit_three_seed/` 的 crossed bootstrap 与报告
4. `06_EVIDENCE/task09_unet_external/statistics.json`
5. `06_EVIDENCE/severity_control/metrics_summary.json`、`bootstrap_results.json`
6. 各负控制与 legacy evidence；`novelty_audit_original.md` 只用于检索线索

## 当前能完成到什么程度

实验主证据已经闭合，可以完成投稿摘要、主结果和限制。剩余人为元数据只有作者、单位、基金、伦理/数据使用声明、代码 URL 与目标会议模板。

## 不要做的事

- 不增加新 loss、模块、backbone 或 grid sampler。
- 不用开发集结果重开方法选择。
- 不把相关性写成因果证明。
- 不把 D 的效果解释为梯度冲突解决或 worst-domain optimization。
- 不把旧固定 R1/R2 的大增益归因于 consistency loss 单独产生。
- 不根据 confirm 或 Task09 结果改方法、换 seed、调阈值或回到开发集重选 arm。
