# Titles and Abstract Templates

## Recommended title

**What Drives Stability Across Voxel Grids? Native-Grid Exposure and Severity-Selected Consistency for 3D Medical Image Segmentation**

## Final scoped abstract

Volumetric segmentation can change when the same anatomy is rendered on another voxel lattice, because spacing alters tensor depth and feature discretization in addition to image appearance. On MSD Task04 Hippocampus, a three-seed controlled audit shows that continuous native-grid exposure improves mapped Dice at 4–5 mm over degradation restored to a fixed tensor by 0.3397 (crossed 95% confidence interval 0.2905–0.3884), while R1-posterior consistency exceeds candidate-grid label supervision by 0.0798 (0.0676–0.0919). We then compare mean, loss-adaptive soft-worst, hard severity selection, and soft severity weighting under shared initializations and grid schedules. Hard selection of the larger requested spacing is the strongest development rule and is frozen before confirmation. On 40 untouched cases across five seeds, severity selection improves Extra mapped Dice over mean aggregation by 0.0344 (0.0101–0.0582) while meeting a −0.005 native-Dice noninferiority margin; its difference from soft-worst is not confirmed. A five-fold Task09 Spleen replication with Plain 3D U-Net gives a positive S−C direction in all three seeds (+0.0200), although its 95% interval crosses zero (−0.0019–0.0388). These results support native-grid exposure and a simple severity rule for controlled voxel-grid stability, not heterogeneous clinical robustness.

## Removed template

All experimental cells are now filled; only author and venue metadata remain.
