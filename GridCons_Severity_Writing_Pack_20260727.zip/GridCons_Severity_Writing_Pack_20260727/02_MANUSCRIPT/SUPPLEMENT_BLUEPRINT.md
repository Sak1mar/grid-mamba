# Supplementary Material Blueprint

## S1. Dataset partition and protection

- Report 80/20/20/40 counts and disjointness verification.
- Explain confirm_v2 SHA-256 denylist without publishing the raw locked IDs before evaluation.
- Distinguish the old fixed-grid confirmation from the new confirm_v2 split.

## S2. Exact grid construction

- Raw-volume to endpoint-matched candidate affine.
- Requested versus actual spacing after integer tensor-depth rounding.
- Candidate-to-R1 probability mapping and renormalization.
- Frozen R1 non-background mean/std normalization.

## S3. Losses and aggregation controls

- Full formulas for C/D/S/W.
- Stop-gradient locations.
- Candidate-order invariance and exact-tie behavior.
- Statement that severity uses millimetres, not tensor depth.

## S4. Training parity and checkpointing

- Initialization SHA-256 by seed.
- Spacing-schedule SHA-256 by seed.
- Identical case order, affines, images, R1 branch, optimizer, lambda schedule, and validation times.
- Exact resume state and earliest-tie checkpoint rule.

## S5. Complete development results

- `../03_TABLES/tableS1_by_seed.csv`.
- Per-class rows can be regenerated from `../06_EVIDENCE/severity_control/metrics_spacing_level.csv`.
- Include all seven spacings and all requested metrics.

## S6. Hierarchical bootstrap

- Pseudocode: sample cases, then seeds within case, average paired differences.
- 10,000 draws, seed 7331.
- Full 80% and 95% interval table from `table4_key_contrasts.csv`.

## S7. Aggregation mechanism analysis

- `tableS2_mechanism.csv`.
- Effective spacing, auxiliary loss, gradient norm, spacing gap, disagreement gap.
- Close/large spacing gaps and loss/spacing order agreement/disagreement.
- Explicit statement: no later-performance causal link was established for mismatch updates.

## S8. Frozen negative controls

- Physical-Step.
- GridREx diagnostic.
- degradation control.
- conservative transport and occupancy supervision.
- gradient diagnostic.
- All stop decisions and their preregistered gates.

## S9. Legacy fixed R1/R2 causal background

- Original five-seed factorial Mamba/U-Net table.
- equal-exposure DualGrid-Sup control.
- negative Task09 heterogeneous-spacing result.
- Explain that these motivate the continuous-grid study but are not confirmation of S.

## S10. Reproducibility and integrity

- Source commit and source hashes.
- unit/smoke test results.
- command ledger and environment.
- final writing-pack SHA-256 manifest.

## S11. Post-freeze confirmation and external boundary

Include the complete confirm_v2 five-seed table, per-seed S−C/S−D directions, native noninferiority, and the Task09/Plain 3D U-Net five-fold table. State explicitly that S−D and the external primary interval cross zero and that the external block changes dataset and backbone jointly.
