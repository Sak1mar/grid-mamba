# What Drives Stability Across Voxel Grids? Native-Grid Exposure and Severity-Selected Consistency for 3D Medical Image Segmentation

**Authors:** [TO BE FILLED]  
**Affiliations:** [TO BE FILLED]  
**Venue:** [TO BE FILLED]

## Abstract

Volumetric segmentation can change when the same anatomy is rendered on another voxel lattice, because spacing alters tensor depth and feature discretization in addition to image appearance. On MSD Task04 Hippocampus, a three-seed controlled audit shows that continuous native-grid exposure improves mapped Dice at 4–5 mm over degradation restored to a fixed tensor by 0.3397 (crossed 95% confidence interval 0.2905–0.3884), while R1-posterior consistency exceeds candidate-grid label supervision by 0.0798 (0.0676–0.0919). Hard selection of the larger requested spacing is frozen before confirmation. On 40 untouched cases across five seeds, it improves Extra mapped Dice over mean aggregation by 0.0344 (0.0101–0.0582) while meeting a −0.005 native-Dice noninferiority margin; its difference from soft-worst is not confirmed. A five-fold Task09 Spleen replication with Plain 3D U-Net gives a positive S−C direction in all three seeds (+0.0200), although its 95% interval crosses zero (−0.0019–0.0388). These results support native-grid exposure and a simple severity rule for controlled voxel-grid stability, not heterogeneous clinical robustness.

**Keywords:** medical image segmentation; voxel spacing; resampling stability; consistency regularization; native-grid exposure

## 1. Introduction

Three-dimensional medical images are sampled on voxel lattices whose through-plane spacing can vary across reconstruction protocols, scanners, and preprocessing pipelines. A segmentation network therefore sees more than a visually blurred or sharpened version of the same anatomy when spacing changes. The number and physical extent of slices change, encoder pooling follows a different discrete trajectory, and intermediate feature maps represent different physical receptive fields. Yet segmentation studies typically report accuracy on one preprocessing grid, leaving the stability of a prediction under alternative physically aligned grids largely implicit.

This omission matters even in a controlled setting where anatomy, labels, physical bounds, and in-plane spacing are held fixed. A model may achieve high native-grid Dice while producing a substantially different mask after the same volume is rendered on a coarser lattice and mapped back to the reference frame. We refer to this controlled property as voxel-grid stability. It is narrower than scanner or clinical domain robustness: it isolates the consequences of discrete grid construction for the same underlying case.

Our earlier fixed-grid experiments showed that paired R1/R2 training can strongly reduce this instability. However, an equal-exposure control reproduced most of the matched-R2 gain with supervised exposure to both grids. The large gain could therefore not be attributed to the prediction-consistency objective alone. That result changes the central question from whether a particular consistency loss works to which component of paired-grid exposure drives extrapolation beyond the fixed training grid.

We answer this question through a sequence of preregistered controls. First, we compare direct forward passes on randomly sampled native tensor grids with matched degradation that is restored to the fixed R1 tensor before the network. This separates changes in image content from changes in tensor depth, voxel lattice, pooling, and feature-map discretization. Second, we compare R1-posterior consistency with ordinary candidate-grid label supervision under the same native random grids. Third, after observing a reproducible gain from loss-adaptive soft-worst aggregation, we test the remaining confound directly: whether soft-worst is useful because it follows prediction disagreement or merely because high disagreement usually occurs at a more severe spacing.

The resulting method is deliberately simple. At each update we sample two native through-plane grids from a frozen log-uniform distribution over 1–3 mm. Both predictions are aligned to the R1 reference frame. Instead of averaging their posterior disagreements or weighting them by current disagreement, we select the candidate with the larger requested spacing. This severity-selected auxiliary objective contains no spacing embedding, learned resampler, teacher model, uncertainty mask, gradient surgery, or distributionally robust optimizer.

Our evidence comprises a three-seed Task04 development audit, a 40-case five-seed frozen confirmation, and a five-fold Task09/3D U-Net joint external replication. Native-grid exposure and posterior consistency give large, seed-consistent source-audit effects. Severity selection confirms an advantage over mean aggregation without native-Dice loss. It does not confirm an advantage over soft-worst, and the joint external estimate is positive but uncertain.

The contributions are:

1. A continuous, physically aligned evaluation protocol that measures prediction agreement, label-referenced mapped accuracy, and surface accuracy across 1–5 mm through-plane spacings.
2. Controlled evidence separating native tensor-grid exposure from fixed-tensor image degradation and comparing posterior consistency with candidate-grid label supervision.
3. A preregistered aggregation audit selecting a simple severity rule, followed by an untouched 40-case five-seed confirmation against mean aggregation.
4. Explicit negative evidence that rules out physical-step recurrence, source-risk variance, conservative transport, occupancy supervision, and gradient-conflict explanations within the tested protocols.

## 2. Related Work

### 2.1 Voxel spacing and resampling in medical segmentation

Most segmentation pipelines standardize voxel spacing before training, treating resampling as preprocessing rather than as an experimental factor. Recent work has examined spacing-aware resampling, semantic reconstruction, and anti-aliased downsampling. These approaches primarily improve the resampler or internal sampling operator. Our question is different: we keep the resampling construction fixed and ask how a segmentation model should be exposed to the family of native tensor grids induced by the same anatomy. Consispace and CROWn are the closest included references for semantic resampling and sampling-aware feature processing, respectively; neither supplies the controlled aggregation comparison studied here.

### 2.2 Transformation and prediction consistency

Transformation-consistent learning aligns predictions from transformed inputs and penalizes disagreement. The general idea predates this study and is not claimed as novel. Our use of an R1 posterior teacher is a direct output-space consistency objective. The contribution is the controlled separation of exposure, supervision target, and aggregation under irreversible changes in voxel lattice, together with a continuous-spacing evaluation panel.

### 2.3 State-space and convolutional backbones

Mamba-style state-space models provide a compact 3D backbone in our development study, but no Mamba-specific mechanism is claimed. Physical spacing inserted into the recurrent step did not improve the preregistered robustness metrics, and the final method does not alter the backbone. The frozen replication plan includes Dynamic Mamba, Static Mamba, and 3D U-Net to determine how far the result extends beyond the development backbone.

## 3. Problem Formulation

Let an anatomical volume be represented on a reference grid R1 with 1 mm through-plane spacing and on alternative endpoint-matched grids with nominal spacing `s`. The alternative grid changes tensor depth and affine geometry while preserving the physical field of view. A candidate prediction is mapped back to R1 using the known affine transformation before comparison.

For each case and spacing, `Dpred` is the foreground Dice between the mapped candidate-grid prediction and the R1 prediction. `Dmap` is the foreground Dice between the mapped candidate prediction and the R1 reference label. `Smap@2mm` is the corresponding surface Dice with a 2 mm tolerance. `Dnative` is R1 foreground Dice. We summarize the spacing curve by its trapezoidal area (`Grid-AUC`), its minimum prediction and mapped Dice, the mean mapped Dice over the source range 1.5–3 mm, and `Extra Dmap`/`Extra Smap`, defined as the average at 4 and 5 mm.

This protocol measures controlled resampling stability. It does not model all changes in image acquisition, reconstruction kernels, motion, pathology prevalence, or scanner hardware.

## 4. Severity-Selected Native-Grid Consistency

### 4.1 Native supervision and posterior teacher

For an R1 image `x0` and label `y0`, the network produces logits `f_theta(x0)`. The native loss is the equal-weight sum of foreground Dice loss and cross entropy. The foreground posterior from R1 is detached to form the teacher:

`q = stopgrad(softmax(f_theta(x0))_foreground)`.

For each of two native candidate grids `g_k`, we resample the raw image directly to its endpoint-matched tensor and affine, run the same network, map the softmax probabilities back to R1, and compute foreground soft-Dice disagreement `e_k` with `q`.

### 4.2 Aggregation controls

Mean aggregation C uses `(e1+e2)/2`. Loss-adaptive D uses stop-gradient weights `softmax(5[e1,e2])`. Soft severity weighting W replaces the errors in this softmax with normalized log-spacing severity. The selected method S defines

`a_k = log(s_k / 1 mm) / log(3)`

and uses the error of the candidate with larger `a_k`; exact spacing ties use the mean. Selection depends only on requested spacing in millimetres. It cannot inspect loss, labels, gradient norm, confidence, or tensor depth.

The total objective is

`L = L_native + lambda(t) L_aux`,

where `lambda(t)` increases linearly to 0.1 over 500 updates. S and the controls share the backbone, initialization, case order, candidate images, affines, spacing pairs, optimizer, validation schedule, and checkpoint rule.

## 5. Controlled Audit Design

### 5.1 Data isolation

The continuous-grid development study uses 80 training, 20 validation, and 20 development-screen cases. A disjoint 40-case confirm_v2 split was protected by a SHA-256 denylist until S and the analysis rules were frozen. Checkpoint selection reads only R1 validation foreground Dice. Confirm_v2 was evaluated once and never used for checkpoint or method selection.

### 5.2 Source-of-gain controls

The native-random arm forwards the network on tensors constructed at each sampled native spacing. Degrade-on-R1 uses the same spacing draws to degrade the raw image but restores it to the R1 tensor before normalization and inference. Their difference isolates the contribution of changing native tensor geometry beyond fixed-grid degradation under this construction.

The label-supervised random arm uses ordinary segmentation loss on nearest-neighbour-resampled labels at both candidate grids. Random-K2 instead aligns both candidate posteriors to the detached R1 posterior. This is a construction-specific comparison between supervision targets, not a universal comparison between consistency and ground truth.

### 5.3 Training and evaluation

All development models use 2,500 full-volume updates, batch size 1, AdamW with learning rate `3e-4` and weight decay `1e-5`, bfloat16, and no augmentation. Validation occurs every 250 updates; ties keep the earliest checkpoint. Evaluation uses nominal through-plane spacings 1, 1.5, 2, 2.5, 3, 4, and 5 mm.

### 5.4 Statistical analysis

All multi-seed contrasts use a paired crossed bootstrap: cases and training seeds are independently resampled once per draw and their crossed product is averaged. This preserves the shared effect of one trained seed across all cases. The development gate retains its preregistered 80% interval; final reporting uses 95% intervals. Source controls use 20 cases × three seeds, confirmation uses 40 cases × five seeds, and external replication uses 41 outer-test cases × three seeds.

## 6. Development Results

### 6.1 Native tensor-grid exposure dominates fixed-tensor degradation

Across three seeds, Random-K2 reaches Extra Dmap 0.3475, compared with 0.0078 for Degrade-on-R1. The paired difference is +0.3397 with a crossed 95% confidence interval of +0.2905 to +0.3884; every seed direction and all 60 case-seed cells are positive. Thus, the tested fixed-tensor degradation control does not reproduce the benefit of direct native-grid forwards. The experiment does not separately identify which coupled property of native tensor geometry is dominant.

### 6.2 Posterior consistency is stronger than candidate-grid label supervision under the tested construction

Random-K2 exceeds label-supervised random by 0.0798 Extra Dmap (crossed 95% CI 0.0676–0.0919); all three seed directions and all 60 case-seed cells are positive. This remains limited to nearest-neighbour candidate labels, the current loss, and the current training protocol.

### 6.3 Development selection favors the hard severity rule

Across three seeds, pooled Extra Dmap is 0.3475 for C, 0.3667 for D, 0.3970 for S, and 0.3783 for W. Under the corrected crossed bootstrap, S exceeds C by 0.0495 (80% CI 0.0261–0.0731; 95% CI 0.0090–0.0781) and is positive in all three seeds. S exceeds D by 0.0304 (80% CI 0.0093–0.0515; 95% CI −0.0052–0.0565); seeds 17 and 29 are positive, whereas seed 41 is −0.0073. W−D is +0.0117, but its 80% interval crosses zero (−0.0067–0.0308). The preregistered development decision remains `PREFER_SEVERITY_CONTROL`, with S selected because it passes the screening gate, is positive against C in every seed, and is the simplest severity rule.

S also raises worst-grid mapped Dice from 0.1743 for C and 0.1911 for D to 0.2283. Native Dice remains comparable: 0.8802 for C, 0.8807 for D, and 0.8816 for S. On the observed hardware, S has the lowest training cost at 0.7658 seconds per update, compared with 0.8877 for C and 0.8841 for D.

### 6.4 Soft-worst largely tracks spacing severity, not a validated gradient mechanism

D assigns the larger weight to the more severe candidate in 88.60%–89.24% of updates. Its weights correlate strongly with W across seeds (Pearson 0.858–0.865; Spearman 0.924–0.929), although their mean absolute difference remains 0.236–0.244. Separate gradient diagnostics show unstable candidate conflict rates and no joint native/worst-grid advantage from projection. We therefore interpret D as an empirical severity-emphasizing rule in this setting. The update-level subset in which loss and spacing rankings disagree does not establish a subsequent causal benefit for loss-adaptive selection.

## 7. Confirmation and Replication Results

### 7.1 Untouched Task04 confirmation

The locked 40-case confirm_v2 set was evaluated once over seeds 17, 29, 41, 53, and 67. S improves Extra Dmap over C by 0.03436 (crossed 95% CI 0.01013–0.05824); four of five seed means are positive. Native Dice changes by +0.00012 (−0.00247–0.00255), whose lower bound exceeds the prespecified −0.005 noninferiority margin. The S−D Extra Dmap difference is only +0.00443 (−0.02495–0.03387), so confirmation supports S over mean aggregation but not a distinct advantage over loss-adaptive soft-worst.

### 7.2 Joint dataset-and-backbone replication

We apply the frozen C/S construction to Task09 Spleen using a 1.40M-parameter Plain 3D U-Net, five outer folds, and seeds 17, 29, and 41. S−C Extra Dmap is +0.01996; every seed mean is positive (+0.03319, +0.02012, +0.00658), but the crossed 95% interval includes zero (−0.00189–0.03885). Native Dice changes by +0.01726 (−0.00756–0.03931). Worst-grid Dmap (+0.00174) and Extra Smap (+0.00919) are also inconclusive. This joint replication is directionally compatible with Task04 but does not establish separate backbone or dataset invariance.

## 8. Discussion

The experiments identify exposure as the first-order factor in this controlled problem. Degrading an image while preserving the R1 tensor fails to approximate the benefit of forwarding the same anatomy on genuinely different native lattices. This distinction matters because a 3D network is discretization-dependent at every stage: changing depth can alter rounding, pooling, feature-map support, and the mapping between index-space and millimetres even when the physical bounds are matched.

The aggregation audit also changes the interpretation of soft-worst. Its three-seed improvement over mean aggregation is real in development, but high-disagreement candidates are usually the coarser candidates. Severity selection was the simplest strong development rule and confirmed over mean aggregation. Because confirm S−D crosses zero, the final claim is parsimony and auditability, not confirmed superiority over adaptive weighting.

Severity selection intentionally uses a known acquisition variable rather than learning a new representation of spacing. This simplicity limits the mechanism claim but improves auditability. It makes the intervention invariant to candidate order, deterministic for a frozen schedule, and independent of labels and model state. It also avoids inferring a worst domain from noisy per-update loss.

Several negative experiments strengthen the boundary of the result. Multiplying physical spacing into the recurrent step did not add independent value. Source-risk variance was negatively associated with extrapolation risk. Conservative probability transport and occupancy supervision were mathematically well behaved but worsened the preregistered mapped metrics. Gradient projection did not provide stable joint improvements. These failures prevent a broader optimization or physical-dynamics story from being attached to the final method.

## 9. Limitations

S was selected on a 20-case development screen, but its S−C effect is independently confirmed on 40 held-out cases over five seeds. The Task09/3D U-Net block changes dataset and backbone jointly and its confidence interval crosses zero, so it cannot identify separate backbone or dataset invariance.

The controlled grids change through-plane spacing while matching physical bounds; they do not reproduce every property of clinical acquisition or reconstruction. The earlier heterogeneous Task09 study of the fixed-grid method was negative, so no cross-dataset robustness claim is justified. Candidate label supervision uses nearest-neighbour-resampled labels and one fixed segmentation objective, limiting the scope of the posterior-versus-label comparison. Finally, S identifies severity by spacing magnitude, not by anatomy-dependent information loss, and absolute performance at 5 mm remains low.

## 10. Conclusion

Across a three-seed controlled source audit and an untouched five-seed confirmation, direct native-grid exposure is the principal supported source of resampling stability, and selecting the more severe candidate improves over mean aggregation without native-accuracy loss. The method is not confirmed superior to soft-worst, and a Task09/3D U-Net replication is positive but uncertain. We therefore support a simple severity rule for controlled voxel-grid stability while rejecting broader claims about gradient conflict, worst-domain optimization, Mamba-specific dynamics, or heterogeneous clinical robustness.

## References

See `../07_RELATED_WORK/references_verified.bib` and `REFERENCE_MAP.md`. Bibliographic fields marked as preprints should be updated only from an official venue record.
