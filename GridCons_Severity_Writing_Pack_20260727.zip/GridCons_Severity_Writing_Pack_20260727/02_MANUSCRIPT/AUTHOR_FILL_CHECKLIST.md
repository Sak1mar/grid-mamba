# Author-Fill Checklist

- [ ] Authors, order, affiliations, correspondence
- [ ] Target venue and exact page/template constraints
- [ ] Ethics/data-use statement appropriate for public MSD data
- [ ] Funding and conflicts of interest
- [ ] Code/repository URL and anonymization plan
- [x] confirm_v2 results and integrity receipt
- [x] joint dataset/backbone replication result
- [x] second-dataset result, including uncertainty
- [x] final abstract numbers synchronized with tables
- [ ] bibliography verified against official records
- [ ] figure font sizes checked in the venue two-column layout
- [ ] author/affiliation/venue `[TO BE FILLED]` tokens removed
- [ ] no forbidden mechanism language introduced during polishing
