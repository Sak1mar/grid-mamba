# Figure Plan and Chart Map

## Main figures available now

### Figure 1 — Protocol and frozen method

- File: `figure1_protocol.svg`
- Question: What changes between R1 supervision, the two native candidates, and severity-selected aggregation?
- Claim: S changes only aggregation; all candidate tensors, affines, schedules and model parameters are shared.
- Caption: “Severity-selected native-grid posterior consistency. The supervised R1 branch supplies a detached foreground posterior. Two endpoint-matched native grids are sampled from LogUniform(1,3 mm), predicted by the same network, and mapped to R1. S applies the auxiliary disagreement only to the candidate with larger requested spacing; exact ties use the mean.”

### Figure 2 — Continuous spacing curves

- File: `figure2_dmap_spacing.svg`
- Source: `source_data/spacing_curve.csv`
- Form: multi-series line chart, seven ordered spacings, four aggregations.
- Claim: S has the strongest pooled mapped-Dice curve, especially outside the 1–3 mm training range.
- Caveat: development screen, pooled over 20 cases × 3 seeds; 4/5 mm are extrapolation points.

### Figure 3 — Aggregation summary

- File: `figure3_aggregation_summary.svg`
- Source: `source_data/aggregation_summary.csv`
- Form: three aligned bar panels for Extra Dmap, Worst Dmap, and Dnative.
- Claim: S improves extra/worst mapped accuracy without an observed native trade-off.
- Caveat: do not visually magnify Dnative; its panel uses a labeled focused scale and must retain exact labels.

### Figure 4 — Seed stability

- File: `figure4_seed_stability.svg`
- Source: `source_data/by_seed.csv`
- Form: dot plot with each seed explicitly shown.
- Claim: S−C is positive in all three seeds; S−D is positive in two and slightly negative in seed 41.

## Final result presentation

Confirmation and external replication are reported as Tables 5–6 rather than additional figures; their exact estimates and intervals are clearer in table form. Optional qualitative cases are unnecessary for the scoped claim.

## Visual QA policy

- SVG is the editable master; convert to PDF only after choosing the venue template.
- All quantitative figures include exact source CSVs.
- Curves use both color and marker/line-style differences.
- No 3D effects, dual axes, or unlabeled truncated scales.
- Development and confirmation figures must never be merged without explicit split labels.
