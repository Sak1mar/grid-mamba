# GridCons Figure 1 web-upload export provenance

## Case and frozen selection

- Anonymous case ID: `hippocampus_104`
- Split: frozen Task04 40-case `confirm_test`
- Backbone: Dynamic Mamba
- Display seed: `17`
- Case rule: mean Dynamic Mamba `R2 prediction_consistency_dice` over two foreground classes × five frozen seeds, ascending sort, closest to the conventional numeric median.
- Tie rule: the two central cases are equidistant from the numeric median; choose the lower mean, then case ID. Central pair: `hippocampus_104` (0.43660489255471202) and `hippocampus_394` (0.43957627937102906).
- Numeric median: `0.43809058596287054`; selected case mean: `0.43660489255471202`.
- GridCons improvement was not used for case or slice selection.

## Slice, geometry, crop, and window

- Axial slice index: `15` (zero-based R1 D index); physical RAS z coordinate: `16.000000 mm`.
- Slice rule: unique maximum R1 foreground-label area; area `326` voxels.
- R1 spacing D×H×W: `[1.0, 1.0, 1.0]` mm.
- R2 spacing D×H×W: `[2.0, 1.0, 1.0]` mm.
- Crop indices on R1 `[Y0:Y1, X0:X1)`: `[13:48, 0:35)`; fixed 5 mm label-derived margin, square-clamped to the shared FoV.
- Crop voxel-center physical bounds XYZ: `[1.0, 14.0, 16.0]` to `[35.0, 48.0, 16.0]` mm.
- Intensity window for every medical panel: R1 unpadded nonzero P1–P99 = `[-1.9459309577941895, 1.557874321937561]` in cached R1 z-score units. The same numeric window is applied to mapped R2.
- Display scaling: deterministic bilinear grayscale enlargement; label/prediction maps use nearest-neighbor display scaling.

## Predictions and metric cross-validation

| Method | Frozen CSV anterior | Frozen CSV posterior | Recomputed anterior | Recomputed posterior | Case mean |
|---|---:|---:|---:|---:|---:|
| Dynamic Mamba | 0.50391236306729259 | 0.56223052601322221 | 0.50391236306729259 | 0.56223052601322221 | 0.53307144454025734 |
| Dynamic Mamba + GridCons | 0.82811176968670619 | 0.85630026809651472 | 0.82811176968670619 | 0.85630026809651472 | 0.84220601889161051 |

- Cross-validation tolerance: absolute `1e-12`; result: **PASS** for both foreground classes and both methods.
- R1 prediction: direct three-class softmax argmax on the unpadded R1 grid.
- Aligned R2 prediction: native R2 three-class softmax probabilities mapped channel-wise to R1 physical space with NIfTI affine order-1 interpolation, clipped to [0,1], renormalized across channels, then argmax. This is the frozen evaluation implementation.
- R2 image in Panel B: affine physical mapping to the R1 grid with order-1 interpolation.
- Disagreement in Panels C/D: exact voxelwise multiclass inequality `R1 argmax != aligned R2 argmax`; the same definition and vermillion alpha are used in both panels. No dilation, smoothing, connected-component filtering, or enlargement is applied to disagreement.
- Contours: exact class-mask boundaries rendered as visual strokes; R1 blue solid, baseline aligned R2 orange dashed, GridCons aligned R2 bluish-green dashed.

## Checkpoints and inference

- Baseline checkpoint: `/home/yanjingjia/metric_mamba_gate/outputs/checkpoints/t1_seed17.pt`; SHA-256 `b0b8d30d666b7aa3d6443355d75b0176461eb10b092bacf1a738e28bcf086826`; parameterization `content_delta`; seed `17`.
- GridCons checkpoint: `/home/yanjingjia/grid_stable_mamba_probe/outputs/paired_full/checkpoints/gridcons_seed17.pt`; SHA-256 `63aaa2643b893099653532fa743fdeadaa62712386199847ccb6fea486084bc1`; parameterization `separated_physical_delta`; seed `17`; selected update `2250`.
- Checkpoint hashes match the frozen protocol/training record before loading.
- Device: `NVIDIA PG506-230`; PyTorch `2.2.2+cu121`; CUDA build `12.1`; autocast `bfloat16`; four forward passes took `3.716598` seconds wall time.
- No training, optimization, augmentation, or checkpoint modification was performed.

## Source and prediction SHA-256

| Artifact | Path | SHA-256 |
|---|---|---|
| raw image NIfTI | `/home/yanjingjia/data/Task04_Hippocampus/imagesTr/hippocampus_104.nii.gz` | `903e8d996687dc8b96685a00e7d2604df669c982c15b34b950fac490ee28133e` |
| raw label NIfTI | `/home/yanjingjia/data/Task04_Hippocampus/labelsTr/hippocampus_104.nii.gz` | `34b761d10da73c1493a7bec67c23158d16a6e54e54b3d6da4da61227f56139c6` |
| R1 image cache | `/home/yanjingjia/metric_mamba_gate/cache/hippocampus_104/R1_image.npy` | `8e15c970d13cfcfcc54ce8f9c09d5597c72625abe35ce98afdc33d76a9b0097c` |
| R2 image cache | `/home/yanjingjia/metric_mamba_gate/cache/hippocampus_104/R2_image.npy` | `f0ec171fea63fa9053328a5ca45f9ac46199a45d7ef0cecc94704a8b2b731c6a` |
| R1 label cache | `/home/yanjingjia/metric_mamba_gate/cache/hippocampus_104/R1_label.npy` | `dbd430a31ee7c4e8a3acf58324dbce54816799bac3de202cc5fa660ba9e1675d` |
| R2 label cache | `/home/yanjingjia/metric_mamba_gate/cache/hippocampus_104/R2_label.npy` | `f3576639d3f4b0c06074172489c4d9f440ebd91500ba54145daf46d32ab3ae4e` |
| frozen metrics | `/home/yanjingjia/grid_stable_mamba_probe/outputs/paired_full/metrics.csv` | `067d3e94b87ebfd7febe21d208a22eb15d1444acc7ecc4b1e7cba464f5533368` |
| confirm manifest | `/home/yanjingjia/grid_stable_mamba_probe/outputs/paired_full/confirm_manifest.json` | `ae909321483b277a216011d73c1cdc730d809d795cc656af4d3a2a0a4a891d96` |
| baseline checkpoint | `/home/yanjingjia/metric_mamba_gate/outputs/checkpoints/t1_seed17.pt` | `b0b8d30d666b7aa3d6443355d75b0176461eb10b092bacf1a738e28bcf086826` |
| GridCons checkpoint | `/home/yanjingjia/grid_stable_mamba_probe/outputs/paired_full/checkpoints/gridcons_seed17.pt` | `63aaa2643b893099653532fa743fdeadaa62712386199847ccb6fea486084bc1` |
| saved predictions | `/home/yanjingjia/GridCons_Figure1_WebUpload/predictions_seed17.npz` | `0747896fa13208df366281358849dd31cec0e8889c3da1ee4828d51317bd5bba` |

## Rendered artifact SHA-256

| Artifact | SHA-256 |
|---|---|
| panel_A_R1.png | `14cfcf7d7310947d0b8505e1c14b0ce4ef60b00338705dd21a777b8196f2effa` |
| panel_B_R2.png | `2a9cccf4c7cca17fbea637886b01d3b3e2d40f3930d49d24e647f6d03c59126d` |
| panel_C_baseline_drift.png | `b43755ef801529dbdf341c6f5a0f8c1c7e35616e7876a9387ba207be72d2583b` |
| panel_D_gridcons.png | `c79ab111a3ee9138720fb539afa16bd9476ad48acc24eca3db71f13d8d0a706f` |
| figure1_contact_sheet.png | `1ca0d342b4ea0e0c6fc88ee6c24c2f2d7750e5af174b6def351eaf6c909a1ff5` |
| method_strip.svg | `28731d1b221b7745334f798599493f4e7d1c44c0f5bc5b37a1b10ddc899f9ad8` |

## Integrity declarations

- Generative medical pixels: `false`.
- Labels or predictions edited: `false`.
- DualGrid-Sup results read or used: `false`.
- Patient identity displayed: `false`.
