# GridCons dataset PNG visualizations

This package contains PNG-only visualization material for all 40 confirm-v2 test cases at 4 mm and 5 mm, using seed 17.

## What is included

- `00_CONTACT_SHEETS/`: one boundary sheet and two filled-mask sheets per case.
- `01_INPUT/`: native degraded input and R1-restored input.
- `02_GT/`: ground-truth boundary, colored mask, and filled MRI overlay.
- `03_RESTORE/`, `04_C/`, `05_D/`, `06_GRIDCONS_S/`: the same three visualization types for each trained method.
- `07_TRAINING_BEFORE/`: prediction before method-specific training.
- `08_CASE_GROUPS/`: all-case metric lists plus duplicated sheets for failure/negative cases.
- `09_FIG1_PNG/`: existing Fig. 1 PNG panels and contact sheet.

Each spacing folder is organized by method, then visualization type, so all 40 cases can be browsed or assembled into paper panels directly.

## Color and panel conventions

- Boundary images: ground truth is blue (`#0072B2`); prediction is orange (`#D55E00`).
- Colored masks: class 1 is sky blue (`#56B4E9`); class 2 is orange (`#E69F00`); background is black.
- Boundary contact-sheet order: `Input | GT | Restore | C | D | GridCons S`.
- Mask/overlay contact-sheet order: `GT | Restore | C | D | GridCons S`.

The PNGs are rendered from the verified raw NPZ/NIfTI export; no predictions or metric values are invented. Contact sheets are for browsing, while individual method PNGs are the easiest material for paper composition.
