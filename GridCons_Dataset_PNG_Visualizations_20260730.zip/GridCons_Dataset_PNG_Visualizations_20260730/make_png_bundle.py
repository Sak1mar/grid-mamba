#!/usr/bin/env python3
"""Render the verified GridCons raw export as a PNG-only dataset package."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import shutil
from pathlib import Path

import numpy as np


SOURCES = {
    "02_GT": None,
    "03_RESTORE": ("trained", "Degrade"),
    "04_C": ("trained", "C"),
    "05_D": ("trained", "D"),
    "06_GRIDCONS_S": ("trained", "S"),
    "07_TRAINING_BEFORE": ("pretraining", "PretrainingShared"),
}
SPACINGS = ("4p0mm", "5p0mm")
CLASS_COLORS = np.asarray(((0, 0, 0), (86, 180, 233), (230, 159, 0)), dtype=np.uint8)


def load_helpers(source_root: Path):
    path = source_root / "export_raw_materials.py"
    spec = importlib.util.spec_from_file_location("gridcons_raw_export", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.panel, module.write_png


def enlarge(image: np.ndarray) -> np.ndarray:
    return np.repeat(np.repeat(image, 4, axis=0), 4, axis=1)


def colored_mask(mask: np.ndarray) -> np.ndarray:
    mask = np.asarray(mask, dtype=np.uint8)
    if not set(np.unique(mask)).issubset({0, 1, 2}):
        raise ValueError("mask labels must be 0/1/2")
    return CLASS_COLORS[mask]


def filled_overlay(background: np.ndarray, mask: np.ndarray, panel) -> np.ndarray:
    result = panel(background).astype(np.float32)
    colors = colored_mask(mask).astype(np.float32)
    foreground = mask != 0
    result[foreground] = 0.58 * result[foreground] + 0.42 * colors[foreground]
    return np.clip(result, 0, 255).astype(np.uint8)


def stack(images: list[np.ndarray]) -> np.ndarray:
    gutter = np.full((images[0].shape[0], 4, 3), 255, dtype=np.uint8)
    parts = []
    for index, image in enumerate(images):
        if index:
            parts.append(gutter)
        parts.append(image)
    return np.concatenate(parts, axis=1)


def copy_file(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def prediction_mask(source_root: Path, state: str, method: str, spacing: str, case_id: str) -> np.ndarray:
    path = source_root / "02_CONFIRM_V2_ALL_RAW/predictions" / state / method / "seed_17" / spacing / case_id / "raw_prediction.npz"
    with np.load(path) as data:
        return data["mask_r1"].copy()


def render(source_root: Path, output_root: Path) -> None:
    panel, write_png = load_helpers(source_root)
    case_root = source_root / "02_CONFIRM_V2_ALL_RAW/cases"
    cases = sorted(path.name for path in case_root.glob("hippocampus_*") if path.is_dir())
    if len(cases) != 40:
        raise RuntimeError(f"expected 40 cases, found {len(cases)}")

    manifest = []
    for spacing in SPACINGS:
        for case_id in cases:
            with np.load(case_root / case_id / "r1_reference/input_and_gt_r1.npz") as reference:
                gt = reference["ground_truth"].copy()
            z = int(np.argmax((gt != 0).sum(axis=(1, 2))))
            input_path = source_root / "02_CONFIRM_V2_ALL_RAW/inputs_and_gt" / spacing / case_id / "raw_input_and_gt.npz"
            with np.load(input_path) as inputs:
                native = inputs["image_native"].copy()
                restored = inputs["image_restored_r1"].copy()
            native_z = int(np.clip(round((z + 0.5) * native.shape[0] / gt.shape[0] - 0.5), 0, native.shape[0] - 1))
            background = restored[z]

            input_dir = output_root / spacing / "01_INPUT"
            write_png(input_dir / "native_degraded" / f"{case_id}.png", enlarge(panel(native[native_z])))
            write_png(input_dir / "restored_R1" / f"{case_id}.png", enlarge(panel(background)))

            masks = {"02_GT": gt}
            for label, source in SOURCES.items():
                if source is not None:
                    masks[label] = prediction_mask(source_root, source[0], source[1], spacing, case_id)

            boundary_panels = [panel(background), panel(background, gt[z] != 0)]
            mask_panels = []
            overlay_panels = []
            for label, volume in masks.items():
                mask = volume[z]
                prediction = None if label == "02_GT" else mask != 0
                boundary = panel(background, gt[z] != 0, prediction)
                mask_rgb = colored_mask(mask)
                overlay = filled_overlay(background, mask, panel)
                method_dir = output_root / spacing / label
                write_png(method_dir / "boundary" / f"{case_id}.png", enlarge(boundary))
                write_png(method_dir / "mask_colored" / f"{case_id}.png", enlarge(mask_rgb))
                write_png(method_dir / "mask_on_MRI" / f"{case_id}.png", enlarge(overlay))
                if label in {"03_RESTORE", "04_C", "05_D", "06_GRIDCONS_S"}:
                    boundary_panels.append(boundary)
                if label != "07_TRAINING_BEFORE":
                    mask_panels.append(mask_rgb)
                    overlay_panels.append(overlay)

            sheets = output_root / spacing / "00_CONTACT_SHEETS"
            write_png(sheets / "boundary_Input_GT_Restore_C_D_S" / f"{case_id}.png", enlarge(stack(boundary_panels)))
            write_png(sheets / "mask_GT_Restore_C_D_S" / f"{case_id}.png", enlarge(stack(mask_panels)))
            write_png(sheets / "mask_on_MRI_GT_Restore_C_D_S" / f"{case_id}.png", enlarge(stack(overlay_panels)))
            manifest.append({"case_id": case_id, "spacing": spacing, "r1_slice_z": z, "native_slice_z": native_z, "seed": 17})

    groups_out = output_root / "08_CASE_GROUPS"
    for spacing in SPACINGS:
        copy_file(source_root / "04_CASE_GROUPS" / spacing / "all_cases.csv", groups_out / spacing / "all_cases.csv")
    failure_source = source_root / "04_CASE_GROUPS/failure_and_negative/all_cases.csv"
    copy_file(failure_source, groups_out / "failure_and_negative/all_cases.csv")
    with failure_source.open(newline="") as handle:
        failures = list(csv.DictReader(handle))
    for row in failures:
        spacing = f"{float(row['spacing_mm']):.1f}mm".replace(".", "p")
        case_id = row["case_id"]
        for sheet_type in ("boundary_Input_GT_Restore_C_D_S", "mask_GT_Restore_C_D_S", "mask_on_MRI_GT_Restore_C_D_S"):
            source = output_root / spacing / "00_CONTACT_SHEETS" / sheet_type / f"{case_id}.png"
            copy_file(source, groups_out / "failure_and_negative" / spacing / sheet_type / source.name)

    fig1_source = source_root / "01_FIG1_ALL_RAW/selected_case_hippocampus_104_existing_export"
    for image in fig1_source.glob("*.png"):
        copy_file(image, output_root / "09_FIG1_PNG" / image.name)

    manifest_path = output_root / "00_MANIFEST/render_index.csv"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with manifest_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(manifest[0]))
        writer.writeheader()
        writer.writerows(manifest)

    expected_minimum = 40 * 2 * 23
    png_count = sum(1 for _ in output_root.rglob("*.png"))
    if png_count < expected_minimum:
        raise RuntimeError(f"expected at least {expected_minimum} PNGs, found {png_count}")
    print(f"cases={len(cases)} spacing_case_sets={len(manifest)} pngs={png_count}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source_root", type=Path)
    parser.add_argument("output_root", type=Path)
    args = parser.parse_args()
    render(args.source_root.resolve(), args.output_root.resolve())
