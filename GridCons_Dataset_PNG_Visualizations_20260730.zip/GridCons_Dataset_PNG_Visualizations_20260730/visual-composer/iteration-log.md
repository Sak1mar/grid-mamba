# Iteration log

- 2026-07-30: replaced the raw-array handoff with a PNG-only dataset package after clarifying that the requested material was boundary visualization and segmentation masks.
- Exported all 40 cases at 4 mm and 5 mm, including individual method images, three contact-sheet types, training-before predictions, failure/negative groups, and Fig. 1 PNGs.
