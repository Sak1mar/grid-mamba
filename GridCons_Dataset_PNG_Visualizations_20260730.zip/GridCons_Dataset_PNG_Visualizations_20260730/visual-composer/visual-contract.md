# Visual contract

- Artifact: dataset-wide boundary and segmentation-mask PNG package.
- Target: paper figure composition and qualitative case screening.
- Core claim: show segmentation behavior for Restore, C, D, and GridCons S at 4 mm and 5 mm without cherry-picking the source pool.
- Reviewer question: what changes at each severity, how do method boundaries compare with GT, and where does S fail?
- Evidence layer: qualitative and limitation evidence.
- Source data: verified confirm-v2 seed-17 predictions for all 40 test cases.
- Panel map: boundary sheet `Input | GT | Restore | C | D | GridCons S`; mask sheets `GT | Restore | C | D | GridCons S`.
- Output: lossless RGB PNG.
- Traceability: manifest CSV, frozen case-group metrics, internal SHA-256 list.
- No-fabrication status: all masks are read directly from saved predictions.
